# sandbox/position_manager.py
"""
Position Manager - Handles position tracking and MTM calculations

Features:
- Real-time position tracking
- Mark-to-Market (MTM) P&L calculations
- Position netting (same symbol/exchange/product)
- Open position retrieval with live P&L
- Background MTM updates (configurable interval)
"""

import os
import sys
import time
from datetime import UTC, datetime, timedelta
from datetime import time as dt_time
from decimal import Decimal

import pytz
from sqlalchemy import update

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.sandbox_db import SandboxPositions, SandboxTrades, db_session, get_config
from database.token_db import get_symbol_info
from sandbox.fund_manager import FundManager
from sandbox.holdings_manager import HoldingsManager
from sandbox.position_locks import holds_position_lock, position_lock  # noqa: F401 (re-exported)
from sandbox.session_boundary import IST, last_session_expiry_utc
from services.market_data_service import get_market_data_service
from services.quotes_service import get_multiquotes, get_quotes
from utils.logging import get_logger

logger = get_logger(__name__)

# Maximum age (seconds) for WebSocket data to be considered fresh
WEBSOCKET_DATA_MAX_AGE = 5


def parse_expiry_from_symbol(symbol, exchange):
    """
    Parse expiry date from F&O symbol name.

    Supports formats like:
    - NIFTY09DEC2526000CE -> 09-Dec-2025
    - BANKNIFTY31JUL25FUT -> 31-Jul-2025
    - RELIANCE25DEC24FUT -> 25-Dec-2024

    Args:
        symbol: Trading symbol (e.g., NIFTY09DEC2526000CE)
        exchange: Exchange (NFO, BFO, MCX, CDS, etc.)

    Returns:
        datetime.date or None if not an F&O instrument or parsing fails
    """
    import re

    # Only process F&O exchanges
    fo_exchanges = ["NFO", "BFO", "MCX", "CDS", "BCD", "NCDEX", "CRYPTO"]
    if exchange not in fo_exchanges:
        return None

    # Pattern to extract date from symbol: DDMMMYY (e.g., 09DEC25, 31JUL25)
    # This pattern looks for 2 digits + 3 letters (month) + 2 digits (year)
    pattern = r"(\d{2})([A-Z]{3})(\d{2})"

    match = re.search(pattern, symbol)
    if not match:
        return None

    try:
        day = int(match.group(1))
        month_str = match.group(2)
        year_short = int(match.group(3))

        # Convert 2-digit year to 4-digit (assuming 20xx)
        year = 2000 + year_short

        # Parse month
        month_map = {
            "JAN": 1,
            "FEB": 2,
            "MAR": 3,
            "APR": 4,
            "MAY": 5,
            "JUN": 6,
            "JUL": 7,
            "AUG": 8,
            "SEP": 9,
            "OCT": 10,
            "NOV": 11,
            "DEC": 12,
        }

        month = month_map.get(month_str)
        if not month:
            return None

        # Create date object
        from datetime import date

        expiry_date = date(year, month, day)

        return expiry_date

    except (ValueError, KeyError) as e:
        logger.debug(f"Could not parse expiry from symbol {symbol}: {e}")
        return None


def get_expiry_from_database(symbol, exchange):
    """
    Get expiry date from SymToken database as fallback.

    Args:
        symbol: Trading symbol
        exchange: Exchange

    Returns:
        datetime.date or None
    """
    try:
        from datetime import datetime

        from database.symbol import SymToken

        sym_token = SymToken.query.filter_by(symbol=symbol, exchange=exchange).first()

        if sym_token and sym_token.expiry:
            # Expiry format in DB is typically "DD-MMM-YY" (e.g., "09-DEC-25")
            try:
                expiry_date = datetime.strptime(sym_token.expiry, "%d-%b-%y").date()
                return expiry_date
            except ValueError:
                try:
                    # Try alternative format "DD-MMM-YYYY"
                    expiry_date = datetime.strptime(sym_token.expiry, "%d-%b-%Y").date()
                    return expiry_date
                except ValueError:
                    logger.debug(f"Could not parse expiry '{sym_token.expiry}' for {symbol}")
                    return None

        return None

    except Exception as e:
        logger.debug(f"Error fetching expiry from DB for {symbol}: {e}")
        return None


def get_contract_expiry(symbol, exchange):
    """
    Get contract expiry date for a symbol.
    First tries to parse from symbol name, then falls back to database lookup.

    Args:
        symbol: Trading symbol
        exchange: Exchange

    Returns:
        datetime.date or None if not an F&O instrument
    """
    # First try parsing from symbol name (faster, no DB query)
    expiry = parse_expiry_from_symbol(symbol, exchange)

    if expiry:
        return expiry

    # Fallback to database lookup
    return get_expiry_from_database(symbol, exchange)


# Exchange close times (IST) used for expiry-day settlement. Distinct from the
# MIS square-off times in sandbox config (15:15 etc.), which are deliberately
# BEFORE close -- an expiring contract trades right up to the closing bell.
EXCHANGE_CLOSE_TIMES = {
    # 15:40, not 15:30: SEBI's Closing Auction Session (effective 2026-08-03)
    # pauses continuous trading in the cash segment at 15:15 and derives its
    # close by auction, while the derivatives segment keeps trading to roughly
    # 15:40. Settling an expiring contract at 15:30 would close it ten minutes
    # before it actually stops trading.
    "NFO": dt_time(15, 40),
    "BFO": dt_time(15, 40),
    "CDS": dt_time(17, 0),
    "BCD": dt_time(17, 0),
    "MCX": dt_time(23, 30),
    "NCDEX": dt_time(17, 0),
}
DEFAULT_CLOSE_TIME = dt_time(15, 30)


def claim_position_for_settlement(position, observed_quantity, *conditions) -> bool:
    """Take a position row for settlement, if it still holds ``observed_quantity``.

    Expiry settlement runs from the position book (every view), from the
    square-off job's minute sweep and from the start-up catch-up, each on
    positions it loaded itself. Two of them could settle the same position,
    each releasing its margin and booking its P&L. The claim is a no-op UPDATE
    matched on the quantity that was read: it starts this session's write
    transaction, so no other settler (or fill) can change the row until the
    caller commits, and a caller that loses finds the row already moved and
    leaves it alone. On success the position is re-read, so the settlement is
    computed from the row as it stands.

    Nothing is committed here; the caller commits the settlement, the funds
    change and the claim together, or rolls all of them back.

    Args:
        position: The SandboxPositions row to settle.
        observed_quantity: The quantity the caller decided to settle.
        *conditions: Further predicates the row must still meet, re-checked
            under the claim (the catch-up passes its session-boundary test).

    Returns:
        True if this caller now owns the row's settlement.
    """
    result = db_session.execute(
        update(SandboxPositions)
        .where(
            SandboxPositions.id == position.id,
            SandboxPositions.quantity == observed_quantity,
            *conditions,
        )
        # Assigning both columns to themselves changes nothing, not even the
        # updated_at the ORM would otherwise stamp.
        .values(
            quantity=SandboxPositions.quantity,
            updated_at=SandboxPositions.updated_at,
        ),
        execution_options={"synchronize_session": False},
    )
    if result.rowcount != 1:
        return False
    db_session.refresh(position)
    return True


def _notify_position_feed_closed(user_id, symbol, exchange):
    """Tell the WS engine a settled position no longer needs its MTM feed.

    Best-effort by design (event-driven MTM is an enhancement): failure to
    release a subscription costs a few stray ticks, never correctness.
    """
    try:
        from sandbox.websocket_execution_engine import peek_websocket_execution_engine

        # peek: settling a position must never create an engine.
        engine = peek_websocket_execution_engine()
        if engine is not None:
            engine.notify_position_closed(user_id, symbol, exchange)
    except Exception:
        logger.debug("Position feed release failed (non-fatal)", exc_info=True)


def is_contract_expired_now(expiry_date, exchange, now=None):
    """Return True when an F&O contract should be treated as expired right now.

    Timing is governed by the ``expiry_settlement_timing`` sandbox config:

      - ``expiry_day_close`` (default): expired from the exchange's closing
        time on expiry day onward -- matching when the real exchange stops
        trading the contract. During live market hours ON expiry day the
        position stays open and marked-to-market.
      - ``next_day``: legacy behaviour -- expired only from the day after.

    Any date strictly past expiry is expired under both modes, which is what
    makes the app-was-down-for-days catch-up work unchanged.

    Args:
        expiry_date: datetime.date of contract expiry (None returns False)
        exchange: Exchange code, used to pick the closing time
        now: Optional aware datetime for testing; defaults to IST now
    """
    if expiry_date is None:
        return False

    ist = pytz.timezone("Asia/Kolkata")
    now = now or datetime.now(ist)
    today = now.date()

    if today > expiry_date:
        return True
    if today < expiry_date:
        return False

    # Expiry day itself: settle from exchange close, if so configured.
    if get_config("expiry_settlement_timing", "expiry_day_close") != "expiry_day_close":
        return False
    close_time = EXCHANGE_CLOSE_TIMES.get(exchange, DEFAULT_CLOSE_TIME)
    return now.time() >= close_time


def get_expiry_settlement_price(position):
    """Settlement price for an expired position, per sandbox config.

    Options (``option_expiry_settlement`` config):
      - ``ltp`` (default): last stored LTP. Near expiry an option's LTP
        converges to intrinsic value, so this lands close to the real
        exchange settlement -- an ITM option keeps its value instead of
        being zeroed. Falls back to 0 when no LTP was ever stored.
      - ``zero``: legacy behaviour -- every option expires worthless.

    Futures: last stored LTP, falling back to average price (unchanged).
    """
    from decimal import Decimal

    symbol = position.symbol
    is_option = symbol.endswith("CE") or symbol.endswith("PE")
    ltp = Decimal(str(position.ltp)) if position.ltp else Decimal("0")

    if is_option:
        if get_config("option_expiry_settlement", "ltp") == "ltp" and ltp > 0:
            logger.info(f"Option {symbol} expired - settling at last LTP: {ltp}")
            return ltp
        logger.info(f"Option {symbol} expired - settling at 0 (worthless)")
        return Decimal("0")

    if ltp > 0:
        logger.info(f"Future {symbol} expired - settling at last LTP: {ltp}")
        return ltp
    avg = Decimal(str(position.average_price))
    logger.info(f"Future {symbol} expired - settling at avg price: {avg}")
    return avg


class PositionManager:
    """Manages positions and MTM calculations"""

    def __init__(self, user_id):
        self.user_id = user_id
        self.fund_manager = FundManager(user_id)

    def _get_contract_value(self, symbol: str, exchange: str) -> Decimal:
        """Look up contract_value multiplier for a symbol (e.g. 0.01 for ETHUSD.P).
        Returns 1.0 for normal equity instruments."""
        try:
            sym_info = get_symbol_info(symbol, exchange)
            if sym_info and sym_info.contract_value and float(sym_info.contract_value) != 1.0:
                return Decimal(str(sym_info.contract_value))
        except Exception:
            pass
        return Decimal("1.0")

    def _check_and_close_expired_positions(self, positions):
        """
        Check for expired F&O contracts and auto-close them.

        For expired contracts with qty > 0:
        - Options expire worthless (value = 0)
        - Futures settle at last LTP or average price
        - Releases blocked margin back to available balance
        - Marks position as closed (quantity = 0)

        Note: Does NOT filter out today's closed positions (qty=0).
        All positions passed to this function are shown (session filtering
        already happened in get_open_positions).

        Args:
            positions: List of SandboxPositions objects to check

        Returns:
            list: All positions (expired ones settled, others unchanged)
        """
        from datetime import date

        today = date.today()
        valid_positions = []
        expired_count = 0

        for position in positions:
            # Get contract expiry date
            expiry_date = get_contract_expiry(position.symbol, position.exchange)

            # If no expiry found (equity or couldn't parse), keep the position
            if expiry_date is None:
                valid_positions.append(position)
                continue

            # Check if contract has expired (timing per expiry_settlement_timing config)
            is_expired = is_contract_expired_now(expiry_date, position.exchange)

            # For already closed positions (qty=0), just keep them
            # These are today's closed trades - show them regardless of expiry
            if position.quantity == 0:
                valid_positions.append(position)
                continue

            # For open positions (qty != 0)
            if is_expired:
                # Contract has expired - auto-close it
                logger.info(
                    f"Expired contract detected: {position.symbol} "
                    f"(expiry: {expiry_date}, today: {today}, user: {position.user_id})"
                )

                try:
                    self._settle_expired_position(position)
                    expired_count += 1
                    # Add to valid_positions - it's now closed but still show it
                    valid_positions.append(position)
                except Exception as e:
                    logger.exception(f"Error settling expired position {position.symbol}: {e}")
                    valid_positions.append(position)
            else:
                # Contract is still valid
                valid_positions.append(position)

        if expired_count > 0:
            logger.info(f"Auto-closed {expired_count} expired contract(s) for user {self.user_id}")

        return valid_positions

    def _settle_expired_position(self, position):
        """
        Settle an expired position.

        Settlement prices:
        - Options: Expire at 0 (most expire worthless - conservative approach)
        - Futures: Use last stored LTP, or average price as fallback
        - Releases margin and updates realized P&L

        Args:
            position: SandboxPositions object to settle
        """
        from decimal import Decimal

        # Claim the row before any money moves; see claim_position_for_settlement.
        if not claim_position_for_settlement(position, position.quantity):
            db_session.rollback()
            logger.info(
                f"Expired position {position.symbol} was settled or changed elsewhere; "
                "leaving it to that settlement"
            )
            return

        symbol = position.symbol
        quantity = position.quantity
        avg_price = Decimal(str(position.average_price))
        margin_blocked = Decimal(str(position.margin_blocked or 0))

        # Settlement price per sandbox config (option_expiry_settlement):
        # options at last LTP (default, converges to intrinsic near expiry)
        # or zero (legacy); futures at last LTP with avg-price fallback.
        settlement_price = get_expiry_settlement_price(position)

        # Calculate realized P&L for this closure
        if quantity > 0:
            # Long position: P&L = (settlement - avg) * qty
            close_pnl = (settlement_price - avg_price) * Decimal(str(quantity))
        else:
            # Short position: P&L = (avg - settlement) * abs(qty)
            close_pnl = (avg_price - settlement_price) * Decimal(str(abs(quantity)))

        # Get accumulated realized P&L from position
        accumulated_realized = Decimal(str(position.accumulated_realized_pnl or 0))

        # Total realized P&L for this position
        total_realized_pnl = accumulated_realized + close_pnl

        logger.info(
            f"Settling expired {symbol}: qty={quantity}, avg={avg_price}, "
            f"settlement={settlement_price}, close_pnl={close_pnl}, "
            f"total_realized={total_realized_pnl}, margin_to_release={margin_blocked}"
        )

        # Release margin and update funds, in the same commit as the position:
        # releasing in one commit and closing in the next let a second settler
        # arriving in between release it again.
        try:
            self.fund_manager.stage_release_margin(
                amount=margin_blocked,
                realized_pnl=close_pnl,
                description=f"Expired contract settlement: {symbol}",
            )
        except Exception:
            db_session.rollback()
            logger.exception(
                f"Could not release margin for expired {symbol}; it stays open and is "
                "settled on the next pass"
            )
            return

        # Get expiry date for hiding the position
        expiry_date = get_contract_expiry(symbol, position.exchange)

        # Update position to closed state
        position.quantity = 0
        position.ltp = settlement_price
        position.pnl = total_realized_pnl
        position.accumulated_realized_pnl = total_realized_pnl
        position.margin_blocked = Decimal("0")

        db_session.commit()

        # Set updated_at to expiry date AFTER commit to bypass onupdate trigger
        # This hides expired contracts from current session
        if expiry_date:
            from sqlalchemy import text

            hide_date = datetime.combine(expiry_date, datetime.min.time())
            db_session.execute(
                text("UPDATE sandbox_positions SET updated_at = :hide_date WHERE id = :pos_id"),
                {"hide_date": hide_date, "pos_id": position.id},
            )
            db_session.commit()

        logger.info(f"Expired position {symbol} settled successfully for user {position.user_id}")

        # Release the position's MTM feed subscription (event-driven MTM);
        # the contract is dead, no further ticks are wanted.
        _notify_position_feed_closed(position.user_id, symbol, position.exchange)

    def get_open_positions(self, update_mtm=True):
        """
        Get all open positions for the user
        - After session expiry, only NRML positions carry forward
        - MIS and CNC positions are settled at session expiry

        Args:
            update_mtm: bool - Whether to update MTM with live prices

        Returns:
            tuple: (success: bool, response: dict, status_code: int)
        """
        try:
            import os
            from datetime import datetime

            # Get session expiry time from config (e.g., '03:00')
            session_expiry_str = os.getenv("SESSION_EXPIRY_TIME", "03:00")

            # updated_at is stored in the database's clock (UTC on SQLite),
            # so the boundary must be resolved in UTC too — see
            # last_session_expiry_utc().
            last_session_expiry = last_session_expiry_utc(session_expiry_str, datetime.now(IST))
            today = datetime.now(UTC).date()

            # Get all positions (including zero quantity ones from current session)
            positions_query = SandboxPositions.query.filter(
                SandboxPositions.user_id == self.user_id
            )

            # Check if we need to filter positions based on product type
            # If position was created before last session expiry and it's not NRML,
            # it should have been settled
            all_positions = positions_query.all()
            positions = []

            for position in all_positions:
                # CATCH-UP RESET: Check if today_realized_pnl needs to be reset
                # This handles the case where the scheduled reset job was missed
                # Reset if position has non-zero today_realized_pnl and was last updated before session boundary
                needs_pnl_reset = False
                if position.today_realized_pnl and position.today_realized_pnl != 0:
                    # Check if there's been a session boundary since the position was created/traded
                    # If position was last modified before today's session boundary, reset today_realized_pnl
                    position_date = position.updated_at.date() if position.updated_at else today
                    session_boundary_date = last_session_expiry.date()

                    # If position's date is before today's session boundary date, or
                    # if same date but position was updated before session expiry time
                    if position_date < session_boundary_date:
                        needs_pnl_reset = True
                    elif (
                        position_date == session_boundary_date
                        and position.updated_at < last_session_expiry
                    ):
                        needs_pnl_reset = True

                if needs_pnl_reset:
                    logger.info(
                        f"Catch-up reset: Resetting today_realized_pnl for {position.symbol} from {position.today_realized_pnl} to 0"
                    )
                    # Use raw SQL to avoid triggering onupdate=func.now() which would change updated_at
                    # If we used ORM commit(), updated_at would be set to NOW and old positions would
                    # pass the session filter, causing yesterday's closed positions to show today
                    from sqlalchemy import text

                    db_session.execute(
                        text(
                            "UPDATE sandbox_positions SET today_realized_pnl = 0 WHERE id = :pos_id"
                        ),
                        {"pos_id": position.id},
                    )
                    db_session.commit()
                    # Refresh from database instead of setting directly
                    # Setting position.today_realized_pnl = X would mark the ORM object as "dirty"
                    # which causes it to be committed later in _update_positions_mtm, triggering
                    # onupdate=func.now() and bringing old closed positions back into view
                    db_session.refresh(position)

                # If position was updated after last session expiry, include it
                if position.updated_at >= last_session_expiry:
                    # For OPEN positions (qty != 0): always include
                    if position.quantity != 0:
                        positions.append(position)
                    # For CLOSED positions (qty == 0): only include if actually traded today
                    # Check: today_realized_pnl != 0 (has P&L from today's trades)
                    # This prevents old closed positions with corrupted updated_at from showing
                    elif position.today_realized_pnl and position.today_realized_pnl != 0:
                        positions.append(position)
                    # Skip old closed positions with corrupted updated_at
                # If position was updated before last session expiry, only include NRML with non-zero quantity
                elif position.product == "NRML" and position.quantity != 0:
                    positions.append(position)
                # Skip MIS and CNC positions from previous session

            # Check for and auto-close expired F&O contracts
            # This handles NRML positions where the contract has expired
            positions = self._check_and_close_expired_positions(positions)

            if update_mtm:
                self._update_positions_mtm(positions)

            positions_list = []
            total_unrealized_pnl = Decimal("0.00")  # Only from open positions
            total_today_realized_pnl = Decimal("0.00")  # Today's realized P&L
            total_pnl_today = Decimal("0.00")  # Today's total (realized + unrealized)

            # Build contract_value lookup map for all positions using in-memory cache
            try:
                _cv_map = {}
                for p in positions:
                    sym_info = get_symbol_info(p.symbol, p.exchange)
                    if sym_info and sym_info.contract_value:
                        _cv_map[p.symbol] = float(sym_info.contract_value)
            except Exception:
                _cv_map = {}

            for position in positions:
                unrealized_pnl = Decimal(str(position.pnl))  # Current unrealized P&L from MTM
                today_realized = Decimal(str(position.today_realized_pnl or 0))

                # For open positions: total_pnl_today = today's realized + unrealized
                # For closed positions (qty=0): total_pnl_today = today's realized only
                if position.quantity != 0:
                    total_unrealized_pnl += unrealized_pnl
                    position_total_pnl_today = today_realized + unrealized_pnl
                else:
                    # Closed position - only today's realized matters
                    position_total_pnl_today = today_realized

                total_today_realized_pnl += today_realized
                total_pnl_today += position_total_pnl_today

                # Calculate P&L% based on total P&L (realized + unrealized) for the day
                # For open positions: % based on total investment
                # For closed positions (qty=0): 0% (like Zerodha - avg resets to 0, can't calculate)
                pos_cv = _cv_map.get(position.symbol, 1.0)
                pos_cv_dec = Decimal(str(pos_cv))
                if position.quantity != 0:
                    investment = abs(
                        Decimal(str(position.average_price))
                        * Decimal(str(position.quantity))
                        * pos_cv_dec
                    )
                    if investment > 0:
                        calculated_pnl_percent = (position_total_pnl_today / investment) * Decimal(
                            "100"
                        )
                    else:
                        calculated_pnl_percent = Decimal("0.00")
                    display_avg_price = float(position.average_price)
                else:
                    # Closed position - show 0% and avg=0 (like Zerodha)
                    calculated_pnl_percent = Decimal("0.00")
                    display_avg_price = 0.0  # Reset to 0 for display (like Zerodha)

                positions_list.append(
                    {
                        "symbol": position.symbol,
                        "exchange": position.exchange,
                        "product": position.product,
                        "quantity": position.quantity,
                        "average_price": display_avg_price,  # 0 for closed positions (like Zerodha)
                        "ltp": float(position.ltp) if position.ltp else 0.0,
                        "pnl": float(
                            position_total_pnl_today
                        ),  # Today's total P&L (realized + unrealized)
                        "pnlpercent": float(
                            calculated_pnl_percent
                        ),  # Fixed: use pnlpercent (no underscore) to match frontend
                        "unrealized_pnl": float(unrealized_pnl),  # Unrealized only (for reference)
                        "today_realized_pnl": float(today_realized),
                        "total_pnl_today": float(position_total_pnl_today),
                        "lot_size": pos_cv,  # contract_value multiplier (e.g. 0.01 for ETHUSD.P)
                    }
                )

            # Update fund unrealized P&L (only from open positions)
            # Closed position P&L is already in realized_pnl, so don't include it here
            if update_mtm:
                self.fund_manager.update_unrealized_pnl(total_unrealized_pnl)

            return (
                True,
                {
                    "status": "success",
                    "data": positions_list,
                    "total_pnl": float(
                        total_pnl_today
                    ),  # Today's total P&L (realized + unrealized)
                    "total_unrealized_pnl": float(total_unrealized_pnl),
                    "total_today_realized_pnl": float(total_today_realized_pnl),
                    "total_pnl_today": float(total_pnl_today),
                    "mode": "analyze",
                },
                200,
            )

        except Exception as e:
            logger.exception(f"Error getting positions for user {self.user_id}: {e}")
            return (
                False,
                {
                    "status": "error",
                    "message": f"Error getting positions: {str(e)}",
                    "mode": "analyze",
                },
                500,
            )

    def get_position_for_symbol(self, symbol, exchange, product):
        """Get position for a specific symbol"""
        try:
            position = SandboxPositions.query.filter_by(
                user_id=self.user_id, symbol=symbol, exchange=exchange, product=product
            ).first()

            if not position:
                return None

            # Update MTM
            self._update_single_position_mtm(position)

            return {
                "symbol": position.symbol,
                "exchange": position.exchange,
                "product": position.product,
                "quantity": position.quantity,
                "average_price": float(position.average_price),
                "ltp": float(position.ltp) if position.ltp else 0.0,
                "pnl": float(position.pnl),
                "pnl_percent": float(position.pnl_percent),
            }

        except Exception as e:
            logger.exception(f"Error getting position for {symbol}: {e}")
            return None

    def _update_positions_mtm(self, positions):
        """
        Update MTM for all positions with live quotes.
        Uses WebSocket data first, falls back to multiquotes API if WebSocket data is stale.
        """
        try:
            if not positions:
                return

            # Get unique symbols
            symbols_to_fetch = set()
            for position in positions:
                if position.quantity != 0:  # Only fetch for open positions
                    symbols_to_fetch.add((position.symbol, position.exchange))

            if not symbols_to_fetch:
                return

            symbols_list = list(symbols_to_fetch)

            # Try WebSocket data first (from MarketDataService)
            quote_cache = self._fetch_quotes_from_websocket(symbols_list)
            ws_count = len(quote_cache)

            # Find symbols that need fallback to multiquotes
            missing_symbols = [
                s for s in symbols_list if s not in quote_cache or quote_cache[s] is None
            ]

            if missing_symbols:
                # Fallback to multiquotes for missing symbols (no individual quote fallback to avoid rate limiting)
                logger.debug(
                    f"Positions MTM: {ws_count} from WebSocket, {len(missing_symbols)} need multiquotes fallback"
                )
                multiquotes_cache = self._fetch_quotes_batch(missing_symbols)
                quote_cache.update(multiquotes_cache)

                # Log any symbols that couldn't be fetched (don't fall back to individual quotes)
                still_missing = [
                    s for s in missing_symbols if s not in quote_cache or quote_cache[s] is None
                ]
                if still_missing:
                    logger.debug(
                        f"{len(still_missing)} symbols not available via multiquotes, waiting for WebSocket data"
                    )
            else:
                logger.debug(f"Positions MTM: All {ws_count} symbols from WebSocket (no API calls)")

            # Update MTM for each position
            for position in positions:
                # Skip MTM update for closed positions (quantity = 0)
                # They already have today's realized P&L stored in position.pnl
                if position.quantity == 0:
                    continue

                quote = quote_cache.get((position.symbol, position.exchange))
                if quote:
                    ltp = Decimal(str(quote.get("ltp", 0)))
                    if ltp > 0:
                        position.ltp = ltp

                        # Calculate current unrealized P&L for open position
                        cv = self._get_contract_value(position.symbol, position.exchange)
                        current_unrealized_pnl = self._calculate_position_pnl(
                            position.quantity, position.average_price, ltp, contract_value=cv
                        )

                        # pnl = unrealized only (broker standard - Zerodha Kite style)
                        # This is the primary P&L field for open positions
                        position.pnl = current_unrealized_pnl

                        position.pnl_percent = self._calculate_pnl_percent(
                            position.average_price, ltp, position.quantity
                        )

            db_session.commit()

        except Exception as e:
            db_session.rollback()
            logger.exception(f"Error updating positions MTM: {e}")

    def _update_single_position_mtm(self, position):
        """
        Update MTM for a single position.
        Uses WebSocket data first, falls back to REST API if unavailable.
        """
        try:
            # Skip MTM update for closed positions (quantity = 0)
            # They already have today's realized P&L stored from when position was closed
            if position.quantity == 0:
                return

            # Try WebSocket first
            ws_quotes = self._fetch_quotes_from_websocket([(position.symbol, position.exchange)])
            quote = ws_quotes.get((position.symbol, position.exchange))

            # Fallback to REST API if WebSocket data not available
            if not quote:
                quote = self._fetch_quote(position.symbol, position.exchange)

            if quote:
                ltp = Decimal(str(quote.get("ltp", 0)))
                if ltp > 0:
                    position.ltp = ltp

                    # Calculate current unrealized P&L for open position
                    cv = self._get_contract_value(position.symbol, position.exchange)
                    current_unrealized_pnl = self._calculate_position_pnl(
                        position.quantity, position.average_price, ltp, contract_value=cv
                    )

                    # pnl = unrealized only (broker standard - Zerodha Kite style)
                    position.pnl = current_unrealized_pnl

                    position.pnl_percent = self._calculate_pnl_percent(
                        position.average_price, ltp, position.quantity
                    )
                    db_session.commit()

        except Exception as e:
            db_session.rollback()
            logger.exception(f"Error updating position MTM for {position.symbol}: {e}")

    def _calculate_position_pnl(self, quantity, avg_price, ltp, contract_value=None):
        """Calculate P&L for a position, multiplied by contract_value (e.g. 0.01 for ETHUSD.P)."""
        try:
            quantity = Decimal(str(quantity))
            avg_price = Decimal(str(avg_price))
            ltp = Decimal(str(ltp))
            cv = Decimal(str(contract_value)) if contract_value is not None else Decimal("1.0")

            if quantity > 0:
                # Long position
                pnl = (ltp - avg_price) * quantity * cv
            else:
                # Short position
                pnl = (avg_price - ltp) * abs(quantity) * cv

            return pnl

        except Exception as e:
            logger.exception(f"Error calculating position P&L: {e}")
            return Decimal("0.00")

    def _calculate_pnl_percent(self, avg_price, ltp, quantity):
        """Calculate P&L percentage"""
        try:
            avg_price = Decimal(str(avg_price))
            ltp = Decimal(str(ltp))

            if avg_price <= 0:
                return Decimal("0.00")

            if quantity > 0:
                # Long position
                pnl_percent = ((ltp - avg_price) / avg_price) * Decimal("100")
            else:
                # Short position
                pnl_percent = ((avg_price - ltp) / avg_price) * Decimal("100")

            return pnl_percent

        except Exception as e:
            logger.exception(f"Error calculating P&L percent: {e}")
            return Decimal("0.00")

    def _fetch_quotes_from_websocket(self, symbols_list):
        """
        Fetch LTP from WebSocket (MarketDataService) for multiple symbols.
        Returns dict mapping (symbol, exchange) to quote data.
        Only returns data that is fresh (within WEBSOCKET_DATA_MAX_AGE seconds).
        """
        quote_cache = {}

        if not symbols_list:
            return quote_cache

        try:
            market_data_service = get_market_data_service()
            current_time = time.time()

            for symbol, exchange in symbols_list:
                # Get all cached data from MarketDataService
                data = market_data_service.get_all_data(symbol, exchange)

                if data:
                    # Check if data is fresh using last_update timestamp
                    last_update = data.get("last_update", 0)
                    age = current_time - last_update

                    if age <= WEBSOCKET_DATA_MAX_AGE:
                        # Get LTP from the ltp sub-dict
                        ltp_data = data.get("ltp", {})
                        ltp = ltp_data.get("value") if isinstance(ltp_data, dict) else None

                        if ltp and ltp > 0:
                            quote_cache[(symbol, exchange)] = {"ltp": ltp}
                    else:
                        logger.debug(f"WebSocket data stale for {symbol} (age: {age:.1f}s)")

            return quote_cache

        except Exception as e:
            logger.debug(f"Error fetching from WebSocket: {e}")
            return quote_cache

    def _fetch_quote(self, symbol, exchange):
        """Fetch real-time quote for a symbol using API key"""
        try:
            # Get any user's API key for fetching quotes
            from database.auth_db import ApiKeys, decrypt_token

            api_key_obj = ApiKeys.query.first()

            if not api_key_obj:
                logger.warning("No API keys found for fetching quotes")
                return None

            # Decrypt the API key
            api_key = decrypt_token(api_key_obj.api_key_encrypted)

            # Use quotes service with API key authentication
            success, response, status_code = get_quotes(
                symbol=symbol, exchange=exchange, api_key=api_key
            )

            if success and "data" in response:
                return response["data"]
            else:
                logger.warning(
                    f"Failed to fetch quote for {symbol}: {response.get('message', 'Unknown error')}"
                )
                return None

        except Exception as e:
            logger.exception(f"Error fetching quote for {symbol}: {e}")
            return None

    def _fetch_quotes_batch(self, symbols_list):
        """
        Fetch quotes for multiple symbols in a single API call using multiquotes.
        Returns dict mapping (symbol, exchange) to quote data.
        Returns empty dict if multiquotes fails completely.
        """
        quote_cache = {}

        if not symbols_list:
            return quote_cache

        try:
            # Get any user's API key for fetching quotes
            from database.auth_db import ApiKeys, decrypt_token

            api_key_obj = ApiKeys.query.first()

            if not api_key_obj:
                logger.debug("No API keys found for fetching multiquotes")
                return quote_cache

            # Decrypt the API key
            api_key = decrypt_token(api_key_obj.api_key_encrypted)

            # Prepare symbols list for multiquotes API
            symbols_payload = [
                {"symbol": symbol, "exchange": exchange} for symbol, exchange in symbols_list
            ]

            # Use multiquotes service
            success, response, status_code = get_multiquotes(
                symbols=symbols_payload, api_key=api_key
            )

            if success and "results" in response:
                results = response["results"]
                successful_count = 0

                for result in results:
                    symbol = result.get("symbol")
                    exchange = result.get("exchange")

                    # Check if this result has data or error
                    if "data" in result and result["data"]:
                        quote_data = result["data"]
                        quote_cache[(symbol, exchange)] = quote_data
                        logger.debug(f"Multiquotes: {symbol} LTP={quote_data.get('ltp', 0)}")
                        successful_count += 1
                    elif "error" in result:
                        logger.debug(f"Multiquotes error for {symbol}: {result['error']}")

                logger.info(
                    f"Positions MTM: Multiquotes fetched {successful_count}/{len(symbols_list)} symbols"
                )
            else:
                logger.debug(f"Multiquotes failed: {response.get('message', 'Unknown error')}")

        except Exception as e:
            logger.debug(f"Exception in multiquotes fetch: {str(e)}")

        return quote_cache

    # Held across the read and the closing order, so a second closer (the
    # square-off job, a smart order, the user) sees this close before deciding.
    @holds_position_lock(
        lambda self, symbol, exchange, product: (self.user_id, exchange, symbol, product)
    )
    def close_position(self, symbol, exchange, product):
        """
        Close a position (square-off)
        Creates a reverse order to close the position
        """
        try:
            # populate_existing: the square-off sweep calls this while holding
            # the positions it loaded, and the session would hand that copy
            # back, however stale, instead of the quantity as it is now.
            position = (
                SandboxPositions.query.filter_by(
                    user_id=self.user_id, symbol=symbol, exchange=exchange, product=product
                )
                .populate_existing()
                .first()
            )

            if not position:
                return (
                    False,
                    {
                        "status": "error",
                        "message": f"No open position found for {symbol}",
                        "mode": "analyze",
                    },
                    404,
                )

            # Determine action (opposite of current position)
            action = "SELL" if position.quantity > 0 else "BUY"
            quantity = abs(position.quantity)

            # Create market order to close position
            from sandbox.order_manager import OrderManager

            order_manager = OrderManager(self.user_id)

            order_data = {
                "symbol": symbol,
                "exchange": exchange,
                "action": action,
                "quantity": quantity,
                "price_type": "MARKET",
                "product": product,
                "strategy": "AUTO_SQUARE_OFF",
            }

            success, response, status_code = order_manager.place_order(order_data)

            if success:
                logger.info(f"Position close order placed: {symbol} {action} {quantity}")
                return (
                    True,
                    {
                        "status": "success",
                        "message": f"Position close order placed for {symbol}",
                        "orderid": response.get("orderid"),
                        "mode": "analyze",
                    },
                    200,
                )
            else:
                return False, response, status_code

        except Exception as e:
            logger.exception(f"Error closing position {symbol}: {e}")
            return (
                False,
                {
                    "status": "error",
                    "message": f"Error closing position: {str(e)}",
                    "mode": "analyze",
                },
                500,
            )

    def get_tradebook(self):
        """Get all executed trades for the user for current session only"""
        try:
            import os
            from datetime import datetime, time, timedelta

            # Get session expiry time from config (e.g., '03:00')
            session_expiry_str = os.getenv("SESSION_EXPIRY_TIME", "03:00")
            expiry_hour, expiry_minute = map(int, session_expiry_str.split(":"))

            # Get current time
            now = datetime.now()
            today = now.date()

            # Calculate session start time
            # If current time is before session expiry (e.g., before 3 AM),
            # session started yesterday at expiry time
            session_expiry_time = time(expiry_hour, expiry_minute)

            if now.time() < session_expiry_time:
                # We're in the early morning before session expiry
                # Session started yesterday at expiry time
                session_start = datetime.combine(today - timedelta(days=1), session_expiry_time)
            else:
                # We're after session expiry time
                # Session started today at expiry time
                session_start = datetime.combine(today, session_expiry_time)

            trades = (
                SandboxTrades.query.filter(
                    SandboxTrades.user_id == self.user_id,
                    SandboxTrades.trade_timestamp >= session_start,
                )
                .order_by(SandboxTrades.trade_timestamp.desc())
                .all()
            )

            tradebook = []
            for trade in trades:
                price = float(trade.price)
                quantity = abs(trade.quantity)  # Use absolute value for trade_value calculation
                trade_value = round(price * quantity, 2)  # Round to 2 decimal places

                tradebook.append(
                    {
                        "tradeid": trade.tradeid,
                        "orderid": trade.orderid,
                        "symbol": trade.symbol,
                        "exchange": trade.exchange,
                        "action": trade.action,
                        "quantity": trade.quantity,
                        "average_price": round(price, 2),  # Round to 2 decimal places
                        "price": round(price, 2),  # Round to 2 decimal places
                        "trade_value": trade_value,  # Trade value already rounded above
                        "product": trade.product,
                        "strategy": trade.strategy or "",
                        "timestamp": trade.trade_timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                    }
                )

            return True, {"status": "success", "data": tradebook, "mode": "analyze"}, 200

        except Exception as e:
            logger.exception(f"Error getting tradebook: {e}")
            return (
                False,
                {
                    "status": "error",
                    "message": f"Error getting tradebook: {str(e)}",
                    "mode": "analyze",
                },
                500,
            )

    def process_session_settlement(self):
        """
        Process session expiry settlement (at SESSION_EXPIRY_TIME):
        1. Auto square-off MIS positions
        2. Move CNC positions to holdings (T+1 settlement)
        3. Keep NRML positions as carry forward

        This should be called at session expiry time (e.g., 3:00 AM IST)
        """
        try:
            import os
            from datetime import date, datetime

            from database import db
            from database.sandbox_db import SandboxHoldings

            # Get session expiry time from config
            session_expiry_str = os.getenv("SESSION_EXPIRY_TIME", "03:00")
            logger.info(f"Processing session settlement at {session_expiry_str}")

            # Get all open positions
            positions = SandboxPositions.query.filter_by(user_id=self.user_id).all()

            for position in positions:
                if position.quantity == 0:
                    continue  # Skip closed positions

                if position.product == "MIS":
                    # Auto square-off MIS positions at market close
                    # Create a reverse order to square off
                    quantity = abs(position.quantity)

                    # Use last traded price or average price for square-off
                    float(position.average_price) if position.average_price else 0

                    # Update position to closed
                    position.quantity = 0
                    position.pnl = float(position.realized_pnl)
                    db.session.commit()

                    logger.info(f"Auto squared-off MIS position: {position.symbol} qty: {quantity}")

                elif position.product == "CNC" and position.quantity > 0:
                    # Move CNC buy positions to holdings (T+1 settlement)
                    # CNC sell positions are already closed (no short delivery allowed)

                    # Check if holdings exist
                    holdings = SandboxHoldings.query.filter_by(
                        user_id=self.user_id, symbol=position.symbol, exchange=position.exchange
                    ).first()

                    if holdings:
                        # Update existing holdings. Compute the weighted average
                        # BEFORE mutating quantity -- the previous version
                        # incremented quantity first, which double-counted the
                        # new shares in the denominator and applied the old
                        # average to the inflated total, skewing the cost basis
                        # low on every repeat settlement of the same symbol
                        # (100@100 + 100@110 gave 103.33 instead of 105).
                        old_quantity = holdings.quantity
                        new_quantity = old_quantity + position.quantity
                        holdings.average_price = (
                            holdings.average_price * old_quantity
                            + position.average_price * position.quantity
                        ) / new_quantity
                        holdings.quantity = new_quantity
                    else:
                        # Create new holdings
                        holdings = SandboxHoldings(
                            user_id=self.user_id,
                            symbol=position.symbol,
                            exchange=position.exchange,
                            quantity=position.quantity,
                            average_price=position.average_price,
                            settlement_date=date.today(),
                        )
                        db.session.add(holdings)

                    # Clear the CNC position
                    position.quantity = 0
                    position.pnl = float(position.realized_pnl)
                    db.session.commit()

                    logger.debug(
                        f"Moved CNC position to holdings: {position.symbol} qty: {position.quantity}"
                    )

                # NRML positions remain as-is (carry forward)

            return (
                True,
                {"status": "success", "message": "Session settlement completed", "mode": "analyze"},
                200,
            )

        except Exception as e:
            logger.exception(f"Error in EOD settlement: {e}")
            db.session.rollback()
            return (
                False,
                {
                    "status": "error",
                    "message": f"Error in EOD settlement: {str(e)}",
                    "mode": "analyze",
                },
                500,
            )


def update_all_positions_mtm():
    """Background task to update MTM for all positions"""
    try:
        # Skip MTM updates when market is closed (prices won't change)
        from database.market_calendar_db import is_market_open

        if not is_market_open():
            logger.debug("Market closed - skipping MTM update")
            return

        # Get all unique users with positions
        positions = SandboxPositions.query.all()

        if not positions:
            logger.debug("No positions to update")
            return

        users = {p.user_id for p in positions}
        logger.info(f"Updating MTM for {len(positions)} positions across {len(users)} users")

        for user_id in users:
            pm = PositionManager(user_id)
            pm.get_open_positions(update_mtm=True)

        logger.info("MTM update completed")

    except Exception as e:
        logger.exception(f"Error updating MTM for all positions: {e}")


def process_all_users_settlement():
    """
    Process T+1 settlement for all users at midnight (00:00 IST)
    - Moves CNC positions to holdings
    - Auto squares-off any remaining MIS positions
    - NRML positions carry forward
    """
    try:
        # Get all unique users with positions
        positions = SandboxPositions.query.all()

        if not positions:
            logger.info("No positions to settle")
            return

        users = {p.user_id for p in positions}
        logger.debug(f"Processing T+1 settlement for {len(users)} users at midnight")

        for user_id in users:
            try:
                holdings_manager = HoldingsManager(user_id)
                success, message = holdings_manager.process_t1_settlement()

                if success:
                    logger.debug(f"Settlement completed for user {user_id}")
                else:
                    logger.error(f"Settlement failed for user {user_id}: {message}")

            except Exception as e:
                logger.exception(f"Error in settlement for user {user_id}: {e}")
                continue

        logger.debug("T+1 settlement completed for all users")

    except Exception as e:
        logger.exception(f"Error in T+1 settlement process: {e}")


def cleanup_expired_contracts():
    """
    Clean up expired F&O contracts from sandbox positions.
    Runs on startup when analyzer mode is enabled.

    This handles cases where:
    - App was stopped for several days
    - User hasn't logged in for a while
    - Contracts expired while app was not running

    Expired contracts are settled with:
    - Margin released back to available balance
    - P&L calculated and added to realized P&L
    - Position quantity set to 0
    """
    from datetime import date
    from decimal import Decimal

    from sandbox.fund_manager import FundManager

    try:
        # Find all open positions in F&O exchanges
        fo_exchanges = ["NFO", "BFO", "MCX", "CDS", "BCD", "NCDEX", "CRYPTO"]

        expired_positions = []

        # Query all open positions in F&O exchanges
        all_fo_positions = SandboxPositions.query.filter(
            SandboxPositions.exchange.in_(fo_exchanges), SandboxPositions.quantity != 0
        ).all()

        if not all_fo_positions:
            logger.debug("No open F&O positions to check for expiry")
            return

        logger.debug(f"Checking {len(all_fo_positions)} F&O positions for expired contracts")

        # Check each position for expiry (timing per expiry_settlement_timing config)
        for position in all_fo_positions:
            expiry_date = get_contract_expiry(position.symbol, position.exchange)

            if expiry_date and is_contract_expired_now(expiry_date, position.exchange):
                expired_positions.append(position)
                logger.debug(
                    f"Found expired contract: {position.symbol} "
                    f"(expiry: {expiry_date}, user: {position.user_id})"
                )

        if not expired_positions:
            logger.debug("No expired F&O contracts found")
            return

        logger.debug(f"Found {len(expired_positions)} expired contracts to clean up")

        # Group by user for efficient processing
        user_positions = {}
        for pos in expired_positions:
            if pos.user_id not in user_positions:
                user_positions[pos.user_id] = []
            user_positions[pos.user_id].append(pos)

        # Process each user's expired positions
        for user_id, positions in user_positions.items():
            try:
                fund_manager = FundManager(user_id)

                for position in positions:
                    try:
                        # Claim the row before any money moves; a view of the
                        # position book or another sweep may be settling it.
                        if not claim_position_for_settlement(position, position.quantity):
                            db_session.rollback()
                            logger.info(
                                f"Expired contract {position.symbol} was settled or changed "
                                "elsewhere; skipping"
                            )
                            continue

                        symbol = position.symbol
                        quantity = position.quantity
                        avg_price = Decimal(str(position.average_price))
                        margin_blocked = Decimal(str(position.margin_blocked or 0))

                        # Settlement price per sandbox config -- same helper as
                        # the on-view settlement path, so both paths agree.
                        settlement_price = get_expiry_settlement_price(position)

                        # Calculate realized P&L
                        if quantity > 0:
                            close_pnl = (settlement_price - avg_price) * Decimal(str(quantity))
                        else:
                            close_pnl = (avg_price - settlement_price) * Decimal(str(abs(quantity)))

                        accumulated_realized = Decimal(str(position.accumulated_realized_pnl or 0))
                        total_realized_pnl = accumulated_realized + close_pnl

                        logger.info(
                            f"Settling expired {symbol}: qty={quantity}, "
                            f"settlement_price={settlement_price}, close_pnl={close_pnl}, "
                            f"margin_to_release={margin_blocked}"
                        )

                        # Release margin and update funds, committed with the
                        # position below rather than on its own.
                        fund_manager.stage_release_margin(
                            amount=margin_blocked,
                            realized_pnl=close_pnl,
                            description=f"Expired contract cleanup: {symbol}",
                        )

                        # Update position to closed state
                        position.quantity = 0
                        position.ltp = settlement_price
                        position.pnl = total_realized_pnl
                        position.accumulated_realized_pnl = total_realized_pnl
                        position.margin_blocked = Decimal("0")

                        db_session.commit()

                        # Set updated_at to expiry date AFTER commit to bypass onupdate trigger
                        # This hides expired contracts from current session.
                        # Recompute THIS position's expiry -- the loop variable
                        # from the scan above holds the LAST scanned position's
                        # expiry, which mis-dated the hide for multi-expiry
                        # cleanups.
                        from sqlalchemy import text

                        pos_expiry = get_contract_expiry(position.symbol, position.exchange)
                        hide_date = datetime.combine(
                            pos_expiry or datetime.now().date(), datetime.min.time()
                        )
                        db_session.execute(
                            text(
                                "UPDATE sandbox_positions SET updated_at = :hide_date WHERE id = :pos_id"
                            ),
                            {"hide_date": hide_date, "pos_id": position.id},
                        )
                        db_session.commit()

                        logger.info(f"Expired contract {symbol} cleaned up for user {user_id}")
                        _notify_position_feed_closed(user_id, symbol, position.exchange)

                    except Exception as e:
                        db_session.rollback()
                        logger.exception(
                            f"Error cleaning up expired position {position.symbol}: {e}"
                        )
                        continue

            except Exception as e:
                logger.exception(f"Error processing expired contracts for user {user_id}: {e}")
                continue

        logger.info(
            f"Expired contract cleanup completed: {len(expired_positions)} contracts processed"
        )

    except Exception as e:
        logger.exception(f"Error in expired contract cleanup: {e}")


def catchup_missed_settlements():
    """
    Catch-up settlement for positions that should have been settled while app was stopped.
    Runs on startup when analyzer mode is enabled.

    This function handles:
    1. Expired F&O contracts - settles them and releases margin
    2. CNC positions older than 1 day - settles them to holdings
    """
    try:
        # First, clean up expired F&O contracts
        # This is important to do first so users don't see stale contracts
        logger.debug("Running expired contract cleanup...")
        cleanup_expired_contracts()

        # Then handle CNC T+1 settlement
        ist = pytz.timezone("Asia/Kolkata")
        today = datetime.now(ist).date()
        cutoff_time = datetime.combine(today, datetime.min.time())

        cnc_positions = (
            SandboxPositions.query.filter_by(product="CNC")
            .filter(SandboxPositions.quantity != 0, SandboxPositions.created_at < cutoff_time)
            .all()
        )

        if not cnc_positions:
            logger.debug("No CNC positions for catch-up settlement")
            return

        logger.info(f"Found {len(cnc_positions)} CNC positions that need catch-up settlement")

        users = {p.user_id for p in cnc_positions}

        for user_id in users:
            try:
                holdings_manager = HoldingsManager(user_id)
                success, message = holdings_manager.process_t1_settlement()

                if success:
                    logger.info(f"Catch-up settlement completed for user {user_id}")
                else:
                    logger.error(f"Catch-up settlement failed for user {user_id}: {message}")

            except Exception as e:
                logger.exception(f"Error in catch-up settlement for user {user_id}: {e}")
                continue

        logger.info("Catch-up settlement process completed")

    except Exception as e:
        logger.exception(f"Error in catch-up settlement: {e}")


if __name__ == "__main__":
    """Run MTM updater in standalone mode"""
    logger.info("Starting Sandbox MTM Updater")

    from database.sandbox_db import init_db

    init_db()

    mtm_interval = int(get_config("mtm_update_interval", "5"))

    if mtm_interval == 0:
        logger.info("Automatic MTM updates disabled (interval = 0)")
        exit(0)

    logger.info(f"MTM update interval: {mtm_interval} seconds")

    try:
        while True:
            update_all_positions_mtm()
            time.sleep(mtm_interval)
    except KeyboardInterrupt:
        logger.info("MTM updater stopped by user")
    except Exception as e:
        logger.exception(f"MTM updater error: {e}")
