"""Persistence for the AI Brain: journal, positions, model versions, audit trail.

Its own SQLite file (``BRAIN_DATABASE_URL``, default ``sqlite:///db/brain.db``), so
journaling never contends with the main database for its single write lock.
The engine comes from ``create_db_engine`` (NullPool on SQLite, CLAUDE.md).

Every function opens a short-lived session and returns plain dicts. The Brain's
loop runs on a background thread, where a request-scoped session would leak, so
nothing here depends on ``teardown_appcontext``.

The exit claim (``position_claim_exit``) is a single compare-and-set UPDATE:
the marker is written *before* any order is dispatched and a refused dispatch
releases it, which is the order-path invariant in CLAUDE.md.
"""

from __future__ import annotations

import json
import os
import time
from contextlib import contextmanager
from typing import Any

from sqlalchemy import (
    Boolean,
    Column,
    Float,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
    text,
)
from sqlalchemy.orm import declarative_base, sessionmaker

from database.engine_factory import create_db_engine
from utils.logging import get_logger

logger = get_logger(__name__)

BRAIN_DATABASE_URL = os.getenv("BRAIN_DATABASE_URL", "sqlite:///db/brain.db")
engine = create_db_engine(BRAIN_DATABASE_URL)
_Session = sessionmaker(autocommit=False, autoflush=False, bind=engine, expire_on_commit=False)
Base = declarative_base()


class BrainState(Base):
    __tablename__ = "brain_state"
    key = Column(String(64), primary_key=True)
    value = Column(Text, nullable=False, default="null")
    updated_at = Column(Float, nullable=False, default=0.0)


class BrainSignal(Base):
    __tablename__ = "brain_signal"
    id = Column(Integer, primary_key=True, index=True)
    ts = Column(Float, nullable=False, index=True)
    bar_ts = Column(Float, nullable=False, index=True)  # completed bar the signal was computed on
    underlying = Column(String(32), nullable=False, index=True)
    side = Column(String(5), nullable=False)
    regime = Column(String(12), nullable=False, default="")
    score = Column(Float, default=0.0)
    agree = Column(Integer, default=0)
    prob = Column(Float, default=0.0)
    prob_prior = Column(Float, default=0.0)
    ev_r = Column(Float, default=0.0)
    rr = Column(Float, default=0.0)
    sigma_h = Column(Float, default=0.0)
    k_stop = Column(Float, default=0.0)
    k_target = Column(Float, default=0.0)
    horizon_bars = Column(Integer, default=12)
    entry_spot = Column(Float, default=0.0)
    passed = Column(Boolean, default=False, index=True)
    reject = Column(String(200), default="")
    status = Column(String(12), default="OBSERVED", index=True)  # OBSERVED|SUGGESTED|TRADED|BLOCKED
    gate_reasons = Column(Text, default="")
    features = Column(Text, default="{}")
    votes = Column(Text, default="{}")
    reasons = Column(Text, default="[]")
    model_version = Column(Integer, default=0)
    label_outcome = Column(Integer, nullable=True)
    label_r = Column(Float, nullable=True)
    label_bars = Column(Integer, nullable=True)
    labeled_at = Column(Float, nullable=True)
    position_id = Column(Integer, nullable=True)
    # Moneyness-band learning (ATM / ITM / OTM). A signal is journalled once per
    # band with its own option leg, so the labeler can score each band's premium
    # path and the band picker can learn which moneyness actually pays.
    band = Column(String(8), default="")  # ITM | ATM | OTM ("" = band-less legacy row)
    symbol = Column(String(64), default="")  # the option leg this band would trade
    dte = Column(Float, default=0.0)  # days to expiry at signal time
    gamma = Column(Float, default=0.0)  # the leg's Black-76 gamma
    leg_delta = Column(Float, default=0.0)  # the leg's |delta|
    leg_entry = Column(Float, default=0.0)  # planned premium levels for the label barrier
    leg_stop = Column(Float, default=0.0)
    leg_target = Column(Float, default=0.0)
    # The leg's own premium-path barrier result (what that band would have
    # earned). Kept beside label_outcome/label_r — which stay the *underlying*'s
    # barrier on every row, so model training semantics are unchanged.
    leg_label_outcome = Column(Integer, nullable=True)
    leg_label_r = Column(Float, nullable=True)
    leg_label_bars = Column(Integer, nullable=True)
    # Which path produced the signal: "Fusion" (the 14-engine brain) or a
    # sidecar's own name. The live scan writes this while the model did not
    # have the column, so every live scan died on the write.
    path = Column(String(16), default="Fusion", index=True)
    # long (buy premium) or short (sell a credit spread). Scoring a short row
    # on the underlying's long-option payoff was worth ~2R for a trade whose
    # own reward-to-risk is ~0.2R; with the marker persisted, the learner can
    # recompute the spread's own R instead.
    position_type = Column(String(8), default="long")

    # A signal is one row per (underlying, side, completed bar, band): bands
    # journal separately, but the same band must never journal twice. The
    # bootstrap replay used to duplicate its entire journal on every re-run
    # because nothing enforced this. Backed by a real UNIQUE index via
    # _migrate_brain_signal_unique_index().
    __table_args__ = (
        UniqueConstraint("underlying", "side", "bar_ts", "band", name="uq_brain_signal_key"),
    )


class BrainPosition(Base):
    __tablename__ = "brain_position"
    id = Column(Integer, primary_key=True, index=True)
    signal_id = Column(Integer, nullable=True, index=True)
    underlying = Column(String(32), nullable=False)
    symbol = Column(String(64), nullable=False)
    exchange = Column(String(10), nullable=False)
    option_type = Column(String(2), default="")
    strike = Column(Float, default=0.0)
    expiry = Column(String(12), default="")
    lots = Column(Integer, default=0)
    qty = Column(Integer, nullable=False)
    lot_size = Column(Integer, default=1)
    mode = Column(
        String(8), nullable=False
    )  # sandbox | live: fixed at entry, never re-read from the global toggle
    # Which broker (and account) took the live entry, recorded at entry so every
    # later order for this position is held to the broker that holds it. Empty
    # for sandbox rows, and for live rows whose session could not be read at
    # entry (those orders are refused by order_dispatch, fail-safe).
    broker = Column(String(50), default="")
    broker_account = Column(String(255), nullable=True)
    state = Column(
        String(8), nullable=False, default="OPEN", index=True
    )  # PENDING | OPEN | CLOSING | CLOSED
    entry_price = Column(Float, default=0.0)
    entry_order_id = Column(String(64), default="")
    entry_ts = Column(Float, default=0.0)
    entry_bar_ts = Column(
        Float, default=0.0
    )  # bar_ts of the bar during which the position was entered
    initial_stop = Column(Float, nullable=True)
    stop_price = Column(Float, nullable=True)
    target_price = Column(Float, nullable=True)
    trail_trigger = Column(Float, default=0.0)  # premium points of profit before trailing starts
    trail_gap = Column(Float, default=0.0)  # premium points kept behind the peak
    highest_price = Column(Float, nullable=True)
    lowest_price = Column(Float, nullable=True)
    risk_per_unit = Column(Float, default=0.0)
    deadline_ts = Column(Float, default=0.0)  # time stop
    exit_kind = Column(String(24), nullable=True)  # claim marker, written BEFORE dispatch
    exit_reason = Column(String(120), nullable=True)
    exit_price = Column(Float, nullable=True)
    exit_order_id = Column(String(64), nullable=True)
    exit_ts = Column(Float, nullable=True)
    pnl = Column(Float, nullable=True)
    r_multiple = Column(Float, nullable=True)
    # Cost attribution (populated at close; NULL for positions closed before
    # this field was added). Values are per-trade rupees, never negative.
    gross_pnl = Column(Float, nullable=True)  # raw mark-out, kept for reference
    brokerage = Column(Float, default=0.0)
    stt = Column(Float, default=0.0)
    exchange_txn = Column(Float, default=0.0)
    sebi_charges = Column(Float, default=0.0)
    stamp_duty = Column(Float, default=0.0)
    gst = Column(Float, default=0.0)
    total_cost = Column(Float, default=0.0)
    net_pnl = Column(Float, nullable=True)  # gross_pnl − total_cost
    mfe = Column(Float, default=0.0)
    mae = Column(Float, default=0.0)
    model_version = Column(Integer, default=0)
    note = Column(Text, default="")
    side = Column(String(8), default="")  # LONG | SHORT, derived from option_type at entry
    band = Column(String(8), default="")  # ITM | ATM | OTM, moneyness band of the traded leg
    # Credit spreads (short premium). ``position_type`` is "long" (buy one
    # option) or "short" (sell one option, buy a further out-of-the-money one
    # as protection). For a short position the row's ``symbol`` is the leg that
    # was SOLD and the hedge leg is carried in the columns below; the row's
    # prices are the SPREAD's prices, not the sold leg's, so the risk core's
    # short-side arithmetic reads them correctly.
    position_type = Column(String(8), default="long")  # long | short
    hedge_symbol = Column(String(64), default="")
    hedge_exchange = Column(String(10), default="")
    hedge_option_type = Column(String(2), default="")
    hedge_strike = Column(Float, default=0.0)
    hedge_qty = Column(Integer, default=0)
    hedge_entry_price = Column(Float, default=0.0)
    spread_credit = Column(Float, default=0.0)
    spread_width = Column(Float, default=0.0)


class BrainModel(Base):
    __tablename__ = "brain_model"
    id = Column(Integer, primary_key=True, index=True)
    created_at = Column(Float, nullable=False)
    role = Column(String(12), nullable=False, index=True)  # champion | challenger | retired
    params = Column(Text, default="{}")
    model = Column(Text, default="{}")
    metrics = Column(Text, default="{}")
    note = Column(Text, default="")


class BrainEval(Base):
    __tablename__ = "brain_eval"
    day = Column(String(10), primary_key=True)
    data = Column(Text, default="{}")
    updated_at = Column(Float, default=0.0)


class BrainPpaCandidate(Base):
    """One premium-PA decision point: the features PPA saw and, later, what happened.

    Written for every completed 5m bar and both sides (CE/PE), whether or not PPA
    traded, so a model can learn from the skipped setups as well as the taken ones.
    ``plan`` holds what is needed to re-derive the stop/target at label time.
    """

    __tablename__ = "brain_ppa_candidate"
    __table_args__ = (
        UniqueConstraint("underlying", "side", "bar_ts", name="uq_brain_ppa_candidate_key"),
    )
    id = Column(Integer, primary_key=True, index=True)
    ts = Column(Float, nullable=False)
    underlying = Column(String(24), nullable=False, index=True)
    side = Column(String(2), nullable=False)
    symbol = Column(String(64), default="")
    exchange = Column(String(8), default="NFO")
    bar_ts = Column(Float, nullable=False, index=True)  # start of the completed 5m bar
    features = Column(Text, default="{}")
    plan = Column(Text, default="{}")
    vote_score = Column(Float, default=0.0)
    status = Column(String(10), default="open", index=True)  # open | labelled | expired
    label_outcome = Column(Integer, nullable=True)  # 1 target first, -1 stop first, 0 timeout
    label_r = Column(Float, nullable=True)  # gross R of the plain triple-barrier walk
    label_r_net = Column(Float, nullable=True)  # after the spread
    label_bars = Column(Integer, nullable=True)
    label_ts = Column(Float, nullable=True)


class BrainEvent(Base):
    __tablename__ = "brain_event"
    id = Column(Integer, primary_key=True, index=True)
    ts = Column(Float, nullable=False, index=True)
    level = Column(String(8), default="info")
    kind = Column(String(32), default="")
    message = Column(Text, default="")
    data = Column(Text, default="{}")


class BrainIvSample(Base):
    __tablename__ = "brain_iv_sample"
    id = Column(Integer, primary_key=True)
    ts = Column(Float, nullable=False, index=True)
    underlying = Column(String(32), nullable=False, index=True)
    atm_iv = Column(Float, nullable=False)


class BrainChainSnapshot(Base):
    """One option-chain snapshot per underlying per decided bar.

    Summary columns are kept forever (small). ``rows`` is the thin raw chain
    (ATM +/- N strikes, bid/ask/OI/IV/Greeks) and is cleared after the raw
    retention window by ``chain_prune``. Joins to ``brain_signal`` on
    (underlying, bar_ts).
    """

    __tablename__ = "brain_chain_snapshot"
    id = Column(Integer, primary_key=True)
    ts = Column(Float, nullable=False, index=True)
    bar_ts = Column(Float, nullable=False, index=True)
    underlying = Column(String(32), nullable=False, index=True)
    expiry = Column(String(12), default="")
    spot = Column(Float, default=0.0)
    atm_strike = Column(Float, default=0.0)
    dte = Column(Float, default=0.0)
    lot_size = Column(Integer, default=1)
    pcr = Column(Float, default=0.0)
    atm_iv = Column(Float, default=0.0)
    straddle = Column(Float, default=0.0)
    skew = Column(Float, default=0.0)
    net_gex = Column(Float, default=0.0)
    gex_norm = Column(Float, default=0.0)
    flip = Column(Float, default=0.0)
    call_wall = Column(Float, default=0.0)
    put_wall = Column(Float, default=0.0)
    max_pain = Column(Float, default=0.0)
    rows = Column(Text, nullable=True)  # {"k": [keys], "r": [[values]...]}


class BrainEdgeReport(Base):
    """One measured cell of the historical edge study (``services/brain/edge_report.py``).

    Each row answers a narrow question: over this fold, for this underlying and
    this barrier configuration, what did the decision rule earn. It is the
    evidence the Brain never had — the live journal holds a few months of its
    own signals, while Historify holds years of bars the engines can replay.

    ``fold`` is a calendar label ("2026Q1", "2026-03", "2026") or the literal
    ``"ALL"`` for the pool of every fold in the run, and ``underlying`` is
    ``"ALL"`` for the pool across underlyings. The pooled rows are what a
    promotion decision would read, because a single fold rarely holds enough
    independent trades to say anything.

    ``label_*`` describes every labelled candidate — the barrier's own edge,
    independent of the gate. ``trade_*`` describes the one-position-at-a-time
    subset the Brain would actually have taken, so the two columns separate
    "was the label learnable" from "did the rule time it well".
    """

    __tablename__ = "brain_edge_report"
    id = Column(Integer, primary_key=True, index=True)
    run_id = Column(String(32), nullable=False, index=True)
    created_at = Column(Float, nullable=False, default=0.0, index=True)
    underlying = Column(String(32), nullable=False, index=True)
    fold = Column(String(12), nullable=False)  # calendar label, or "ALL"
    bar_from = Column(Float, default=0.0)  # first bar of the fold
    bar_to = Column(Float, default=0.0)  # last bar the fold's labels could see
    k_stop = Column(Float, default=0.0)
    k_target = Column(Float, default=0.0)
    horizon_bars = Column(Integer, default=0)
    label_n = Column(Integer, default=0)
    label_win_rate = Column(Float, default=0.0)  # share of candidates that hit the target first
    label_expectancy_r = Column(Float, default=0.0)
    label_lcb_r = Column(Float, default=0.0)
    trade_n = Column(Integer, default=0)
    trade_win_rate = Column(Float, default=0.0)
    trade_expectancy_r = Column(Float, default=0.0)
    trade_lcb_r = Column(Float, default=0.0)
    trade_stderr_r = Column(Float, default=0.0)
    trade_profit_factor = Column(Float, default=0.0)
    trade_max_dd_r = Column(Float, default=0.0)
    trade_total_r = Column(Float, default=0.0)
    params_note = Column(String(64), default="")  # which parameter set produced the cell

    __table_args__ = (
        # One cell per (run, underlying, fold, barrier). A re-run of the same
        # configuration inside one run overwrites rather than accumulating.
        UniqueConstraint(
            "run_id",
            "underlying",
            "fold",
            "horizon_bars",
            "k_stop",
            "k_target",
            name="uq_brain_edge_report_cell",
        ),
        Index("ix_brain_edge_report_lookup", "underlying", "fold", "horizon_bars"),
    )


def init_db() -> None:
    from database.db_init_helper import init_db_with_logging

    init_db_with_logging(Base, engine, "Brain DB", logger)
    _migrate_brain_position_columns()
    _migrate_brain_signal_columns()
    _migrate_brain_signal_unique_index()


def _migrate_brain_signal_unique_index() -> None:
    """Enforce the (underlying, side, bar_ts, band) signal key on existing DBs.

    create_all only builds the UNIQUE constraint into fresh tables, and the
    journal predates it — so a database written while deduplication was broken
    (the bootstrap replay duplicated its whole journal on every re-run) holds
    duplicate rows. This migration clears them (keeping the lowest id, which
    is the row the labeler/journal first saw) and then creates the UNIQUE
    index ``create_all`` declared. If the cleanup leaves anything ungroupable
    (NULLs in the key columns), the index creation is skipped with a warning
    rather than failing startup.
    """
    from sqlalchemy.exc import SQLAlchemyError

    try:
        with engine.begin() as conn:
            conn.execute(
                text(
                    "DELETE FROM brain_signal WHERE id NOT IN ("
                    "  SELECT MIN(id) FROM brain_signal"
                    "  GROUP BY underlying, IFNULL(side, ''),"
                    "           IFNULL(bar_ts, 0), IFNULL(band, '')"
                    ")"
                )
            )
            conn.execute(
                text(
                    "CREATE UNIQUE INDEX IF NOT EXISTS uq_brain_signal_key"
                    " ON brain_signal (underlying, side, bar_ts, band)"
                )
            )
    except SQLAlchemyError as e:
        logger.warning(f"Brain DB: could not enforce the brain_signal unique key: {e}")


def _migrate_brain_position_columns() -> None:
    """Add cost-attribution columns if they are missing (first run after this change)."""
    from sqlalchemy import inspect as sa_inspect

    insp = sa_inspect(engine)
    cols = {c["name"] for c in insp.get_columns("brain_position")}
    needed = {
        "gross_pnl",
        "brokerage",
        "stt",
        "exchange_txn",
        "sebi_charges",
        "stamp_duty",
        "gst",
        "total_cost",
        "net_pnl",
        "broker",
        "broker_account",
        "side",
        "band",
        "position_type",
        "hedge_symbol",
        "hedge_exchange",
        "hedge_option_type",
        "hedge_strike",
        "hedge_qty",
        "hedge_entry_price",
        "spread_credit",
        "spread_width",
    }
    missing = needed - cols
    if not missing:
        return
    col_defs = {
        "gross_pnl": "FLOAT",
        "broker": "VARCHAR(50) DEFAULT ''",
        "broker_account": "VARCHAR(255)",
        "brokerage": "FLOAT DEFAULT 0.0",
        "stt": "FLOAT DEFAULT 0.0",
        "exchange_txn": "FLOAT DEFAULT 0.0",
        "sebi_charges": "FLOAT DEFAULT 0.0",
        "stamp_duty": "FLOAT DEFAULT 0.0",
        "gst": "FLOAT DEFAULT 0.0",
        "total_cost": "FLOAT DEFAULT 0.0",
        "net_pnl": "FLOAT",
        "side": "VARCHAR(8) DEFAULT ''",
        "band": "VARCHAR(8) DEFAULT ''",
        "position_type": "VARCHAR(8) DEFAULT 'long'",
        "hedge_symbol": "VARCHAR(64) DEFAULT ''",
        "hedge_exchange": "VARCHAR(10) DEFAULT ''",
        "hedge_option_type": "VARCHAR(2) DEFAULT ''",
        "hedge_strike": "FLOAT DEFAULT 0.0",
        "hedge_qty": "INTEGER DEFAULT 0",
        "hedge_entry_price": "FLOAT DEFAULT 0.0",
        "spread_credit": "FLOAT DEFAULT 0.0",
        "spread_width": "FLOAT DEFAULT 0.0",
    }
    with engine.connect() as conn:
        for col_name in sorted(missing):
            conn.execute(
                text(f"ALTER TABLE brain_position ADD COLUMN {col_name} {col_defs[col_name]}")
            )
        conn.commit()
    logger.info("brain: added %s column(s) to brain_position: %s", len(missing), sorted(missing))

    # Backfill side/band from linked signals for any rows that landed before these
    # columns existed. Only touches CLOSED positions; open/pending ones pick up the
    # values at next entry via executor.enter().
    if "side" in missing or "band" in missing:
        try:
            with engine.connect() as conn:
                rows = conn.execute(
                    text(
                        "SELECT id, signal_id FROM brain_position WHERE state = 'CLOSED' "
                        "AND signal_id IS NOT NULL AND signal_id > 0"
                    )
                ).fetchall()
                updated = 0
                for row in rows:
                    pid, sig_id = int(row[0]), int(row[1])
                    sig = conn.execute(
                        text("SELECT side, band FROM brain_signal WHERE id = :sid"),
                        {"sid": sig_id},
                    ).fetchone()
                    if sig:
                        conn.execute(
                            text("UPDATE brain_position SET side=:side, band=:band WHERE id=:pid"),
                            {"side": str(sig.side or ""), "band": str(sig.band or ""), "pid": pid},
                        )
                        updated += 1
                conn.commit()
                if updated:
                    logger.info("brain: backfilled side/band on %d brain_position row(s)", updated)
        except Exception as exc:  # pragma: no cover — defensive; migration already succeeded
            logger.warning("brain: side/band backfill failed: %s", exc)


def _migrate_brain_signal_columns() -> None:
    """Add moneyness-band columns if they are missing (first run after this change)."""
    from sqlalchemy import inspect as sa_inspect

    insp = sa_inspect(engine)
    cols = {c["name"] for c in insp.get_columns("brain_signal")}
    needed = {
        "band",
        "symbol",
        "dte",
        "gamma",
        "leg_delta",
        "leg_entry",
        "leg_stop",
        "leg_target",
        "leg_label_outcome",
        "leg_label_r",
        "leg_label_bars",
        "path",
        "position_type",
    }
    missing = needed - cols
    if not missing:
        return
    col_defs = {
        "band": "VARCHAR(8) DEFAULT ''",
        "symbol": "VARCHAR(64) DEFAULT ''",
        "dte": "FLOAT DEFAULT 0.0",
        "gamma": "FLOAT DEFAULT 0.0",
        "leg_delta": "FLOAT DEFAULT 0.0",
        "leg_entry": "FLOAT DEFAULT 0.0",
        "leg_stop": "FLOAT DEFAULT 0.0",
        "leg_target": "FLOAT DEFAULT 0.0",
        "leg_label_outcome": "INTEGER",
        "leg_label_r": "FLOAT",
        "leg_label_bars": "INTEGER",
        "path": "VARCHAR(16) DEFAULT 'Fusion'",
        "position_type": "VARCHAR(8) DEFAULT 'long'",
    }
    with engine.connect() as conn:
        for col_name in sorted(missing):
            conn.execute(
                text(f"ALTER TABLE brain_signal ADD COLUMN {col_name} {col_defs[col_name]}")
            )
        conn.commit()
    logger.info("brain: added %s column(s) to brain_signal: %s", len(missing), sorted(missing))


@contextmanager
def session_scope():
    s = _Session()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()


def _row(obj: Any) -> dict[str, Any]:
    d = {c.name: getattr(obj, c.name) for c in obj.__table__.columns}
    for k in ("features", "votes", "reasons", "params", "model", "metrics", "data"):
        if k in d and isinstance(d[k], str):
            try:
                d[k] = json.loads(d[k])
            except (TypeError, ValueError):
                pass
    return d


# --- state -----------------------------------------------------------------
def state_get(key: str, default: Any = None) -> Any:
    with session_scope() as s:
        row = s.get(BrainState, key)
        if row is None:
            return default
        try:
            return json.loads(row.value)
        except (TypeError, ValueError):
            return default


def state_set(key: str, value: Any) -> None:
    """Upsert a brain_state row, recovering from stale-row conflicts."""
    from sqlalchemy.orm.exc import StaleDataError

    with session_scope() as s:
        row = s.get(BrainState, key)
        payload = json.dumps(value)
        if row is None:
            s.add(BrainState(key=key, value=payload, updated_at=time.time()))
        else:
            try:
                row.value, row.updated_at = payload, time.time()
            except StaleDataError:
                # Another writer beat us to the UPDATE (rare on first tick).
                # Re-read: if the row was inserted by the winner we lose nothing;
                # if it was deleted we re-insert so the key is never lost.
                s.rollback()
                existing = s.get(BrainState, key)
                if existing is None:
                    s.add(BrainState(key=key, value=payload, updated_at=time.time()))
                else:
                    existing.value, existing.updated_at = payload, time.time()
                s.commit()


# --- user-added underlyings -------------------------------------------------
_UNDERLYINGS_KEY = "underlyings"
_LEGACY_UNDERLYINGS_KEY = "brain_underlyings"


def _legacy_underlyings() -> dict[str, str] | None:
    """Read the list an earlier build kept in the sandbox settings table.

    Only used once, to carry an existing install's list across. Returns None when the sandbox
    table cannot be read right now, so the caller tries again later rather than concluding there
    was nothing to carry across.
    """
    try:
        from database.sandbox_db import get_config

        raw = get_config(_LEGACY_UNDERLYINGS_KEY, "{}")
        data = json.loads(raw) if raw else {}
    except Exception:
        logger.exception("brain: could not read legacy underlyings from sandbox settings")
        return None
    if not isinstance(data, dict):
        return {}
    return {str(k).upper(): str(v).upper() for k, v in data.items()}


def underlyings_get() -> dict[str, str]:
    """User-added underlyings as {symbol: exchange}, kept in the Brain's own database."""
    stored = state_get(_UNDERLYINGS_KEY)
    if isinstance(stored, dict):
        return {str(k): str(v) for k, v in stored.items()}
    # Never saved here yet: adopt the earlier sandbox-table value, once. An empty answer is saved
    # too, so the sandbox table is not asked again on every call.
    legacy = _legacy_underlyings()
    if legacy is None:
        return {}
    state_set(_UNDERLYINGS_KEY, legacy)
    return legacy


def underlyings_set(custom: dict[str, str]) -> None:
    state_set(_UNDERLYINGS_KEY, dict(custom))


# --- audit -----------------------------------------------------------------
def event(level: str, kind: str, message: str, data: dict[str, Any] | None = None) -> None:
    try:
        with session_scope() as s:
            s.add(
                BrainEvent(
                    ts=time.time(),
                    level=level,
                    kind=kind,
                    message=message[:2000],
                    data=json.dumps(data or {}, default=str),
                )
            )
    except Exception:
        logger.exception("could not write brain event")


def events(limit: int = 100) -> list[dict[str, Any]]:
    with session_scope() as s:
        return [_row(r) for r in s.query(BrainEvent).order_by(BrainEvent.id.desc()).limit(limit)]


# --- signals ---------------------------------------------------------------


def signals_already_journaled(underlying: str, band: str = "") -> list[tuple[str, float]]:
    """Every ``(side, bar_ts)`` already journalled for this underlying + band.

    The bootstrap replay probes this once per run and deduplicates in memory,
    instead of hitting the DB per bar. Bands journal separately — the same
    (underlying, side, bar) can carry an ITM, an ATM and an OTM signal — so
    the band scope must match the caller's (the bootstrap replay writes
    band-less rows, i.e. ``""``).
    """
    with session_scope() as s:
        q = s.query(BrainSignal.side, BrainSignal.bar_ts).filter(
            BrainSignal.underlying == underlying,
            BrainSignal.band == (band or ""),
        )
        return [(str(side), float(bar_ts)) for side, bar_ts in q.all()]


def signal_bulk_add(rows: list[dict[str, Any]]) -> int:
    """Add a batch of signals in one round-trip.

    The bootstrap replays thousands of bars and hits the DB per bar; without
    a batch path it would take minutes for each underlying because SQLite is
    slow on individual commits. A single ``session.add_all`` keeps every row
    in one transaction, so the cost drops from O(n * latency) to O(latency).

    Rows already journalled (same underlying/side/bar_ts/band) are skipped —
    both within the batch and against what the table already holds — and the
    UNIQUE key (uq_brain_signal_key) is the backstop for anything that slips
    through a race. The docstring used to claim "the caller already ran
    ``signal_seen``"; that was not true of the bootstrap path, which
    duplicated its entire journal on every re-run.
    """
    if not rows:
        return 0
    norm: list[dict[str, Any]] = []
    batch_keys: set[tuple[str, str, float, str]] = set()
    for row in rows:
        r = dict(row)
        for k in ("features", "votes", "reasons"):
            if k in r and not isinstance(r[k], str):
                r[k] = json.dumps(r[k])
        key = (
            str(r.get("underlying") or ""),
            str(r.get("side") or ""),
            float(r.get("bar_ts") or 0.0),
            str(r.get("band") or ""),
        )
        if key in batch_keys:
            continue
        batch_keys.add(key)
        norm.append(r)
    added = 0
    with session_scope() as s:
        by_underlying: dict[str, list[dict[str, Any]]] = {}
        for r in norm:
            by_underlying.setdefault(str(r.get("underlying") or ""), []).append(r)
        for u, urows in by_underlying.items():
            # Existing-key probe, chunked to stay inside SQLite's variable
            # limit on large replays.
            ts_list = sorted({float(r.get("bar_ts") or 0.0) for r in urows})
            existing: set[tuple[str, float, str]] = set()
            for i in range(0, len(ts_list), 500):
                chunk = ts_list[i : i + 500]
                existing |= {
                    (str(side), float(bar_ts), str(band or ""))
                    for side, bar_ts, band in s.query(
                        BrainSignal.side, BrainSignal.bar_ts, BrainSignal.band
                    )
                    .filter(BrainSignal.underlying == u, BrainSignal.bar_ts.in_(chunk))
                    .all()
                }
            for r in urows:
                if (
                    str(r.get("side") or ""),
                    float(r.get("bar_ts") or 0.0),
                    str(r.get("band") or ""),
                ) in existing:
                    continue
                s.add(BrainSignal(**r))
                added += 1
        s.commit()
    return added


def signal_add(row: dict[str, Any]) -> int:
    row = dict(row)
    for k in ("features", "votes", "reasons"):
        if k in row and not isinstance(row[k], str):
            row[k] = json.dumps(row[k])
    with session_scope() as s:
        obj = BrainSignal(**row)
        s.add(obj)
        try:
            s.flush()
        except Exception:
            s.rollback()
            # Dedup against a concurrent insert that beat us to the UNIQUE key.
            # The caller (bootstrap / label_pending) already ran signal_seen(),
            # but two racing threads can both pass that check before either
            # commits. Return the existing id so callers don't crash on a
            # duplicate that is harmless to the journal semantics.
            existing = (
                s.query(BrainSignal.id)
                .filter_by(
                    underlying=row["underlying"],
                    side=row["side"],
                    bar_ts=row["bar_ts"],
                    band=row.get("band", ""),
                )
                .first()
            )
            if existing is not None:
                # existing is a Row(id=...); index into it directly to avoid
                # int(Row) which raises TypeError on SQLAlchemy >= 2.0.
                return int(existing[0])
            raise
        return int(obj.id)


def signal_update(signal_id: int, **fields: Any) -> None:
    with session_scope() as s:
        s.query(BrainSignal).filter(BrainSignal.id == signal_id).update(fields)


def signal_seen(underlying: str, side: str, bar_ts: float, band: str = "") -> bool:
    """Already journalled for this bar? Bands journal separately, so the same
    (underlying, side, bar) can carry an ITM, an ATM and an OTM signal."""
    with session_scope() as s:
        q = s.query(BrainSignal.id).filter_by(underlying=underlying, side=side, bar_ts=bar_ts)
        q = q.filter(BrainSignal.band == (band or ""))
        return q.first() is not None


def signal_get(signal_id: int) -> dict[str, Any] | None:
    with session_scope() as s:
        obj = s.get(BrainSignal, signal_id)
        return _row(obj) if obj else None


def signals_recent(limit: int = 50, suggested_only: bool = False) -> list[dict[str, Any]]:
    with session_scope() as s:
        q = s.query(BrainSignal)
        if suggested_only:
            q = q.filter(BrainSignal.passed.is_(True))
        return [_row(r) for r in q.order_by(BrainSignal.id.desc()).limit(limit)]


def signals_labelled_probs(limit: int = 5000) -> list[tuple[float, int]]:
    """(predicted probability, outcome) for the latest labelled signals."""
    with session_scope() as s:
        q = (
            s.query(BrainSignal.prob, BrainSignal.label_outcome)
            .filter(BrainSignal.label_outcome.isnot(None))
            .order_by(BrainSignal.id.desc())
            .limit(limit)
        )
        return [(float(p or 0.0), int(o)) for p, o in q]


def signals_unlabeled(before_ts: float, limit: int = 2000) -> list[dict[str, Any]]:
    """Signals old enough that their horizon has fully elapsed."""
    with session_scope() as s:
        q = s.query(BrainSignal).filter(
            BrainSignal.label_outcome.is_(None), BrainSignal.bar_ts <= before_ts
        )
        return [_row(r) for r in q.order_by(BrainSignal.id).limit(limit)]


# A leg whose premium path can no longer be observed (expired contract, dead
# feed) is given up after this age so the 2000-row scan window does not fill
# with permanently-unlabeled dead rows. Five days covers weekly expiries plus
# a grace window.
MAX_LEG_LABEL_AGE_S = 5 * 24 * 3600


def signals_leg_unlabeled(before_ts: float, limit: int = 2000) -> list[dict[str, Any]]:
    """Band signals whose option leg has levels but no premium-path label yet.

    Kept separate from :func:`signals_unlabeled` so a leg whose premium bars
    were still warming when its underlying was labelled gets another chance on
    a later cycle instead of sitting unlabelled forever.

    The scan is bounded by age: rows older than MAX_LEG_LABEL_AGE_S are
    abandoned (marked terminal by :func:`services.brain.learner.label_legs_pending`)
    so expired contracts never retry forever and never clog the scan window.
    """
    with session_scope() as s:
        q = s.query(BrainSignal).filter(
            BrainSignal.band.isnot(None),
            BrainSignal.band != "",
            BrainSignal.symbol.isnot(None),
            BrainSignal.symbol != "",
            BrainSignal.leg_entry > 0,
            BrainSignal.leg_stop > 0,
            BrainSignal.leg_target > 0,
            BrainSignal.leg_label_outcome.is_(None),
            BrainSignal.bar_ts <= before_ts,
            # Only scan recently-created legs; old dead rows are abandoned
            # elsewhere so they cannot starve the window forever.
            BrainSignal.bar_ts > (before_ts - MAX_LEG_LABEL_AGE_S),
        )
        return [_row(r) for r in q.order_by(BrainSignal.id).limit(limit)]


def _band_dedup(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """One row per (underlying, side, bar): the same decision is journalled
    once per moneyness band with near-identical features and an identical
    underlying label. Letting all of them into training would weight that
    decision threefold and place exact duplicates on both sides of the
    fit/validate split — ``purge()`` cannot remove them (identical bar_ts and
    label_bars). The band-less (legacy) row is preferred, then ATM."""
    dedup: dict[tuple[str, str, float], dict[str, Any]] = {}
    for r in rows:
        key = (r["underlying"], r["side"], float(r["bar_ts"] or 0.0))
        cur = dedup.get(key)
        if cur is None or _BAND_PREF.get(r.get("band") or "", 9) < _BAND_PREF.get(
            cur.get("band") or "", 9
        ):
            dedup[key] = r
    out = list(dedup.values())
    out.sort(key=lambda r: r["bar_ts"] or 0.0)
    return out


def signals_labeled(since_ts: float | None = None, limit: int = 20000) -> list[dict[str, Any]]:
    """The newest ``limit`` labelled rows, returned chronologically for training.

    Ordered oldest-first with a plain ``LIMIT`` the trainer would forever see the
    same oldest sliver of a long backfill (2021 while trading in 2026). Taking the
    tail by ``bar_ts`` and restoring chronological order keeps the trainer's
    fit/validate/confirm split meaningful: the confirm slice is *now*-adjacent.

    Band-tripled rows are deduplicated here — the orchestrator journals one row
    per moneyness band per (side, bar) and they all share the same underlying
    label, so rows sort contiguously by bar_ts and the 60/80 split can fall
    *inside* a trio (direct holdout leakage, evidence counts inflated ~3x).
    """
    with session_scope() as s:
        q = s.query(BrainSignal).filter(BrainSignal.label_outcome.isnot(None))
        if since_ts is not None:
            q = q.filter(BrainSignal.bar_ts >= since_ts)
        rows = [_row(r) for r in q.order_by(BrainSignal.bar_ts.desc()).limit(limit)]
    return _band_dedup(rows)


_BAND_PREF = {"": 0, "ATM": 1}  # lower wins; any other band sorts after these


def signals_labeled_live(limit: int = 20000) -> list[dict[str, Any]]:
    """The newest ``limit`` *live* labelled rows, chronologically.

    Live rows are the ones produced by the running Brain; they carry the option
    chain (and therefore the ``options.*`` features), while a replayed row has
    no chain and zeros for every one of them.

    One row per (underlying, side, bar): the same decision is journalled once
    per moneyness band with near-identical features and an identical underlying
    label, and letting all of them into training would weight that decision
    threefold and place exact duplicates on both sides of the fit/validate
    split. The band-less (legacy) row is preferred, then ATM.
    """
    with session_scope() as s:
        q = s.query(BrainSignal).filter(
            BrainSignal.label_outcome.isnot(None), BrainSignal.status != "BACKTEST"
        )
        rows = [_row(r) for r in q.order_by(BrainSignal.bar_ts.desc()).limit(limit)]
    return _band_dedup(rows)


def signal_counts() -> dict[str, int]:
    with session_scope() as s:
        total = s.query(func.count(BrainSignal.id)).scalar() or 0
        labeled = (
            s.query(func.count(BrainSignal.id))
            .filter(BrainSignal.label_outcome.isnot(None))
            .scalar()
            or 0
        )
        return {"total": int(total), "labeled": int(labeled)}


def clear_signals() -> dict[str, int]:
    """Drop every journalled signal.

    Used when the engines' meaning changes: a stored vote is only meaningful
    against the engine that produced it, so a change to how an engine reads
    the market invalidates the whole journal. The journal is a derived cache —
    it is rebuilt from the bars — so dropping it costs time, not information.
    """
    with session_scope() as s:
        total = s.query(func.count(BrainSignal.id)).scalar() or 0
        deleted = s.query(BrainSignal).delete(synchronize_session=False)
        s.commit()
        return {"deleted": int(deleted), "remaining": int(total)}


def retire_champions(note: str = "engine change") -> int:
    """Retire every champion model.

    A model trained on the old meaning of a feature cannot be trusted against
    the new one. It is retired rather than deleted, so the audit trail of what
    was promoted and when survives.
    """
    with session_scope() as s:
        n = (
            s.query(BrainModel)
            .filter(BrainModel.role == "champion")
            .update({"role": "retired", "note": note}, synchronize_session=False)
        )
        s.commit()
        return int(n or 0)


# --- retention ----------------------------------------------------------------
# The journal grows with every replayed and live signal: a five-year bootstrap
# replay alone is ~310k rows at ~2.3 kB each, which is more than a gigabyte of
# SQLite. The trainer only ever reads the newest rows (see signals_labeled), so
# the old replay rows are kept for a while and then dropped: the newest
# ``keep`` replay rows plus every live row stay, the rest goes.
BACKTEST_KEEP_ROWS = 60_000


def prune_backtest_signals(keep: int = BACKTEST_KEEP_ROWS) -> dict[str, int]:
    """Drop replay rows older than the newest ``keep``. Live rows are never touched."""
    with session_scope() as s:
        total = s.query(func.count(BrainSignal.id)).scalar() or 0
        # ids follow insertion order, so the oldest kept row is the boundary
        boundary = (
            s.query(BrainSignal.id)
            .filter(BrainSignal.status == "BACKTEST")
            .order_by(BrainSignal.id.desc())
            .limit(1)
            .offset(max(int(keep) - 1, 0))
            .scalar()
        )
        if boundary is None:
            return {"deleted": 0, "remaining": int(total)}
        deleted = (
            s.query(BrainSignal)
            .filter(BrainSignal.status == "BACKTEST", BrainSignal.id < boundary)
            .delete(synchronize_session=False)
        )
        return {"deleted": int(deleted), "remaining": int(total) - int(deleted)}


def vacuum() -> bool:
    """Reclaim the space the pruned rows left behind.

    VACUUM cannot run inside a transaction, so it gets its own autocommit
    connection. It rewrites the file, which needs no other writer: it is safe
    to call while the Brain is running, but the file is briefly locked.
    """
    try:
        with engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
            conn.execute(text("VACUUM"))
        return True
    except Exception:
        logger.exception("brain: VACUUM failed")
        return False


# --- positions -------------------------------------------------------------
def position_add(row: dict[str, Any]) -> int:
    with session_scope() as s:
        obj = BrainPosition(**row)
        s.add(obj)
        s.flush()
        return int(obj.id)


def position_get(pid: int) -> dict[str, Any] | None:
    with session_scope() as s:
        obj = s.get(BrainPosition, pid)
        return _row(obj) if obj else None


def positions_open() -> list[dict[str, Any]]:
    """PENDING, OPEN and CLOSING: held until CLOSED. PENDING is an entry whose order
    is in flight; it is journalled *before* dispatch so a crash cannot orphan it."""
    with session_scope() as s:
        return [
            _row(r)
            for r in s.query(BrainPosition)
            .filter(BrainPosition.state.in_(("PENDING", "OPEN", "CLOSING")))
            .order_by(BrainPosition.id)
        ]


def position_update(pid: int, **fields: Any) -> None:
    with session_scope() as s:
        s.query(BrainPosition).filter(BrainPosition.id == pid).update(fields)


def position_claim_exit(pid: int, kind: str) -> bool:
    """Atomically move OPEN -> CLOSING and stamp why. False if someone already did."""
    with session_scope() as s:
        n = (
            s.query(BrainPosition)
            .filter(BrainPosition.id == pid, BrainPosition.state == "OPEN")
            .update({"state": "CLOSING", "exit_kind": kind}, synchronize_session=False)
        )
        return n == 1


def position_release_exit(pid: int) -> None:
    """The dispatch was refused: the position is still held, so it goes back under management."""
    with session_scope() as s:
        s.query(BrainPosition).filter(
            BrainPosition.id == pid, BrainPosition.state == "CLOSING"
        ).update({"state": "OPEN", "exit_kind": None}, synchronize_session=False)


def positions_closed(since_ts: float | None = None, limit: int = 5000) -> list[dict[str, Any]]:
    with session_scope() as s:
        q = s.query(BrainPosition).filter(BrainPosition.state == "CLOSED")
        if since_ts is not None:
            q = q.filter(BrainPosition.exit_ts >= since_ts)
        return [_row(r) for r in q.order_by(BrainPosition.exit_ts.desc()).limit(limit)]


def is_refused_entry(pos: dict[str, Any]) -> bool:
    """True when a CLOSED position never actually traded — a refused entry journaled
    so a crash cannot orphan it, but with no real fill. These must be excluded from
    all realized-P&L calculations so the numbers match the broker's.

    IMPORTANT: Reconciled closes ("closed outside the Brain") carry only ``pnl``
    (no gross_pnl/net_pnl/total_cost/exit_order_id). They MUST NOT be filtered out,
    because they are real realised P&L the operator needs to see.
    """
    reason = str(pos.get("exit_reason") or "")
    reason_lower = reason.lower()
    if "entry refused" in reason_lower:
        return True
    # Never drop broker force-closes / MIS auto-square-offs — they have real pnl.
    if "closed outside the brain" in reason_lower:
        return False
    # A real entry order was dispatched to the broker, so the position really
    # traded — the legacy zero-pnl heuristic must not journal away a live fill
    # that happened to net to zero (e.g. scratch exit, full fee credit).
    if pos.get("entry_order_id"):
        return False
    # Legacy heuristic for truly-unfilled entries (pre-migration rows).
    return (
        float(pos.get("gross_pnl") or 0) == 0.0
        and float(pos.get("net_pnl") or 0) == 0.0
        and float(pos.get("total_cost") or 0) == 0.0
        and not pos.get("exit_order_id")
    )


def positions_closed_realized(
    since_ts: float | None = None, limit: int = 5000
) -> list[dict[str, Any]]:
    """Closed positions that actually traded — excludes refused/failed entries."""
    return [p for p in positions_closed(since_ts, limit) if not is_refused_entry(p)]


# --- models ----------------------------------------------------------------
def model_add(
    role: str,
    params: dict[str, Any],
    model: dict[str, Any],
    metrics: dict[str, Any],
    note: str = "",
) -> int:
    with session_scope() as s:
        obj = BrainModel(
            created_at=time.time(),
            role=role,
            params=json.dumps(params),
            model=json.dumps(model),
            metrics=json.dumps(metrics),
            note=note,
        )
        s.add(obj)
        s.flush()
        return int(obj.id)


def model_get(model_id: int) -> dict[str, Any] | None:
    with session_scope() as s:
        obj = s.get(BrainModel, model_id)
        return _row(obj) if obj else None


def model_by_role(role: str) -> dict[str, Any] | None:
    with session_scope() as s:
        obj = (
            s.query(BrainModel)
            .filter(BrainModel.role == role)
            .order_by(BrainModel.id.desc())
            .first()
        )
        return _row(obj) if obj else None


def model_set_role(model_id: int, role: str) -> None:
    with session_scope() as s:
        s.query(BrainModel).filter(BrainModel.id == model_id).update({"role": role})


def models_list(limit: int = 30) -> list[dict[str, Any]]:
    with session_scope() as s:
        rows = [_row(r) for r in s.query(BrainModel).order_by(BrainModel.id.desc()).limit(limit)]
    for r in rows:  # the weights are large and the list view does not need them
        m = r.get("model") or {}
        # "n" is optimiser updates (rows x epochs); n_rows / n_eff are what the model really saw.
        r["model"] = {"n": m.get("n", 0), "n_rows": m.get("n_rows"), "n_eff": m.get("n_eff")}
    return rows


# --- evaluation, iv --------------------------------------------------------
def eval_upsert(day: str, data: dict[str, Any]) -> None:
    """Upsert an evaluation record. Uses INSERT OR REPLACE so concurrent
    writers on the same day never raise an IntegrityError — the last writer
    wins, which is acceptable for daily audit rows."""
    payload = json.dumps(data, default=str)
    with session_scope() as s:
        row = s.get(BrainEval, day)
        if row is None:
            s.add(BrainEval(day=day, data=payload, updated_at=time.time()))
        else:
            row.data, row.updated_at = payload, time.time()


def evals_recent(n: int = 60) -> list[dict[str, Any]]:
    with session_scope() as s:
        rows = s.query(BrainEval).order_by(BrainEval.day.desc()).limit(n).all()
        return [{"day": r.day, **json.loads(r.data or "{}")} for r in rows]


def iv_add(underlying: str, atm_iv: float, ts: float | None = None) -> None:
    with session_scope() as s:
        s.add(BrainIvSample(ts=ts or time.time(), underlying=underlying, atm_iv=atm_iv))


def iv_sample_count(underlying: str, days: int = 30) -> int:
    """How many IV series samples iv_rank() currently has to work with."""
    with session_scope() as s:
        return int(
            s.query(func.count(BrainIvSample.id))
            .filter(
                BrainIvSample.underlying == underlying,
                BrainIvSample.ts >= time.time() - days * 86400,
            )
            .scalar()
            or 0
        )


def iv_rank(underlying: str, current: float, days: int = 30) -> float | None:
    since = time.time() - days * 86400
    with session_scope() as s:
        vals = [
            r[0]
            for r in s.query(BrainIvSample.atm_iv)
            .filter(BrainIvSample.underlying == underlying, BrainIvSample.ts >= since)
            .all()
        ]
    if len(vals) < 30:
        return None
    lo, hi = min(vals), max(vals)
    return 0.5 if hi - lo < 1e-9 else float((current - lo) / (hi - lo))


def iv_prune(keep_days: int = 60) -> None:
    with session_scope() as s:
        s.execute(
            text("DELETE FROM brain_iv_sample WHERE ts < :t"),
            {"t": time.time() - keep_days * 86400},
        )


# --- option chain snapshots ----------------------------------------------------
def chain_snapshot_seen(underlying: str, bar_ts: float) -> bool:
    with session_scope() as s:
        return (
            s.query(BrainChainSnapshot.id).filter_by(underlying=underlying, bar_ts=bar_ts).first()
            is not None
        )


def chain_snapshot_add(row: dict[str, Any]) -> int:
    row = dict(row)
    if row.get("rows") is not None and not isinstance(row["rows"], str):
        row["rows"] = json.dumps(row["rows"], separators=(",", ":"))
    with session_scope() as s:
        obj = BrainChainSnapshot(**row)
        s.add(obj)
        s.flush()
        return int(obj.id)


def chain_snapshots_recent(
    underlying: str | None = None, limit: int = 50, with_rows: bool = False
) -> list[dict[str, Any]]:
    with session_scope() as s:
        q = s.query(BrainChainSnapshot)
        if underlying:
            q = q.filter(BrainChainSnapshot.underlying == underlying)
        out = []
        for r in q.order_by(BrainChainSnapshot.bar_ts.desc()).limit(limit):
            d = {c.name: getattr(r, c.name) for c in r.__table__.columns}
            if with_rows and d.get("rows"):
                d["rows"] = json.loads(d["rows"])
            elif not with_rows:
                d.pop("rows", None)
            out.append(d)
        return out


def chain_snapshot_count() -> int:
    with session_scope() as s:
        return int(s.query(func.count(BrainChainSnapshot.id)).scalar() or 0)


def chain_prune(keep_raw_days: int = 90) -> None:
    """Drop the raw rows of old snapshots; the summary columns stay."""
    with session_scope() as s:
        s.execute(
            text("UPDATE brain_chain_snapshot SET rows = NULL WHERE ts < :t AND rows IS NOT NULL"),
            {"t": time.time() - keep_raw_days * 86400},
        )


def signals_labeled_live_count() -> int:
    """Labelled decisions the running Brain produced (the ones that carry a chain).

    One per (underlying, side, bar) — band rows are the same decision journalled
    once per moneyness band, and the maturity gate would otherwise read three
    times the evidence. A replayed row has no option chain, so only a live row
    can teach the ``options.*`` features.
    """
    with session_scope() as s:
        pairs = (
            s.query(BrainSignal.underlying, BrainSignal.side, BrainSignal.bar_ts).filter(
                BrainSignal.label_outcome.isnot(None), BrainSignal.status != "BACKTEST"
            )
        ).all()
    return len({(u, sd, round(float(b or 0.0), 3)) for u, sd, b in pairs})


def signals_labeled_with_chain() -> int:
    """Labelled signals whose decision saw a live chain (options.opt_available == 1)."""
    with session_scope() as s:
        rows = (
            s.query(BrainSignal.underlying, BrainSignal.side, BrainSignal.bar_ts).filter(
                BrainSignal.label_outcome.isnot(None),
                BrainSignal.features.like('%"options.opt_available": 1.0%'),
            )
        ).all()
    return len({(u, sd, round(float(b or 0.0), 3)) for u, sd, b in rows})


# --- premium-PA candidate journal ---------------------------------------------
def ppa_candidate_add(rows: list[dict[str, Any]]) -> int:
    """Insert candidates, skipping any (underlying, side, bar_ts) already journaled."""
    from sqlalchemy.exc import IntegrityError

    added = 0
    for r in rows:
        try:
            with session_scope() as s:
                s.add(
                    BrainPpaCandidate(
                        ts=float(r.get("ts") or time.time()),
                        underlying=str(r["underlying"]),
                        side=str(r["side"]),
                        symbol=str(r.get("symbol") or ""),
                        exchange=str(r.get("exchange") or "NFO"),
                        bar_ts=float(r["bar_ts"]),
                        features=json.dumps(r.get("features") or {}, default=str),
                        plan=json.dumps(r.get("plan") or {}, default=str),
                        vote_score=float(r.get("vote_score") or 0.0),
                        status="open",
                    )
                )
            added += 1
        except IntegrityError:
            continue
    return added


def ppa_candidate_pending(before_ts: float, limit: int = 400) -> list[dict[str, Any]]:
    """Open candidates whose bar started at or before ``before_ts``, oldest first."""
    with session_scope() as s:
        rows = (
            s.query(BrainPpaCandidate)
            .filter(BrainPpaCandidate.status == "open", BrainPpaCandidate.bar_ts <= before_ts)
            .order_by(BrainPpaCandidate.bar_ts.asc())
            .limit(limit)
            .all()
        )
        out = []
        for o in rows:
            d = {c.name: getattr(o, c.name) for c in o.__table__.columns}
            for k in ("features", "plan"):
                try:
                    d[k] = json.loads(d[k]) if isinstance(d[k], str) else (d[k] or {})
                except (TypeError, ValueError):
                    d[k] = {}
            out.append(d)
        return out


def ppa_candidate_label(cid: int, **fields: Any) -> None:
    allowed = {"status", "label_outcome", "label_r", "label_r_net", "label_bars", "label_ts"}
    upd = {k: v for k, v in fields.items() if k in allowed}
    if not upd:
        return
    with session_scope() as s:
        s.query(BrainPpaCandidate).filter(BrainPpaCandidate.id == cid).update(upd)


def ppa_candidates_labelled(limit: int = 20000) -> list[dict[str, Any]]:
    """Labelled candidates, oldest first (the newest ``limit`` of them)."""
    with session_scope() as s:
        rows = (
            s.query(BrainPpaCandidate)
            .filter(BrainPpaCandidate.status == "labelled")
            .order_by(BrainPpaCandidate.bar_ts.desc())
            .limit(limit)
            .all()
        )
        out = []
        for o in rows:
            d = {c.name: getattr(o, c.name) for c in o.__table__.columns}
            for k in ("features", "plan"):
                try:
                    d[k] = json.loads(d[k]) if isinstance(d[k], str) else (d[k] or {})
                except (TypeError, ValueError):
                    d[k] = {}
            out.append(d)
    out.reverse()
    return out


def ppa_candidate_counts() -> dict[str, int]:
    with session_scope() as s:
        rows = s.query(BrainPpaCandidate.status, BrainPpaCandidate.id).all()
    out = {"open": 0, "labelled": 0, "expired": 0}
    for status, _ in rows:
        out[str(status)] = out.get(str(status), 0) + 1
    out["total"] = sum(out.values())
    return out


# --- historical edge study -------------------------------------------------
EDGE_REPORT_COLUMNS = (
    "underlying",
    "fold",
    "bar_from",
    "bar_to",
    "k_stop",
    "k_target",
    "horizon_bars",
    "label_n",
    "label_win_rate",
    "label_expectancy_r",
    "label_lcb_r",
    "trade_n",
    "trade_win_rate",
    "trade_expectancy_r",
    "trade_lcb_r",
    "trade_stderr_r",
    "trade_profit_factor",
    "trade_max_dd_r",
    "trade_total_r",
    "params_note",
)
"""The measured fields of a ``brain_edge_report`` row, in report order."""


def edge_report_add(run_id: str, created_at: float, rows: list[dict[str, Any]]) -> int:
    """Upsert a batch of edge-study cells for one run.

    The unique key is ``(run_id, underlying, fold, horizon_bars, k_stop,
    k_target)``, so re-running one fold inside the same run rewrites its cell
    instead of accumulating a second copy. Every value is written, including a
    zero, because a zero is a measurement here ("no trades in this fold") and
    not a missing value.
    """
    if not rows:
        return 0
    written = 0
    with session_scope() as s:
        for row in rows:
            key = (
                str(run_id),
                str(row["underlying"]),
                str(row["fold"]),
                int(row["horizon_bars"]),
                float(row["k_stop"]),
                float(row["k_target"]),
            )
            values = {c: row.get(c, 0) for c in EDGE_REPORT_COLUMNS}
            existing = (
                s.query(BrainEdgeReport)
                .filter(
                    BrainEdgeReport.run_id == key[0],
                    BrainEdgeReport.underlying == key[1],
                    BrainEdgeReport.fold == key[2],
                    BrainEdgeReport.horizon_bars == key[3],
                    BrainEdgeReport.k_stop == key[4],
                    BrainEdgeReport.k_target == key[5],
                )
                .one_or_none()
            )
            if existing is None:
                s.add(BrainEdgeReport(run_id=key[0], created_at=float(created_at), **values))
            else:
                for col, val in values.items():
                    setattr(existing, col, val)
                existing.created_at = float(created_at)
            written += 1
    return written


def edge_report_run(run_id: str) -> list[dict[str, Any]]:
    """Every cell of one run, ordered by underlying then fold."""
    with session_scope() as s:
        rows = (
            s.query(BrainEdgeReport)
            .filter(BrainEdgeReport.run_id == str(run_id))
            .order_by(
                BrainEdgeReport.underlying.asc(),
                BrainEdgeReport.fold.asc(),
                BrainEdgeReport.horizon_bars.asc(),
                BrainEdgeReport.k_stop.asc(),
                BrainEdgeReport.k_target.asc(),
            )
            .all()
        )
        return [_row(o) for o in rows]


def edge_report_recent(limit: int = 200, run_id: str | None = None) -> list[dict[str, Any]]:
    """The newest cells, newest run first. ``run_id`` narrows to one run."""
    with session_scope() as s:
        q = s.query(BrainEdgeReport)
        if run_id:
            q = q.filter(BrainEdgeReport.run_id == str(run_id))
        rows = (
            q.order_by(BrainEdgeReport.created_at.desc(), BrainEdgeReport.id.desc())
            .limit(limit)
            .all()
        )
        return [_row(o) for o in rows]


def edge_report_runs(limit: int = 20) -> list[dict[str, Any]]:
    """One summary row per run: when it was written and how many cells it holds."""
    with session_scope() as s:
        rows = (
            s.query(
                BrainEdgeReport.run_id,
                func.min(BrainEdgeReport.created_at),
                func.count(BrainEdgeReport.id),
            )
            .group_by(BrainEdgeReport.run_id)
            .order_by(func.min(BrainEdgeReport.created_at).desc())
            .limit(limit)
            .all()
        )
    return [{"run_id": r[0], "created_at": r[1], "cells": r[2]} for r in rows]
