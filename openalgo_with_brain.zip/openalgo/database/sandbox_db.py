# database/sandbox_db.py

import os
from datetime import datetime

import pytz

from dotenv import load_dotenv
from sqlalchemy import (
    DECIMAL,
    Boolean,
    CheckConstraint,
    Column,
    Date,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    create_engine,
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, scoped_session, sessionmaker
from sqlalchemy.pool import NullPool
from sqlalchemy.sql import func

#: The sandbox keeps every timestamp as naive IST wall-clock: the order book
#: stamps datetime.now(IST) and SQLite drops the offset on the way in. GTT rows
#: and the GTT manager's clock use the same helper so they compare and display
#: consistently, whatever timezone the host machine runs in.
IST = pytz.timezone("Asia/Kolkata")


def ist_now() -> datetime:
    return datetime.now(IST).replace(tzinfo=None)


from utils.logging import get_logger

# Initialize logger
logger = get_logger(__name__)

# Load environment variables
load_dotenv()

# Sandbox database URL - separate database for isolation
# Get from environment variable or use default path in /db directory
SANDBOX_DATABASE_URL = os.getenv("SANDBOX_DATABASE_URL", "sqlite:///db/sandbox.db")

# Conditionally create engine based on DB type
if SANDBOX_DATABASE_URL and "sqlite" in SANDBOX_DATABASE_URL:
    # SQLite: Use NullPool to prevent connection pool exhaustion
    engine = create_engine(
        SANDBOX_DATABASE_URL, poolclass=NullPool, connect_args={"check_same_thread": False}
    )
else:
    # For other databases like PostgreSQL, use connection pooling
    engine = create_engine(SANDBOX_DATABASE_URL, pool_size=20, max_overflow=40, pool_timeout=10)

db_session = scoped_session(sessionmaker(autocommit=False, autoflush=False, bind=engine))
Base = declarative_base()
Base.query = db_session.query_property()


class SandboxOrders(Base):
    """Sandbox orders table - all sandbox orders"""

    __tablename__ = "sandbox_orders"

    id = Column(Integer, primary_key=True, autoincrement=True)
    orderid = Column(String(50), unique=True, nullable=False, index=True)
    user_id = Column(String(50), nullable=False, index=True)
    strategy = Column(String(100), nullable=True)
    symbol = Column(String(50), nullable=False, index=True)
    exchange = Column(String(20), nullable=False, index=True)
    action = Column(String(10), nullable=False)  # BUY or SELL
    quantity = Column(Integer, nullable=False)
    price = Column(DECIMAL(10, 2), nullable=True)  # Null for market orders
    trigger_price = Column(DECIMAL(10, 2), nullable=True)  # For SL and SL-M orders
    price_type = Column(String(20), nullable=False)  # MARKET, LIMIT, SL, SL-M
    product = Column(String(20), nullable=False)  # CNC, NRML, MIS
    order_status = Column(
        String(20), nullable=False, default="open", index=True
    )  # open, trigger pending, complete, cancelled, rejected
    average_price = Column(DECIMAL(10, 2), nullable=True)  # Filled price
    filled_quantity = Column(Integer, default=0)  # Always 0 or quantity (no partial fills)
    pending_quantity = Column(Integer, nullable=False)  # Remaining quantity
    rejection_reason = Column(Text, nullable=True)
    margin_blocked = Column(
        DECIMAL(10, 2), nullable=True, default=0.00
    )  # NULL means a recorded zero; migrated legacy rows retain default zero
    # Set only on an order a GTT leg placed, and written in the same INSERT as
    # the order itself. That atomicity is the point: SandboxGTTLeg.triggered_order_id
    # is written in a later commit, so a crash in between would leave the order
    # with no marker and recovery would re-arm a GTT that had already fired.
    # Unique, so replaying the same claim cannot create a second child order.
    gtt_leg_id = Column(Integer, nullable=True, unique=True, index=True)

    order_timestamp = Column(DateTime, nullable=False, default=func.now())
    update_timestamp = Column(DateTime, nullable=False, default=func.now(), onupdate=func.now())

    __table_args__ = (
        Index("idx_sandbox_user_status", "user_id", "order_status"),
        Index("idx_sandbox_symbol_exchange", "symbol", "exchange"),
        CheckConstraint(
            "order_status IN ('open', 'trigger pending', 'complete', 'cancelled', 'rejected')",
            name="check_order_status",
        ),
        CheckConstraint("action IN ('BUY', 'SELL')", name="check_action"),
        CheckConstraint("price_type IN ('MARKET', 'LIMIT', 'SL', 'SL-M')", name="check_price_type"),
        CheckConstraint("product IN ('CNC', 'NRML', 'MIS')", name="check_product"),
    )


class SandboxTrades(Base):
    """Sandbox trades table - executed trades"""

    __tablename__ = "sandbox_trades"

    id = Column(Integer, primary_key=True, autoincrement=True)
    tradeid = Column(String(50), unique=True, nullable=False, index=True)
    orderid = Column(String(50), nullable=False, index=True)
    user_id = Column(String(50), nullable=False, index=True)
    symbol = Column(String(50), nullable=False, index=True)
    exchange = Column(String(20), nullable=False, index=True)
    action = Column(String(10), nullable=False)  # BUY or SELL
    quantity = Column(Integer, nullable=False)
    price = Column(DECIMAL(10, 2), nullable=False)  # Execution price
    product = Column(String(20), nullable=False)  # CNC, NRML, MIS
    strategy = Column(String(100), nullable=True)
    trade_timestamp = Column(DateTime, nullable=False, default=func.now())

    __table_args__ = (
        Index("idx_user_symbol", "user_id", "symbol"),
        Index("idx_orderid", "orderid"),
    )


class SandboxPositions(Base):
    """Sandbox positions table - open positions"""

    __tablename__ = "sandbox_positions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String(50), nullable=False, index=True)
    symbol = Column(String(50), nullable=False, index=True)
    exchange = Column(String(20), nullable=False, index=True)
    product = Column(String(20), nullable=False)  # CNC, NRML, MIS
    quantity = Column(Integer, nullable=False)  # Net quantity (can be negative for short)
    average_price = Column(DECIMAL(10, 2), nullable=False)  # Average entry price

    # MTM tracking
    ltp = Column(DECIMAL(10, 2), nullable=True)  # Last traded price
    pnl = Column(
        DECIMAL(10, 2), default=0.00
    )  # Current P&L (unrealized for open, realized for closed)
    pnl_percent = Column(DECIMAL(10, 4), default=0.00)  # P&L percentage
    accumulated_realized_pnl = Column(
        DECIMAL(10, 2), default=0.00
    )  # Accumulated realized P&L (all-time for this position)
    today_realized_pnl = Column(
        DECIMAL(10, 2), default=0.00
    )  # Today's realized P&L only (resets daily)

    # Margin tracking - stores exact margin blocked for this position
    # This prevents margin release bugs when execution price differs from order placement price
    margin_blocked = Column(DECIMAL(15, 2), default=0.00)  # Total margin blocked for this position

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=func.now())
    updated_at = Column(DateTime, nullable=False, default=func.now(), onupdate=func.now())

    __table_args__ = (
        UniqueConstraint("user_id", "symbol", "exchange", "product", name="unique_position"),
        Index("idx_user_product", "user_id", "product"),
    )


class SandboxHoldings(Base):
    """Sandbox holdings table - T+1 settled CNC positions"""

    __tablename__ = "sandbox_holdings"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String(50), nullable=False, index=True)
    symbol = Column(String(50), nullable=False, index=True)
    exchange = Column(String(20), nullable=False, index=True)
    quantity = Column(Integer, nullable=False)  # Total holdings quantity
    average_price = Column(DECIMAL(10, 2), nullable=False)  # Average buy price

    # MTM tracking
    ltp = Column(DECIMAL(10, 2), nullable=True)  # Last traded price
    pnl = Column(DECIMAL(10, 2), default=0.00)  # Unrealized P&L
    pnl_percent = Column(DECIMAL(10, 4), default=0.00)  # P&L percentage

    # Settlement tracking
    settlement_date = Column(Date, nullable=False)  # Date when position was settled to holdings

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=func.now())
    updated_at = Column(DateTime, nullable=False, default=func.now(), onupdate=func.now())

    __table_args__ = (UniqueConstraint("user_id", "symbol", "exchange", name="unique_holding"),)


class SandboxFunds(Base):
    """Sandbox funds table - simulated capital and margin tracking"""

    __tablename__ = "sandbox_funds"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String(50), unique=True, nullable=False, index=True)

    # Fund balances
    total_capital = Column(DECIMAL(15, 2), default=10000000.00)  # ₹1 Crore starting capital
    available_balance = Column(DECIMAL(15, 2), default=10000000.00)  # Available for trading
    used_margin = Column(DECIMAL(15, 2), default=0.00)  # Margin blocked in positions

    # P&L tracking
    realized_pnl = Column(
        DECIMAL(15, 2), default=0.00
    )  # Realized profit/loss from closed positions (all-time)
    today_realized_pnl = Column(
        DECIMAL(15, 2), default=0.00
    )  # Today's realized P&L only (resets daily)
    unrealized_pnl = Column(DECIMAL(15, 2), default=0.00)  # Unrealized P&L from open positions
    total_pnl = Column(DECIMAL(15, 2), default=0.00)  # Total P&L (realized + unrealized)

    # Reset tracking
    last_reset_date = Column(DateTime, nullable=False, default=func.now())
    reset_count = Column(Integer, default=0)  # Number of times reset has occurred

    # Timestamps
    created_at = Column(DateTime, nullable=False, default=func.now())
    updated_at = Column(DateTime, nullable=False, default=func.now(), onupdate=func.now())


class SandboxDailyPnL(Base):
    """Sandbox daily P&L snapshots - tracks end-of-day P&L for historical reporting"""

    __tablename__ = "sandbox_daily_pnl"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String(50), nullable=False, index=True)
    date = Column(Date, nullable=False, index=True)  # Trading date

    # Realized P&L (from closed positions/trades)
    realized_pnl = Column(DECIMAL(15, 2), default=0.00)

    # Unrealized P&L (from open positions + holdings at EOD)
    positions_unrealized_pnl = Column(DECIMAL(15, 2), default=0.00)  # Open positions MTM
    holdings_unrealized_pnl = Column(DECIMAL(15, 2), default=0.00)  # Holdings MTM

    # Total MTM = Realized + Unrealized
    total_mtm = Column(DECIMAL(15, 2), default=0.00)

    # Portfolio value at EOD
    available_balance = Column(DECIMAL(15, 2), default=0.00)
    used_margin = Column(DECIMAL(15, 2), default=0.00)
    portfolio_value = Column(DECIMAL(15, 2), default=0.00)  # Total value including positions

    # Metadata
    created_at = Column(DateTime, nullable=False, default=func.now())

    __table_args__ = (
        UniqueConstraint("user_id", "date", name="unique_user_daily_pnl"),
        Index("idx_user_date", "user_id", "date"),
    )


class SandboxConfig(Base):
    """Sandbox configuration table - all configurable settings"""

    __tablename__ = "sandbox_config"

    id = Column(Integer, primary_key=True, autoincrement=True)
    config_key = Column(String(100), unique=True, nullable=False, index=True)
    config_value = Column(Text, nullable=False)
    description = Column(Text, nullable=True)
    updated_at = Column(DateTime, nullable=False, default=func.now(), onupdate=func.now())


class SandboxGTT(Base):
    """A single GTT (Good Till Triggered) trigger - single-leg or two-leg OCO.

    State machine: active -> triggered | cancelled | expired | rejected.
    Children (legs) carry the order payloads and the per-leg ``triggering``
    intermediate state used by the atomic-claim concurrency pattern.
    """

    __tablename__ = "sandbox_gtt"

    id = Column(Integer, primary_key=True, autoincrement=True)

    # Broker-neutral OpenAlgo-side ID (sandbox-minted). Format:
    # ``GTT-YYMMDD-<8hex>`` - parallels the sandbox orderid scheme but prefixed
    # to make origin obvious in logs.
    gtt_id = Column(String(50), unique=True, nullable=False, index=True)

    user_id = Column(String(50), nullable=False, index=True)
    strategy = Column(String(100), nullable=True)

    # "single" | "two-leg"
    trigger_type = Column(String(10), nullable=False)

    symbol = Column(String(50), nullable=False, index=True)
    exchange = Column(String(20), nullable=False, index=True)

    # Snapshot of the instrument's LTP at the time the GTT was placed. Kept for
    # broker parity (Kite's /gtt/triggers echoes it back) and monitor diagnostics.
    last_price = Column(DECIMAL(10, 2), nullable=False)

    # active -> triggered | cancelled | expired | rejected
    gtt_status = Column(String(20), nullable=False, default="active", index=True)

    # Authoritative margin blocked for this GTT. ``max(legs)`` in ``max`` mode
    # (default) or ``sum(legs)`` in ``sum`` mode per
    # ``SandboxConfig.gtt_oco_margin_mode``. Equals the leg's margin for single-leg.
    margin_blocked = Column(DECIMAL(15, 2), nullable=False, default=0.00)

    # Wall-clock expiry (Zerodha parity: default 365d from placement). Nullable.
    expires_at = Column(DateTime, nullable=True)

    # IST wall-clock like every other sandbox stamp. func.now() is SQLite's
    # CURRENT_TIMESTAMP, which is UTC, so these two columns were the only
    # sandbox timestamps 5h30 behind the order book and the GTT's own expiry.
    created_at = Column(DateTime, nullable=False, default=ist_now)
    updated_at = Column(DateTime, nullable=False, default=ist_now, onupdate=ist_now)

    legs = relationship(
        "SandboxGTTLeg",
        back_populates="gtt",
        cascade="all, delete-orphan",
        order_by="SandboxGTTLeg.leg_number",
    )

    __table_args__ = (
        Index("idx_gtt_user_status", "user_id", "gtt_status"),
        Index("idx_gtt_symbol_exchange", "symbol", "exchange"),
        CheckConstraint("trigger_type IN ('single', 'two-leg')", name="check_gtt_trigger_type"),
        CheckConstraint(
            "gtt_status IN ('active', 'triggered', 'cancelled', 'expired', 'rejected')",
            name="check_gtt_status",
        ),
    )


class SandboxGTTLeg(Base):
    """One leg (order payload + trigger price) belonging to a GTT.

    State machine: pending -> triggering -> triggered | cancelled.
    The ``triggering`` intermediate state is the atomic-claim target: evaluators
    CAS-flip the row from ``pending`` to ``triggering`` in a single conditional
    UPDATE; only the winner proceeds to ``_fire_leg``. ``claimed_at`` lets the
    stranded-leg reaper reclaim rows stuck in ``triggering`` after a crash.
    """

    __tablename__ = "sandbox_gtt_legs"

    id = Column(Integer, primary_key=True, autoincrement=True)

    gtt_id = Column(
        String(50),
        ForeignKey("sandbox_gtt.gtt_id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    # 1 for single-leg GTTs; 1 or 2 for two-leg OCO. Preserves pairing order
    # with the parent GTT's ``trigger_values`` list.
    leg_number = Column(Integer, nullable=False)

    trigger_price = Column(DECIMAL(10, 2), nullable=False)

    # Which way the market must move to fire this leg: "below" when the trigger
    # sits under the LTP at placement (triggerprice_sl - SELL stop-loss, BUY the
    # dip) and "above" when it sits over it (triggerprice_tg - BUY breakout,
    # SELL at target). Stored because the direction is a property of the trigger
    # role, NOT of the leg's action: a BUY-on-dip fires falling and a
    # SELL-at-target fires rising, so deriving it from BUY/SELL inverts both.
    trigger_direction = Column(String(5), nullable=False, default="below")

    action = Column(String(10), nullable=False)  # BUY | SELL
    quantity = Column(Integer, nullable=False)
    price = Column(DECIMAL(10, 2), nullable=False)
    pricetype = Column(String(10), nullable=False, default="LIMIT")
    product = Column(String(10), nullable=False)  # CNC | NRML | MIS

    # pending -> triggering -> triggered | cancelled
    leg_status = Column(String(20), nullable=False, default="pending")

    # Orderid of the sandbox_orders row inserted when this leg fired.
    triggered_order_id = Column(String(50), nullable=True)

    # Per-leg margin captured at GTT placement. Exact amount to release from
    # ``SandboxGTT.margin_blocked`` when this leg fires (sum mode) or the anchor
    # to compare against the blocked-max when releasing (max mode). Stored here
    # so release is deterministic even if the user flips
    # ``gtt_oco_margin_mode`` mid-flight.
    leg_margin = Column(DECIMAL(15, 2), nullable=False, default=0.00)

    # Set to CURRENT_TIMESTAMP on the CAS claim UPDATE; cleared (NULL) on revert
    # or any final transition. The stranded-leg reaper reads this column to
    # find legs stuck in ``triggering`` after a worker crash.
    claimed_at = Column(DateTime, nullable=True)

    # IST wall-clock like every other sandbox stamp. func.now() is SQLite's
    # CURRENT_TIMESTAMP, which is UTC, so these two columns were the only
    # sandbox timestamps 5h30 behind the order book and the GTT's own expiry.
    created_at = Column(DateTime, nullable=False, default=ist_now)
    updated_at = Column(DateTime, nullable=False, default=ist_now, onupdate=ist_now)

    gtt = relationship("SandboxGTT", back_populates="legs")

    __table_args__ = (
        # Covers both the active-trigger scan (leg_status='pending') and the
        # reaper's stale-claim query (leg_status='triggering' AND claimed_at < cutoff).
        Index("idx_gtt_leg_status_claimed", "leg_status", "claimed_at"),
        CheckConstraint(
            "trigger_direction IN ('below', 'above')", name="check_gtt_trigger_direction"
        ),
        CheckConstraint(
            "leg_status IN ('pending', 'triggering', 'triggered', 'cancelled')",
            name="check_gtt_leg_status",
        ),
        CheckConstraint("action IN ('BUY', 'SELL')", name="check_gtt_leg_action"),
        CheckConstraint("product IN ('CNC', 'NRML', 'MIS')", name="check_gtt_leg_product"),
    )


def init_db():
    """Initialize sandbox database and tables"""
    from database.db_init_helper import init_db_with_logging

    init_db_with_logging(Base, engine, "Sandbox DB", logger)

    _migrate_add_gtt_trigger_direction()
    _migrate_add_order_gtt_leg_id()

    # Initialize default configuration
    init_default_config()


def _migrate_add_order_gtt_leg_id():
    """Add sandbox_orders.gtt_leg_id to databases created without it."""
    from sqlalchemy import text

    try:
        with engine.connect() as conn:
            existing = {row[1] for row in conn.execute(text("PRAGMA table_info(sandbox_orders)"))}
            if not existing or "gtt_leg_id" in existing:
                return
            conn.execute(text("ALTER TABLE sandbox_orders ADD COLUMN gtt_leg_id INTEGER"))
            # SQLite cannot add a UNIQUE column by ALTER, so the constraint is
            # created as an index afterwards. Partial, because every non-GTT
            # order leaves this NULL and many NULLs must stay allowed.
            conn.execute(
                text(
                    "CREATE UNIQUE INDEX IF NOT EXISTS idx_sandbox_orders_gtt_leg "
                    "ON sandbox_orders(gtt_leg_id) WHERE gtt_leg_id IS NOT NULL"
                )
            )
            conn.commit()
            logger.info("Added sandbox_orders.gtt_leg_id")
    except Exception as e:
        logger.exception(f"Could not add sandbox_orders.gtt_leg_id: {e}")


def _migrate_add_gtt_trigger_direction():
    """Add sandbox_gtt_legs.trigger_direction to databases created without it.

    create_all() only creates missing tables, never missing columns, so an
    install that already has sandbox_gtt_legs would keep a table with no
    direction column and every GTT read would fail. Existing rows default to
    "below", which is the safe reading: it is the direction a stop-loss uses,
    and the leg is re-evaluated on the next tick either way.
    """
    from sqlalchemy import text

    try:
        with engine.connect() as conn:
            existing = {
                row[1] for row in conn.execute(text("PRAGMA table_info(sandbox_gtt_legs)"))
            }
            if not existing or "trigger_direction" in existing:
                return
            conn.execute(
                text(
                    "ALTER TABLE sandbox_gtt_legs ADD COLUMN trigger_direction "
                    "VARCHAR(5) NOT NULL DEFAULT 'below'"
                )
            )
            # Backfill from the data rather than leaving every existing leg at
            # the column default. A leg whose trigger sits above the price
            # recorded when the GTT was placed is a target leg and fires on a
            # rise; calling it 'below' would fire it on the wrong side, and for
            # an already-active GTT that means an unexpected order.
            conn.execute(
                text(
                    "UPDATE sandbox_gtt_legs SET trigger_direction = 'above' "
                    "WHERE gtt_id IN (SELECT gtt_id FROM sandbox_gtt) "
                    "AND trigger_price > ("
                    "  SELECT last_price FROM sandbox_gtt "
                    "  WHERE sandbox_gtt.gtt_id = sandbox_gtt_legs.gtt_id"
                    ")"
                )
            )
            conn.commit()
            logger.info(
                "Added sandbox_gtt_legs.trigger_direction and backfilled it from "
                "each leg's trigger price relative to the GTT's placement price"
            )
    except Exception as e:
        logger.exception(f"Could not add sandbox_gtt_legs.trigger_direction: {e}")


def init_default_config():
    """Initialize default sandbox configuration"""
    from sqlalchemy.exc import IntegrityError

    default_configs = [
        {
            "config_key": "starting_capital",
            "config_value": "10000000.00",
            "description": "Starting sandbox capital in INR (₹1 Crore) - Min: ₹1000",
        },
        {
            "config_key": "reset_day",
            "config_value": "Never",
            "description": "Day of week for automatic fund reset (Never = disabled)",
        },
        {
            "config_key": "reset_time",
            "config_value": "00:00",
            "description": "Time for automatic fund reset (IST)",
        },
        {
            "config_key": "order_check_interval",
            "config_value": "5",
            "description": "Interval in seconds to check pending orders - Range: 1-30 seconds",
        },
        {
            "config_key": "mtm_update_interval",
            "config_value": "5",
            "description": "Interval in seconds to update MTM - Range: 0-60 seconds (0 = manual only)",
        },
        {
            "config_key": "nse_bse_square_off_time",
            "config_value": "15:15",
            "description": "Square-off time for NSE/BSE MIS positions (IST)",
        },
        {
            "config_key": "cds_bcd_square_off_time",
            "config_value": "16:45",
            "description": "Square-off time for CDS/BCD MIS positions (IST)",
        },
        {
            "config_key": "mcx_square_off_time",
            "config_value": "23:30",
            "description": "Square-off time for MCX MIS positions (IST)",
        },
        {
            "config_key": "ncdex_square_off_time",
            "config_value": "17:00",
            "description": "Square-off time for NCDEX MIS positions (IST)",
        },
        {
            "config_key": "equity_mis_leverage",
            "config_value": "5",
            "description": "Leverage multiplier for equity MIS (NSE/BSE) - Range: 1-50x",
        },
        {
            "config_key": "equity_cnc_leverage",
            "config_value": "1",
            "description": "Leverage multiplier for equity CNC (NSE/BSE) - Range: 1-50x",
        },
        {
            "config_key": "futures_leverage",
            "config_value": "10",
            "description": "Leverage multiplier for all futures (NFO/BFO/CDS/BCD/MCX/NCDEX) - Range: 1-50x",
        },
        {
            "config_key": "option_buy_leverage",
            "config_value": "1",
            "description": "Leverage for buying options (full premium) - Range: 1-50x",
        },
        {
            "config_key": "option_sell_leverage",
            "config_value": "1",
            "description": "Leverage for selling options (same as buying - full premium) - Range: 1-50x",
        },
        {
            "config_key": "order_rate_limit",
            "config_value": "10",
            "description": "Maximum orders per second - Range: 1-100 orders/sec (for future use)",
        },
        {
            "config_key": "api_rate_limit",
            "config_value": "50",
            "description": "Maximum API calls per second - Range: 1-1000 calls/sec (for future use)",
        },
        {
            "config_key": "smart_order_rate_limit",
            "config_value": "2",
            "description": "Maximum smart orders per second - Range: 1-50 orders/sec (for future use)",
        },
        {
            "config_key": "smart_order_delay",
            "config_value": "0.5",
            "description": "Delay between multi-leg smart orders - Range: 0.1-10 seconds (for future use)",
        },
        {
            "config_key": "expiry_settlement_timing",
            "config_value": "expiry_day_close",
            "description": "When expired F&O settles: 'expiry_day_close' (at exchange close on expiry day) or 'next_day' (from midnight after expiry)",
        },
        {
            "config_key": "option_expiry_settlement",
            "config_value": "ltp",
            "description": "Expired option settlement price: 'ltp' (last traded price, keeps ITM value) or 'zero' (all options expire worthless)",
        },
        {
            "config_key": "gtt_oco_margin_mode",
            "config_value": "max",
            "description": "OCO GTT margin mode: 'max' (block only the larger leg) or 'sum'",
        },
        {
            "config_key": "gtt_claim_timeout_sec",
            "config_value": "60",
            "description": "Seconds after which a GTT leg stuck in 'triggering' is reclaimed to 'pending'",
        },
    ]

    for config in default_configs:
        try:
            existing = SandboxConfig.query.filter_by(config_key=config["config_key"]).first()
            if not existing:
                config_obj = SandboxConfig(**config)
                db_session.add(config_obj)
                db_session.commit()
                logger.debug(f"Added default config: {config['config_key']}")
        except IntegrityError:
            db_session.rollback()
            logger.debug(f"Config already exists: {config['config_key']}")
        except Exception as e:
            db_session.rollback()
            logger.exception(f"Error adding config {config['config_key']}: {e}")


def get_config(config_key, default=None):
    """Get configuration value by key"""
    try:
        config = SandboxConfig.query.filter_by(config_key=config_key).first()
        if config:
            return config.config_value
        return default
    except Exception as e:
        logger.exception(f"Error fetching config {config_key}: {e}")
        return default


def set_config(config_key, config_value, description=None):
    """Set configuration value"""
    try:
        config = SandboxConfig.query.filter_by(config_key=config_key).first()
        if config:
            config.config_value = str(config_value)
            if description:
                config.description = description
        else:
            config = SandboxConfig(
                config_key=config_key, config_value=str(config_value), description=description
            )
            db_session.add(config)
        db_session.commit()
        logger.info(f"Updated config: {config_key} = {config_value}")
        return True
    except Exception as e:
        db_session.rollback()
        logger.exception(f"Error setting config {config_key}: {e}")
        return False


def get_all_configs():
    """Get all configuration values"""
    try:
        configs = SandboxConfig.query.all()
        return {
            config.config_key: {"value": config.config_value, "description": config.description}
            for config in configs
        }
    except Exception as e:
        logger.exception(f"Error fetching all configs: {e}")
        return {}
