# database/settings_db.py

import base64
import os

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from sqlalchemy import Boolean, Column, Integer, MetaData, String, Text, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import scoped_session, sessionmaker
from sqlalchemy.pool import NullPool

from database.auth_db import PEPPER
from utils.logging import get_logger
from utils.thread_safe_cache import MISSING, LockedTTLCache

logger = get_logger(__name__)

# Settings cache - 1 hour TTL (settings rarely change)
# This cache significantly reduces DB queries since get_analyze_mode() is called on every request
#
# get_analyze_mode() decides whether an order goes to the broker or to the
# sandbox, so a stale entry is an order sent to the wrong place for up to the
# TTL. Readers fill with the generation they read before their query, and
# every writer invalidates after its commit, so a read that raced a toggle is
# returned to its own caller but never cached (see utils/thread_safe_cache).
_settings_cache = LockedTTLCache(maxsize=10, ttl=3600)  # 1 hour TTL

DATABASE_URL = os.getenv("DATABASE_URL")

# Conditionally create engine based on DB type
if DATABASE_URL and "sqlite" in DATABASE_URL:
    # SQLite: Use NullPool to prevent connection pool exhaustion
    engine = create_engine(
        DATABASE_URL, poolclass=NullPool, connect_args={"check_same_thread": False}
    )
else:
    # For other databases like PostgreSQL, use connection pooling
    engine = create_engine(DATABASE_URL, pool_size=50, max_overflow=100, pool_timeout=10)

db_session = scoped_session(sessionmaker(autocommit=False, autoflush=False, bind=engine))
Base = declarative_base()
Base.query = db_session.query_property()


class Settings(Base):
    __tablename__ = "settings"
    id = Column(Integer, primary_key=True)
    analyze_mode = Column(Boolean, default=False)  # Default to Live Mode

    # SMTP Configuration
    smtp_server = Column(String(255), nullable=True)
    smtp_port = Column(Integer, nullable=True)
    smtp_username = Column(String(255), nullable=True)
    smtp_password_encrypted = Column(Text, nullable=True)  # Encrypted SMTP password
    smtp_use_tls = Column(Boolean, default=True)
    smtp_from_email = Column(String(255), nullable=True)
    smtp_helo_hostname = Column(String(255), nullable=True)  # HELO/EHLO hostname

    # Security Settings
    security_auto_ban_enabled = Column(Boolean, default=False)  # Auto-ban disabled by default
    security_404_threshold = Column(Integer, default=100)  # 404 errors per day before ban
    security_404_ban_duration = Column(Integer, default=0)  # 0 = permanent ban
    security_api_threshold = Column(Integer, default=100)  # Invalid API attempts before ban
    security_api_ban_duration = Column(Integer, default=0)  # 0 = permanent ban
    security_repeat_offender_limit = Column(Integer, default=2)  # Bans before permanent ban


def init_db():
    """Initialize the settings database"""
    from database.db_init_helper import init_db_with_logging

    init_db_with_logging(Base, engine, "Settings DB", logger)

    # Create default settings only if no settings exist (with race condition protection)
    try:
        if not Settings.query.first():
            logger.debug("Settings DB: Creating default configuration (Live Mode)")
            default_settings = Settings(analyze_mode=False)
            db_session.add(default_settings)
            db_session.commit()
    except Exception as e:
        db_session.rollback()
        logger.debug(f"Settings DB: Default config may already exist (race condition): {e}")


def get_analyze_mode():
    """Get current analyze mode setting (cached for 1 hour)"""
    cache_key = "analyze_mode"

    # Check cache first. One get, never a membership test then a subscript:
    # the entry can go between the two, and the KeyError failed the order.
    cached = _settings_cache.get(cache_key, MISSING)
    if cached is not MISSING:
        return cached

    # Cache miss - query database. The generation is read first, so a toggle
    # that commits while this read is in flight keeps its value in the cache.
    generation = _settings_cache.generation
    settings = Settings.query.first()
    if not settings:
        settings = Settings(analyze_mode=False)  # Default to Live Mode
        db_session.add(settings)
        db_session.commit()

    # Store in cache
    mode = settings.analyze_mode
    _settings_cache.fill(cache_key, mode, generation)
    return mode


def set_analyze_mode(mode: bool):
    """Set analyze mode setting"""
    settings = Settings.query.first()
    if not settings:
        settings = Settings(analyze_mode=mode)
        db_session.add(settings)
    else:
        settings.analyze_mode = mode
    db_session.commit()

    # Invalidate cache after update. After the commit, never before, and an
    # invalidation rather than a delete: a reader that loaded the old mode
    # before this commit is then refused when it tries to store it.
    _settings_cache.invalidate("analyze_mode")


# SMTP password encryption.
#
# New ciphertext uses a strong PBKDF2-HMAC-SHA256 key derived from the
# validated API_KEY_PEPPER (imported from auth_db, which fails fast if the
# pepper is missing or too short) plus a dedicated salt -- the same KDF
# discipline as database/telegram_db.py. Older installs stored the SMTP
# password under a weak legacy key (the raw pepper, padded/truncated to 32
# bytes with no KDF); _decrypt_password() transparently falls back to that
# legacy key so existing values keep working, and re-saving SMTP settings
# re-encrypts under the strong key, migrating it forward.
SMTP_KEY_SALT = os.getenv("SMTP_KEY_SALT", "smtp-openalgo-salt").encode()


def _get_smtp_fernet() -> Fernet:
    """Strong Fernet for the SMTP password: PBKDF2(PEPPER, SMTP_KEY_SALT)."""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=SMTP_KEY_SALT,
        iterations=100000,
    )
    return Fernet(base64.urlsafe_b64encode(kdf.derive(PEPPER.encode())))


def _legacy_smtp_fernet() -> Fernet:
    """Legacy read-only key (raw pepper, no KDF). Used only to decrypt values
    stored before the switch to _get_smtp_fernet(); never for new writes.
    """
    return Fernet(base64.urlsafe_b64encode(PEPPER.ljust(32)[:32].encode()))


# Module-level cipher; PEPPER is fixed for the process lifetime.
_smtp_fernet = _get_smtp_fernet()


def _encrypt_password(password: str) -> str:
    """Encrypt SMTP password with the strong per-install key."""
    if not password:
        return None
    return _smtp_fernet.encrypt(password.encode()).decode()


def _decrypt_password(encrypted_password: str) -> str:
    """Decrypt SMTP password, falling back to the legacy key for values
    written before the KDF upgrade."""
    if not encrypted_password:
        return None
    token = encrypted_password.encode()
    try:
        return _smtp_fernet.decrypt(token).decode()
    except InvalidToken:
        return _legacy_smtp_fernet().decrypt(token).decode()


def get_smtp_settings():
    """Get SMTP configuration"""
    settings = Settings.query.first()
    if not settings:
        return None

    return {
        "smtp_server": settings.smtp_server,
        "smtp_port": settings.smtp_port,
        "smtp_username": settings.smtp_username,
        "smtp_password": _decrypt_password(settings.smtp_password_encrypted)
        if settings.smtp_password_encrypted
        else None,
        "smtp_use_tls": settings.smtp_use_tls,
        "smtp_from_email": settings.smtp_from_email,
        "smtp_helo_hostname": settings.smtp_helo_hostname,
    }


def set_smtp_settings(
    smtp_server=None,
    smtp_port=None,
    smtp_username=None,
    smtp_password=None,
    smtp_use_tls=True,
    smtp_from_email=None,
    smtp_helo_hostname=None,
):
    """Set SMTP configuration"""
    settings = Settings.query.first()
    if not settings:
        settings = Settings(analyze_mode=False)
        db_session.add(settings)

    if smtp_server is not None:
        settings.smtp_server = smtp_server
    if smtp_port is not None:
        settings.smtp_port = smtp_port
    if smtp_username is not None:
        settings.smtp_username = smtp_username
    if smtp_password is not None:
        settings.smtp_password_encrypted = _encrypt_password(smtp_password)
    if smtp_use_tls is not None:
        settings.smtp_use_tls = smtp_use_tls
    if smtp_from_email is not None:
        settings.smtp_from_email = smtp_from_email
    if smtp_helo_hostname is not None:
        settings.smtp_helo_hostname = smtp_helo_hostname

    db_session.commit()
    logger.info("SMTP settings updated successfully")


def get_security_settings():
    """Get security configuration (cached for 1 hour)"""
    cache_key = "security_settings"

    # Check cache first
    cached = _settings_cache.get(cache_key, MISSING)
    if cached is not MISSING:
        return cached

    # Cache miss - query database
    generation = _settings_cache.generation
    settings = Settings.query.first()
    if not settings:
        # Create with defaults
        settings = Settings(
            analyze_mode=False,
            security_auto_ban_enabled=False,
            security_404_threshold=100,
            security_404_ban_duration=0,
            security_api_threshold=100,
            security_api_ban_duration=0,
            security_repeat_offender_limit=2,
        )
        db_session.add(settings)
        db_session.commit()

    result = {
        "auto_ban_enabled": bool(settings.security_auto_ban_enabled) if settings.security_auto_ban_enabled is not None else False,
        "404_threshold": settings.security_404_threshold or 100,
        "404_ban_duration": settings.security_404_ban_duration if settings.security_404_ban_duration is not None else 0,
        "api_threshold": settings.security_api_threshold or 100,
        "api_ban_duration": settings.security_api_ban_duration if settings.security_api_ban_duration is not None else 0,
        "repeat_offender_limit": settings.security_repeat_offender_limit or 2,
    }

    # Store in cache
    _settings_cache.fill(cache_key, result, generation)
    return result


def set_security_settings(
    auto_ban_enabled=None,
    threshold_404=None,
    ban_duration_404=None,
    threshold_api=None,
    ban_duration_api=None,
    repeat_offender_limit=None,
):
    """Set security configuration"""
    settings = Settings.query.first()
    if not settings:
        settings = Settings(analyze_mode=False)
        db_session.add(settings)

    if auto_ban_enabled is not None:
        settings.security_auto_ban_enabled = auto_ban_enabled
    if threshold_404 is not None:
        settings.security_404_threshold = threshold_404
    if ban_duration_404 is not None:
        settings.security_404_ban_duration = ban_duration_404
    if threshold_api is not None:
        settings.security_api_threshold = threshold_api
    if ban_duration_api is not None:
        settings.security_api_ban_duration = ban_duration_api
    if repeat_offender_limit is not None:
        settings.security_repeat_offender_limit = repeat_offender_limit

    db_session.commit()
    logger.info("Security settings updated successfully")

    # Invalidate cache after update
    _settings_cache.invalidate("security_settings")


def clear_settings_cache():
    """
    Clear all settings caches.
    Called on logout/session expiry to ensure fresh data on next login.
    """
    _settings_cache.invalidate()
    logger.info("Settings cache cleared")
