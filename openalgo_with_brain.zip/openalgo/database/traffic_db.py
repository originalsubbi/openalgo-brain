import json
import logging
import os
from datetime import datetime, timedelta

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    create_engine,
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import scoped_session, sessionmaker
from sqlalchemy.pool import NullPool
from sqlalchemy.sql import func

from database.settings_db import get_security_settings
from utils.keyed_locks import KeyedLocks
from utils.thread_safe_cache import MISSING, LockedTTLCache

logger = logging.getLogger(__name__)

# Use a separate database for logs
LOGS_DATABASE_URL = os.getenv("LOGS_DATABASE_URL", "sqlite:///db/logs.db")

# Conditionally create engine based on DB type
if LOGS_DATABASE_URL and "sqlite" in LOGS_DATABASE_URL:
    # SQLite: Use NullPool — each checkout creates a fresh connection, and
    # closing it returns the FD immediately.  Session cleanup (which prevents
    # FD leaks) is handled by:
    #   - app.py teardown_appcontext (removes all scoped sessions per request)
    #   - traffic_logger.py (logs_session.remove() in finally block)
    #   - security_middleware.py (logs_session.remove() for banned-IP path)
    # StaticPool (single shared connection) must NOT be used here: concurrent
    # requests on the same SQLite connection cause "bad parameter or other API
    # misuse" and "cannot commit — SQL statements in progress" errors on all
    # platforms (Windows, Mac, Linux).
    logs_engine = create_engine(
        LOGS_DATABASE_URL, poolclass=NullPool, connect_args={"check_same_thread": False}
    )
else:
    # For other databases like PostgreSQL, use connection pooling
    logs_engine = create_engine(LOGS_DATABASE_URL, pool_size=50, max_overflow=100, pool_timeout=10)

logs_session = scoped_session(sessionmaker(autocommit=False, autoflush=False, bind=logs_engine))
LogBase = declarative_base()
LogBase.query = logs_session.query_property()

# Ban-status cache: SecurityMiddleware checks every request at the WSGI layer,
# which with NullPool means a fresh SQLite connection per request. Cache the
# verdict per IP; ban_ip/unban_ip invalidate so enforcement stays immediate
# (bans are only mutated in-process — single-instance deployment).
#
# A LockedTTLCache filled with the generation read before the query: under the
# gthread worker a ban committed while another request's check is in flight
# would otherwise be overwritten by that check's "not banned" for the TTL.
_ip_ban_cache = LockedTTLCache(maxsize=2048, ttl=60)

# The abuse trackers read a counter, add one and write it back. Two requests
# from one address at once (a scanner, under the gthread worker) would each
# read the same count and lose an increment, and two first hits would each
# insert a row. One lock per (tracker, address) serialises exactly those, and
# nothing else: unrelated addresses never wait on each other. The locks are
# stdlib ones (green under eventlet), because the holder does database I/O.
_tracker_locks = KeyedLocks(name="abuse-trackers")


class TrafficLog(LogBase):
    """Model for traffic logging"""

    __tablename__ = "traffic_logs"

    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    client_ip = Column(String(50), nullable=False)
    method = Column(String(10), nullable=False)
    path = Column(String(500), nullable=False)
    status_code = Column(Integer, nullable=False)
    duration_ms = Column(Float, nullable=False)
    host = Column(String(500))
    error = Column(String(500))
    user_id = Column(Integer)  # No foreign key since it's a separate database

    # Performance indexes for common query patterns
    __table_args__ = (
        Index(
            "idx_traffic_timestamp", "timestamp"
        ),  # Speeds up time-based queries and log retrieval
        Index("idx_traffic_client_ip", "client_ip"),  # Speeds up IP-based filtering and analytics
        Index("idx_traffic_status_code", "status_code"),  # Speeds up error rate calculations
        Index("idx_traffic_user_id", "user_id"),  # Speeds up per-user traffic analysis
        Index(
            "idx_traffic_ip_timestamp", "client_ip", "timestamp"
        ),  # Composite for IP + time range queries
    )

    @staticmethod
    def log_request(
        client_ip, method, path, status_code, duration_ms, host=None, error=None, user_id=None
    ):
        """Log a request to the database"""
        try:
            log = TrafficLog(
                client_ip=client_ip,
                method=method,
                path=path,
                status_code=status_code,
                duration_ms=duration_ms,
                host=host,
                error=error,
                user_id=user_id,
            )
            logs_session.add(log)
            logs_session.commit()
            return True
        except Exception as e:
            logger.exception(f"Error logging traffic: {str(e)}")
            logs_session.rollback()
            return False

    @staticmethod
    def get_recent_logs(limit=100):
        """Get recent traffic logs ordered by timestamp"""
        try:
            return TrafficLog.query.order_by(TrafficLog.timestamp.desc()).limit(limit).all()
        except Exception as e:
            logger.exception(f"Error getting recent logs: {str(e)}")
            return []

    @staticmethod
    def get_stats():
        """Get basic traffic statistics"""
        try:
            from sqlalchemy import func

            total_requests = TrafficLog.query.count()
            error_requests = TrafficLog.query.filter(TrafficLog.status_code >= 400).count()
            avg_duration = logs_session.query(func.avg(TrafficLog.duration_ms)).scalar() or 0

            return {
                "total_requests": total_requests,
                "error_requests": error_requests,
                "avg_duration": round(float(avg_duration), 2),
            }
        except Exception as e:
            logger.exception(f"Error getting traffic stats: {str(e)}")
            return {"total_requests": 0, "error_requests": 0, "avg_duration": 0}


class IPBan(LogBase):
    """Model for banned IPs"""

    __tablename__ = "ip_bans"

    id = Column(Integer, primary_key=True)
    ip_address = Column(String(50), unique=True, nullable=False, index=True)
    ban_reason = Column(String(200))
    ban_count = Column(Integer, default=1)  # Track repeat offenses
    banned_at = Column(DateTime(timezone=True), server_default=func.now())
    expires_at = Column(DateTime(timezone=True))  # NULL means permanent ban
    is_permanent = Column(Boolean, default=False)
    created_by = Column(String(50), default="system")  # 'system' or 'manual'

    @staticmethod
    def is_ip_banned(ip_address):
        """Check if an IP is currently banned"""
        cached = _ip_ban_cache.get(ip_address, MISSING)
        if cached is not MISSING:
            return cached

        # Read before the query: a ban committed while this check is in flight
        # invalidates the entry, and this verdict is then not cached over it.
        generation = _ip_ban_cache.generation
        try:
            ban = IPBan.query.filter_by(ip_address=ip_address).first()
            if not ban:
                _ip_ban_cache.fill(ip_address, False, generation)
                return False

            # Check permanent ban
            if ban.is_permanent:
                _ip_ban_cache.fill(ip_address, True, generation)
                return True

            # Check temporary ban expiry
            if ban.expires_at:
                if datetime.utcnow() < ban.expires_at.replace(tzinfo=None):
                    _ip_ban_cache.fill(ip_address, True, generation)
                    return True
                else:
                    # Ban expired, remove it
                    logs_session.delete(ban)
                    logs_session.commit()
                    _ip_ban_cache.fill(ip_address, False, generation)
                    return False

            _ip_ban_cache.fill(ip_address, False, generation)
            return False
        except Exception as e:
            logger.exception(f"Error checking IP ban status: {e}")
            logs_session.rollback()
            return False

    @staticmethod
    def ban_ip(ip_address, reason, duration_hours=24, permanent=False, created_by="system"):
        """Ban an IP address"""
        try:
            # Never ban localhost
            if ip_address in ["127.0.0.1", "::1", "localhost"]:
                logger.warning(f"Attempted to ban localhost IP {ip_address} - ignoring")
                return False

            # Get repeat offender limit from settings
            security_settings = get_security_settings()
            repeat_limit = security_settings["repeat_offender_limit"]

            existing_ban = IPBan.query.filter_by(ip_address=ip_address).first()

            if existing_ban:
                # Increment ban count for repeat offender
                existing_ban.ban_count += 1
                existing_ban.ban_reason = reason
                existing_ban.banned_at = datetime.utcnow()

                # After configured number of bans, make it permanent
                if existing_ban.ban_count >= repeat_limit:
                    existing_ban.is_permanent = True
                    existing_ban.expires_at = None
                    logger.warning(
                        f"IP {ip_address} permanently banned after {existing_ban.ban_count} offenses"
                    )
                else:
                    existing_ban.is_permanent = permanent
                    existing_ban.expires_at = (
                        None if permanent else datetime.utcnow() + timedelta(hours=duration_hours)
                    )
            else:
                # Create new ban
                ban = IPBan(
                    ip_address=ip_address,
                    ban_reason=reason,
                    is_permanent=permanent,
                    expires_at=None
                    if permanent
                    else datetime.utcnow() + timedelta(hours=duration_hours),
                    created_by=created_by,
                )
                logs_session.add(ban)

            logs_session.commit()
            _ip_ban_cache.invalidate(ip_address)
            logger.info(f"IP {ip_address} banned: {reason}")
            return True
        except Exception as e:
            logger.exception(f"Error banning IP {ip_address}: {e}")
            logs_session.rollback()
            return False

    @staticmethod
    def unban_ip(ip_address):
        """Remove IP ban"""
        try:
            ban = IPBan.query.filter_by(ip_address=ip_address).first()
            if ban:
                logs_session.delete(ban)
                logs_session.commit()
                _ip_ban_cache.invalidate(ip_address)
                logger.info(f"IP {ip_address} unbanned")
                return True
            return False
        except Exception as e:
            logger.exception(f"Error unbanning IP: {e}")
            logs_session.rollback()
            return False

    @staticmethod
    def get_all_bans():
        """Get all current IP bans"""
        try:
            # Remove expired bans first
            expired = IPBan.query.filter(
                IPBan.is_permanent == False, IPBan.expires_at < datetime.utcnow()
            ).all()

            expired_ips = [ban.ip_address for ban in expired]
            for ban in expired:
                logs_session.delete(ban)

            logs_session.commit()
            for ip_address in expired_ips:
                _ip_ban_cache.invalidate(ip_address)

            # Return active bans
            return IPBan.query.all()
        except Exception as e:
            logger.exception(f"Error getting IP bans: {e}")
            return []


class Error404Tracker(LogBase):
    """Track 404 errors per IP for bot detection"""

    __tablename__ = "error_404_tracker"

    id = Column(Integer, primary_key=True)
    ip_address = Column(String(50), nullable=False, index=True)
    error_count = Column(Integer, default=1)
    first_error_at = Column(DateTime(timezone=True), server_default=func.now())
    last_error_at = Column(DateTime(timezone=True), server_default=func.now())
    paths_attempted = Column(Text)  # JSON array of attempted paths

    # Performance indexes for security monitoring
    __table_args__ = (
        Index("idx_404_error_count", "error_count"),  # Speeds up get_suspicious_ips() filtering
        Index("idx_404_first_error_at", "first_error_at"),  # Speeds up old entry cleanup
    )

    @staticmethod
    def track_404(ip_address, path):
        """Track a 404 error for an IP.

        Serialised per address, so parallel 404s from one scanner each count.
        """
        with _tracker_locks.hold(("404", ip_address)):
            return Error404Tracker._track_404_locked(ip_address, path)

    @staticmethod
    def _track_404_locked(ip_address, path):
        """The read-modify-write behind track_404. Call with the address locked."""
        try:
            # Check if already banned
            if IPBan.is_ip_banned(ip_address):
                return False

            # Get security settings from database
            security_settings = get_security_settings()
            threshold_404 = security_settings["404_threshold"]
            ban_duration_404 = security_settings["404_ban_duration"]

            now = datetime.utcnow()
            tracker = Error404Tracker.query.filter_by(ip_address=ip_address).first()

            if tracker:
                # Check if tracking period expired (24 hours)
                if (now - tracker.first_error_at.replace(tzinfo=None)).days >= 1:
                    # Reset counter for new day
                    tracker.error_count = 1
                    tracker.first_error_at = now
                    tracker.paths_attempted = json.dumps([path])
                else:
                    # Increment counter
                    tracker.error_count += 1

                    # Add path to attempted paths
                    paths = json.loads(tracker.paths_attempted or "[]")
                    if path not in paths:
                        paths.append(path)
                        tracker.paths_attempted = json.dumps(paths[-50:])  # Keep last 50 paths

                tracker.last_error_at = now

                # Auto-ban if enabled and threshold reached (configurable via Security Dashboard)
                if security_settings.get("auto_ban_enabled", False) and tracker.error_count >= threshold_404:
                    # Don't ban localhost IPs
                    if ip_address not in ['127.0.0.1', '::1', 'localhost']:
                        # Ban the IP (duration 0 = permanent)
                        IPBan.ban_ip(
                            ip_address=ip_address,
                            reason=f"Exceeded 404 threshold: {tracker.error_count} errors in 24 hours",
                            duration_hours=ban_duration_404,
                            permanent=(ban_duration_404 == 0),
                            created_by='404_detector'
                        )

                        # Clean up tracker entry
                        logs_session.delete(tracker)
            else:
                # Create new tracker
                tracker = Error404Tracker(
                    ip_address=ip_address, error_count=1, paths_attempted=json.dumps([path])
                )
                logs_session.add(tracker)

            logs_session.commit()
            return True

        except Exception as e:
            logger.exception(f"Error tracking 404: {e}")
            logs_session.rollback()
            return False

    @staticmethod
    def get_suspicious_ips(min_errors=5):
        """Get IPs with suspicious 404 activity"""
        try:
            # Clean up old entries (older than 24 hours)
            cutoff = datetime.utcnow() - timedelta(days=1)
            old_entries = Error404Tracker.query.filter(
                Error404Tracker.first_error_at < cutoff
            ).all()

            for entry in old_entries:
                logs_session.delete(entry)

            logs_session.commit()

            # Return suspicious IPs
            return (
                Error404Tracker.query.filter(Error404Tracker.error_count >= min_errors)
                .order_by(Error404Tracker.error_count.desc())
                .all()
            )
        except Exception as e:
            logger.exception(f"Error getting suspicious IPs: {e}")
            return []


class InvalidAPIKeyTracker(LogBase):
    """Track invalid API key attempts per IP"""

    __tablename__ = "invalid_api_key_tracker"

    id = Column(Integer, primary_key=True)
    ip_address = Column(String(50), nullable=False, index=True)
    attempt_count = Column(Integer, default=1)
    first_attempt_at = Column(DateTime(timezone=True), server_default=func.now())
    last_attempt_at = Column(DateTime(timezone=True), server_default=func.now())
    api_keys_tried = Column(Text)  # JSON array of API keys tried (hashed)

    # Performance indexes for security monitoring
    __table_args__ = (
        Index(
            "idx_api_tracker_attempt_count", "attempt_count"
        ),  # Speeds up get_suspicious_api_users() filtering
        Index(
            "idx_api_tracker_first_attempt_at", "first_attempt_at"
        ),  # Speeds up old entry cleanup
    )

    @staticmethod
    def track_invalid_api_key(ip_address, api_key_hash=None):
        """Track an invalid API key attempt.

        Serialised per address, so parallel attempts from one address each count.
        """
        with _tracker_locks.hold(("api", ip_address)):
            return InvalidAPIKeyTracker._track_invalid_api_key_locked(ip_address, api_key_hash)

    @staticmethod
    def _track_invalid_api_key_locked(ip_address, api_key_hash=None):
        """The read-modify-write behind track_invalid_api_key. Call with the address locked."""
        try:
            # Check if already banned
            if IPBan.is_ip_banned(ip_address):
                return False

            # Get security settings from database
            security_settings = get_security_settings()
            threshold_api = security_settings["api_threshold"]
            ban_duration_api = security_settings["api_ban_duration"]

            now = datetime.utcnow()
            tracker = InvalidAPIKeyTracker.query.filter_by(ip_address=ip_address).first()

            if tracker:
                # Check if tracking period expired (24 hours)
                if (now - tracker.first_attempt_at.replace(tzinfo=None)).days >= 1:
                    # Reset counter for new day
                    tracker.attempt_count = 1
                    tracker.first_attempt_at = now
                    tracker.api_keys_tried = json.dumps([api_key_hash] if api_key_hash else [])
                else:
                    # Increment counter
                    tracker.attempt_count += 1

                    # Add API key hash to tried list
                    if api_key_hash:
                        keys_tried = json.loads(tracker.api_keys_tried or "[]")
                        if api_key_hash not in keys_tried:
                            keys_tried.append(api_key_hash)
                            tracker.api_keys_tried = json.dumps(
                                keys_tried[-20:]
                            )  # Keep last 20 keys

                tracker.last_attempt_at = now

                # Auto-ban if enabled and threshold reached (configurable via Security Dashboard)
                if security_settings.get("auto_ban_enabled", False) and tracker.attempt_count >= threshold_api:
                    # Don't ban localhost IPs but keep tracking
                    if ip_address not in ['127.0.0.1', '::1', 'localhost']:
                        # Ban the IP (duration 0 = permanent)
                        success = IPBan.ban_ip(
                            ip_address=ip_address,
                            reason=f"Exceeded invalid API key threshold: {tracker.attempt_count} attempts in 24 hours",
                            duration_hours=ban_duration_api,
                            permanent=(ban_duration_api == 0),
                            created_by='api_key_detector'
                        )

                        # Only delete tracker if ban was successful
                        if success:
                            logs_session.delete(tracker)
            else:
                # Create new tracker
                tracker = InvalidAPIKeyTracker(
                    ip_address=ip_address,
                    attempt_count=1,
                    api_keys_tried=json.dumps([api_key_hash] if api_key_hash else []),
                )
                logs_session.add(tracker)

            logs_session.commit()
            return True

        except Exception as e:
            logger.exception(f"Error tracking invalid API key: {e}")
            logs_session.rollback()
            return False

    @staticmethod
    def get_suspicious_api_users(min_attempts=3):
        """Get IPs with suspicious API key activity"""
        try:
            # Clean up old entries (older than 24 hours)
            cutoff = datetime.utcnow() - timedelta(days=1)
            old_entries = InvalidAPIKeyTracker.query.filter(
                InvalidAPIKeyTracker.first_attempt_at < cutoff
            ).all()

            for entry in old_entries:
                logs_session.delete(entry)

            logs_session.commit()

            # Return suspicious IPs
            return (
                InvalidAPIKeyTracker.query.filter(
                    InvalidAPIKeyTracker.attempt_count >= min_attempts
                )
                .order_by(InvalidAPIKeyTracker.attempt_count.desc())
                .all()
            )
        except Exception as e:
            logger.exception(f"Error getting suspicious API users: {e}")
            return []


def purge_old_traffic_logs(days=None):
    """Delete traffic log entries older than the retention window.

    Without this, logs.db grows unbounded (every request ever made is kept)
    and the traffic/security dashboards slow down over time. Called once at
    startup from init_traffic_logging().

    Args:
        days: Retention in days. Defaults to TRAFFIC_LOG_RETENTION_DAYS
            env var (30 if unset).

    Returns:
        Number of rows deleted.
    """
    if days is None:
        days = int(os.getenv("TRAFFIC_LOG_RETENTION_DAYS", "30"))

    try:
        cutoff = datetime.utcnow() - timedelta(days=days)
        deleted = (
            logs_session.query(TrafficLog)
            .filter(TrafficLog.timestamp < cutoff)
            .delete(synchronize_session=False)
        )
        logs_session.commit()
        if deleted:
            logger.debug(f"Purged {deleted} traffic log entries older than {days} days")
        return deleted
    except Exception as e:
        logger.exception(f"Error purging old traffic logs: {e}")
        logs_session.rollback()
        return 0
    finally:
        logs_session.remove()


def init_logs_db():
    """Initialize the logs database"""
    # Extract directory from database URL and create if it doesn't exist
    db_path = LOGS_DATABASE_URL.replace("sqlite:///", "")
    db_dir = os.path.dirname(db_path)
    if db_dir:
        os.makedirs(db_dir, exist_ok=True)

    from database.db_init_helper import init_db_with_logging

    init_db_with_logging(LogBase, logs_engine, "Traffic Logs DB", logger)
