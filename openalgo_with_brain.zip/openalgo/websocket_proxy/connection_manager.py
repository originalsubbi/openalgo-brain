"""
Connection Manager for WebSocket Proxy

Handles multiple WebSocket connections per broker to overcome symbol limits.
Each broker typically limits symbols per WebSocket session (e.g., Angel: 1000, Zerodha: 3000).
This module manages connection pooling transparently without modifying broker adapters.

Configuration:
    MAX_SYMBOLS_PER_WEBSOCKET: Maximum symbols per single WebSocket connection (default: 1000)
    MAX_WEBSOCKET_CONNECTIONS: Maximum WebSocket connections per user/broker (default: 3)
"""

import json
import os
import threading
from collections import defaultdict
from collections.abc import Callable
from typing import Any

import zmq

from utils.logging import get_logger

logger = get_logger(__name__)

# Thread-local storage for pooled adapter creation context
# This allows BaseBrokerWebSocketAdapter to detect when it's being created
# within a ConnectionPool and skip its own ZMQ socket creation
_pooled_creation_context = threading.local()


def is_pooled_creation() -> bool:
    """Check if we're currently creating an adapter within a ConnectionPool"""
    return getattr(_pooled_creation_context, "active", False)


def get_shared_publisher_for_pooled_creation():
    """Get the shared publisher during pooled adapter creation"""
    return getattr(_pooled_creation_context, "shared_publisher", None)


# Default configuration - can be overridden via environment variables
DEFAULT_MAX_SYMBOLS_PER_WEBSOCKET = 1000
DEFAULT_MAX_WEBSOCKET_CONNECTIONS = 3


def get_max_symbols_per_websocket() -> int:
    """Get maximum symbols per WebSocket connection from config"""
    return int(os.getenv("MAX_SYMBOLS_PER_WEBSOCKET", DEFAULT_MAX_SYMBOLS_PER_WEBSOCKET))


def get_max_websocket_connections() -> int:
    """Get maximum WebSocket connections from config"""
    return int(os.getenv("MAX_WEBSOCKET_CONNECTIONS", DEFAULT_MAX_WEBSOCKET_CONNECTIONS))


# Keywords used to recognize auth-related failures returned by broker adapters.
# Matches 401/403 plus the common token-expiry phrasings emitted by broker REST
# APIs and WS clients. Used by ConnectionPool to decide whether a connect or
# subscribe failure is recoverable via a forced re-init that reads a fresh
# token from auth_db. See issue #1419.
_AUTH_ERROR_INDICATORS = (
    "401",
    "403",
    "unauthorized",
    "forbidden",
    "authentication failed",
    "auth failed",
    "invalid token",
    "token expired",
    "access token has expired",
    "access denied",
    "invalid credentials",
    "session expired",
)


def _is_auth_error(error_message: str) -> bool:
    """True if ``error_message`` looks like an auth failure (401/403/expired)."""
    if not error_message:
        return False
    msg = str(error_message).lower()
    return any(indicator in msg for indicator in _AUTH_ERROR_INDICATORS)


class SharedZmqPublisher:
    """
    Shared ZeroMQ publisher that can be used by multiple adapter instances.
    Ensures all connections publish to the same ZeroMQ socket, so the WebSocketProxy
    receives data from all connections on a single port.

    The singleton is built completely before it is published. It used to be
    published by ``__new__`` and then set up by ``__init__``, which marked it
    initialised before creating the context, the socket and the connection
    flag: a second thread arriving in between got the half-built object and
    failed reading ``_connected``, so a cache invalidation after a re-login or
    an order update was silently dropped. ``SharedZmqPublisher()`` and
    :meth:`instance` both return the finished object.
    """

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        """Singleton pattern to ensure only one shared publisher exists"""
        return cls.instance()

    @classmethod
    def instance(cls) -> "SharedZmqPublisher":
        """Return the shared publisher, building it on first use.

        Built and set up entirely under ``_lock``, and only then published,
        so no caller can see a publisher without its socket.
        """
        existing = cls._instance
        if existing is not None:
            return existing
        with cls._lock:
            if cls._instance is None:
                publisher = super().__new__(cls)
                publisher._setup()
                cls._instance = publisher
            return cls._instance

    def __init__(self):
        # Construction happens once, in instance(); calling the class again
        # must not reset a publisher other threads are using.
        pass

    def _setup(self) -> None:
        self.logger = get_logger("shared_zmq_publisher")
        self.zmq_port = None
        self._connected = False
        self._publish_lock = threading.Lock()
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.PUB)
        self.socket.setsockopt(zmq.LINGER, 1000)
        self.socket.setsockopt(zmq.SNDHWM, 1000)
        self._initialized = True

    @property
    def connected(self) -> bool:
        """True once connect() has attached this publisher to the proxy's SUB."""
        return self._connected

    def connect(self) -> int:
        """Connect this PUB to the proxy's SUB on the ZMQ bus.

        Fan-in topology: the websocket_proxy SUB is the SOLE binder; every
        publisher CONNECTs to it. Connecting — rather than the old bind +
        port-scan — lets publishers in different processes (this shared
        market-data publisher, plus the cache-invalidation publisher) share one
        fixed rendezvous port with no bind race. The old scan is exactly what
        stranded this publisher on 5556 while the SUB listened on 5555, so no
        ticks were delivered. Idempotent: connects only once.

        Returns:
            The ZMQ port this publisher is connected to.
        """
        if self._connected:
            return self.zmq_port

        with self._lock:
            if self._connected:
                return self.zmq_port

            # Internal message bus — loopback by default. Operators who genuinely
            # need a multi-host setup can point ZMQ_HOST at the proxy's address.
            zmq_host = os.getenv("ZMQ_HOST", "127.0.0.1")
            zmq_port = int(os.getenv("ZMQ_PORT", "5555"))
            endpoint = f"tcp://{zmq_host}:{zmq_port}"
            self.socket.connect(endpoint)
            self.zmq_port = zmq_port
            self._connected = True
            self.logger.debug(f"Shared ZMQ publisher connected to {endpoint}")
            return zmq_port

    def publish(self, topic: str, data: dict):
        """
        Publish market data to ZeroMQ subscribers.
        Thread-safe publishing.

        Args:
            topic: Topic string for subscriber filtering
            data: Market data dictionary
        """
        if not self._connected:
            self.logger.error("Cannot publish: ZMQ publisher not connected")
            return

        with self._publish_lock:
            if self.socket is None:
                # cleanup() closed it; a publish racing the shutdown is dropped.
                self.logger.debug("Cannot publish: ZMQ publisher already closed")
                return
            try:
                self.socket.send_multipart(
                    [topic.encode("utf-8"), json.dumps(data).encode("utf-8")]
                )
            except Exception as e:
                self.logger.exception(f"Error publishing to ZMQ: {e}")

    def cleanup(self):
        """Clean up ZeroMQ resources with separate error handling for each step"""
        # Under the publish lock, so no publish can be using the socket while
        # it closes (a ZMQ socket must never be used from two threads at once).
        with self._publish_lock:
            # Close socket first (separate try/except to ensure context.term() is attempted)
            try:
                if self.socket:
                    self.socket.close(linger=0)
            except Exception as e:
                self.logger.warning(f"Error closing shared ZMQ socket: {e}")
            finally:
                self.socket = None

            # Terminate context (always attempt even if socket.close() failed)
            try:
                if self.context:
                    self.context.term()
            except Exception as e:
                self.logger.warning(f"Error terminating shared ZMQ context: {e}")
            finally:
                self.context = None

            # Reset state
            self._connected = False
            self._initialized = False
        with SharedZmqPublisher._lock:
            if SharedZmqPublisher._instance is self:
                SharedZmqPublisher._instance = None
        self.logger.info("Shared ZMQ publisher cleaned up")


class ConnectionPool:
    """
    Manages multiple WebSocket connections for a single broker/user.

    Automatically creates new connections when symbol limits are reached,
    up to the configured maximum. Distributes subscriptions across connections
    and aggregates data from all connections through a shared ZeroMQ publisher.

    Usage:
        pool = ConnectionPool(
            adapter_class=AngelWebSocketAdapter,
            broker_name='angel',
            user_id='user123'
        )
        pool.initialize()
        pool.connect()
        pool.subscribe('RELIANCE', 'NSE', mode=2)
    """

    def __init__(
        self,
        adapter_class: type,
        broker_name: str,
        user_id: str,
        max_symbols_per_connection: int | None = None,
        max_connections: int | None = None,
    ):
        """
        Initialize the connection pool.

        Args:
            adapter_class: The broker adapter class to instantiate
            broker_name: Name of the broker (e.g., 'angel', 'zerodha')
            user_id: User ID for authentication
            max_symbols_per_connection: Max symbols per WebSocket (default from config)
            max_connections: Max WebSocket connections (default from config)
        """
        self.adapter_class = adapter_class
        self.broker_name = broker_name
        self.user_id = user_id
        self.max_symbols = max_symbols_per_connection or get_max_symbols_per_websocket()
        self.max_connections = max_connections or get_max_websocket_connections()

        self.logger = get_logger(f"connection_pool_{broker_name}")
        self.lock = threading.RLock()

        # Connection tracking
        self.adapters: list[Any] = []  # List of adapter instances
        self.adapter_symbol_counts: list[int] = []  # Symbols per adapter

        # Subscription tracking: (symbol, exchange, mode) -> adapter_index
        self.subscription_map: dict[tuple[str, str, int], int] = {}
        # Per-subscription depth_level so auth-recovery restore can re-issue
        # mode=3 (Depth) at its originally requested depth, not the default.
        self.subscription_depths: dict[tuple[str, str, int], int] = {}

        # Shared ZeroMQ publisher
        self.shared_publisher = SharedZmqPublisher()

        # State
        self.initialized = False
        self.connected = False

        # Peak usage tracking (for logging purposes)
        self.peak_total_symbols = 0
        self.peak_connections_used = 0
        self.peak_symbol_counts = []  # Snapshot of counts at peak

        self.logger.info("[POOL] ========== CONNECTION POOL INITIALIZED ==========")
        self.logger.info(f"[POOL] Broker: {broker_name} | User: {user_id}")
        self.logger.info(
            f"[POOL] Config: {self.max_symbols} symbols/connection x {self.max_connections} max connections = {self.max_symbols * self.max_connections} total capacity"
        )
        self.logger.info("[POOL] ==================================================")

    def _create_adapter(self) -> Any:
        """
        Create a new adapter instance configured to use the shared ZeroMQ publisher.

        Returns:
            New adapter instance
        """
        # Ensure shared publisher is connected to the bus
        self.shared_publisher.connect()

        # Set context flag so BaseBrokerWebSocketAdapter knows to skip ZMQ creation
        _pooled_creation_context.active = True
        _pooled_creation_context.shared_publisher = self.shared_publisher

        try:
            # Create adapter instance
            # BaseBrokerWebSocketAdapter will detect the context and skip ZMQ socket creation
            adapter = self.adapter_class()

            # Override the adapter's publish method to use shared publisher
            def shared_publish(topic: str, data: dict):
                self.shared_publisher.publish(topic, data)

            adapter.publish_market_data = shared_publish

            # Mark that this adapter uses shared ZMQ (to skip individual cleanup)
            adapter._uses_shared_zmq = True
            adapter._shared_publisher = self.shared_publisher

            return adapter

        finally:
            # Clear context flag
            _pooled_creation_context.active = False
            _pooled_creation_context.shared_publisher = None

    def _get_adapter_with_capacity(self) -> tuple[int, Any]:
        """
        Get an adapter with available capacity, or create a new one.

        Returns:
            Tuple of (adapter_index, adapter_instance)

        Raises:
            RuntimeError: If max connections reached and all are full
        """
        with self.lock:
            # Find adapter with capacity
            for idx, count in enumerate(self.adapter_symbol_counts):
                if count < self.max_symbols:
                    return idx, self.adapters[idx]

            # Need new adapter
            if len(self.adapters) >= self.max_connections:
                total_symbols = sum(self.adapter_symbol_counts)
                raise RuntimeError(
                    f"Maximum capacity reached: {self.max_connections} connections × "
                    f"{self.max_symbols} symbols = {self.max_connections * self.max_symbols} symbols. "
                    f"Currently subscribed to {total_symbols} symbols."
                )

            # Create new adapter
            prev_conn_symbols = self.adapter_symbol_counts[-1] if self.adapter_symbol_counts else 0
            total_symbols = sum(self.adapter_symbol_counts)
            self.logger.info(
                f"[POOL] Creating NEW connection {len(self.adapters) + 1}/{self.max_connections} "
                f"for {self.broker_name} (previous connection full: {prev_conn_symbols}/{self.max_symbols} symbols, "
                f"total subscribed: {total_symbols})"
            )

            adapter = self._create_adapter()

            # Initialize and connect the new adapter
            adapter.initialize(self.broker_name, self.user_id)
            adapter.connect()

            self.adapters.append(adapter)
            self.adapter_symbol_counts.append(0)

            return len(self.adapters) - 1, adapter

    def _get_existing_modes(self, symbol: str, exchange: str) -> dict[int, int]:
        """
        Return {mode: adapter_idx} for all tracked subscriptions of this symbol/exchange.
        Must be called while holding self.lock.
        """
        return {
            m: idx
            for (s, e, m), idx in self.subscription_map.items()
            if s == symbol and e == exchange
        }

    def initialize(
        self, broker_name: str = None, user_id: str = None, auth_data: dict = None, force: bool = False
    ) -> dict:
        """
        Initialize the connection pool with the first adapter.

        Args:
            broker_name: Optional broker name override
            user_id: Optional user ID override
            auth_data: Optional authentication data
            force: If True, force re-initialization even if already initialized.
                   Used for retrying with fresh credentials after auth errors (issue #765).

        Returns:
            Initialization result dict
        """
        if self.initialized and not force:
            return {"success": True, "message": "Already initialized"}

        with self.lock:
            # If forcing re-initialization, clean up existing adapters first (inside lock to prevent race conditions)
            if force and self.initialized:
                self.logger.info(f"Force re-initializing pool for {self.broker_name} with fresh credentials")
                # Disconnect existing adapters
                for adapter in self.adapters:
                    try:
                        adapter.disconnect()
                    except Exception as e:
                        self.logger.warning(f"Error disconnecting adapter during re-init: {e}")
                self.adapters.clear()
                self.adapter_symbol_counts.clear()
                self.subscription_map.clear()
                self.subscription_depths.clear()
                self.connected = False
                self.initialized = False
            try:
                # Use provided values or defaults
                self.broker_name = broker_name or self.broker_name
                self.user_id = user_id or self.user_id

                # Ensure shared publisher is connected to the bus
                self.shared_publisher.connect()

                # Create first adapter
                adapter = self._create_adapter()
                result = adapter.initialize(self.broker_name, self.user_id, auth_data)

                # Handle both response formats from adapters:
                # - {"success": False, "error": "..."} (ConnectionPool format)
                # - {"status": "error", "code": "...", "message": "..."} (Adapter format)
                is_error = (
                    (result and result.get("success") is False) or
                    (result and result.get("status") == "error")
                )
                if is_error:
                    error_msg = result.get("message", result.get("error", "Initialization failed"))
                    self.logger.error(f"Adapter initialization failed: {error_msg}")
                    return {"success": False, "error": error_msg}

                self.adapters.append(adapter)
                self.adapter_symbol_counts.append(0)
                self.initialized = True

                self.logger.info(f"ConnectionPool initialized for {self.broker_name}")
                return {"success": True, "message": "Connection pool initialized"}

            except Exception as e:
                self.logger.exception(f"Failed to initialize connection pool: {e}")
                return {"success": False, "error": str(e)}

    def _clear_auth_cache_for_user(self) -> None:
        """Drop cached auth tokens for this pool's user.

        The next ``initialize(force=True)`` then re-reads from ``auth_db`` and
        constructs adapters with the fresh token. Called when an auth error is
        detected on connect/subscribe (issue #1419).
        """
        try:
            from database.auth_db import invalidate_user_auth_cache

            cleared = invalidate_user_auth_cache(self.user_id)
            if cleared:
                self.logger.info(
                    f"Cleared auth caches for user {self.user_id}: {', '.join(cleared)}"
                )
        except Exception as e:
            self.logger.warning(f"Error clearing auth cache for user {self.user_id}: {e}")

    def _attempt_auth_recovery(self, error_msg: str) -> bool:
        """Rebuild the pool with a fresh token after an auth failure.

        Tears down the existing adapter (which was constructed with a stale
        token), clears cached auth state, re-initializes the pool — which
        re-reads the token from ``auth_db`` — and reconnects. Existing
        subscriptions are snapshotted before the rebuild and re-issued on the
        new adapter so callers don't silently lose their feeds.

        Does not recurse into ``self.connect()``; it calls the adapter's
        ``connect()`` directly on the freshly rebuilt adapter. Returns ``True``
        when the post-refresh reconnect succeeds.
        """
        self.logger.warning(
            f"Auth error on {self.broker_name} (user={self.user_id}): {error_msg}. "
            f"Refreshing token and rebuilding pool."
        )

        # Snapshot (symbol, exchange, mode, depth_level) before
        # initialize(force=True) clears subscription_map / subscription_depths.
        with self.lock:
            prior_subs = [
                (s, e, m, self.subscription_depths.get((s, e, m), 5))
                for (s, e, m) in self.subscription_map
            ]

        self._clear_auth_cache_for_user()
        reinit = self.initialize(force=True)
        if not reinit.get("success"):
            self.logger.error(
                f"Pool re-initialization after auth error failed: {reinit.get('error')}"
            )
            return False
        if not self.adapters:
            return False
        result = self.adapters[0].connect()
        is_error = (result and result.get("success") is False) or (
            result and result.get("status") == "error"
        )
        if is_error:
            err = result.get("message", result.get("error", "Connection failed"))
            self.logger.error(f"Reconnect after auth refresh failed: {err}")
            return False
        self.connected = True

        if prior_subs:
            self.logger.info(
                f"Restoring {len(prior_subs)} subscription(s) after auth refresh"
            )
            restored = 0
            for symbol, exchange, mode, depth in prior_subs:
                try:
                    sub_result = self._subscribe_inner(symbol, exchange, mode, depth)
                    if sub_result.get("status") == "success":
                        restored += 1
                    else:
                        self.logger.warning(
                            f"Failed to restore {symbol}.{exchange} mode={mode}: "
                            f"{sub_result.get('message')}"
                        )
                except Exception as e:
                    self.logger.warning(
                        f"Error restoring {symbol}.{exchange} mode={mode}: {e}"
                    )
            self.logger.info(
                f"Restored {restored}/{len(prior_subs)} subscriptions after auth refresh"
            )

        self.logger.info(
            f"Auth recovery succeeded for {self.broker_name} (user={self.user_id})"
        )
        return True

    def connect(self) -> dict:
        """
        Connect the first adapter in the pool.
        Additional connections are created on-demand when capacity is needed.

        Returns:
            Connection result dict
        """
        if not self.initialized:
            return {"success": False, "error": "Not initialized"}

        if self.connected:
            return {"success": True, "message": "Already connected"}

        with self.lock:
            try:
                if self.adapters:
                    result = self.adapters[0].connect()
                    # Handle both response formats from adapters:
                    # - {"success": False, "error": "..."} (ConnectionPool format)
                    # - {"status": "error", "code": "...", "message": "..."} (Adapter format)
                    is_error = (
                        (result and result.get("success") is False) or
                        (result and result.get("status") == "error")
                    )
                    if is_error:
                        error_msg = result.get("message", result.get("error", "Connection failed"))
                        # Issue #1419: try recovery once if this looks like a stale
                        # auth token (new trading day, etc.) before surfacing the
                        # error. _attempt_auth_recovery() does not call back into
                        # self.connect(), so no recursion; _recovering guards against
                        # repeat attempts on the same call.
                        if _is_auth_error(error_msg) and not getattr(self, "_recovering", False):
                            self._recovering = True
                            try:
                                if self._attempt_auth_recovery(error_msg):
                                    return {"success": True, "message": "Connected after auth refresh"}
                            finally:
                                self._recovering = False
                        self.logger.error(f"Adapter connection failed: {error_msg}")
                        return {"success": False, "error": error_msg}
                    self.connected = True
                    return {"success": True, "message": "Connected"}
                else:
                    return {"success": False, "error": "No adapters available"}

            except Exception as e:
                err_str = str(e)
                # Some adapters raise instead of returning an error dict; apply the
                # same recovery path if the exception message looks auth-related.
                if _is_auth_error(err_str) and not getattr(self, "_recovering", False):
                    self._recovering = True
                    try:
                        if self._attempt_auth_recovery(err_str):
                            return {"success": True, "message": "Connected after auth refresh"}
                    finally:
                        self._recovering = False
                self.logger.exception(f"Failed to connect: {e}")
                return {"success": False, "error": err_str}

    def subscribe(self, symbol: str, exchange: str, mode: int = 2, depth_level: int = 5) -> dict:
        """
        Subscribe to market data, automatically using connection with capacity.

        Implements mode hierarchy: Depth (3) > Quote (2) > LTP (1).
        Higher modes include all data from lower modes, so only the highest
        requested mode is sent to the broker. All requested modes are tracked
        in subscription_map so unsubscribe can downgrade correctly.

        Issue #1419: if the underlying subscribe fails with what looks like a
        stale auth token, the pool tears itself down, re-reads the token from
        ``auth_db``, and retries once.

        Args:
            symbol: Trading symbol
            exchange: Exchange code
            mode: Subscription mode (1=LTP, 2=Quote, 3=Depth)
            depth_level: Market depth level

        Returns:
            Subscription result dict
        """
        result = self._subscribe_inner(symbol, exchange, mode, depth_level)

        if (
            isinstance(result, dict)
            and result.get("status") == "error"
            and _is_auth_error(result.get("message", ""))
            and not getattr(self, "_recovering", False)
        ):
            self._recovering = True
            try:
                if self._attempt_auth_recovery(result.get("message", "")):
                    result = self._subscribe_inner(symbol, exchange, mode, depth_level)
            finally:
                self._recovering = False

        return result

    def _subscribe_inner(
        self, symbol: str, exchange: str, mode: int = 2, depth_level: int = 5
    ) -> dict:
        """Core subscribe logic without the auth-recovery wrapper.

        ``subscribe()`` wraps this so it can retry once after a forced pool
        refresh when an auth error is detected.
        """
        sub_key = (symbol, exchange, mode)

        with self.lock:
            # Already subscribed in this exact mode
            if sub_key in self.subscription_map:
                return {
                    "status": "success",
                    "message": f"Already subscribed to {symbol}.{exchange}",
                    "connection": self.subscription_map[sub_key] + 1,
                }

            existing_modes = self._get_existing_modes(symbol, exchange)
            highest_existing = max(existing_modes.keys()) if existing_modes else 0

            try:
                if existing_modes:
                    # Reuse the same adapter as existing subscriptions
                    adapter_idx = existing_modes[highest_existing]
                    adapter = self.adapters[adapter_idx]

                    if mode > highest_existing:
                        # UPGRADE: new mode is higher — tell broker to switch up
                        result = adapter.subscribe(symbol, exchange, mode, depth_level)
                        if result.get("status") == "success":
                            self.subscription_map[sub_key] = adapter_idx
                            self.subscription_depths[sub_key] = depth_level
                            # Don't increment adapter_symbol_counts — same symbol, already counted
                            result["connection"] = adapter_idx + 1
                            self.logger.info(
                                f"[POOL] Upgraded {symbol}.{exchange} from mode {highest_existing} "
                                f"to mode {mode} on connection {adapter_idx + 1}"
                            )
                        return result
                    else:
                        # COVERED: higher mode already active — just track, skip broker call
                        self.subscription_map[sub_key] = adapter_idx
                        self.subscription_depths[sub_key] = depth_level
                        # Don't increment adapter_symbol_counts — same symbol, already counted
                        self.logger.debug(
                            f"Tracked {symbol}.{exchange} mode {mode} "
                            f"(covered by active mode {highest_existing})"
                        )
                        return {
                            "status": "success",
                            "message": f"Subscribed to {symbol}.{exchange} (covered by mode {highest_existing})",
                            "connection": adapter_idx + 1,
                        }
                else:
                    # NEW SYMBOL: normal path
                    adapter_idx, adapter = self._get_adapter_with_capacity()
                    result = adapter.subscribe(symbol, exchange, mode, depth_level)

                    if result.get("status") == "success":
                        self.subscription_map[sub_key] = adapter_idx
                        self.subscription_depths[sub_key] = depth_level
                        self.adapter_symbol_counts[adapter_idx] += 1
                        symbols_on_conn = self.adapter_symbol_counts[adapter_idx]
                        total_symbols = sum(self.adapter_symbol_counts)

                        # Update peak usage tracking
                        if total_symbols > self.peak_total_symbols:
                            self.peak_total_symbols = total_symbols
                            self.peak_connections_used = len(self.adapters)
                            self.peak_symbol_counts = list(self.adapter_symbol_counts)

                        # Add connection info to result
                        result["connection"] = adapter_idx + 1
                        result["total_connections"] = len(self.adapters)
                        result["symbols_on_connection"] = symbols_on_conn

                        # Log at key milestones
                        if symbols_on_conn == 1:
                            self.logger.info(
                                f"[POOL] Connection {adapter_idx + 1} started - "
                                f"first symbol: {symbol}.{exchange}"
                            )
                        elif symbols_on_conn % 100 == 0 or symbols_on_conn == self.max_symbols:
                            capacity_pct = (symbols_on_conn / self.max_symbols) * 100
                            self.logger.info(
                                f"[POOL] Connection {adapter_idx + 1}: "
                                f"{symbols_on_conn}/{self.max_symbols} symbols "
                                f"({capacity_pct:.0f}% full) | Total: {total_symbols} "
                                f"symbols across {len(self.adapters)} connection(s)"
                            )

                        self.logger.debug(
                            f"Subscribed {symbol}.{exchange} on connection {adapter_idx + 1}, "
                            f"symbols: {symbols_on_conn}/{self.max_symbols}"
                        )

                    return result

            except RuntimeError as e:
                # Max capacity reached
                return {"status": "error", "code": "MAX_CAPACITY_REACHED", "message": str(e)}
            except Exception as e:
                self.logger.exception(f"Error subscribing to {symbol}.{exchange}: {e}")
                return {"status": "error", "code": "SUBSCRIPTION_ERROR", "message": str(e)}

    def unsubscribe(self, symbol: str, exchange: str, mode: int = 2) -> dict:
        """
        Unsubscribe from market data.

        Implements mode hierarchy awareness: when the highest mode is removed but
        lower modes remain, the broker subscription is downgraded rather than
        fully removed. When a lower mode is removed while a higher mode is still
        active, only the tracking entry is removed (no broker call needed).

        Args:
            symbol: Trading symbol
            exchange: Exchange code
            mode: Subscription mode

        Returns:
            Unsubscription result dict
        """
        sub_key = (symbol, exchange, mode)

        with self.lock:
            if sub_key not in self.subscription_map:
                return {
                    "status": "error",
                    "code": "NOT_SUBSCRIBED",
                    "message": f"Not subscribed to {symbol}.{exchange}",
                }

            try:
                adapter_idx = self.subscription_map[sub_key]
                adapter = self.adapters[adapter_idx]

                # Remove tracking entry. Stash the prior depth so rollback paths
                # below can restore both maps atomically if the broker call fails.
                old_depth = self.subscription_depths.get(sub_key, 5)
                del self.subscription_map[sub_key]
                self.subscription_depths.pop(sub_key, None)

                # Check what modes remain for this symbol
                remaining_modes = self._get_existing_modes(symbol, exchange)

                if not remaining_modes:
                    # LAST mode removed — fully unsubscribe from broker
                    result = adapter.unsubscribe(symbol, exchange, mode)
                    if result.get("status") == "success":
                        self.adapter_symbol_counts[adapter_idx] -= 1
                        self.logger.debug(
                            f"Fully unsubscribed {symbol}.{exchange} from connection "
                            f"{adapter_idx + 1}, remaining: {self.adapter_symbol_counts[adapter_idx]}"
                        )
                    else:
                        # Rollback tracking on failure
                        self.subscription_map[sub_key] = adapter_idx
                        self.subscription_depths[sub_key] = old_depth
                    return result

                else:
                    new_highest = max(remaining_modes.keys())

                    if mode > new_highest:
                        # DOWNGRADE: removed the highest mode, broker needs to switch down
                        try:
                            release_result = adapter.unsubscribe(symbol, exchange, mode)
                        except Exception as release_error:
                            release_result = {
                                "status": "error",
                                "message": str(release_error),
                            }

                        if (
                            not isinstance(release_result, dict)
                            or release_result.get("status") != "success"
                        ):
                            self.subscription_map[sub_key] = adapter_idx
                            self.subscription_depths[sub_key] = old_depth
                            release_message = (
                                release_result.get("message", "broker release refused")
                                if isinstance(release_result, dict)
                                else "invalid broker release response"
                            )
                            return {
                                "status": "error",
                                "code": "DOWNGRADE_RELEASE_FAILED",
                                "message": (
                                    f"Could not release mode {mode} for "
                                    f"{symbol}.{exchange}: {release_message}"
                                ),
                                "phase": "release_high_mode",
                                "rollback": {"status": "not_required"},
                                "reconciliation_required": False,
                            }

                        lower_key = (symbol, exchange, new_highest)
                        lower_depth = self.subscription_depths.get(lower_key, 5)
                        try:
                            result = adapter.subscribe(
                                symbol, exchange, new_highest, lower_depth
                            )
                        except Exception as subscribe_error:
                            result = {
                                "status": "error",
                                "message": str(subscribe_error),
                            }

                        if (
                            isinstance(result, dict)
                            and result.get("status") == "success"
                        ):
                            self.logger.info(
                                f"[POOL] Downgraded {symbol}.{exchange} from mode {mode} "
                                f"to mode {new_highest} on connection {adapter_idx + 1}"
                            )
                            return {
                                "status": "success",
                                "message": f"Unsubscribed mode {mode}, downgraded to mode {new_highest}",
                                "phase": "complete",
                                "release": {"status": "success", "mode": mode},
                                "reconciliation_required": False,
                            }
                        else:
                            # Lower subscribe failed after a proven high release.
                            # Restore desired ownership and report whether the
                            # broker-side high-mode rollback also succeeded.
                            self.logger.error(
                                f"[POOL] Failed to downgrade {symbol}.{exchange} to mode "
                                f"{new_highest}, rolling back: {result}"
                            )
                            self.subscription_map[sub_key] = adapter_idx
                            self.subscription_depths[sub_key] = old_depth
                            try:
                                rollback_result = adapter.subscribe(
                                    symbol, exchange, mode, old_depth
                                )
                            except Exception as rollback_error:
                                rollback_result = {
                                    "status": "error",
                                    "message": str(rollback_error),
                                }

                            rollback_ok = (
                                isinstance(rollback_result, dict)
                                and rollback_result.get("status") == "success"
                            )
                            rollback_summary = {
                                "status": "success" if rollback_ok else "error",
                                "mode": mode,
                            }
                            if not rollback_ok:
                                rollback_summary["message"] = (
                                    rollback_result.get(
                                        "message", "broker rollback refused"
                                    )
                                    if isinstance(rollback_result, dict)
                                    else "invalid broker rollback response"
                                )
                            return {
                                "status": "error",
                                "code": (
                                    "DOWNGRADE_FAILED"
                                    if rollback_ok
                                    else "DOWNGRADE_RECONCILIATION_REQUIRED"
                                ),
                                "message": f"Failed to downgrade {symbol}.{exchange} to mode {new_highest}",
                                "phase": "subscribe_lower_mode",
                                "release": {"status": "success", "mode": mode},
                                "rollback": rollback_summary,
                                "reconciliation_required": not rollback_ok,
                            }
                    else:
                        # Removed a lower mode — broker still has the higher mode active
                        # No broker call needed
                        self.logger.debug(
                            f"Removed {symbol}.{exchange} mode {mode} tracking "
                            f"(broker still at mode {new_highest})"
                        )
                        return {
                            "status": "success",
                            "message": f"Unsubscribed from {symbol}.{exchange} mode {mode}",
                        }

            except Exception as e:
                # Rollback tracking on exception
                if sub_key not in self.subscription_map:
                    self.subscription_map[sub_key] = adapter_idx
                    self.subscription_depths[sub_key] = old_depth
                self.logger.exception(f"Error unsubscribing from {symbol}.{exchange}: {e}")
                return {"status": "error", "code": "UNSUBSCRIPTION_ERROR", "message": str(e)}

    def unsubscribe_all(self):
        """Unsubscribe from all symbols across all connections.

        Pool ownership is committed only when every child adapter explicitly
        acknowledges the release.  A caller can then disconnect the pool when
        any child refuses or returns an invalid response.
        """
        with self.lock:
            # Log stats before clearing
            total_symbols = sum(self.adapter_symbol_counts) if self.adapter_symbol_counts else 0
            num_connections = len(self.adapters)

            if total_symbols > 0:
                self.logger.info("[POOL] ========== UNSUBSCRIBING ALL ==========")
                self.logger.info(f"[POOL] Connections used: {num_connections}")
                self.logger.info(f"[POOL] Total symbols subscribed: {total_symbols}")
                for idx, count in enumerate(self.adapter_symbol_counts):
                    if count > 0:
                        self.logger.info(
                            f"[POOL]   Connection {idx + 1}: {count}/{self.max_symbols} symbols ({(count / self.max_symbols) * 100:.0f}%)"
                        )
                self.logger.info("[POOL] ==========================================")

            errors = []
            for index, adapter in enumerate(self.adapters):
                if not hasattr(adapter, "unsubscribe_all"):
                    errors.append(f"connection {index + 1}: unsupported")
                    continue
                try:
                    response = adapter.unsubscribe_all()
                except Exception as exc:
                    self.logger.exception(
                        "Error unsubscribing all on connection %s", index + 1
                    )
                    errors.append(f"connection {index + 1}: {exc}")
                    continue
                if not isinstance(response, dict) or response.get("status") != "success":
                    message = (
                        response.get("message")
                        if isinstance(response, dict)
                        else "invalid response"
                    )
                    errors.append(f"connection {index + 1}: {message}")

            if errors:
                return {
                    "status": "error",
                    "code": "UNSUBSCRIBE_ALL_ERROR",
                    "message": "; ".join(errors),
                }

            self.subscription_map.clear()
            self.subscription_depths.clear()
            self.adapter_symbol_counts = [0] * len(self.adapters)

            self.logger.info("[POOL] Unsubscribed from all symbols")
            return {
                "status": "success",
                "message": "Unsubscribed from all symbols",
            }

    def disconnect(self):
        """Disconnect all adapters and clean up"""
        with self.lock:
            # Log PEAK usage (not current, since unsubscribes may have already happened)
            self.logger.info("[POOL] ========== DISCONNECTING POOL ==========")
            self.logger.info(f"[POOL] Peak connections used: {self.peak_connections_used}")
            self.logger.info(f"[POOL] Peak symbols subscribed: {self.peak_total_symbols}")
            for idx, count in enumerate(self.peak_symbol_counts):
                self.logger.info(
                    f"[POOL]   Connection {idx + 1}: {count}/{self.max_symbols} symbols ({(count / self.max_symbols) * 100:.0f}%)"
                )
            self.logger.info("[POOL] ==========================================")

            for idx, adapter in enumerate(self.adapters):
                original_cleanup = None
                try:
                    # Skip ZMQ cleanup for adapters using shared publisher
                    if hasattr(adapter, "_uses_shared_zmq") and adapter._uses_shared_zmq:
                        # Temporarily disable ZMQ cleanup
                        original_cleanup = getattr(adapter, "cleanup_zmq", None)
                        adapter.cleanup_zmq = lambda: None

                    adapter.disconnect()

                    self.logger.debug(f"Disconnected connection {idx + 1}")
                except Exception as e:
                    self.logger.exception(f"Error disconnecting adapter {idx + 1}: {e}")
                finally:
                    # Always restore original cleanup method to prevent resource leaks
                    if original_cleanup is not None:
                        try:
                            adapter.cleanup_zmq = original_cleanup
                        except Exception:
                            pass  # Adapter may already be in bad state

            self.adapters.clear()
            self.adapter_symbol_counts.clear()
            self.subscription_map.clear()
            self.subscription_depths.clear()
            self.connected = False
            self.initialized = False

            # Reset peak counters for next session
            self.peak_total_symbols = 0
            self.peak_connections_used = 0
            self.peak_symbol_counts = []

            self.logger.info("[POOL] ConnectionPool disconnected successfully")

    def get_stats(self) -> dict:
        """
        Get pool statistics.

        Returns:
            Dict with pool statistics
        """
        with self.lock:
            total_symbols = sum(self.adapter_symbol_counts)
            max_capacity = self.max_connections * self.max_symbols

            return {
                "broker": self.broker_name,
                "user_id": self.user_id,
                "active_connections": len(self.adapters),
                "max_connections": self.max_connections,
                "max_symbols_per_connection": self.max_symbols,
                "total_subscriptions": total_symbols,
                "max_capacity": max_capacity,
                "capacity_used_percent": (total_symbols / max_capacity * 100)
                if max_capacity > 0
                else 0,
                "connections": [
                    {
                        "index": idx + 1,
                        "symbols": count,
                        "capacity_percent": (count / self.max_symbols * 100),
                    }
                    for idx, count in enumerate(self.adapter_symbol_counts)
                ],
            }

    # Compatibility methods to match BaseBrokerWebSocketAdapter interface

    @property
    def subscriptions(self) -> dict:
        """Get subscriptions dict for compatibility"""
        return {
            f"{k[0]}_{k[1]}_{k[2]}": {"symbol": k[0], "exchange": k[1], "mode": k[2]}
            for k in self.subscription_map.keys()
        }

    def publish_market_data(self, topic: str, data: dict):
        """Publish market data through shared publisher"""
        self.shared_publisher.publish(topic, data)


def create_pooled_adapter(
    adapter_class: type,
    broker_name: str,
    max_symbols_per_connection: int | None = None,
    max_connections: int | None = None,
) -> Callable:
    """
    Factory function to create a pooled adapter factory.

    This returns a function that can be used in place of direct adapter instantiation,
    providing transparent connection pooling.

    Args:
        adapter_class: The broker adapter class
        broker_name: Name of the broker
        max_symbols_per_connection: Optional override for max symbols
        max_connections: Optional override for max connections

    Returns:
        A factory function that creates ConnectionPool instances
    """

    def factory():
        # The pool will be initialized with user_id later
        # Return a wrapper that creates the pool on first use
        class PooledAdapterWrapper:
            def __init__(self):
                self._pool = None
                self._adapter_class = adapter_class
                self._broker_name = broker_name
                self._max_symbols = max_symbols_per_connection
                self._max_connections = max_connections

            def _ensure_pool(self, user_id: str) -> ConnectionPool:
                if self._pool is None:
                    self._pool = ConnectionPool(
                        adapter_class=self._adapter_class,
                        broker_name=self._broker_name,
                        user_id=user_id,
                        max_symbols_per_connection=self._max_symbols,
                        max_connections=self._max_connections,
                    )
                return self._pool

            def initialize(self, broker_name: str, user_id: str, auth_data: dict = None):
                pool = self._ensure_pool(user_id)
                return pool.initialize(broker_name, user_id, auth_data)

            def connect(self):
                if self._pool:
                    return self._pool.connect()
                return {"success": False, "error": "Not initialized"}

            def disconnect(self):
                if self._pool:
                    self._pool.disconnect()

            def subscribe(self, symbol: str, exchange: str, mode: int = 2, depth_level: int = 5):
                if self._pool:
                    return self._pool.subscribe(symbol, exchange, mode, depth_level)
                return {"status": "error", "message": "Not initialized"}

            def unsubscribe(self, symbol: str, exchange: str, mode: int = 2):
                if self._pool:
                    return self._pool.unsubscribe(symbol, exchange, mode)
                return {"status": "error", "message": "Not initialized"}

            def unsubscribe_all(self):
                if self._pool:
                    self._pool.unsubscribe_all()

            def get_stats(self):
                if self._pool:
                    return self._pool.get_stats()
                return {}

            @property
            def subscriptions(self):
                if self._pool:
                    return self._pool.subscriptions
                return {}

            def publish_market_data(self, topic: str, data: dict):
                if self._pool:
                    self._pool.publish_market_data(topic, data)

        return PooledAdapterWrapper()

    return factory
