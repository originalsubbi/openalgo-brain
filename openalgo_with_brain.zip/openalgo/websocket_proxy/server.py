import asyncio as aio
import json
import os
import signal
import socket
import threading
import time
from collections import defaultdict

import websockets
import zmq
import zmq.asyncio
from dotenv import load_dotenv
from sqlalchemy import text

from database.auth_db import get_broker_name, verify_api_key
from services.market_data_service import get_market_data_service
from utils.logging import get_logger, highlight_url

from .base_adapter import BaseBrokerWebSocketAdapter
from .broker_factory import create_broker_adapter
from .mode_utils import (
    MODE_BY_UPPER_LABEL as _MODE_BY_UPPER_LABEL,
)
from .mode_utils import (
    normalize_mode,
    normalize_mode_or_none,
)
from .port_check import find_available_port, is_port_in_use

# Initialize logger
logger = get_logger("websocket_proxy")


class WebSocketProxy:
    """
    WebSocket Proxy Server that handles client connections and authentication,
    manages subscriptions, and routes market data from broker adapters to clients.
    Supports dynamic broker selection based on user configuration.
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 8765):
        """
        Initialize the WebSocket Proxy

        Args:
            host: Hostname to bind the WebSocket server to
            port: Port number to bind the WebSocket server to
        """
        self.host = host
        self.port = port

        # Check if the required port is already in use - wait briefly for cleanup to complete
        if is_port_in_use(host, port, wait_time=2.0):  # Wait up to 2 seconds for port release
            error_msg = (
                f"WebSocket port {port} is already in use on {host}.\n"
                f"This port is required for SDK compatibility (see strategies/ltp_example.py).\n"
                f"Please:\n"
                f"1. Stop any other OpenAlgo instances running on port {port}\n"
                f"2. Kill any processes using port {port}: lsof -ti:{port} | xargs kill -9\n"
                f"3. Or wait for the port to be released\n"
                f"Cannot start WebSocket server with port switching as it would break SDK clients."
            )
            logger.error(error_msg)
            raise RuntimeError(error_msg)

        self.clients = {}  # Maps client_id to websocket connection
        self.subscriptions = {}  # Maps client_id to set of subscriptions
        self.broker_adapters = {}  # Maps user_id to broker adapter
        self.user_mapping = {}  # Maps client_id to user_id
        self.user_broker_mapping = {}  # Maps user_id to broker_name
        self.running = False

        # PERFORMANCE OPTIMIZATION: Subscription index for O(1) lookup
        # Maps (symbol, exchange, mode) -> set of client_ids
        # This eliminates the need for nested loops in zmq_listener
        self.subscription_index: dict[tuple[str, str, int], set[int]] = defaultdict(set)

        # Order-update subscribers: user_id -> set of client_ids that sent
        # {"action": "subscribe_orders"}. Account-scoped (no symbol/mode),
        # unlike market-data subscriptions above.
        self.order_subscribers: dict[str, set[int]] = defaultdict(set)

        # PERFORMANCE OPTIMIZATION 2: Message throttling to avoid excessive updates
        # Maps (symbol, exchange, mode) -> last message timestamp
        # Prevents sending duplicate LTP updates faster than 50ms
        self.last_message_time: dict[tuple[str, str, int], float] = {}
        self.message_throttle_interval = 0.05  # 50ms minimum between messages

        # OBSERVABILITY: last time any tick was delivered to each user. Used to
        # surface "adapter is connected but silent while subscribed" — the
        # stale-feed symptom behind issues #1226/#1419/#1421. This is a
        # diagnostic signal only: it is logged and exposed via get_adapter_health(),
        # never used to auto-evict (a quiet market or illiquid symbol legitimately
        # produces no ticks, so auto-eviction would churn healthy feeds). Actual
        # eviction stays with the connected-state check in authenticate_client.
        self.last_tick_time: dict[str, float] = {}  # user_id -> epoch seconds
        self._last_stale_warn: dict[str, float] = {}  # user_id -> epoch of last warning
        self._stale_tick_warn_seconds = int(os.getenv("WS_STALE_TICK_WARN_SECONDS", "120"))
        self._last_stale_check = time.time()
        self._stale_check_interval = 30  # evaluate stale-feed warnings at most every 30s

        # MODE_MAP retained for any external consumers that imported it from
        # this class. New code should call normalize_mode() / normalize_mode_or_none()
        # at module level — those accept case-insensitive strings AND ints.
        self.MODE_MAP = dict(_MODE_BY_UPPER_LABEL)

        # RESOURCE MONITORING: Track metrics for health checks
        self._stats_lock = aio.Lock() if hasattr(aio, 'Lock') else None
        self._messages_processed = 0
        self._last_cleanup_time = time.time()
        self._cleanup_interval = 300  # Clean stale entries every 5 minutes
        self._throttle_entry_max_age = 60  # Remove throttle entries older than 60 seconds

        # ZeroMQ bus for market data + cache-invalidation events.
        self.context = zmq.asyncio.Context()
        self.socket = self.context.socket(zmq.SUB)
        # Fan-in topology: this SUB is the SINGLE binder on the ZMQ bus and every
        # publisher CONNECTs to it — the broker market-data adapters (this process)
        # and the cache-invalidation publisher (the Flask/gunicorn process). The
        # publishers used to bind and the SUB used to connect, which raced across
        # those two processes once the proxy moved out-of-process (#1421): whoever
        # bound the configured port first won, the loser silently slid to the next
        # port (5556...), and the SUB — fixed on the configured port — heard nothing
        # from it. Auth + subscribe succeeded but no ticks were delivered. Binding
        # the SUB makes the rendezvous port deterministic regardless of process
        # start order. Publisher side: base_adapter._connect_to_zmq_bus and
        # connection_manager.SharedZmqPublisher.connect.
        ZMQ_HOST = os.getenv("ZMQ_HOST", "127.0.0.1")
        ZMQ_PORT = os.getenv("ZMQ_PORT", "5555")
        self.socket.bind(f"tcp://{ZMQ_HOST}:{ZMQ_PORT}")

        # Receive all topics (market data + CACHE_INVALIDATE_*)
        self.socket.setsockopt(zmq.SUBSCRIBE, b"")

    async def start(self):
        """Start the WebSocket server and ZeroMQ listener"""
        self.running = True

        try:
            # Start ZeroMQ listener
            logger.debug("Initializing ZeroMQ listener task")

            # Get the current event loop
            loop = aio.get_running_loop()

            # Create the ZMQ listener task
            _zmq_task = loop.create_task(self.zmq_listener())

            # Start WebSocket server
            stop = aio.Future()  # Used to stop the server

            # Create a task to monitor the running flag
            async def monitor_shutdown():
                while self.running:
                    await aio.sleep(0.5)
                stop.set_result(None)

            monitor_task = aio.create_task(monitor_shutdown())

            # Periodic stats snapshot for the Flask-side health monitor. The
            # proxy runs in its own process, so utils/health_monitor.py cannot
            # read the in-process pools; it falls back to this file (#1301).
            stats_task = aio.create_task(self._stats_file_writer())

            # Handle graceful shutdown
            # Windows doesn't support add_signal_handler, so we'll use a simpler approach
            # Also, when running in a thread on Unix systems, signal handlers can't be set
            try:
                loop = aio.get_running_loop()

                # Check if we're in the main thread
                if threading.current_thread() is threading.main_thread():
                    try:
                        for sig in (signal.SIGINT, signal.SIGTERM):
                            loop.add_signal_handler(sig, stop.set_result, None)
                        logger.debug("Signal handlers registered successfully")
                    except (NotImplementedError, RuntimeError) as e:
                        # On Windows or when in a non-main thread
                        logger.debug(
                            f"Signal handlers not registered: {e}. Using fallback mechanism."
                        )
                else:
                    logger.debug("Running in a non-main thread. Signal handlers will not be used.")
            except RuntimeError:
                logger.debug("No running event loop found for signal handlers")

            highlighted_address = highlight_url(f"{self.host}:{self.port}")
            logger.debug(f"Starting WebSocket server on {highlighted_address}")

            # Try to start the WebSocket server with proper socket options for immediate port reuse
            try:
                # max_queue caps per-client send buffer to absorb tick bursts
                # without prematurely killing slow clients (default 32 was
                # surfacing as "random disconnects" during NIFTY expiry-day
                # storms). ping_interval/ping_timeout are set explicitly so
                # the keepalive contract is locked into the codebase rather
                # than relying on the websockets library defaults.
                ws_max_queue = int(os.getenv("WS_MAX_QUEUE", "1024"))
                ws_ping_interval = int(os.getenv("WS_PING_INTERVAL", "20"))
                ws_ping_timeout = int(os.getenv("WS_PING_TIMEOUT", "20"))

                # Start WebSocket server with socket reuse options
                self.server = await websockets.serve(
                    self.handle_client,
                    self.host,
                    self.port,
                    # Enable socket reuse for immediate port availability after close
                    reuse_port=True if hasattr(socket, "SO_REUSEPORT") else False,
                    max_queue=ws_max_queue,
                    ping_interval=ws_ping_interval,
                    ping_timeout=ws_ping_timeout,
                )

                highlighted_success_address = highlight_url(f"{self.host}:{self.port}")
                logger.debug(
                    f"WebSocket server successfully started on {highlighted_success_address}"
                )

                await stop  # Wait until stopped

                # Cancel the monitor task
                monitor_task.cancel()
                try:
                    await monitor_task
                except aio.CancelledError:
                    pass

                stats_task.cancel()
                try:
                    await stats_task
                except aio.CancelledError:
                    pass

                # Properly stop the server and release the port.
                # This calls server.wait_closed() which ensures the socket
                # is fully released before the event loop shuts down.
                await self.stop()

            except Exception as e:
                logger.exception(f"Failed to start WebSocket server: {e}")
                raise

        except Exception as e:
            logger.exception(f"Error in start method: {e}")
            raise

    async def stop(self):
        """Stop the WebSocket server and clean up all resources"""
        logger.info("Stopping WebSocket server...")
        self.running = False

        try:
            # Close the WebSocket server first (this releases the port)
            if hasattr(self, "server") and self.server:
                try:
                    logger.info("Closing WebSocket server...")
                    # On Windows, we need to handle the case where we're in a different event loop
                    try:
                        self.server.close()
                        await self.server.wait_closed()
                        logger.info("WebSocket server closed and port released")
                    except RuntimeError as e:
                        if "attached to a different loop" in str(e):
                            logger.warning(
                                f"WebSocket server cleanup skipped due to event loop mismatch: {e}"
                            )
                            # Force close the server without waiting
                            try:
                                self.server.close()
                            except Exception:
                                pass
                        else:
                            raise
                except Exception as e:
                    logger.exception(f"Error closing WebSocket server: {e}")

            # Close all client connections
            close_tasks = []
            for client_id, websocket in self.clients.items():
                try:
                    if hasattr(websocket, "open") and websocket.open:
                        close_tasks.append(websocket.close())
                except Exception as e:
                    logger.exception(f"Error preparing to close client {client_id}: {e}")

            # Wait for all connections to close with timeout
            if close_tasks:
                try:
                    await aio.wait_for(
                        aio.gather(*close_tasks, return_exceptions=True),
                        timeout=2.0,  # 2 second timeout
                    )
                except TimeoutError:
                    logger.warning("Timeout waiting for client connections to close")

            # Disconnect all broker adapters
            for user_id, adapter in self.broker_adapters.items():
                try:
                    adapter.disconnect()
                except Exception as e:
                    logger.exception(f"Error disconnecting adapter for user {user_id}: {e}")

            # Close ZeroMQ socket with linger=0 for immediate close
            if hasattr(self, "socket") and self.socket and not self.socket.closed:
                try:
                    self.socket.setsockopt(zmq.LINGER, 0)  # Don't wait for pending messages
                    self.socket.close()
                except Exception as e:
                    logger.exception(f"Error closing ZMQ socket: {e}")

            # Close ZeroMQ context with timeout
            if hasattr(self, "context") and self.context and not self.context.closed:
                try:
                    self.context.term()
                except Exception as e:
                    logger.exception(f"Error terminating ZMQ context: {e}")

            logger.info("WebSocket server stopped and resources cleaned up")

        except Exception as e:
            logger.exception(f"Error during WebSocket server stop: {e}")

    def _cleanup_zmq_sync(self):
        """
        Synchronous cleanup of ZeroMQ resources.
        Called from __del__ to ensure resources are freed even if stop() is never called.
        """
        try:
            if hasattr(self, "socket") and self.socket:
                try:
                    self.socket.setsockopt(zmq.LINGER, 0)
                    self.socket.close()
                except Exception:
                    pass  # Ignore errors during cleanup
                finally:
                    self.socket = None

            if hasattr(self, "context") and self.context:
                try:
                    self.context.term()
                except Exception:
                    pass  # Ignore errors during cleanup
                finally:
                    self.context = None
        except Exception:
            pass  # Suppress all errors in cleanup

    def __del__(self):
        """
        Destructor to ensure ZeroMQ resources are cleaned up.
        This is a safety net for cases where stop() is never called
        (e.g., exception during start() or unexpected termination).
        """
        try:
            self.running = False
            self._cleanup_zmq_sync()
        except Exception:
            pass  # Cannot raise in __del__

    # Seconds between stats-file snapshots for the cross-process health monitor.
    STATS_FILE_INTERVAL = 10

    async def _stats_file_writer(self):
        """Periodically write a compact stats snapshot for the Flask process.

        The health monitor (utils/health_monitor.py) used to read the proxy's
        connection pools in-process; since the proxy moved to its own process
        that always reads empty, so the Health Monitor page showed no
        WebSocket details (GitHub issue #1301). This file is its data source
        now. Written atomically (tmp + os.replace) so readers never see a
        partial file.
        """
        stats_path = os.getenv("WS_PROXY_STATS_FILE", os.path.join("log", "ws_proxy_stats.json"))
        tmp_path = f"{stats_path}.tmp"
        while self.running:
            try:
                health = self.get_health_stats()
                snapshot = {
                    "timestamp": time.time(),
                    "total_connections": health["broker_adapters"]["active_count"],
                    "total_symbols": health["subscriptions"]["unique_symbols"],
                    "clients_connected": health["clients"]["connected_count"],
                    "brokers": health["broker_adapters"]["brokers"],
                }
                with open(tmp_path, "w") as f:
                    json.dump(snapshot, f)
                os.replace(tmp_path, stats_path)
            except Exception as e:
                # Never let stats writing affect the feed path.
                logger.debug(f"Stats snapshot write failed: {e}")
            await aio.sleep(self.STATS_FILE_INTERVAL)

    def get_health_stats(self) -> dict:
        """
        Get health statistics for monitoring file descriptors and resources.

        Returns:
            dict: Health statistics including connection counts, subscription metrics,
                  and resource usage information.
        """
        try:
            # Get base adapter stats if available
            from .base_adapter import BaseBrokerWebSocketAdapter
            adapter_stats = BaseBrokerWebSocketAdapter.get_resource_stats()
        except Exception:
            adapter_stats = {}

        # Calculate subscription index stats
        total_subscriptions = len(self.subscription_index)
        total_client_subscriptions = sum(len(clients) for clients in self.subscription_index.values())
        throttle_entries = len(self.last_message_time)

        return {
            "server": {
                "running": self.running,
                "host": self.host,
                "port": self.port,
            },
            "clients": {
                "connected_count": len(self.clients),
                "user_mappings": len(self.user_mapping),
            },
            "subscriptions": {
                "unique_symbols": total_subscriptions,
                "total_client_subscriptions": total_client_subscriptions,
                "per_client_counts": {
                    str(client_id): len(subs)
                    for client_id, subs in self.subscriptions.items()
                },
            },
            "broker_adapters": {
                "active_count": len(self.broker_adapters),
                "brokers": list(self.user_broker_mapping.values()),
            },
            "performance": {
                "throttle_entries": throttle_entries,
                "messages_processed": self._messages_processed,
                "last_cleanup_time": self._last_cleanup_time,
            },
            "zmq_resources": adapter_stats,
        }

    def _cleanup_stale_throttle_entries(self):
        """
        Remove stale entries from last_message_time dict.

        This prevents unbounded memory growth from symbols that were
        subscribed to but are no longer active.
        """
        current_time = time.time()

        # Only run cleanup periodically
        if current_time - self._last_cleanup_time < self._cleanup_interval:
            return

        self._last_cleanup_time = current_time
        initial_count = len(self.last_message_time)

        # Find and remove stale entries
        stale_keys = [
            key for key, timestamp in self.last_message_time.items()
            if current_time - timestamp > self._throttle_entry_max_age
        ]

        for key in stale_keys:
            del self.last_message_time[key]

        if stale_keys:
            logger.info(
                f"Cleaned up {len(stale_keys)} stale throttle entries "
                f"(was {initial_count}, now {len(self.last_message_time)})"
            )

        # Log subscription index stats periodically
        total_subs = len(self.subscription_index)
        total_clients = len(self.clients)
        if total_subs > 0 or total_clients > 0:
            logger.debug(
                f"Resource stats: {total_clients} clients, "
                f"{total_subs} unique subscriptions, "
                f"{len(self.last_message_time)} throttle entries"
            )

    def _users_with_active_subscriptions(self) -> set:
        """Return the set of user_ids that currently have at least one client
        subscribed to at least one symbol."""
        active_users = set()
        for client_set in self.subscription_index.values():
            for client_id in client_set:
                user_id = self.user_mapping.get(client_id)
                if user_id:
                    active_users.add(user_id)
        return active_users

    def _log_stale_adapters(self):
        """Observability only: warn when a broker adapter reports connected but
        has delivered no ticks for longer than the threshold while the user still
        has active subscriptions. This surfaces the stale-feed symptom of issues
        #1226/#1419/#1421 without auto-evicting (a quiet market legitimately has
        no ticks). Actual recovery is handled by the connected-state eviction in
        authenticate_client.
        """
        current_time = time.time()
        if current_time - self._last_stale_check < self._stale_check_interval:
            return
        self._last_stale_check = current_time

        threshold = self._stale_tick_warn_seconds
        if threshold <= 0:
            return

        active_users = self._users_with_active_subscriptions()
        for user_id, adapter in list(self.broker_adapters.items()):
            if user_id not in active_users:
                continue  # no subscriptions => no ticks expected
            if not bool(getattr(adapter, "connected", False)):
                continue  # disconnected adapters are handled on next auth
            last_tick = self.last_tick_time.get(user_id)
            if last_tick is None:
                continue  # never delivered yet (just connected) — don't flag
            silent_for = current_time - last_tick
            if silent_for < threshold:
                continue
            # Throttle repeat warnings per user to once per threshold window
            if current_time - self._last_stale_warn.get(user_id, 0) < threshold:
                continue
            self._last_stale_warn[user_id] = current_time
            broker = self.user_broker_mapping.get(user_id, "unknown")
            # Debug, not warning. A subscribed feed is legitimately silent every
            # night, every weekend and every trading holiday, and this check
            # cannot tell that apart from a dead socket without an
            # exchange-aware calendar. Logging it at warning meant hours of
            # identical lines whenever the market was simply shut, which buries
            # the entries that do need attention. The signal is still available
            # when it is wanted: get_adapter_health() reports seconds since the
            # last tick per user, and raising the log level surfaces this again.
            logger.debug(
                f"Stale feed: {broker} adapter for user {user_id} reports connected "
                f"but no ticks for {silent_for:.0f}s while subscribed. Expected "
                f"outside market hours; if it persists during a session the "
                f"broker WebSocket may be silently dead."
            )

    def get_adapter_health(self) -> dict:
        """Per-user adapter health snapshot for diagnostics (#1432).

        Returns connected state, seconds since last tick, and whether the user
        has active subscriptions — enough to triage the stale-feed class of bug
        from /admin/diagnostics without a code dive.
        """
        current_time = time.time()
        active_users = self._users_with_active_subscriptions()
        health = {}
        for user_id, adapter in self.broker_adapters.items():
            last_tick = self.last_tick_time.get(user_id)
            health[user_id] = {
                "broker": self.user_broker_mapping.get(user_id, "unknown"),
                "connected": bool(getattr(adapter, "connected", False)),
                "has_subscriptions": user_id in active_users,
                "seconds_since_last_tick": (
                    round(current_time - last_tick, 1) if last_tick is not None else None
                ),
            }
        return health

    async def handle_client(self, websocket):
        """
        Handle a client connection

        Args:
            websocket: The WebSocket connection
        """
        client_id = id(websocket)
        self.clients[client_id] = websocket
        self.subscriptions[client_id] = set()

        # Get path info from websocket if available
        path = getattr(websocket, "path", "/unknown")
        logger.info(f"Client connected: {client_id} from path: {path}")

        # Unauthenticated grace window: drop connections that don't complete auth
        # within WS_AUTH_GRACE_SECONDS to prevent idle/holding-pattern resource
        # exhaustion from unauthenticated clients on a public-facing port.
        auth_grace_seconds = int(os.getenv("WS_AUTH_GRACE_SECONDS", "15"))

        async def _enforce_auth_deadline():
            try:
                await aio.sleep(auth_grace_seconds)
                if client_id not in self.user_mapping:
                    logger.warning(
                        f"Client {client_id} failed to authenticate within "
                        f"{auth_grace_seconds}s — closing connection"
                    )
                    try:
                        await websocket.close(code=4401, reason="auth timeout")
                    except Exception:
                        pass
            except aio.CancelledError:
                pass

        auth_deadline_task = aio.ensure_future(_enforce_auth_deadline())

        try:
            # Process messages from the client
            async for message in websocket:
                try:
                    # OPTIMIZATION: Remove debug logging from hot path
                    # logger.debug(f"Received message from client {client_id}: {message}")
                    await self.process_client_message(client_id, message)
                except Exception as e:
                    logger.exception(f"Error processing message from client {client_id}: {e}")
                    # Send error to client but don't disconnect
                    try:
                        await self.send_error(client_id, "PROCESSING_ERROR", str(e))
                    except Exception:
                        pass
        except websockets.exceptions.ConnectionClosed as e:
            logger.info(f"Client disconnected: {client_id}, code: {e.code}, reason: {e.reason}")
        except Exception as e:
            logger.exception(f"Unexpected error handling client {client_id}: {e}")
        finally:
            auth_deadline_task.cancel()
            # Clean up when the client disconnects
            await self.cleanup_client(client_id)

    async def cleanup_client(self, client_id):
        """
        Clean up client resources when they disconnect

        Args:
            client_id: Client ID to clean up
        """
        self.clients.pop(client_id, None)
        user_id = self.user_mapping.get(client_id)
        adapter = self.broker_adapters.get(user_id) if user_id else None
        release_failed = False

        parsed_subscriptions, rows_by_key = self._indexed_client_subscriptions(client_id)
        processed_keys = set()
        processed_count = 0
        for _sub_info, sub_key, _mode_label, mode_error in parsed_subscriptions:
            try:
                if mode_error is not None or sub_key is None or sub_key in processed_keys:
                    continue
                processed_keys.add(sub_key)
                symbol, exchange, mode = sub_key
                stored_rows = rows_by_key[sub_key]
                if adapter is None:
                    self._drop_subscription_ownership(
                        client_id, sub_key, stored_rows
                    )
                else:
                    ok, error = self._unsubscribe_owned_subscription(
                        client_id,
                        adapter,
                        symbol,
                        exchange,
                        mode,
                        stored_rows=stored_rows,
                    )
                    if not ok:
                        release_failed = True
                        logger.error(
                            "Disconnect could not release %s:%s mode %s exactly: %s",
                            symbol,
                            exchange,
                            mode,
                            error,
                        )
            except Exception as e:
                logger.exception(f"Error processing subscription: {e}")
                release_failed = True
            finally:
                processed_count += 1
                if processed_count % 128 == 0:
                    # Keep the single event loop responsive during a maximum
                    # 3,000-symbol teardown. No thread or executor is created.
                    await aio.sleep(0)

        if user_id in self.order_subscribers:
            self.order_subscribers[user_id].discard(client_id)
            if not self.order_subscribers[user_id]:
                del self.order_subscribers[user_id]

        has_other_live_client = bool(
            user_id
            and any(
                other_client_id in self.clients
                and other_user_id == user_id
                for other_client_id, other_user_id in self.user_mapping.items()
                if other_client_id != client_id
            )
        )

        if user_id and adapter is not None and not has_other_live_client:
            broker_name = self.user_broker_mapping.get(user_id)
            keep_special_adapter = False
            if broker_name in ["flattrade", "shoonya"] and hasattr(
                adapter, "unsubscribe_all"
            ):
                logger.info(
                    "%s adapter for user %s: last client disconnected. "
                    "Unsubscribing all symbols instead of disconnecting.",
                    broker_name.title(),
                    user_id,
                )
                try:
                    response = adapter.unsubscribe_all()
                    keep_special_adapter = bool(
                        isinstance(response, dict)
                        and response.get("status") == "success"
                    )
                    if not keep_special_adapter:
                        logger.error(
                            "%s unsubscribe_all was not acknowledged for user %s: %r",
                            broker_name.title(),
                            user_id,
                            response,
                        )
                except Exception:
                    logger.exception(
                        "%s unsubscribe_all raised for user %s",
                        broker_name.title(),
                        user_id,
                    )

            if not keep_special_adapter:
                logger.info(
                    "Last client for user %s disconnected. Disconnecting %s adapter.",
                    user_id,
                    broker_name or "unknown broker",
                )
                try:
                    adapter.disconnect()
                except Exception:
                    logger.exception(
                        "Error disconnecting %s adapter for user %s",
                        broker_name or "unknown broker",
                        user_id,
                    )
                finally:
                    self.broker_adapters.pop(user_id, None)
                    self.user_broker_mapping.pop(user_id, None)

        elif release_failed:
            # Another live client still owns this user's shared adapter.  The
            # broker-side row remains bounded by that adapter's symbol limit
            # and is reclaimed by the authoritative last-client teardown.  A
            # disconnected client must never remain as a registry owner.
            logger.error(
                "Dropping failed exact-release ownership for disconnected client %s; "
                "the shared adapter will reclaim it at last-client teardown",
                client_id,
            )

        self._purge_client_subscription_ownership(client_id)
        self.user_mapping.pop(client_id, None)

    async def process_client_message(self, client_id, message):
        """
        Process messages from a client

        Args:
            client_id: ID of the client
            message: The message from the client
        """
        try:
            data = json.loads(message)
            # OPTIMIZATION: Remove debug logging from hot path
            # logger.debug(f"Parsed message from client {client_id}: {data}")

            # Accept both 'action' and 'type' fields for better compatibility with different clients
            action = data.get("action") or data.get("type")
            # OPTIMIZATION: Only log important actions, not every subscribe/unsubscribe
            if action not in ["subscribe", "unsubscribe"]:
                logger.info(f"Client {client_id} requested action: {action}")

            if action in ["authenticate", "auth"]:
                await self.authenticate_client(client_id, data)
            elif action == "subscribe":
                await self.subscribe_client(client_id, data)
            elif action in ["unsubscribe", "unsubscribe_all"]:
                await self.unsubscribe_client(client_id, data)
            elif action == "subscribe_orders":
                await self.subscribe_orders_client(client_id, data)
            elif action == "unsubscribe_orders":
                await self.unsubscribe_orders_client(client_id, data)
            elif action == "get_broker_info":
                await self.get_broker_info(client_id)
            elif action == "get_supported_brokers":
                await self.get_supported_brokers(client_id)
            elif action == "ping":
                await self.handle_ping(client_id, data)
            else:
                logger.warning(f"Client {client_id} requested invalid action: {action}")
                await self.send_error(client_id, "INVALID_ACTION", f"Invalid action: {action}")
        except json.JSONDecodeError:
            logger.exception(f"Invalid JSON from client {client_id}: {message}")
            await self.send_error(client_id, "INVALID_JSON", "Invalid JSON message")
        except Exception as e:
            logger.exception(f"Error processing client message: {e}")
            await self.send_error(client_id, "SERVER_ERROR", str(e))

    async def get_user_broker_configuration(self, user_id):
        """
        Get the broker configuration for a specific user from database

        Args:
            user_id: User ID to get broker configuration for

        Returns:
            dict: Broker configuration containing broker_name and credentials
        """
        try:
            from database.auth_db import Auth

            auth_obj = Auth.query.filter_by(name=user_id).first()

            if auth_obj and not auth_obj.is_revoked and auth_obj.broker:
                broker_name = auth_obj.broker
                logger.info(f"Found broker '{broker_name}' for user {user_id} from database")
            else:
                # Fallback to environment variable
                valid_brokers = os.getenv("VALID_BROKERS", "angel").split(",")
                broker_name = valid_brokers[0].strip() if valid_brokers else "angel"
                logger.warning(
                    f"No broker found in database for user {user_id}, using fallback: {broker_name}"
                )

            # Get broker credentials from environment variables
            # In a production system, these would be stored encrypted in the database per user
            broker_config = {
                "broker_name": broker_name,
                "api_key": os.getenv("BROKER_API_KEY"),
                "api_secret": os.getenv("BROKER_API_SECRET"),
                "api_key_market": os.getenv("BROKER_API_KEY_MARKET"),
                "api_secret_market": os.getenv("BROKER_API_SECRET_MARKET"),
                "broker_user_id": os.getenv("BROKER_USER_ID"),
                "password": os.getenv("BROKER_PASSWORD"),
                "totp_secret": os.getenv("BROKER_TOTP_SECRET"),
            }

            # Validate broker is supported
            valid_brokers_list = os.getenv("VALID_BROKERS", "").split(",")
            valid_brokers_list = [b.strip() for b in valid_brokers_list if b.strip()]

            if broker_name not in valid_brokers_list:
                logger.error(
                    f"Broker '{broker_name}' is not in VALID_BROKERS list: {valid_brokers_list}"
                )
                return None

            if not broker_config.get("broker_name"):
                logger.error(f"No broker configuration found for user {user_id}")
                return None

            logger.info(
                f"Retrieved broker configuration for user {user_id}: {broker_config['broker_name']}"
            )
            return broker_config

        except Exception as e:
            logger.exception(f"Error getting broker configuration for user {user_id}: {e}")
            return None

    async def authenticate_client(self, client_id, data):
        """
        Authenticate a client using their API key and determine their broker

        Args:
            client_id: ID of the client
            data: Authentication data containing API key
        """
        # Accept both 'api_key' and 'apikey' formats for compatibility
        api_key = data.get("api_key") or data.get("apikey")

        if not api_key:
            await self.send_error(client_id, "AUTHENTICATION_ERROR", "API key is required")
            return

        # Verify the API key and get the user ID
        user_id = verify_api_key(api_key)

        if not user_id:
            await self.send_error(client_id, "AUTHENTICATION_ERROR", "Invalid API key")
            return

        # Store the user mapping
        self.user_mapping[client_id] = user_id

        # Get broker name
        broker_name = get_broker_name(api_key)

        if not broker_name:
            await self.send_error(
                client_id, "BROKER_ERROR", "No broker configuration found for user"
            )
            return

        previous_broker_name = self.user_broker_mapping.get(user_id)

        # Store the broker mapping for this user
        self.user_broker_mapping[user_id] = broker_name

        # A successful API-key auth is not enough: the cached broker adapter/pool
        # can be disconnected or still hold a previous day's broker token. Evict
        # it before the normal create/connect path runs so the fresh DB token is
        # used immediately after broker re-login.
        if user_id in self.broker_adapters:
            cached_adapter = self.broker_adapters[user_id]
            cached_connected = bool(getattr(cached_adapter, "connected", False))
            broker_changed = bool(previous_broker_name and previous_broker_name != broker_name)

            if broker_changed or not cached_connected:
                reason = (
                    f"broker changed {previous_broker_name}->{broker_name}"
                    if broker_changed
                    else "cached adapter disconnected"
                )
                logger.info(
                    f"Cached {broker_name} adapter for user {user_id} is stale ({reason}) - "
                    "evicting to rebuild with fresh credentials"
                )
                try:
                    cached_adapter.disconnect()
                except Exception as adapter_error:
                    logger.warning(
                        f"Error disconnecting stale adapter for user {user_id}: {adapter_error}"
                    )
                self.broker_adapters.pop(user_id, None)

                try:
                    from .broker_factory import cleanup_pools_for_user

                    cleanup_pools_for_user(user_id, broker_name=previous_broker_name or broker_name)
                except Exception as pool_error:
                    logger.warning(
                        f"Error cleaning stale connection pools for user {user_id}: {pool_error}"
                    )

        # Create or reuse broker adapter
        if user_id not in self.broker_adapters:
            try:
                # Create broker adapter with dynamic broker selection
                adapter = create_broker_adapter(broker_name)
                if not adapter:
                    await self.send_error(
                        client_id,
                        "BROKER_ERROR",
                        f"Failed to create adapter for broker: {broker_name}",
                    )
                    return

                # Initialize adapter with broker configuration
                # The adapter's initialize method should handle broker-specific setup
                initialization_result = adapter.initialize(broker_name, user_id)
                if initialization_result and initialization_result.get("status") == "error":
                    error_msg = initialization_result.get(
                        "message", initialization_result.get("error", "Failed to initialize broker adapter")
                    )

                    # Check if this is an auth error (403/401) - retry with fresh token
                    # This handles the stale cache issue described in GitHub issue #765
                    if adapter.is_auth_error(error_msg):
                        logger.warning(f"Auth error during initialization for user {user_id}, retrying with fresh token")
                        adapter.clear_auth_cache_for_user(user_id)

                        # Retry initialization with fresh credentials
                        initialization_result = adapter.initialize(broker_name, user_id)
                        if initialization_result and initialization_result.get("status") == "error":
                            error_msg = initialization_result.get("message", "Failed to initialize after retry")
                            await self.send_error(client_id, "BROKER_INIT_ERROR", error_msg)
                            return
                    else:
                        await self.send_error(client_id, "BROKER_INIT_ERROR", error_msg)
                        return

                # Connect to the broker
                connect_result = adapter.connect()
                # Handle both response formats:
                # - Adapter format: {"status": "error", "code": "...", "message": "..."}
                # - ConnectionPool format: {"success": False, "error": "..."}
                is_error = (
                    (connect_result and connect_result.get("status") == "error") or
                    (connect_result and connect_result.get("success") is False)
                )
                if is_error:
                    error_msg = connect_result.get("message", connect_result.get("error", "Failed to connect to broker"))
                    error_code = connect_result.get("code", "")

                    # Always retry connection failures with fresh token (issue #765)
                    # Connection failures after re-login are almost always due to stale cached tokens
                    # The upstox_client logs "401 Unauthorized" but returns generic "CONNECTION_FAILED"
                    should_retry = (
                        adapter.is_auth_error(error_msg) or
                        error_code in ("CONNECTION_FAILED", "CONNECTION_ERROR") or
                        "failed to connect" in error_msg.lower()
                    )

                    if should_retry:
                        logger.warning(f"Connection failed for user {user_id}, retrying with fresh token (error: {error_msg}, code: {error_code})")

                        # Clear stale cache in WebSocket process (issue #765)
                        self._clear_auth_cache_for_user(user_id)
                        adapter.clear_auth_cache_for_user(user_id)

                        # Re-initialize with fresh credentials from database
                        # Use force=True for pooled adapters to override existing initialization
                        logger.info(f"Re-initializing adapter for user {user_id} with fresh token")
                        try:
                            # Try with force parameter (supported by _PooledAdapterWrapper)
                            init_retry_result = adapter.initialize(broker_name, user_id, force=True)
                        except TypeError:
                            # Fallback for raw adapters that don't support force parameter
                            init_retry_result = adapter.initialize(broker_name, user_id)
                        # Handle both response formats
                        init_is_error = (
                            (init_retry_result and init_retry_result.get("status") == "error") or
                            (init_retry_result and init_retry_result.get("success") is False)
                        )
                        if init_is_error:
                            error_msg = init_retry_result.get("message", init_retry_result.get("error", "Failed to re-initialize"))
                            logger.error(f"Re-initialization failed for user {user_id}: {error_msg}")
                            await self.send_error(client_id, "BROKER_INIT_ERROR", error_msg)
                            return

                        # Retry connection
                        logger.info(f"Retrying connection for user {user_id}")
                        connect_result = adapter.connect()
                        # Handle both response formats
                        connect_is_error = (
                            (connect_result and connect_result.get("status") == "error") or
                            (connect_result and connect_result.get("success") is False)
                        )
                        if connect_is_error:
                            error_msg = connect_result.get("message", connect_result.get("error", "Failed to connect after retry"))
                            logger.error(f"Retry connection also failed for user {user_id}: {error_msg}")
                            await self.send_error(client_id, "BROKER_CONNECTION_ERROR", error_msg)
                            return

                        logger.info(f"Retry successful for user {user_id}")
                    else:
                        await self.send_error(client_id, "BROKER_CONNECTION_ERROR", error_msg)
                        return

                # Store the adapter
                self.broker_adapters[user_id] = adapter

                logger.info(
                    f"Successfully created and connected {broker_name} adapter for user {user_id}"
                )

            except Exception as e:
                error_str = str(e)
                logger.exception(f"Failed to create broker adapter for {broker_name}: {e}")

                # Check if exception is an auth error - retry with fresh token
                # This handles the stale cache issue described in GitHub issue #765
                if self._is_auth_error_exception(error_str):
                    logger.warning(f"Auth exception for user {user_id}, retrying with fresh token")
                    try:
                        self._clear_auth_cache_for_user(user_id)

                        # Retry adapter creation
                        adapter = create_broker_adapter(broker_name)
                        if adapter:
                            # Clear cache on the new adapter as well
                            if hasattr(adapter, 'clear_auth_cache_for_user'):
                                adapter.clear_auth_cache_for_user(user_id)

                            initialization_result = adapter.initialize(broker_name, user_id)
                            # Handle both response formats
                            init_is_error = (
                                (initialization_result and initialization_result.get("status") == "error") or
                                (initialization_result and initialization_result.get("success") is False)
                            )
                            if not init_is_error:
                                connect_result = adapter.connect()
                                # Handle both response formats
                                connect_is_error = (
                                    (connect_result and connect_result.get("status") == "error") or
                                    (connect_result and connect_result.get("success") is False)
                                )
                                if not connect_is_error:
                                    self.broker_adapters[user_id] = adapter
                                    logger.info(f"Successfully connected {broker_name} adapter for user {user_id} after retry")
                                    # Fall through to success response
                                else:
                                    error_msg = connect_result.get("message", connect_result.get("error", "Failed to connect after retry"))
                                    await self.send_error(client_id, "BROKER_CONNECTION_ERROR", error_msg)
                                    return
                            else:
                                error_msg = initialization_result.get("message", initialization_result.get("error", "Failed to initialize after retry"))
                                await self.send_error(client_id, "BROKER_INIT_ERROR", error_msg)
                                return
                        else:
                            await self.send_error(client_id, "BROKER_ERROR", f"Failed to create adapter for {broker_name}")
                            return
                    except Exception as retry_error:
                        logger.exception(f"Retry also failed for {broker_name}: {retry_error}")
                        await self.send_error(client_id, "BROKER_ERROR", str(retry_error))
                        return
                else:
                    logger.exception(f"Broker error for {broker_name}: {error_str}")
                    await self.send_error(client_id, "BROKER_ERROR", error_str)
                    return

        # Send success response with broker information
        await self.send_message(
            client_id,
            {
                "type": "auth",
                "status": "success",
                "message": "Authentication successful",
                "broker": broker_name,
                "user_id": user_id,
                "supported_features": {"ltp": True, "quote": True, "depth": True},
            },
        )

    async def get_supported_brokers(self, client_id):
        """
        Get list of supported brokers from environment configuration

        Args:
            client_id: ID of the client
        """
        try:
            valid_brokers = os.getenv("VALID_BROKERS", "").split(",")
            supported_brokers = [broker.strip() for broker in valid_brokers if broker.strip()]

            await self.send_message(
                client_id,
                {
                    "type": "supported_brokers",
                    "status": "success",
                    "brokers": supported_brokers,
                    "count": len(supported_brokers),
                },
            )
        except Exception as e:
            logger.exception(f"Error getting supported brokers: {e}")
            await self.send_error(client_id, "BROKER_LIST_ERROR", str(e))

    async def get_broker_info(self, client_id):
        """
        Get broker information for an authenticated client

        Args:
            client_id: ID of the client
        """
        # Check if the client is authenticated
        if client_id not in self.user_mapping:
            await self.send_error(client_id, "NOT_AUTHENTICATED", "You must authenticate first")
            return

        user_id = self.user_mapping[client_id]
        broker_name = self.user_broker_mapping.get(user_id)

        if not broker_name:
            await self.send_error(client_id, "BROKER_ERROR", "Broker information not available")
            return

        # Get adapter status
        adapter_status = "disconnected"
        if user_id in self.broker_adapters:
            adapter = self.broker_adapters[user_id]
            # Assuming the adapter has a status method or property
            adapter_status = getattr(adapter, "status", "connected")

        await self.send_message(
            client_id,
            {
                "type": "broker_info",
                "status": "success",
                "broker": broker_name,
                "adapter_status": adapter_status,
                "user_id": user_id,
            },
        )

    async def handle_ping(self, client_id, data):
        """
        Handle ping request from client

        Args:
            client_id: ID of the client
            data: Ping data containing optional timestamp
        """
        logger.debug(f"Handling ping from client {client_id}: {data}")
        client_timestamp = data.get("timestamp")
        ping_id = data.get("_pingId")
        server_timestamp = int(time.time() * 1000)  # Current time in milliseconds

        response = {"type": "pong", "status": "success", "server_timestamp": server_timestamp}

        # Include client timestamp in response if provided (for latency calculation)
        if client_timestamp is not None:
            response["client_timestamp"] = client_timestamp

        # Echo back _pingId for frontend latency calculation
        if ping_id is not None:
            response["_pingId"] = ping_id

        logger.debug(f"Sending pong to client {client_id}: {response}")
        await self.send_message(client_id, response)

    async def subscribe_client(self, client_id, data):
        """
        Subscribe a client to market data using their configured broker

        Args:
            client_id: ID of the client
            data: Subscription data
        """
        # Check if the client is authenticated
        if client_id not in self.user_mapping:
            await self.send_error(
                client_id, "NOT_AUTHENTICATED", "You must authenticate first", request_id=data.get("request_id")
            )
            return

        # Get subscription parameters
        symbols = data.get("symbols") or []  # Handle array of symbols
        raw_mode = data.get("mode", "Quote")  # Accepts 1/2/3 or LTP/Quote/Depth (any case)
        # The chart library sent the level as "depth_level" through 2.0.0 and
        # the proxy never read it, so accept either key before defaulting to 5.
        depth_level = data.get("depth")
        if depth_level is None:
            depth_level = data.get("depth_level")
        if depth_level is None:
            depth_level = 5
        # Optional request_id (issue #1376): when the client supplies one, we
        # echo it back in the response so the client can correlate this ack
        # with the originating request and learn per-symbol success/failure
        # rather than guessing from tick activity.
        request_id = data.get("request_id")

        # Normalize mode through the single source of truth. Previously the
        # in-handler mapping was Title-Case-only and silently passed through
        # unknown strings (e.g. documented "QUOTE") — broker adapters then
        # received the raw string instead of a numeric mode. See issue #1375.
        try:
            mode, mode_label = normalize_mode(raw_mode)
        except (ValueError, TypeError) as e:
            await self.send_error(
                client_id, "INVALID_MODE", str(e), request_id=data.get("request_id")
            )
            return
        mode_str = mode_label  # Canonical label echoed back in subscribe response

        # Handle case where a single symbol is passed directly instead of as an array
        if not symbols and (data.get("symbol") and data.get("exchange")):
            symbols = [{"symbol": data.get("symbol"), "exchange": data.get("exchange")}]

        if not symbols:
            await self.send_error(
                client_id, "INVALID_PARAMETERS", "At least one symbol must be specified", request_id=data.get("request_id")
            )
            return

        # Get the user's broker adapter
        user_id = self.user_mapping[client_id]
        if user_id not in self.broker_adapters:
            await self.send_error(
                client_id, "BROKER_ERROR", "Broker adapter not found", request_id=data.get("request_id")
            )
            return

        adapter = self.broker_adapters[user_id]
        broker_name = self.user_broker_mapping.get(user_id, "unknown")

        # Process each symbol in the subscription request
        subscription_responses = []
        subscription_success = True

        for symbol_info in symbols:
            symbol = symbol_info.get("symbol")
            exchange = symbol_info.get("exchange")

            if not symbol or not exchange:
                continue  # Skip invalid symbols

            # Subscribe to market data
            response = adapter.subscribe(symbol, exchange, mode, depth_level)

            if response.get("status") == "success":
                # Store the subscription
                subscription_info = {
                    "symbol": symbol,
                    "exchange": exchange,
                    "mode": mode,
                    "depth_level": depth_level,
                    "broker": broker_name,
                }

                if client_id in self.subscriptions:
                    self.subscriptions[client_id].add(json.dumps(subscription_info))
                else:
                    self.subscriptions[client_id] = {json.dumps(subscription_info)}

                # OPTIMIZATION: Update subscription index for O(1) lookup
                sub_key = (symbol, exchange, mode)
                self.subscription_index[sub_key].add(client_id)

                # Add to successful subscriptions
                subscription_responses.append(
                    {
                        "symbol": symbol,
                        "exchange": exchange,
                        "status": "success",
                        "mode": mode_str,
                        "depth": response.get("actual_depth", depth_level),
                        "broker": broker_name,
                    }
                )
            else:
                subscription_success = False
                # Add to failed subscriptions
                subscription_responses.append(
                    {
                        "symbol": symbol,
                        "exchange": exchange,
                        "status": "error",
                        "message": response.get("message", "Subscription failed"),
                        "broker": broker_name,
                    }
                )

        # Send combined response
        response = {
            "type": "subscribe",
            "status": "success" if subscription_success else "partial",
            "subscriptions": subscription_responses,
            "message": "Subscription processing complete",
            "broker": broker_name,
        }
        if request_id is not None:
            response["request_id"] = request_id
        await self.send_message(client_id, response)

    def _matching_client_subscriptions(self, client_id, sub_key):
        """Stored JSON rows owned by one client for an exact subscription key."""
        matches = []
        for sub_json in self.subscriptions.get(client_id, ()):
            try:
                sub_data = json.loads(sub_json)
            except json.JSONDecodeError:
                continue
            if (
                sub_data.get("symbol"),
                sub_data.get("exchange"),
                sub_data.get("mode"),
            ) == sub_key:
                matches.append(sub_json)
        return matches

    def _indexed_client_subscriptions(self, client_id):
        """Parse one client's stored rows once and index them by exact key."""
        parsed = []
        rows_by_key = defaultdict(list)
        for sub_json in self.subscriptions.get(client_id, ()):
            try:
                sub_data = json.loads(sub_json)
            except json.JSONDecodeError as exc:
                logger.error("Failed to parse subscription %r: %s", sub_json, exc)
                continue

            try:
                mode, mode_label = normalize_mode(sub_data.get("mode"))
                mode_error = None
            except (ValueError, TypeError) as exc:
                mode = None
                mode_label = None
                mode_error = str(exc)

            symbol = sub_data.get("symbol")
            exchange = sub_data.get("exchange")
            sub_key = (symbol, exchange, mode) if symbol and exchange and mode is not None else None
            parsed.append((sub_data, sub_key, mode_label, mode_error))
            if sub_key is not None:
                rows_by_key[sub_key].append(sub_json)
        return parsed, rows_by_key

    def _drop_subscription_ownership(self, client_id, sub_key, stored_rows):
        """Commit an acknowledged local ownership release."""
        owners = self.subscription_index.get(sub_key)
        if owners is not None:
            owners.discard(client_id)
            if not owners:
                del self.subscription_index[sub_key]
        client_subscriptions = self.subscriptions.get(client_id)
        if client_subscriptions is not None:
            for sub_json in stored_rows:
                client_subscriptions.discard(sub_json)

    def _purge_client_subscription_ownership(self, client_id):
        """Remove every local registry reference to a disconnected client."""
        for sub_key, owners in list(self.subscription_index.items()):
            owners.discard(client_id)
            if not owners:
                del self.subscription_index[sub_key]
        self.subscriptions.pop(client_id, None)

    def _unsubscribe_owned_subscription(
        self,
        client_id,
        adapter,
        symbol,
        exchange,
        mode,
        *,
        stored_rows=None,
    ):
        """Release one exact owner, committing only after the broker ack.

        When another client still owns the same broker subscription there is
        no broker call to acknowledge: removing this caller is a local commit.
        For the final owner, both registries remain intact until the adapter
        explicitly answers success.  That retained ownership is what makes a
        retry or disconnect able to release a feed the broker still holds.
        """
        sub_key = (symbol, exchange, mode)
        if stored_rows is None:
            stored_rows = self._matching_client_subscriptions(client_id, sub_key)
        owners = self.subscription_index.get(sub_key, set())
        owns_subscription = bool(stored_rows) or client_id in owners
        if not owns_subscription:
            return True, None

        if owners - {client_id}:
            self._drop_subscription_ownership(client_id, sub_key, stored_rows)
            return True, None

        try:
            response = adapter.unsubscribe(symbol, exchange, mode)
        except Exception as exc:
            logger.exception(
                "Broker unsubscribe raised for %s:%s mode %s",
                symbol,
                exchange,
                mode,
            )
            return False, str(exc) or "Unsubscription failed"

        if not isinstance(response, dict) or response.get("status") != "success":
            message = (
                response.get("message")
                if isinstance(response, dict)
                else "Invalid response from broker"
            )
            return False, message or "Unsubscription failed"

        self._drop_subscription_ownership(client_id, sub_key, stored_rows)
        logger.debug(
            "Last client unsubscribed from %s:%s, unsubscribing from adapter",
            symbol,
            exchange,
        )
        return True, None

    async def unsubscribe_client(self, client_id, data):
        """
        Unsubscribe a client from market data

        Args:
            client_id: ID of the client
            data: Unsubscription data
        """
        # Check if the client is authenticated
        if client_id not in self.user_mapping:
            await self.send_error(
                client_id, "NOT_AUTHENTICATED", "You must authenticate first", request_id=data.get("request_id")
            )
            return

        # Check if this is an unsubscribe_all request
        is_unsubscribe_all = (
            data.get("type") == "unsubscribe_all" or data.get("action") == "unsubscribe_all"
        )

        # Get unsubscription parameters for specific symbols
        symbols = data.get("symbols") or []
        # Optional request_id (issue #1376) — echoed in the response so callers
        # can correlate this ack with the originating unsubscribe request.
        request_id = data.get("request_id")

        # Handle single symbol format
        if not symbols and not is_unsubscribe_all and (data.get("symbol") and data.get("exchange")):
            try:
                _mode_int, _ = normalize_mode(data.get("mode", 2))
            except (ValueError, TypeError) as e:
                await self.send_error(
                client_id, "INVALID_MODE", str(e), request_id=data.get("request_id")
            )
                return
            symbols = [
                {
                    "symbol": data.get("symbol"),
                    "exchange": data.get("exchange"),
                    "mode": _mode_int,
                }
            ]

        # If no symbols provided and not unsubscribe_all, return error
        if not symbols and not is_unsubscribe_all:
            await self.send_error(
                client_id, "INVALID_PARAMETERS", "Either symbols or unsubscribe_all is required", request_id=data.get("request_id")
            )
            return

        # Get the user's broker adapter
        user_id = self.user_mapping[client_id]
        if user_id not in self.broker_adapters:
            await self.send_error(
                client_id, "BROKER_ERROR", "Broker adapter not found", request_id=data.get("request_id")
            )
            return

        adapter = self.broker_adapters[user_id]
        broker_name = self.user_broker_mapping.get(user_id, "unknown")

        # Process unsubscribe request
        successful_unsubscriptions = []
        failed_unsubscriptions = []

        # Handle unsubscribe_all case
        if is_unsubscribe_all:
            if client_id in self.subscriptions:
                parsed_subscriptions, rows_by_key = self._indexed_client_subscriptions(client_id)
                processed_keys = set()
                for index, (sub, sub_key, mode_label, mode_error) in enumerate(
                    parsed_subscriptions,
                    start=1,
                ):
                    symbol = sub.get("symbol")
                    exchange = sub.get("exchange")
                    if index % 128 == 0:
                        await aio.sleep(0)
                    if mode_error is not None:
                        failed_unsubscriptions.append(
                            {
                                "symbol": symbol,
                                "exchange": exchange,
                                "mode": None,
                                "status": "error",
                                "message": mode_error,
                                "broker": broker_name,
                            }
                        )
                        continue

                    if sub_key is not None and sub_key not in processed_keys:
                        processed_keys.add(sub_key)
                        mode = sub_key[2]
                        ok, error = self._unsubscribe_owned_subscription(
                            client_id,
                            adapter,
                            symbol,
                            exchange,
                            mode,
                            stored_rows=rows_by_key[sub_key],
                        )
                        if not ok:
                            failed_unsubscriptions.append(
                                {
                                    "symbol": symbol,
                                    "exchange": exchange,
                                    "mode": mode_label,
                                    "status": "error",
                                    "message": error,
                                    "broker": broker_name,
                                }
                            )
                            continue

                        successful_unsubscriptions.append(
                            {
                                "symbol": symbol,
                                "exchange": exchange,
                                "mode": mode_label,
                                "status": "success",
                                "broker": broker_name,
                            }
                        )
        else:
            # Process specific symbols
            for symbol_info in symbols:
                symbol = symbol_info.get("symbol")
                exchange = symbol_info.get("exchange")
                # Normalize mode (accepts 1/2/3 or LTP/Quote/Depth case-insensitive).
                # A per-symbol mode is the most specific value.  Array-form
                # requests historically ignored their documented top-level
                # mode and silently defaulted every item to Quote, which could
                # answer success while leaving an LTP/Depth subscription live.
                # Fall back to the request mode, then Quote only when neither
                # spelling supplied one.
                try:
                    raw_mode = (
                        symbol_info["mode"]
                        if "mode" in symbol_info
                        else data.get("mode", 2)
                    )
                    mode, mode_label = normalize_mode(raw_mode)
                except (ValueError, TypeError) as e:
                    failed_unsubscriptions.append(
                        {
                            "symbol": symbol,
                            "exchange": exchange,
                            "mode": None,
                            "status": "error",
                            "message": str(e),
                            "broker": broker_name,
                        }
                    )
                    continue

                if not symbol or not exchange:
                    continue  # Skip invalid symbols

                ok, error = self._unsubscribe_owned_subscription(
                    client_id, adapter, symbol, exchange, mode
                )
                if not ok:
                    failed_unsubscriptions.append(
                        {
                            "symbol": symbol,
                            "exchange": exchange,
                            "mode": mode_label,
                            "status": "error",
                            "message": error,
                            "broker": broker_name,
                        }
                    )
                    continue

                successful_unsubscriptions.append(
                    {
                        "symbol": symbol,
                        "exchange": exchange,
                        "mode": mode_label,
                        "status": "success",
                        "broker": broker_name,
                    }
                )

        # Send combined response
        status = "success"
        if len(failed_unsubscriptions) > 0 and len(successful_unsubscriptions) > 0:
            status = "partial"
        elif len(failed_unsubscriptions) > 0 and len(successful_unsubscriptions) == 0:
            status = "error"

        unsub_response = {
            "type": "unsubscribe",
            "status": status,
            "message": "Unsubscription processing complete",
            "successful": successful_unsubscriptions,
            "failed": failed_unsubscriptions,
            "broker": broker_name,
        }
        if request_id is not None:
            unsub_response["request_id"] = request_id
        await self.send_message(client_id, unsub_response)

    async def subscribe_orders_client(self, client_id, data):
        """
        Subscribe a client to real-time order updates for their account.

        Account-scoped (no symbol/exchange/mode) — every order-status change
        for the authenticated user's broker session is delivered, sourced
        from the order.update event bus topic (broker postback/order-WS
        adapters or the sandbox engine) via subscribers/wsproxy_subscriber.py.

        Args:
            client_id: ID of the client
            data: Subscription data (optional request_id)
        """
        if client_id not in self.user_mapping:
            await self.send_error(
                client_id, "NOT_AUTHENTICATED", "You must authenticate first", request_id=data.get("request_id")
            )
            return

        user_id = self.user_mapping[client_id]
        request_id = data.get("request_id")

        self.order_subscribers[user_id].add(client_id)

        response = {
            "type": "subscribe_orders",
            "status": "success",
            "message": "Subscribed to order updates",
        }
        if request_id is not None:
            response["request_id"] = request_id
        await self.send_message(client_id, response)

    async def unsubscribe_orders_client(self, client_id, data):
        """
        Unsubscribe a client from real-time order updates.

        Args:
            client_id: ID of the client
            data: Unsubscription data (optional request_id)
        """
        if client_id not in self.user_mapping:
            await self.send_error(
                client_id, "NOT_AUTHENTICATED", "You must authenticate first", request_id=data.get("request_id")
            )
            return

        user_id = self.user_mapping[client_id]
        request_id = data.get("request_id")

        if user_id in self.order_subscribers:
            self.order_subscribers[user_id].discard(client_id)
            if not self.order_subscribers[user_id]:
                del self.order_subscribers[user_id]

        response = {
            "type": "unsubscribe_orders",
            "status": "success",
            "message": "Unsubscribed from order updates",
        }
        if request_id is not None:
            response["request_id"] = request_id
        await self.send_message(client_id, response)

    async def send_message(self, client_id, message):
        """
        Send a message to a client

        Args:
            client_id: ID of the client
            message: The message to send
        """
        if client_id in self.clients:
            websocket = self.clients[client_id]
            try:
                await websocket.send(json.dumps(message))
            except websockets.exceptions.ConnectionClosed:
                logger.info(f"Connection closed while sending message to client {client_id}")

    async def send_error(self, client_id, code, message, request_id=None):
        """
        Send an error message to a client

        Args:
            client_id: ID of the client
            code: Error code
            message: Error message
            request_id: The request this error answers, when it answers one.
                Success responses have echoed it since issue #1376 so a caller
                can correlate an ack; errors did not, so a client awaiting an
                ack had nothing to match it against and waited out its own
                timeout for a reply that had already arrived. Always pass it
                from a handler that was given one.
        """
        payload = {"status": "error", "code": code, "message": message}
        if request_id is not None:
            payload["request_id"] = request_id
        await self.send_message(client_id, payload)

    def _handle_cache_invalidation(self, topic_str: str, data_str: str):
        """
        Handle cache invalidation messages from Flask process.

        When a user re-authenticates or logs out, Flask publishes a cache invalidation
        message via ZeroMQ. This method clears the local auth caches so that the next
        request fetches fresh data from the database.

        This solves the stale token issue described in GitHub issue #765.

        Args:
            topic_str: The ZMQ topic (format: CACHE_INVALIDATE_{TYPE}_{USER_ID})
            data_str: JSON string with invalidation details
        """
        try:
            # Import caches locally to avoid circular imports
            from database.auth_db import (
                auth_cache,
                broker_cache,
                feed_token_cache,
                invalid_api_key_cache,
                verified_api_key_cache,
            )

            # Parse the invalidation message
            message = json.loads(data_str)
            user_id = message.get("user_id")
            cache_type = message.get("cache_type", "ALL")

            if not user_id:
                logger.warning("Cache invalidation message missing user_id")
                return

            logger.info(f"Received cache invalidation for user: {user_id}, type: {cache_type}")

            # CRITICAL: Clear ALL cache entries to prevent stale token issues
            # This is necessary because get_auth_token_broker() uses a different cache key format
            # (sha256(api_key)_include_feed_token) than the user-id based keys.
            # Without clearing all entries, old cached tokens would persist and cause
            # 401 Unauthorized errors after re-login.
            # See GitHub issue #851 for details on this cache key mismatch bug.
            caches_cleared = []

            if cache_type in ("AUTH", "ALL"):
                auth_cache.clear()
                caches_cleared.append("auth_cache")

            if cache_type in ("FEED", "ALL"):
                feed_token_cache.clear()
                caches_cleared.append("feed_token_cache")

            if cache_type == "ALL":
                broker_cache.clear()
                caches_cleared.append("broker_cache")

                verified_api_key_cache.clear()
                invalid_api_key_cache.clear()
                caches_cleared.append("verified_api_key_cache")
                caches_cleared.append("invalid_api_key_cache")

            if caches_cleared:
                logger.info(f"Cleared caches for user {user_id}: {', '.join(caches_cleared)}")
            else:
                logger.debug(f"No cached data found for user {user_id}")

            # Also disconnect and clean up any existing broker adapters for this user
            # This forces re-initialization with fresh credentials on next connection
            if user_id in self.broker_adapters:
                try:
                    adapter = self.broker_adapters[user_id]
                    adapter.disconnect()
                    del self.broker_adapters[user_id]
                    logger.info(f"Disconnected stale broker adapter for user {user_id}")
                except Exception as adapter_error:
                    logger.warning(f"Error disconnecting adapter for user {user_id}: {adapter_error}")

            # broker_adapters only tracks the wrapper currently attached to a
            # client. The global connection-pool registry may still contain an
            # old per-user pool after logout/re-login, especially when the
            # invalidation races with a dashboard reconnect. Purge it too.
            try:
                from .broker_factory import cleanup_pools_for_user

                removed_pools = cleanup_pools_for_user(user_id)
                if removed_pools:
                    logger.info(
                        f"Disconnected {removed_pools} cached connection pool(s) for user {user_id}"
                    )
            except Exception as pool_error:
                logger.warning(
                    f"Error cleaning connection pools for user {user_id}: {pool_error}"
                )

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse cache invalidation message: {e}")
        except Exception as e:
            logger.exception(f"Error processing cache invalidation: {e}")

    async def _handle_order_update(self, data_str: str):
        """
        Relay an order-update message (published by
        subscribers/wsproxy_subscriber.py onto the "{BROKER}_{USER_ID}_orders"
        / "ANALYZE_{USER_ID}_orders" ZMQ topics) to every WS client that sent
        {"action": "subscribe_orders"} for that user.

        Args:
            data_str: JSON string — the payload built in
                subscribers/wsproxy_subscriber.py::on_order_update, already
                shaped as the client-facing {"type": "order_update", ...} message.
        """
        message = json.loads(data_str)
        user_id = message.get("user_id")
        if not user_id:
            logger.warning("Order update message missing user_id")
            return

        client_ids = self.order_subscribers.get(user_id)
        if not client_ids:
            return  # no WS clients currently subscribed for this user

        send_tasks = [
            self.send_message(client_id, message)
            for client_id in list(client_ids)
            if client_id in self.clients
        ]
        if send_tasks:
            await aio.gather(*send_tasks, return_exceptions=True)

    def _is_auth_error_exception(self, error_message: str) -> bool:
        """
        Check if an error message indicates an authentication failure.

        Used to detect when to retry with fresh credentials (issue #765).

        Args:
            error_message: The error message string

        Returns:
            True if the error indicates authentication failure (401/403)
        """
        if not error_message:
            return False

        error_lower = str(error_message).lower()
        auth_error_indicators = [
            "401",
            "403",
            "unauthorized",
            "forbidden",
            "authentication failed",
            "auth failed",
            "invalid token",
            "token expired",
            "access denied",
            "invalid credentials",
            "session expired",
        ]
        return any(indicator in error_lower for indicator in auth_error_indicators)

    def _clear_auth_cache_for_user(self, user_id: str):
        """
        Clear all cached authentication data for a user.

        Called when detecting stale credentials (e.g., 403 error from broker).
        See GitHub issue #765 for details.

        Args:
            user_id: The user's ID
        """
        try:
            from database.auth_db import broker_cache, invalidate_user_auth_cache

            cache_key_auth = f"auth-{user_id}"

            # One call per cache, never a membership test then a delete.
            caches_cleared = invalidate_user_auth_cache(user_id)
            if broker_cache.pop(cache_key_auth, None) is not None:
                caches_cleared.append("broker_cache")

            if caches_cleared:
                logger.info(f"Cleared auth caches for user {user_id}: {', '.join(caches_cleared)}")
            else:
                logger.debug(f"No cached auth data found for user {user_id}")

        except Exception as e:
            logger.exception(f"Error clearing auth cache for user {user_id}: {e}")

    async def zmq_listener(self):
        """
        OPTIMIZED: Listen for messages from broker adapters via ZeroMQ and forward to clients

        Key Performance Improvements:
        1. Increased timeout from 0.1s to 0.3s (reduces busy-waiting by 66%)
        2. Use subscription_index for O(1) lookup instead of O(n²) iteration
        3. Batch message sending with asyncio.gather

        Also handles cache invalidation messages from Flask process for cross-process
        cache synchronization (see GitHub issue #765).
        """
        logger.debug("Starting OPTIMIZED ZeroMQ listener with subscription indexing and cache invalidation support")

        while self.running:
            try:
                # Check if we should stop
                if not self.running:
                    break

                # RESOURCE CLEANUP: Periodically clean stale throttle entries
                self._cleanup_stale_throttle_entries()

                # OBSERVABILITY: periodically warn on connected-but-silent feeds
                self._log_stale_adapters()

                # OPTIMIZATION 1: Increased timeout to reduce busy-waiting
                try:
                    [topic, data] = await aio.wait_for(
                        self.socket.recv_multipart(),
                        timeout=0.3,  # Increased from 0.1s (66% less CPU usage)
                    )
                except TimeoutError:
                    # No message received within timeout, continue the loop
                    continue

                # Parse the message
                topic_str = topic.decode("utf-8")
                data_str = data.decode("utf-8")

                # Handle cache invalidation messages (from Flask process)
                # These messages clear stale auth tokens after re-login
                # See GitHub issue #765 for details
                if topic_str.startswith("CACHE_INVALIDATE"):
                    try:
                        self._handle_cache_invalidation(topic_str, data_str)
                    except Exception as e:
                        logger.exception(f"Error handling cache invalidation: {e}")
                    continue  # Skip market data processing for cache messages

                # Order-update relay: published by subscribers/wsproxy_subscriber.py
                # (topic "{BROKER}_{USER_ID}_orders" or "ANALYZE_{USER_ID}_orders").
                # user_id comes from the JSON payload, not topic-string parsing —
                # usernames may contain underscores, same reasoning as the
                # CACHE_INVALIDATE_* handling below.
                if topic_str.endswith("_orders"):
                    try:
                        await self._handle_order_update(data_str)
                    except Exception as e:
                        logger.exception(f"Error handling order update: {e}")
                    continue

                # Skip other private account-level event topics (positions, margins).
                # These are published by broker adapters on the shared ZMQ socket but
                # do not follow the BROKER_EXCHANGE_SYMBOL_MODE market-data format.
                if topic_str.endswith(("_positions", "_margins")):
                    logger.debug(f"Skipping private event topic: {topic_str}")
                    continue

                market_data = json.loads(data_str)

                # Extract topic components from ZMQ topic string.
                # All adapters publish: EXCHANGE_SYMBOL_MODE
                # Mode (LTP/QUOTE/DEPTH) is always the LAST segment.
                # Exchange is the first segment (NSE, BSE, NFO, MCX, CRYPTO, …)
                #   except NSE_INDEX / BSE_INDEX which span two segments.
                # Symbol is everything between exchange and mode — may contain
                # underscores for crypto spot pairs (e.g. CRYPTO_SOL_INR_LTP).
                parts = topic_str.split("_")

                if len(parts) < 3:
                    logger.warning(f"Invalid topic format: {topic_str}")
                    continue

                broker_name = "unknown"

                # Mode is always the last segment
                mode_str = parts[-1]
                remaining = parts[:-1]  # everything except mode

                # Detect two-segment exchange prefixes (NSE_INDEX, BSE_INDEX,
                # MCX_INDEX, GLOBAL_INDEX, NSEIX_INDEX). Add new index/multi-segment
                # exchanges here when introducing them.
                _MULTI_SEGMENT_EXCHANGE_PREFIXES = (
                    ("NSE", "INDEX"),
                    ("BSE", "INDEX"),
                    ("MCX", "INDEX"),
                    ("GLOBAL", "INDEX"),
                )
                if len(remaining) >= 2 and (remaining[0], remaining[1]) in _MULTI_SEGMENT_EXCHANGE_PREFIXES:
                    exchange = f"{remaining[0]}_{remaining[1]}"
                    symbol = "_".join(remaining[2:])
                else:
                    exchange = remaining[0]
                    symbol = "_".join(remaining[1:])

                if not symbol:
                    logger.warning(f"Invalid topic format (no symbol): {topic_str}")
                    continue

                # Route through the single normalizer so topic parsing stays
                # consistent with client-side mode handling.
                normalized = normalize_mode_or_none(mode_str)
                if normalized is None:
                    logger.warning(f"Invalid mode in topic: {mode_str}")
                    continue
                mode, _ = normalized

                # No server-side LTP throttling: the previous time-based
                # throttle dropped intra-window ticks instead of coalescing
                # them, so clients could miss the latest price during bursts
                # (e.g. NIFTY expiry, circuit triggers). With the O(1)
                # subscription_index, fan-out is cheap enough to forward every
                # tick. If CPU pressure ever returns, replace this with a
                # trailing-edge coalescer that emits the latest pending tick.
                sub_key = (symbol, exchange, mode)
                current_time = time.time()
                self.last_message_time[sub_key] = current_time

                # Feed market data to MarketDataService for backend consumers
                # (sandbox execution engine, position MTM, RMS, etc.)
                # This runs regardless of whether WebSocket clients are subscribed
                try:
                    mds_data = {
                        "symbol": symbol,
                        "exchange": exchange,
                        "mode": mode,
                        "data": market_data,
                    }
                    market_data_service = get_market_data_service()
                    market_data_service.process_market_data(mds_data)
                except Exception as mds_error:
                    # Don't block WebSocket delivery if MarketDataService has issues
                    logger.debug(f"MarketDataService processing error: {mds_error}")

                # OPTIMIZATION 2: O(1) lookup using subscription index
                # Higher modes include all lower-mode data (Depth > Quote > LTP),
                # so also deliver to subscribers at lower modes.
                # Maps client_id -> the mode they subscribed to (for correct message tagging)
                all_client_modes = {}
                for m in range(1, mode + 1):
                    for cid in self.subscription_index.get((symbol, exchange, m), set()):
                        all_client_modes[cid] = m

                if not all_client_modes:
                    continue  # No WebSocket clients subscribed, skip delivery

                # OPTIMIZATION 3: Batch message sends for parallel delivery
                send_tasks = []

                # OPTIMIZATION 4: Pre-create base message (reused for all clients)
                # This avoids creating the same dict 1000 times
                base_message = {
                    "type": "market_data",
                    "symbol": symbol,
                    "exchange": exchange,
                    "mode": mode,
                    "data": market_data,
                }

                for client_id, client_mode in all_client_modes.items():
                    # Verify client still exists
                    if client_id not in self.clients:
                        continue

                    # Verify user mapping exists
                    user_id = self.user_mapping.get(client_id)
                    if not user_id:
                        continue

                    # OBSERVABILITY: record that this user's feed is live (a tick
                    # was delivered). Cheap dict write; lets _log_stale_adapters()
                    # detect connected-but-silent adapters.
                    self.last_tick_time[user_id] = current_time

                    # Check broker match (important for multi-broker setups)
                    client_broker = self.user_broker_mapping.get(user_id)
                    if broker_name != "unknown" and client_broker and client_broker != broker_name:
                        continue

                    # Tag message with client's subscribed mode so frontend renders correctly
                    message = base_message.copy()
                    message["mode"] = client_mode
                    message["broker"] = broker_name if broker_name != "unknown" else client_broker

                    # Add to batch
                    send_tasks.append(self.send_message(client_id, message))

                # Send all messages in parallel (non-blocking)
                if send_tasks:
                    await aio.gather(*send_tasks, return_exceptions=True)

                # METRICS: Track message count for health monitoring
                self._messages_processed += 1

            except Exception as e:
                logger.exception(f"Error in ZeroMQ listener: {e}")
                # Continue running despite errors
                await aio.sleep(1)


#: Set by the app when it starts this process as a supervised child (gthread
#: worker only): the pid of the worker that owns it.
PARENT_PID_ENV = "OPENALGO_PROXY_PARENT_PID"
ORPHAN_CHECK_SECONDS = 1.0


def _expected_parent_pid() -> int | None:
    """The owning worker's pid, when this child should exit once orphaned."""
    if os.name != "posix":
        return None
    raw = os.environ.get(PARENT_PID_ENV, "").strip()
    try:
        pid = int(raw)
    except ValueError:
        return None
    return pid if pid > 0 else None


async def _exit_when_orphaned(proxy, parent_pid: int) -> None:
    """Stop the proxy once the worker that started it has gone.

    A worker killed hard (a worker timeout, or SIGKILL after the graceful
    window) never runs its exit handlers, so nothing terminates this child.
    Left running it would keep the WebSocket and ZeroMQ ports, and the next
    worker's child would fail to bind them. When the parent dies the child is
    re-parented, so a changed parent pid means it is time to go.
    """
    warned = False
    while True:
        await aio.sleep(ORPHAN_CHECK_SECONDS)
        if os.getppid() == parent_pid:
            continue
        if not warned:
            warned = True
            logger.warning(
                "The OpenAlgo web server that started live market data has "
                "stopped; stopping this copy so the next one can start."
            )
        # Every check, not once: start() sets the flag when it begins, so a
        # parent that died before that would otherwise be missed.
        proxy.running = False


# Entry point for running the server standalone
async def main():
    """Main entry point for running the WebSocket proxy server"""
    proxy = None
    orphan_watch = None

    try:
        # Load environment variables
        load_dotenv()

        # Get WebSocket configuration from environment variables
        ws_host = os.getenv("WEBSOCKET_HOST", "127.0.0.1")
        ws_port = int(os.getenv("WEBSOCKET_PORT", "8765"))

        # Create and start the WebSocket proxy
        proxy = WebSocketProxy(host=ws_host, port=ws_port)

        parent_pid = _expected_parent_pid()
        if parent_pid is not None:
            orphan_watch = aio.create_task(_exit_when_orphaned(proxy, parent_pid))

        await proxy.start()

    except KeyboardInterrupt:
        logger.info("Server stopped by user (KeyboardInterrupt)")
    except RuntimeError as e:
        if "set_wakeup_fd only works in main thread" in str(e):
            logger.error(f"Error in start method: {e}")
            logger.info("Starting ZeroMQ listener without signal handlers")
            # Continue with ZeroMQ listener even if signal handlers fail
            if proxy:
                await proxy.zmq_listener()
        else:
            logger.error(f"Runtime error: {e}")
            raise
    except Exception as e:
        logger.exception(f"Server error: {e}")
        raise
    finally:
        if orphan_watch is not None:
            orphan_watch.cancel()
        # Always clean up resources
        if proxy:
            try:
                await proxy.stop()
            except Exception as cleanup_error:
                logger.exception(f"Error during cleanup: {cleanup_error}")


if __name__ == "__main__":
    aio.run(main())
