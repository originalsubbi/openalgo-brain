import json
import os

from flask import jsonify, make_response, request
from flask_restx import Namespace, Resource
from marshmallow import ValidationError

from limiter import limiter
from services.chart_service import get_chart_preferences, update_chart_preferences
from utils.logging import get_logger

from .account_schema import ChartSchema

API_RATE_LIMIT = os.getenv("API_RATE_LIMIT", "10 per second")
api = Namespace("chart", description="Chart Preferences and Cloud Workspace Sync")

# Initialize logger
logger = get_logger(__name__)

# Initialize schema
chart_schema = ChartSchema()


@api.route("", strict_slashes=False)
class ChartPreferencesResource(Resource):
    @limiter.limit(API_RATE_LIMIT)
    @api.doc(params={"apikey": "API Key for authentication"})
    def get(self):
        """
        Get chart preferences.

        Pass apikey as query parameter: /api/v1/chart?apikey=your-api-key
        Returns all saved chart preferences for the user.
        """
        try:
            # Get apikey from query parameter
            api_key = request.args.get("apikey")

            if not api_key:
                return make_response(
                    jsonify({"status": "error", "message": "Missing apikey parameter"}), 400
                )

            logger.info(f"[ChartAPI] GET preferences request. API Key present: {bool(api_key)}")
            success, response_data, status_code = get_chart_preferences(api_key)

            return make_response(jsonify(response_data), status_code)

        except Exception as e:
            logger.exception(f"Unexpected error in chart GET endpoint: {e}")
            return make_response(
                jsonify({"status": "error", "message": "An unexpected error occurred"}), 500
            )

    @limiter.limit(API_RATE_LIMIT)
    def post(self):
        """
        Update chart preferences.

        Send apikey and preferences in JSON body:
        {"apikey": "your-api-key", "tv_theme": "dark", "tv_chart_layout": "{...}"}
        """
        try:
            data = request.json
            if not data:
                return make_response(
                    jsonify({"status": "error", "message": "No data provided"}), 400
                )

            # Validate that apikey is present
            chart_data = chart_schema.load(data)
            api_key = chart_data["apikey"]

            # Extract preferences (all keys except apikey)
            preferences = {k: v for k, v in data.items() if k != "apikey"}

            # Limit payload: max 50 keys, each key max 50 chars, each value max 1MB
            if len(preferences) > 50:
                return make_response(
                    jsonify({"status": "error", "message": "Too many preference keys (max 50)"}), 400
                )
            for k, v in preferences.items():
                if len(k) > 50:
                    return make_response(
                        jsonify({"status": "error", "message": f"Preference key too long: {k[:20]}... (max 50 chars)"}), 400
                    )
                # Check serialized size for all value types (not just strings)
                try:
                    serialized = json.dumps(v)
                except (TypeError, ValueError):
                    serialized = str(v)
                if len(serialized) > 1_048_576:
                    return make_response(
                        jsonify({"status": "error", "message": f"Preference value too large for key: {k} (max 1MB)"}), 400
                    )

            if not preferences:
                return make_response(
                    jsonify({"status": "error", "message": "No preferences provided to update"}),
                    400,
                )

            logger.info(f"[ChartAPI] POST update request. Keys: {list(preferences.keys())}")
            success, response_data, status_code = update_chart_preferences(api_key, preferences)

            return make_response(jsonify(response_data), status_code)

        except ValidationError as err:
            return make_response(jsonify({"status": "error", "message": err.messages}), 400)
        except Exception as e:
            logger.exception(f"Unexpected error in chart POST endpoint: {e}")
            return make_response(
                jsonify({"status": "error", "message": "An unexpected error occurred"}), 500
            )
