import os

from flask import jsonify, make_response, request
from flask_restx import Namespace, Resource
from marshmallow import ValidationError

from database.settings_db import get_analyze_mode
from events import OrderFailedEvent
from utils.event_bus import bus
from limiter import limiter
from restx_api.schemas import SplitOrderSchema
from services.split_order_service import emit_analyzer_error, split_order
from utils.logging import get_logger

API_RATE_LIMIT = os.getenv("API_RATE_LIMIT", "10 per second")
api = Namespace("split_order", description="Split Order API")

# Initialize logger
logger = get_logger(__name__)

# Initialize schema
split_schema = SplitOrderSchema()


@api.route("/", strict_slashes=False)
class SplitOrder(Resource):
    @limiter.limit(API_RATE_LIMIT)
    def post(self):
        """Split a large order into multiple orders of specified size"""
        try:
            data = request.json

            # Validate and deserialize input
            try:
                split_data = split_schema.load(data)
            except ValidationError as err:
                error_message = str(err.messages)
                if get_analyze_mode():
                    return make_response(jsonify(emit_analyzer_error(data, error_message)), 400)
                error_response = {"status": "error", "message": error_message}
                bus.publish(OrderFailedEvent(
                    mode="live",
                    api_type="splitorder",
                    request_data=data,
                    response_data=error_response,
                    error_message=error_message,
                ))
                return make_response(jsonify(error_response), 400)

            # Extract API key
            api_key = split_data.pop("apikey", None)

            # Call the service function to split the order
            success, response_data, status_code = split_order(
                split_data=split_data, api_key=api_key
            )

            return make_response(jsonify(response_data), status_code)

        except Exception:
            logger.exception("An unexpected error occurred in SplitOrder endpoint.")
            error_message = "An unexpected error occurred"
            if get_analyze_mode():
                return make_response(jsonify(emit_analyzer_error(data, error_message)), 500)
            error_response = {"status": "error", "message": error_message}
            bus.publish(OrderFailedEvent(
                mode="live",
                api_type="splitorder",
                request_data=data,
                response_data=error_response,
                error_message=error_message,
            ))
            return make_response(jsonify(error_response), 500)
