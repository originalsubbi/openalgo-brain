import os

from flask import jsonify, make_response, request
from flask_restx import Namespace, Resource
from marshmallow import ValidationError

from database.settings_db import get_analyze_mode
from events import OrderFailedEvent
from utils.event_bus import bus
from limiter import limiter
from restx_api.schemas import SmartOrderSchema
from services.place_smart_order_service import emit_analyzer_error, place_smart_order
from utils.logging import get_logger

SMART_ORDER_RATE_LIMIT = os.getenv("SMART_ORDER_RATE_LIMIT", "10 per second")
api = Namespace("place_smart_order", description="Place Smart Order API")

# Initialize logger
logger = get_logger(__name__)

# Initialize schema
smart_order_schema = SmartOrderSchema()


@api.route("/", strict_slashes=False)
class SmartOrder(Resource):
    @limiter.limit(SMART_ORDER_RATE_LIMIT)
    def post(self):
        """Place a smart order"""
        try:
            data = request.json

            # Validate and deserialize input
            try:
                order_data = smart_order_schema.load(data)
            except ValidationError as err:
                error_message = str(err.messages)
                if get_analyze_mode():
                    return make_response(jsonify(emit_analyzer_error(data, error_message)), 400)
                error_response = {"status": "error", "message": error_message}
                bus.publish(OrderFailedEvent(
                    mode="live",
                    api_type="placesmartorder",
                    request_data=data,
                    response_data=error_response,
                    error_message=error_message,
                ))
                return make_response(jsonify(error_response), 400)

            # Extract API key
            api_key = order_data.pop("apikey", None)

            # Call the service function to place the smart order
            success, response_data, status_code = place_smart_order(
                order_data=order_data, api_key=api_key
            )

            return make_response(jsonify(response_data), status_code)

        except Exception:
            logger.exception("An unexpected error occurred in SmartOrder endpoint.")
            error_message = "An unexpected error occurred"
            if get_analyze_mode():
                return make_response(jsonify(emit_analyzer_error(data, error_message)), 500)
            error_response = {"status": "error", "message": error_message}
            bus.publish(OrderFailedEvent(
                mode="live",
                api_type="placesmartorder",
                request_data=data,
                response_data=error_response,
                error_message=error_message,
            ))
            return make_response(jsonify(error_response), 500)
