/**
 * TradeBook Node
 * Fetch trade book with executed trades
 */

import { Handle, Position } from '@xyflow/react'
import { Receipt } from 'lucide-react'
import { memo } from 'react'
import { cn } from '@/lib/utils'
import type { TradeBookNodeData } from '@/types/flow'

interface TradeBookNodeProps {
  data: TradeBookNodeData
  selected?: boolean
}

export const TradeBookNode = memo(({ data, selected }: TradeBookNodeProps) => {
  return (
    <div className={cn('workflow-node min-w-[110px] border-l-primary', selected && 'selected')}>
      <Handle type="target" position={Position.Top} className="!top-0 !-translate-y-1/2" />
      <div className="p-2">
        <div className="mb-1.5 flex items-center gap-1.5">
          <div className="flex h-5 w-5 items-center justify-center rounded bg-primary/20 text-primary">
            <Receipt className="h-3 w-3" />
          </div>
          <div>
            <div className="text-xs font-medium leading-tight">Trade Book</div>
            <div className="text-[9px] text-muted-foreground">Executed trades</div>
          </div>
        </div>
        {data.outputVariable && (
          <div className="rounded bg-muted/50 px-1.5 py-1 text-center">
            <span className="text-[9px] text-muted-foreground">{data.outputVariable}</span>
          </div>
        )}
      </div>
      <Handle type="source" position={Position.Bottom} className="!bottom-0 !translate-y-1/2" />
    </div>
  )
})

TradeBookNode.displayName = 'TradeBookNode'
