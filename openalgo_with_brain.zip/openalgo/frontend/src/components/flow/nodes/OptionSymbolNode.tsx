/**
 * OptionSymbol Node
 * Resolve option symbol from underlying, expiry, offset, option type
 */

import { Handle, Position } from '@xyflow/react'
import { Target } from 'lucide-react'
import { memo } from 'react'
import { cn } from '@/lib/utils'
import type { OptionSymbolNodeData } from '@/types/flow'

interface OptionSymbolNodeProps {
  data: OptionSymbolNodeData
  selected?: boolean
}

export const OptionSymbolNode = memo(({ data, selected }: OptionSymbolNodeProps) => {
  return (
    <div className={cn('workflow-node min-w-[130px] border-l-primary', selected && 'selected')}>
      <Handle type="target" position={Position.Top} className="!top-0 !-translate-y-1/2" />
      <div className="p-2">
        <div className="mb-1.5 flex items-center gap-1.5">
          <div className="flex h-5 w-5 items-center justify-center rounded bg-primary/20 text-primary">
            <Target className="h-3 w-3" />
          </div>
          <div>
            <div className="text-xs font-medium leading-tight">Option Symbol</div>
            <div className="text-[9px] text-muted-foreground">
              {data.optionType || 'CE'} {data.offset || 'ATM'}
            </div>
          </div>
        </div>
        <div className="space-y-0.5 rounded bg-muted/50 px-1.5 py-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-muted-foreground">Underlying</span>
            <span className="mono-data text-[10px] font-medium">{data.underlying || '-'}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-muted-foreground">Expiry</span>
            <span className="mono-data text-[10px] font-medium">{data.expiryDate || '-'}</span>
          </div>
        </div>
        {data.outputVariable && (
          <div className="mt-1 text-center text-[9px] text-muted-foreground">
            {data.outputVariable}
          </div>
        )}
      </div>
      <Handle type="source" position={Position.Bottom} className="!bottom-0 !translate-y-1/2" />
    </div>
  )
})

OptionSymbolNode.displayName = 'OptionSymbolNode'
