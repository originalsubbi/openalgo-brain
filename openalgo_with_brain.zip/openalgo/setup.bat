@echo off
REM ============================================================================
REM  OpenAlgo - setup.bat
REM  Interactive configuration of the .env file. Asks for the broker API key and
REM  secret, server address/port, redirect URL, WebSocket, CORS, sessions and
REM  logging. Press Enter to keep the value shown in [brackets]; type - to clear
REM  a value. At the end you can optionally walk through EVERY other variable in
REM  .env (rate limits, CSP, databases, ...).
REM
REM  Nothing is written until you confirm. The old file is kept as .env.bak.
REM  The security keys are handled by keys.bat, not here.
REM ============================================================================
setlocal EnableExtensions
cd /d "%~dp0"
title OpenAlgo - Setup

set "DBLCLICK="
echo %cmdcmdline% | find /i "/c" >nul && set "DBLCLICK=1"

if not exist "envtool.py" (
    echo [ERROR] envtool.py not found next to setup.bat.
    goto :fail
)

call :find_python
if not defined PY (
    echo [ERROR] Python was not found. Run install.bat first.
    goto :fail
)

%PY% "%~dp0envtool.py" setup
if errorlevel 1 goto :fail

echo.
echo   Next: start.bat   (run keys.bat first if you have not generated keys yet)
echo.
if defined DBLCLICK pause
exit /b 0

:fail
if defined DBLCLICK pause
exit /b 1

:find_python
set "PY="
python -c "import sys" >nul 2>&1 && set "PY=python"
if not defined PY (
    py -3 -c "import sys" >nul 2>&1 && set "PY=py -3"
)
exit /b 0
