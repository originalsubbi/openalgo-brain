@echo off
REM ============================================================================
REM  OpenAlgo - rebuild-venv.bat
REM
REM  Makes THIS copy of OpenAlgo runnable on a computer it was not built on.
REM  A .venv folder is bound to the machine that created it: its python.exe is a
REM  launcher with an absolute interpreter path burned in, so a .venv copied
REM  from a USB stick always fails on another PC with
REM      "did not find executable at ... The system cannot find the path specified."
REM  This script rebuilds that part, keeps everything else (config, database,
REM  web UI, strategies) exactly as it is on the stick.
REM
REM  Steps
REM     1  stop a running OpenAlgo server (so .venv files are not locked)
REM     2  delete the old .venv
REM     3  make sure "uv" is available            - installs it if it is not
REM     4  make sure Python 3.12 or newer is there - installs it if it is not
REM     5  rebuild .venv from pyproject.toml + uv.lock
REM     6  runtime folders, .env, security keys, web UI
REM     7  verify the result
REM
REM  Usage
REM     rebuild-venv.bat          full rebuild (delete .venv, install, sync)
REM     rebuild-venv.bat keep     keep the current .venv, only install/sync
REM
REM  After it finishes, start the project with:  start.bat
REM ============================================================================
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title OpenAlgo - Rebuild Environment

set "PY_MIN=3.12"
set "KEEPVENV="
if /i "%~1"=="keep" set "KEEPVENV=1"

set "PY_CMD="
set "PY_PATH="
set "UV_CMD="

echo.
echo   ===========================================
echo     OpenAlgo - rebuild local environment
echo   ===========================================
echo   Project : %CD%
echo   Python  : !PY_MIN! or newer required
echo.

REM ---- 0. sanity -------------------------------------------------------------
if not exist "app.py" (
    echo [ERROR] app.py not found. Put this file in the OpenAlgo project root.
    goto :fail
)

REM ---- 1. stop a running server ----------------------------------------------
echo [1/7] Stopping any running OpenAlgo server...
if exist "stop.bat" (
    call "stop.bat" quiet
) else (
    echo       stop.bat not found - skipping.
)

REM ---- 2. delete the old .venv ----------------------------------------------
if defined KEEPVENV (
    echo [2/7] Keeping the existing .venv ^(argument "keep"^).
) else (
    echo [2/7] Removing the old virtual environment...
    if exist ".venv" (
        rmdir /s /q ".venv" >nul 2>&1
        if exist ".venv" (
            REM long paths / locked files - mirror an empty folder over it
            set "EMPTYFOLDER=%TEMP%\oa_empty_%RANDOM%%RANDOM%"
            mkdir "!EMPTYFOLDER!" >nul 2>&1
            robocopy "!EMPTYFOLDER!" ".venv" /MIR /NFL /NDL /NJH /NJS /NC /NS >nul 2>&1
            rmdir /s /q ".venv" >nul 2>&1
            rmdir /s /q "!EMPTYFOLDER!" >nul 2>&1
        )
        if exist ".venv" (
            echo [ERROR] Could not delete .venv.
            echo         Close every terminal, editor and Python process that is using
            echo         this folder, then run this file again.
            goto :fail
        )
        echo       OK - old .venv deleted.
    ) else (
        echo       OK - there was no .venv.
    )
)

REM ---- 3. make sure uv is available -----------------------------------------
echo [3/7] Checking the "uv" package manager...
call :find_uv
if not defined UV_CMD (
    echo       uv not found - installing it...
    where winget >nul 2>&1
    if not errorlevel 1 (
        echo       trying winget...
        winget install --id=astral-sh.uv -e --source winget --scope user --accept-package-agreements --accept-source-agreements --disable-interactivity >nul 2>&1
        if errorlevel 1 winget install --id=astral-sh.uv -e --source winget --accept-package-agreements --accept-source-agreements --disable-interactivity >nul 2>&1
        call :add_path_candidates
        call :find_uv
    )
    if not defined UV_CMD (
        echo       trying the official installer...
        powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://astral.sh/uv/install.ps1 | iex" >nul 2>&1
        call :add_path_candidates
        call :find_uv
    )
    if not defined UV_CMD (
        call :find_any_python
        if defined PY_ANY (
            echo       trying pip...
            !PY_ANY! -m pip install --upgrade uv >nul 2>&1
            call :add_path_candidates
            call :find_uv
        )
    )
)
if not defined UV_CMD (
    echo [ERROR] Could not install uv.
    echo         Install it manually with:  winget install astral-sh.uv
    echo         or see https://docs.astral.sh/uv/getting-started/installation/
    goto :fail
)
echo       OK - using "!UV_CMD!"

REM ---- 4. make sure a compatible Python is available --------------------------
echo [4/7] Checking for Python !PY_MIN! or newer...
call :find_python_compatible
if not defined PY_PATH (
    echo       no compatible Python found - installing one...
    if defined UV_CMD (
        echo       installing a standalone Python !PY_MIN! with uv ^(no admin needed^)
        "!UV_CMD!" python install !PY_MIN!
        call :find_python_compatible
    )
)
if not defined PY_PATH (
    where winget >nul 2>&1
    if not errorlevel 1 (
        echo       installing Python !PY_MIN! with winget...
        winget install --id=Python.Python.!PY_MIN! -e --source winget --accept-package-agreements --accept-source-agreements --disable-interactivity >nul 2>&1
        call :add_path_candidates
        call :find_python_compatible
    )
)
if not defined PY_PATH (
    echo       downloading the Python !PY_MIN! installer from python.org...
    set "PYURL=https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $o=Join-Path $env:TEMP 'oa-python-installer.exe'; try { Invoke-WebRequest -Uri '!PYURL!' -OutFile $o -UseBasicParsing; Start-Process -FilePath $o -ArgumentList '/quiet','InstallAllUsers=0','PrependPath=1','Include_test=0','Include_launcher=1','AssociateFiles=0','Shortcuts=0' -Wait | Out-Null; exit 0 } catch { exit 1 }"
    call :add_path_candidates
    call :find_python_compatible
)
if not defined PY_PATH (
    echo [ERROR] Python !PY_MIN! or newer is required and could not be installed.
    echo         Install Python from https://www.python.org/downloads/ and run this again.
    goto :fail
)
echo       OK - using !PY_CMD!
"!PY_PATH!" -c "import sys; print('       version: ' + sys.version.split()[0])"

REM ---- 5. rebuild the virtual environment -------------------------------------
echo [5/7] Rebuilding the virtual environment ^(this downloads packages, be patient^)...
set "VIRTUAL_ENV="
set "UV_LINK_MODE=copy"
"!UV_CMD!" sync --python "!PY_PATH!" --frozen
if errorlevel 1 (
    echo       the lock file was not accepted - retrying without --frozen...
    "!UV_CMD!" sync --python "!PY_PATH!"
)
if errorlevel 1 (
    echo [ERROR] uv sync failed. Check your internet connection and the messages above.
    goto :fail
)
if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] uv sync finished but .venv\Scripts\python.exe is missing.
    goto :fail
)

REM ---- 6. runtime folders, config, web UI ------------------------------------
echo [6/7] Preparing runtime folders and configuration...
for %%D in (db log log\strategies strategies strategies\scripts keys tmp) do if not exist "%%D" mkdir "%%D" >nul 2>&1
if not exist ".env" (
    if exist ".sample.env" (
        copy /y ".sample.env" ".env" >nul
        echo       created .env from .sample.env
    ) else (
        echo [WARNING] .env not found and .sample.env is missing - run setup.bat
    )
)
if exist ".env" if exist "envtool.py" if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" envtool.py keys --quiet >nul 2>&1
    echo       security keys are in place
)
if exist "frontend\dist\index.html" (
    echo       web UI is already built.
) else (
    if exist "frontend\package.json" (
        where npm >nul 2>&1
        if not errorlevel 1 (
            echo       building the web UI with npm...
            pushd frontend
            call npm ci
            if not errorlevel 1 call npm run build
            popd
        ) else (
            echo [WARNING] frontend\dist is missing and Node.js was not found.
            echo           The web UI will not load. Install Node.js LTS and run this again.
        )
    ) else (
        echo [WARNING] frontend\dist is missing - the web UI will not load.
    )
)

REM ---- 7. verify --------------------------------------------------------------
echo [7/7] Verifying the new environment...
".venv\Scripts\python.exe" -c "import flask, flask_sqlalchemy, flask_login, flask_socketio, requests; print('       dependencies: OK')"
if errorlevel 1 (
    echo [ERROR] The rebuilt environment does not work. See the message above.
    goto :fail
)
".venv\Scripts\python.exe" -c "import sys; print('       python     : ' + sys.version.split()[0]); print('       venv       : ' + sys.prefix)"

echo.
echo   ===========================================
echo     Ready - start OpenAlgo with:  start.bat
echo   ===========================================
echo     Web UI : http://127.0.0.1:5000
echo     Stop   : stop.bat
echo.
echo   Note: keep .env and db\ together with the project - they hold your
echo   accounts, broker keys and history.
echo.
goto :end

REM ============================================================================
REM  Subroutines
REM ============================================================================

REM ---- find a Python that satisfies the version requirement ------------------
:find_python_compatible
set "PY_CMD="
set "PY_PATH="
REM (1) the interpreter uv would pick itself - this is the one "uv sync" uses
REM     by default, so the rebuilt .venv matches the old one as closely as
REM     possible.
if defined UV_CMD (
    for /f "usebackq delims=" %%i in (`"!UV_CMD!" python find --no-project 2^>nul`) do if not defined PY_PATH set "PY_PATH=%%i"
    if defined PY_PATH if not exist "!PY_PATH!" set "PY_PATH="
    if defined PY_PATH (
        "!PY_PATH!" -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
        if errorlevel 1 set "PY_PATH="
    )
)
if defined PY_PATH set "PY_CMD=!PY_PATH!"
if defined PY_CMD exit /b 0
REM (2) the Windows py launcher and python on PATH
call :probe_python "py -3"
if not defined PY_CMD call :probe_python "py -3.14"
if not defined PY_CMD call :probe_python "py -3.13"
if not defined PY_CMD call :probe_python "py -3.12"
if not defined PY_CMD call :probe_python "python"
if not defined PY_CMD call :probe_python "python3"
REM (3) any managed interpreter of the right version
if not defined PY_CMD if defined UV_CMD (
    for /f "usebackq delims=" %%i in (`"!UV_CMD!" python find --no-project !PY_MIN! 2^>nul`) do if not defined PY_PATH set "PY_PATH=%%i"
    if defined PY_PATH if not exist "!PY_PATH!" set "PY_PATH="
)
if not defined PY_CMD if defined PY_PATH (
    "!PY_PATH!" -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
    if errorlevel 1 set "PY_PATH="
)
if not defined PY_CMD if defined PY_PATH set "PY_CMD=!PY_PATH!"
exit /b 0

REM ---- test one interpreter, set PY_CMD / PY_PATH when it is usable -----------
:probe_python
set "CAND=%~1"
%CAND% -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
if errorlevel 1 exit /b 1
set "PY_CMD=%~1"
for /f "usebackq delims=" %%i in (`%CAND% -c "import sys; print(sys.executable)" 2^>nul`) do set "PY_PATH=%%i"
if not defined PY_PATH set "PY_PATH=%~1"
exit /b 0

REM ---- any Python at all, used only to bootstrap pip/uv ----------------------
:find_any_python
set "PY_ANY="
python -c "import sys" >nul 2>&1 && set "PY_ANY=python"
if not defined PY_ANY py -3 -c "import sys" >nul 2>&1 && set "PY_ANY=py -3"
if not defined PY_ANY py -c "import sys" >nul 2>&1 && set "PY_ANY=py"
exit /b 0

REM ---- locate uv.exe ---------------------------------------------------------
:find_uv
set "UV_CMD="
for /f "usebackq delims=" %%i in (`where uv 2^>nul`) do if not defined UV_CMD set "UV_CMD=%%i"
if not defined UV_CMD if exist "%USERPROFILE%\.local\bin\uv.exe" set "UV_CMD=%USERPROFILE%\.local\bin\uv.exe"
if not defined UV_CMD if exist "%LOCALAPPDATA%\Microsoft\WinGet\Links\uv.exe" set "UV_CMD=%LOCALAPPDATA%\Microsoft\WinGet\Links\uv.exe"
for %%V in (314 313 312 311 310) do if not defined UV_CMD if exist "%APPDATA%\Python\Python%%V\Scripts\uv.exe" set "UV_CMD=%APPDATA%\Python\Python%%V\Scripts\uv.exe"
for %%V in (314 313 312 311 310) do if not defined UV_CMD if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\Scripts\uv.exe" set "UV_CMD=%LOCALAPPDATA%\Programs\Python\Python%%V\Scripts\uv.exe"
exit /b 0

REM ---- add the usual installer folders to PATH for this session --------------
:add_path_candidates
set "PATH=%PATH%;%USERPROFILE%\.local\bin;%LOCALAPPDATA%\Microsoft\WinGet\Links;%APPDATA%\Python\Python312\Scripts;%APPDATA%\Python\Python313\Scripts;%APPDATA%\Python\Python314\Scripts;%LOCALAPPDATA%\Programs\Python\Python312;%LOCALAPPDATA%\Programs\Python\Python313;%LOCALAPPDATA%\Programs\Python\Python314;%LOCALAPPDATA%\Programs\Python\Python312\Scripts;%LOCALAPPDATA%\Programs\Python\Python313\Scripts;%LOCALAPPDATA%\Programs\Python\Python314\Scripts"
exit /b 0

REM ============================================================================
:fail
echo.
echo [FAILED] The environment was not rebuilt. See the messages above.
echo.
exit /b 1

:end
exit /b 0
