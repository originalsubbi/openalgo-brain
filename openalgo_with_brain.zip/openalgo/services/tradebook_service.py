import importlib
from typing import Any

from database.auth_db import get_auth_token_broker
from services.broker_busy import BrokerBusyError, broker_busy_result
from utils.logging import get_logger

# Initialize logger
logger = get_logger(__name__)


def format_decimal(value):
    """Format numeric value to 2 decimal places"""
    if isinstance(value, (int, float)):
        return round(float(value), 2)
    return value


def format_trade_data(trade_data):
    """Format all numeric values in trade data to 2 decimal places, except quantity fields"""
    # Fields that should remain as integers
    quantity_fields = {
        "quantity",
        "qty",
        "tradedqty",
        "filledqty",
        "filled_quantity",
        "traded_quantity",
    }

    if isinstance(trade_data, list):
        return [
            {
                key: (int(value) if value == int(value) else value)
                if (key.lower() in quantity_fields and isinstance(value, (int, float)))
                else (format_decimal(value) if isinstance(value, (int, float)) else value)
                for key, value in item.items()
            }
            for item in trade_data
        ]
    return trade_data


def import_broker_module(broker_name: str) -> dict[str, Any] | None:
    """
    Dynamically import the broker-specific tradebook modules.

    Args:
        broker_name: Name of the broker

    Returns:
        Dictionary of broker functions or None if import fails
    """
    try:
        # Import API module
        api_module = importlib.import_module(f"broker.{broker_name}.api.order_api")
        # Import mapping module
        mapping_module = importlib.import_module(f"broker.{broker_name}.mapping.order_data")
        return {
            "get_trade_book": api_module.get_trade_book,
            "map_trade_data": mapping_module.map_trade_data,
            "transform_tradebook_data": mapping_module.transform_tradebook_data,
        }
    except (ImportError, AttributeError) as error:
        logger.error(f"Error importing broker modules: {error}")
        return None


def get_tradebook_with_auth(
    auth_token: str, broker: str, original_data: dict[str, Any] = None
) -> tuple[bool, dict[str, Any], int]:
    """
    Get trade book details using provided auth token.

    Args:
        auth_token: Authentication token for the broker API
        broker: Name of the broker
        original_data: Original request data (for sandbox mode, optional for internal calls)

    Returns:
        Tuple containing:
        - Success status (bool)
        - Response data (dict)
        - HTTP status code (int)
    """
    # If in analyze mode AND we have original_data (API call), route to sandbox
    # If original_data is None (internal call), use live broker
    from database.settings_db import get_analyze_mode

    if get_analyze_mode() and original_data:
        from services.sandbox_service import sandbox_get_tradebook

        api_key = original_data.get("apikey")
        if not api_key:
            return (
                False,
                {
                    "status": "error",
                    "message": "API key required for sandbox mode",
                    "mode": "analyze",
                },
                400,
            )

        return sandbox_get_tradebook(api_key, original_data)

    broker_funcs = import_broker_module(broker)
    if broker_funcs is None:
        return False, {"status": "error", "message": "Broker-specific module not found"}, 404

    try:
        # Get tradebook data using broker's implementation
        trade_data = broker_funcs["get_trade_book"](auth_token)

        if "status" in trade_data and trade_data["status"] == "error":
            return (
                False,
                {
                    "status": "error",
                    "message": trade_data.get("message", "Error fetching trade data"),
                },
                500,
            )

        # Transform data using mapping functions
        trade_data = broker_funcs["map_trade_data"](trade_data=trade_data)
        trade_data = broker_funcs["transform_tradebook_data"](trade_data)

        # Format numeric values to 2 decimal places
        formatted_trades = format_trade_data(trade_data)

        return True, {"status": "success", "data": formatted_trades}, 200
    except BrokerBusyError as e:
        return broker_busy_result(e, "Trade book request")
    except Exception as e:
        logger.exception(f"Error processing trade data: {e}")
        return False, {"status": "error", "message": str(e)}, 500


def get_tradebook(
    api_key: str | None = None, auth_token: str | None = None, broker: str | None = None
) -> tuple[bool, dict[str, Any], int]:
    """
    Get trade book details.
    Supports both API-based authentication and direct internal calls.

    Args:
        api_key: OpenAlgo API key (for API-based calls)
        auth_token: Direct broker authentication token (for internal calls)
        broker: Direct broker name (for internal calls)

    Returns:
        Tuple containing:
        - Success status (bool)
        - Response data (dict)
        - HTTP status code (int)
    """
    # Case 1: API-based authentication
    if api_key and not (auth_token and broker):
        AUTH_TOKEN, broker_name = get_auth_token_broker(api_key)
        if AUTH_TOKEN is None:
            return False, {"status": "error", "message": "Invalid openalgo apikey"}, 403
        original_data = {"apikey": api_key}
        return get_tradebook_with_auth(AUTH_TOKEN, broker_name, original_data)

    # Case 2: Direct internal call with auth_token and broker
    elif auth_token and broker:
        return get_tradebook_with_auth(auth_token, broker, None)

    # Case 3: Invalid parameters
    else:
        return (
            False,
            {
                "status": "error",
                "message": "Either api_key or both auth_token and broker must be provided",
            },
            400,
        )
