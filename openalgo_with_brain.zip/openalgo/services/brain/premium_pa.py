"""Option-premium price-action model (PPA).

Trades the premium of at-the-money CE/PE contracts on their own price action:

* a vote from premium-side PA (momentum, range position, volume) decides
  whether CE or PE is the stronger side,
* the entry is the premium itself with a premium stop and target
  (``enter at 25, target 30`` scaled as a percentage barrier, not absolute
  rupees, so the rule transfers across strikes and expiries),
* while the position is open, a per-bar posterior
  ``P(target before stop | premium path)`` answers the stay-or-cut question:
  when the probability collapses the position is cut before the hard stop.

Paper-first: entries are only allowed while the platform runs in
analyzer (sandbox) mode, and sizing is measured against the paper capital
(``BRAIN_PAPER_CAPITAL``) plus realised paper P&L — nothing goes live until
that pipe is switched and qualified in the normal go-live sequence.

Everything reads/writes through the same pipes the Brain already uses:
positions live in ``brain_position`` tagged ``note='premium_pa'`` (the shared
executor loops skip them; this module manages their exits), orders go through
``executor.dispatch``/``executor.exit_position``, history goes through the
OpenAlgo history service into Historify, and the option chain comes from the
scan the Brain is already running — no second chain fetch.
"""

from __future__ import annotations

import functools
import json
import os
import threading
import time
from typing import Any

import numpy as np
from cachetools import TTLCache

from services.brain import knobs as _knobs
from services.brain.bands import GAMMA_DTE_MAX  # pylint: disable=Cyclic import
from utils.logging import get_logger

logger = get_logger(__name__)

PPA_NOTE = "premium_pa"
SKIP_LOG_INTERVAL_S = 15 * 60.0  # one skip note per underlying per 15 min
_skip_log: dict[str, float] = {}
COOLDOWN_S = 20 * 60.0
MIN_HOLD_BARS = 3  # a premium position gets 15 minutes before it may be cut
BARS_TTL = 60.0
COLLECT_MIN_INTERVAL_S = 120.0
_PAPER_WARN_DAY_KEY = "ppa_paper_warn_day"

# ---- configuration -----------------------------------------------------------


def _f(name: str, dflt: float) -> float:
    try:
        return float(os.getenv(name, dflt))
    except (TypeError, ValueError):
        return dflt


def _i(name: str, dflt: int) -> int:
    try:
        return int(float(os.getenv(name, dflt)))
    except (TypeError, ValueError):
        return dflt


def load_config() -> dict[str, Any]:
    """One knob bundle read per call, so .env edits apply without a restart."""
    cfg = {
        "enable": os.getenv("BRAIN_PREMIUM_PA", "0").strip().lower() in ("1", "true", "yes", "on"),
        "stop_pct": min(max(_f("BRAIN_PPA_STOP_PCT", 0.15), 0.05), 0.60),
        "k_stop": min(max(_f("BRAIN_PPA_K_STOP", 0.8), 0.2), 2.0),  # in premium sigmas
        "rr": min(max(_f("BRAIN_PPA_RR", 1.5), 0.5), 4.0),
        "min_score": min(max(_f("BRAIN_PPA_MIN_SCORE", 0.45), 0.10), 1.0),
        "hold_min": min(max(_f("BRAIN_PPA_HOLD_MIN", 0.25), 0.05), 0.90),
        "max_open": max(_i("BRAIN_PPA_MAX_OPEN", 2), 1),
        "max_trades_day": max(_i("BRAIN_PPA_MAX_TRADES_DAY", 6), 1),
        "confirm_underlying": os.getenv("BRAIN_PPA_CONFIRM_UNDERLYING", "1").strip()
        not in ("0", "false", "off"),
        "horizon_bars": max(_i("BRAIN_PPA_HORIZON_BARS", 12), 4),  # 5m bars held
        # ---- loss-aware adaptation (Phase 1) ----
        "adapt": os.getenv("BRAIN_PPA_ADAPT", "1").strip() not in ("0", "false", "off"),
        "streak_score_step": min(max(_f("BRAIN_PPA_STREAK_SCORE_STEP", 0.10), 0.0), 0.30),
        "streak_cooldown_mult": min(max(_f("BRAIN_PPA_STREAK_COOLDOWN_MULT", 1.0), 0.0), 3.0),
        "streak_cap": max(_i("BRAIN_PPA_STREAK_CAP", 2), 1),
        "max_losses_day": max(_i("BRAIN_PPA_MAX_LOSSES_DAY", 4), 1),
        # ---- pyramid on winners (Phase 2) ----
        "pyramid": os.getenv("BRAIN_PPA_PYRAMID", "1").strip() not in ("0", "false", "off"),
        "pyramid_trigger_r": min(max(_f("BRAIN_PPA_PYRAMID_TRIGGER_R", 1.0), 0.5), 3.0),
        "pyramid_max_adds": min(max(_i("BRAIN_PPA_PYRAMID_MAX_ADDS", 1), 1), 3),
        "pyramid_min_post": min(max(_f("BRAIN_PPA_PYRAMID_MIN_POST", 0.50), 0.20), 0.90),
        # ---- averaging down on losers (Phase 3) ----
        # Defaults OFF because real-money averaging-down without manual oversight
        # is how accounts die — even with guards, it is a high-risk behaviour.
        # `averaging_live` must be explicitly enabled via .env before the feature
        # will ever fire outside paper/sandbox, and only after maturity clears.
        "averaging": os.getenv("BRAIN_PPA_AVERAGING", "0").strip().lower()
        not in ("0", "false", "off"),
        "averaging_live": os.getenv("BRAIN_PPA_AVERAGING_LIVE", "0").strip().lower()
        not in ("0", "false", "off"),
        "avg_min_drop_pct": min(max(_f("BRAIN_PPA_AVG_MIN_DROP_PCT", 5.0), 2.0), 15.0),
        "avg_max_adds": min(max(_i("BRAIN_PPA_AVG_MAX_ADDS", 1), 1), 3),
        # Factor applied to the original risk when raising stop post-average.
        # 0.6 = new stop sits 60% of the way from blended entry toward old stop —
        # tighter with each add so the averaged position can't turn a smaller loss
        # into a bigger one.
        "avg_stop_adjust": min(max(_f("BRAIN_PPA_AVG_STOP_ADJUST", 0.6), 0.3), 0.85),
        # ---- self-tuning (slider card + PPA's own adjustments) ----
        "auto_tune": os.getenv("BRAIN_PPA_AUTO_TUNE", "1").strip() not in ("0", "false", "off"),
    }
    return _apply_overrides(cfg)


# ---- tunable sliders (the Brain page card) ------------------------------------
#
# Every key here is real-time tunable: the UI writes an override into
# ``brain_state`` (``ppa_overrides``), ``load_config`` applies it on its next
# read, and the running loop picks it up within one call — no restart. The
# .env values remain the base; a reset drops the overrides back onto them.

PPA_SLIDERS: dict[str, dict[str, Any]] = {
    "min_score": {"min": 0.10, "max": 1.00, "step": 0.05},
    "stop_pct": {"min": 0.05, "max": 0.60, "step": 0.01},
    "k_stop": {"min": 0.20, "max": 2.00, "step": 0.05},
    "rr": {"min": 0.50, "max": 4.00, "step": 0.10},
    "hold_min": {"min": 0.05, "max": 0.90, "step": 0.05},
    "max_open": {"min": 1, "max": 5, "step": 1, "int": True},
    "max_trades_day": {"min": 1, "max": 12, "step": 1, "int": True},
    "pyramid_trigger_r": {"min": 0.50, "max": 3.00, "step": 0.10},
    "pyramid_max_adds": {"min": 1, "max": 3, "step": 1, "int": True},
    "pyramid_min_post": {"min": 0.20, "max": 0.90, "step": 0.05},
    # ---- averaging down (Phase 3) ----
    "avg_min_drop_pct": {"min": 2.0, "max": 15.0, "step": 0.5},
    "avg_max_adds": {"min": 1, "max": 3, "step": 1, "int": True},
    "avg_stop_adjust": {"min": 0.30, "max": 0.85, "step": 0.05},
    "streak_score_step": {"min": 0.00, "max": 0.30, "step": 0.05},
    "max_losses_day": {"min": 1, "max": 12, "step": 1, "int": True},
}

PPA_TOGGLES = ("adapt", "pyramid", "auto_tune", "averaging")

_AUTO_TUNE_RECENT_N = 30  # rolling R window the self-tuner reads (10 trades is mostly noise)
_AUTO_TUNE_MIN_SAMPLES = 30
_AUTO_TUNE_BAND_R = 0.25  # |mean R| beyond which the tuner acts


# The override store is read-modify-written by the human UI, the Brain-AI tuner
# and the PPA self-tuner from different threads. Without a lock the last writer
# silently discarded the others' edits (a slider move could vanish if a tuner
# saved a moment later from a stale read).
_OV_LOCK = threading.RLock()


def _locked(fn):
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        with _OV_LOCK:
            return fn(*args, **kwargs)

    return wrapper


def _overrides() -> dict[str, Any]:
    st = _state()
    ov = st.get("ppa_overrides")
    return ov if isinstance(ov, dict) else {}


# Override source hierarchy (highest wins):
#   "manual"  — human UI edit; ALL auto-tuners respect it (never touched)
#   "ai"      — Brain self-tuner wrote it; PPA self-tuner respects it
#   "auto"    — PPA self-tuner wrote it; lowest priority, gets overridden freely
_SOURCE_HIERARCHY = {"manual": 3, "ai": 2, "auto": 1, "base": 0}


def _override_priority(key: str) -> int:
    """Priority of the current owner of one override key (higher = stronger)."""
    srcs = _overrides().get("sources")
    srcs = srcs if isinstance(srcs, dict) else {}
    raw_src = srcs.get(key)
    return _SOURCE_HIERARCHY.get(raw_src or "base", 0)


def _apply_overrides(cfg: dict[str, Any]) -> dict[str, Any]:
    """Clamp and merge slider/toggle overrides onto the env-based config."""
    vals = _overrides().get("values")
    if not isinstance(vals, dict):
        return cfg
    for key, raw in vals.items():
        spec = PPA_SLIDERS.get(key)
        if spec is not None:
            try:
                v = float(raw)
            except (TypeError, ValueError):
                continue
            v = min(max(v, float(spec["min"])), float(spec["max"]))
            cfg[key] = int(round(v)) if spec.get("int") else v
        elif key in PPA_TOGGLES:
            cfg[key] = bool(raw)
    return cfg


def ppa_status() -> dict[str, Any]:
    """Report whether the PPA sidecar can enter paper trades right now.

    Independent of the Brain's drift / drawdown halt flags — PPA has its own
    entry gates (sandbox mode, bars warm, edge, cooldown, position caps).
    """
    cfg = load_config()
    from database import brain_db as db
    from services.brain.orchestrator import platform_mode

    mode = platform_mode()
    st = _state()
    stats = st.get("stats") if isinstance(st.get("stats"), dict) else {}
    # Read the live degraded flag directly — no separate drift_paused state
    # needed; try_enter already guards against entries while degraded.
    drift_paused = bool(db.state_get("degraded", False))
    return {
        "enabled": bool(cfg["enable"] and not drift_paused),
        "drift_paused": drift_paused,
        "mode": mode,  # "sandbox" or "live"
        "can_enter": bool(cfg["enable"] and mode == "sandbox" and not drift_paused),
        "max_open": cfg["max_open"],
        "max_trades_day": cfg["max_trades_day"],
        "adapt": bool(cfg["adapt"]),
        "streak": stats.get("streak") or {},
        "recent_r": stats.get("recent") or [],
        "pyramid": bool(cfg["pyramid"]),
        "pyramid_max_adds": cfg["pyramid_max_adds"],
        "pyramid_trigger_r": cfg["pyramid_trigger_r"],
        "auto_tune": bool(cfg["auto_tune"]),
        # ---- averaging down (Phase 3) ----
        "averaging": bool(cfg["averaging"]),
        # Live averaging is gated twice: env opt-in + LIVE_ELIGIBLE maturity.
        # Exposed so the UI can tell the operator what's actually armed.
        "averaging_live": bool(cfg.get("averaging_live", False)),
        "avg_min_drop_pct": cfg["avg_min_drop_pct"],
        "avg_max_adds": cfg["avg_max_adds"],
        "avg_stop_adjust": cfg["avg_stop_adjust"],
    }


def ppa_stats() -> dict[str, Any]:
    """Detailed PPA stats: per-underlying streaks + cooldown remaining + mean R
    + today's counts — consumed by the Activity Monitor and PPA stats card."""
    import time

    from database import brain_db as db

    cfg = load_config()
    st = _state()
    stats = st.get("stats") if isinstance(st.get("stats"), dict) else {}
    streaks = stats.get("streak") or {}
    recent_r = list(stats.get("recent") or [])

    # Per-underlying cooldown remaining
    now = time.time()
    today0 = _ist0(now)
    underlyings_data: dict[str, dict[str, Any]] = {}
    for u in ("NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY", "SENSEX", "BANKEX"):
        trades_u = [
            p
            for p in db.positions_closed(today0)
            if p.get("note") == PPA_NOTE
            and p.get("underlying") == u
            and (p.get("exit_ts") or 0) >= today0
        ]
        last_exit = max(
            (float(p.get("exit_ts") or 0) for p in trades_u),
            default=0.0,
        )
        n = int(streaks.get(u) or 0)
        eff_score, cooldown_s, _ = adaptive_edge(cfg, stats, u)
        cd_left = max(0, cooldown_s - (now - last_exit)) if last_exit > 0 else 0.0
        underlyings_data[u] = {
            "streak": n,
            "cooldown_remaining_min": round(cd_left / 60, 1),
            "effective_min_score": round(eff_score, 3),
            "last_exit": last_exit,
            "closes_today": len(trades_u),
            "losses_today": sum(1 for p in trades_u if float(p.get("pnl") or 0) < 0),
        }

    recent_n = min(len(recent_r), _AUTO_TUNE_RECENT_N)
    recent_slice = recent_r[-recent_n:] if recent_r else []
    mean_r = sum(recent_slice) / len(recent_slice) if recent_slice else None

    # Today's PPA totals
    all_today = [
        p
        for p in db.positions_closed(today0)
        if p.get("note") == PPA_NOTE and (p.get("exit_ts") or 0) >= today0
    ]
    wins = [p for p in all_today if float(p.get("net_pnl") or 0) > 0]
    losses = [p for p in all_today if float(p.get("net_pnl") or 0) < 0]
    total_net = sum(float(p.get("net_pnl") or 0) for p in all_today)

    return {
        "enabled": bool(cfg["enable"]),
        "drift_paused": bool(db.state_get("degraded", False)),
        "mean_r": round(mean_r, 4) if mean_r is not None else None,
        "mean_r_samples": recent_n,
        "today_closes": len(all_today),
        "today_wins": len(wins),
        "today_losses": len(losses),
        "today_net_pnl": round(total_net, 2),
        "auto_tune_active": bool(cfg["auto_tune"])
        and mean_r is not None
        and abs(mean_r) > _AUTO_TUNE_BAND_R,
        "underlyings": underlyings_data,
    }


# ---- pure math ---------------------------------------------------------------


def aggregate_5m(bars_1m: np.ndarray) -> np.ndarray:
    """Aggregate a 1m bar array (ts, o, h, l, c, v[, oi]) into 5m bars."""
    if bars_1m is None or len(bars_1m) < 5:
        return bars_1m if bars_1m is not None else np.zeros((0, 6))
    b = np.asarray(bars_1m, dtype=float)
    day_bucket = (b[:, 0] + 19800) // 300 * 300 - 19800  # IST-aligned 5m buckets
    idx = np.argsort(day_bucket, kind="stable")
    out: list[list[float]] = []
    cur = -1
    for i in idx:
        t = day_bucket[i]
        if t != cur:
            out.append([t, b[i, 1], b[i, 2], b[i, 3], b[i, 4], b[i, 5]])
            cur = t
        else:
            row = out[-1]
            row[2] = max(row[2], b[i, 2])  # high
            row[3] = min(row[3], b[i, 3])  # low
            row[4] = b[i, 4]  # close
            row[5] += b[i, 5]  # volume
    return np.array(out, dtype=float)


def premium_vote(ce: np.ndarray, pe: np.ndarray, cfg: dict[str, Any]) -> dict[str, Any]:
    """Which premium side is moving: PA with momentum-in-ATR, range and volume.

    Both are long-premium reads (we always buy): CE strength = calls bid up,
    PE strength = puts bid up. Returns None-reasons when data is thin so a
    caller can just stand aside.
    """
    if ce is None or pe is None or len(ce) < 25 or len(pe) < 25:
        return {"score": 0.0, "side": "", "confidence": 0.0, "reason": "warmup"}
    side_scores: dict[str, dict[str, float]] = {}
    for name, arr in (("CE", ce), ("PE", pe)):
        closes = arr[:, 4]
        highs = arr[:, 2]
        lows = arr[:, 3]
        vols = np.where(arr[:, 5] > 0, arr[:, 5], 1.0)
        # Guard EVERY close in the window, not only the last bar — an earlier
        # zero-close poisons np.log and leaves sigma/momentum as NaN, which then
        # passes every gate comparison (nan < x is always False).
        if bool(np.any(closes <= 0)):
            side_scores[name] = {"m": 0.0, "r": 0.0, "v": 0.0, "atr": 0.0}
            continue
        c = float(closes[-1])
        tr = np.diff(np.log(closes[-21:])) + 1e-12
        sigma_m = float(np.std(tr)) + 1e-6
        mom20 = float(closes[-1] / closes[-21] - 1.0)
        lo20 = float(np.min(lows[-20:]))
        hi20 = float(np.max(highs[-20:]))
        ran = (c - lo20) / max(hi20 - lo20, 1e-9) - 0.5  # [-0.5, 0.5]
        volr = float(np.mean(vols[-3:]) / (np.mean(vols[-20:]) + 1e-9))
        atr = float(np.mean(highs[-10:] - lows[-10:])) / c
        side_scores[name] = {
            "m": float(np.tanh(mom20 / (2.5 * sigma_m + 1e-9))),
            "r": float(ran * 2.0),
            "v": float(np.tanh((volr - 1.0) / 0.8)),
            "atr": atr,
        }
    ce_s = side_scores["CE"]
    pe_s = side_scores["PE"]
    ce_score = 0.5 * ce_s["m"] + 0.3 * ce_s["r"] + 0.2 * ce_s["v"]
    pe_score = 0.5 * pe_s["m"] + 0.3 * pe_s["r"] + 0.2 * pe_s["v"]
    # Spread asymmetry: the *decelerating* side is often already run up; the
    # direction is whichever premium is exhibiting cleaner drive against its
    # counterpart, expressed as cream-of both.
    score = ce_score - pe_score
    side = "CE" if score >= 0 else "PE"
    own = ce_s if side == "CE" else pe_s
    conf = float(
        min(
            1.0,
            0.30 + 0.45 * abs(np.tanh(0.6 * (ce_s["m"] - pe_s["m"]))) + 0.25 * max(0.0, own["v"]),
        )
    )
    return {
        "score": float(np.clip(score, -1, 1)),
        "side": side,
        "confidence": conf,
        "ce_mom": ce_s["m"],
        "pe_mom": pe_s["m"],
        "volume_ratio": (ce_s["v"], pe_s["v"]),
        "atr_pct": max(own["atr"], pe_s["atr"]),
        "pa_ce": ce_score,
        "pa_pe": pe_score,
    }


def premium_sigma_h(bars5: np.ndarray | None, horizon_bars: int) -> float | None:
    """Volatility of the premium over the holding horizon, in log-return units.

    The premium's own movement decides how far a target can be: a flat
    percentage of the premium is unreachable on a quiet contract (the posterior
    then reads P(target)=0 and every position is cut at once) and trivial on a
    wild one. This is the premium's equivalent of the underlying's sigma_h.
    """
    if bars5 is None or len(bars5) < 10:
        return None
    closes = np.asarray(bars5[:, 4], dtype=float)
    if np.any(closes <= 0):
        return None
    rets = np.diff(np.log(closes))
    tail = rets[-40:] if len(rets) >= 10 else rets
    if len(tail) < 5:
        return None
    sigma_bar = float(np.std(tail))
    return float(sigma_bar * np.sqrt(max(int(horizon_bars), 1)))


def plan_premium_levels(
    entry: float,
    cfg: dict[str, Any],
    spread: float,
    horizon_bars: int,
    sigma_h: float | None = None,
) -> dict[str, float]:
    """Premium stop/target.

    The risk distance comes from the premium's own volatility over the holding
    horizon (``k_stop`` times sigma_h), clamped into a sane band of the
    premium, so the target is reachable and the stay-or-cut posterior means
    something. Without a volatility estimate it falls back to a fixed share of
    the premium.
    """
    if sigma_h and sigma_h > 0:
        risk = entry * cfg["k_stop"] * sigma_h
        risk = min(max(risk, entry * 0.05), entry * 0.30)
    else:
        risk = max(entry * cfg["stop_pct"], spread * 1.5, entry * 0.03)
    stop = max(entry - risk, entry * 0.35)  # never plan to lose the whole premium
    risk = entry - stop  # the clamped risk, so R multiples stay meaningful
    return {
        "entry": entry,
        "risk_per_unit": float(risk),
        "stop": float(stop),
        "target": float(entry + risk * cfg["rr"]),
        "trail_trigger": 0.8 * risk,
        "trail_gap": 0.4 * risk,
        "deadline_s": horizon_bars * 300.0,
    }


def size_lots(
    risk_per_unit: float, lot_size: int, paper_equity: float, max_lots: int, risk_pct: float
) -> int:
    """Lots such that a full stop-out costs ``risk_pct`` of the paper equity."""
    budget = paper_equity * (risk_pct / 100.0) * 0.9
    if risk_per_unit <= 0 or lot_size <= 0:
        return 0
    lots = int(budget // (risk_per_unit * lot_size))
    return max(0, min(lots, max_lots))


def posterior_survival(
    bars5: np.ndarray,
    ltp: float,
    stop: float,
    target: float,
    bars_left: int,
    entry_edge: float = 0.0,
) -> dict[str, float]:
    """P(target before stop) for the open premium position, from its own path.

    Premium is always a long exposure: it wins when premium rises to the
    target, loses the defined amount at the stop. ``bars_left`` keeps the
    question honest — a distant target does not help in 2 bars.

    The drift is a blend of (a) the entry edge — the CE-vs-PE vote score that
    caused the entry, scaled by per-bar volatility — and (b) the shrunken
    recent mean return. Without (a), posterior drift collapses to near zero
    (or negative after a mean-reverting dip) and every position is cut at a
    loss regardless of how strong the entry edge was.
    """
    from services.brain.engines import stat as pstat

    horizon = max(int(bars_left), 2)
    rets = np.diff(np.log(np.asarray(bars5[:, 4], dtype=float) + 1e-9))
    tail = rets[-40:] if len(rets) >= 5 else rets
    if len(tail) == 0:
        return {"p_target": 0.0, "p_stop": 0.0, "p_timeout": 1.0}
    sigma_bar = float(np.std(tail)) + 1e-6
    # Blend the entry-direction prior (edge * sigma per bar) with the noisy,
    # shrunken recent mean. A strong entry biases the drift toward the target;
    # a weak or negative edge leaves the recent mean in charge, so marginal
    # positions are still cut quickly.
    mu_entry = float(entry_edge) * sigma_bar
    mu_recent = float(np.mean(tail)) * 0.35
    mu_bar = 0.65 * mu_entry + 0.35 * mu_recent
    tgt_d = np.log(max(target, 1e-9) / max(ltp, 1e-9))
    stop_d = np.log(max(ltp, 1e-9) / max(stop, 1e-9))
    if tgt_d <= 1e-9 or stop_d <= 1e-9:
        return {"p_target": 0.0, "p_stop": 1.0, "p_timeout": 0.0}
    out = pstat.barrier_probabilities(
        mu_bar,
        sigma_bar,
        float(stop_d),
        float(tgt_d),
        horizon,
        paths=400,
    )
    return {
        "p_target": float(out.get("p_target", 0.0)),
        "p_stop": float(out.get("p_stop", 0.0)),
        "p_timeout": float(out.get("p_timeout", 0.0)),
    }


# ---- market data helpers (impure, cached) ------------------------------------

_bars_cache: TTLCache[str, tuple[float, np.ndarray | None]] = TTLCache(maxsize=64, ttl=180)
_collect_state: TTLCache[str, float] = TTLCache(maxsize=64, ttl=3600)  # symbol -> last collect ts


def _fo_exchange(underlying: str) -> str:
    """Where this index's options trade: NFO for NSE indices, BFO for BSE ones.

    The exchange decides which broker symbol table the contract is looked up
    in; asking for a BSE contract on NFO finds nothing, which looks exactly
    like "no premium data".
    """
    try:
        from services.brain.orchestrator import get_underlyings

        return get_underlyings().get(underlying, ("", "NFO"))[1] or "NFO"
    except Exception:
        return "NFO"


def _bars_from_historify(symbol: str, exchange: str = "NFO") -> np.ndarray | None:
    """The premium bars this module already collected into Historify.

    Reading them back costs no broker call, and the collector keeps them
    current every couple of minutes. Going to the broker for the same data on
    every scan competes with the option-chain fetches for the broker's rate
    limit, and a throttled call looks exactly like "no data".
    """
    try:
        from database.historify_db import get_connection

        with get_connection() as conn:
            rows = conn.execute(
                "SELECT timestamp, open, high, low, close, volume, oi FROM market_data "
                "WHERE symbol = ? AND exchange = ? AND interval = '1m' ORDER BY timestamp",
                [symbol.upper(), exchange.upper()],
            ).fetchall()
        if not rows or len(rows) < 30:
            return None
        return np.array([[float(v) for v in row] for row in rows], dtype=float)
    except Exception:
        return None


def premium_bars(
    symbol: str, api_key: str, days: int = 2, exchange: str = "NFO"
) -> np.ndarray | None:
    """1m premium bars for an option contract, cached; None when unavailable.

    Historify first (free, already collected), the broker only as a fallback
    for a contract the collector has not filled yet.
    """
    now = time.time()
    key = f"{exchange}:{symbol}"
    hit = _bars_cache.get(key)
    if hit and now - hit[0] < BARS_TTL:
        return hit[1]
    arr = _bars_from_historify(symbol, exchange)
    if arr is None:
        arr = _bars_from_broker(symbol, api_key, days, exchange)
    _bars_cache[key] = (now, arr)
    return arr


def _bars_from_broker(
    symbol: str, api_key: str, days: int = 2, exchange: str = "NFO"
) -> np.ndarray | None:
    """The broker's 1m history for a contract, when Historify has not got it."""
    arr = None
    try:
        from datetime import datetime, timedelta, timezone

        from services.history_service import get_history

        IST = timezone(timedelta(hours=5, minutes=30))
        today = datetime.now(IST).date()
        ok, resp, _ = get_history(
            symbol,
            exchange,
            "1m",
            (today - timedelta(days=days)).isoformat(),
            today.isoformat(),
            api_key=api_key,
            source="api",
        )
        if ok and isinstance(resp, dict):
            rows = resp.get("data") or []
            if len(rows) >= 30:
                arr = np.array(
                    [
                        [
                            float(r["timestamp"]),
                            float(r["open"]),
                            float(r["high"]),
                            float(r["low"]),
                            float(r["close"]),
                            float(r.get("volume") or 0),
                            float(r.get("oi") or 0),
                        ]
                        for r in rows
                    ]
                )
    except Exception:
        logger.exception("ppa: premium bars fetch failed for %s", symbol)
        arr = None
    return arr


def collect_symbol(symbol: str, api_key: str, exchange: str = "NFO") -> int:
    """Incemental top-up of today's 1m premium bars into Historify."""
    try:
        from datetime import datetime, timedelta, timezone

        import pandas as pd

        from database.historify_db import upsert_market_data
        from services.history_service import get_history

        IST = timezone(timedelta(hours=5, minutes=30))
        today = datetime.now(IST).date().isoformat()
        ok, resp, _ = get_history(
            symbol, exchange, "1m", today, today, api_key=api_key, source="api"
        )
        if not ok or not isinstance(resp, dict):
            return 0
        rows = resp.get("data") or []
        if not rows:
            return 0
        df = pd.DataFrame(rows)
        n = upsert_market_data(df, symbol, exchange, "1m")
        return int(n)
    except Exception:
        logger.exception("ppa: collect failed for %s", symbol)
        return 0


# ---- paper equity ------------------------------------------------------------


def paper_equity() -> float:
    """The paper account's equity: base capital plus the sandbox account's realised P&L.

    Single source of truth: the sandbox FundManager ledger - the same number
    the /sandbox funds page and the fusion risk gate read - so PPA sizing, the
    dashboard and the paper account cannot disagree. Falls back to the
    brain-position ledger only when the sandbox account is unavailable.
    """
    base = _paper_base()
    try:
        from sandbox.fund_manager import get_user_funds
        from services.brain.orchestrator import resolve_api_key
        from services.sandbox_service import get_user_id_from_apikey

        key = resolve_api_key()
        user_id = get_user_id_from_apikey(key) if key else None
        if user_id:
            funds = get_user_funds(user_id)
            if funds:
                # get_funds() returns a dict: "total_realized_pnl" is the
                # all-time realised P&L, "m2mrealized" only today's.
                realized = funds.get("total_realized_pnl")
                if realized is not None:
                    return base + float(realized)
    except Exception:
        logger.debug("ppa: sandbox funds unavailable; falling back to the brain ledger")
    from database import brain_db as db

    closed = db.positions_closed_realized()
    # Use is not None so an exactly-zero net_pnl (scratch trade) counts as zero
    # instead of falling back to gross pnl, which would overstate equity by the
    # cost amount.
    realized = sum(
        float(p["net_pnl"]) if p.get("net_pnl") is not None else float(p.get("pnl") or 0)
        for p in closed
    )
    return base + realized


def _paper_base() -> float:
    """The shared paper capital: the sandbox's starting_capital, overridable by BRAIN_PAPER_CAPITAL."""
    from database.sandbox_db import get_config
    from utils.env_config import paper_capital

    try:
        configured = float(get_config("starting_capital", "1000000.00") or 0)
    except (TypeError, ValueError):
        configured = 0.0
    return paper_capital(configured)


def paper_base() -> float:
    """Public accessor for the configured seed capital the card shows."""
    return _paper_base()


# ---- state -------------------------------------------------------------------


def _state() -> dict[str, Any]:
    from database import brain_db as db

    raw = db.state_get("premium_pa_state", {}) or {}
    return raw if isinstance(raw, dict) else {}


def _save_state(s: dict[str, Any]) -> None:
    from database import brain_db as db

    db.state_set("premium_pa_state", s)


STATS_TRADES_WINDOW = 40  # rolling R-multiples remembered for the edge estimate


def _record_closed(now: float) -> dict[str, Any]:
    """Fold newly closed PPA trades into the adaptive-learning stats.

    Called once per ``try_enter``; idempotent via a stored high-water mark on
    ``exit_ts``. Losses raise the per-underlying loss streak (which tightens
    that underlying's edge gate and cooldown), wins reset it, and every
    realised R-multiple feeds a short rolling window.

    Rows with zero pnl (entry refused, flat closes) are neutral: they advance
    the high-water mark but never touch the streak.
    """
    from database import brain_db as db

    st = _state()
    stats = st.get("stats") if isinstance(st.get("stats"), dict) else {}
    last_ts = float(stats.get("last_ts") or 0)
    rows = [
        r
        for r in db.positions_closed(since_ts=last_ts)
        if r.get("note") == PPA_NOTE and last_ts < float(r.get("exit_ts") or 0) <= now
    ]
    if not rows and isinstance(st.get("stats"), dict):
        return stats

    streak = stats.get("streak") if isinstance(stats.get("streak"), dict) else {}
    recent = list(stats.get("recent") or [])
    cfg = load_config()
    step = cfg["streak_score_step"]
    changed = False
    for r in sorted(rows, key=lambda x: float(x.get("exit_ts") or 0)):
        xt = float(r.get("exit_ts") or 0)
        pnl = float(r.get("pnl") or 0.0)
        u = str(r.get("underlying") or "")
        if abs(pnl) < 1e-9:
            last_ts = max(last_ts, xt)
            continue
        if pnl > 0:
            if int(streak.get(u) or 0) > 0:
                db.event("info", "ppa_adapt", f"{u}: win resets loss streak (was {streak[u]})")
                changed = True
            streak[u] = 0
        else:
            streak[u] = int(streak.get(u) or 0) + 1
            tight = step * min(streak[u], cfg["streak_cap"])
            db.event(
                "warn",
                "ppa_adapt",
                f"{u}: loss #{streak[u]} — edge gate +{tight:.2f}, "
                f"cooldown x{1 + cfg['streak_cooldown_mult'] * min(streak[u], 3):.1f}",
            )
            changed = True
        rm = r.get("r_multiple")
        if rm is None:
            risk_total = float(r.get("risk_per_unit") or 0) * int(r.get("qty") or 0)
            rm = (pnl / risk_total) if risk_total > 0 else None
        if rm is not None:
            recent.append(round(float(rm), 3))
            recent = recent[-STATS_TRADES_WINDOW:]
        _pyramid_forget(int(r.get("id") or 0))  # closed positions keep no add-on counter
        last_ts = max(last_ts, xt)
    stats = {"last_ts": last_ts, "streak": streak, "recent": recent}
    st["stats"] = stats
    _save_state(st)
    _auto_tune(load_config(), stats)
    if changed:
        _skip_log.clear()  # let the next adaptive skip note through immediately
    return stats


def adaptive_edge(
    cfg: dict[str, Any], stats: dict[str, Any], underlying: str
) -> tuple[float, float, int]:
    """Adaptive gate for one underlying from the learning stats.

    Returns ``(effective_min_score, cooldown_seconds, loss_streak)``. A loss
    streak raises the PA edge requirement and stretches the per-underlying
    cooldown; a win streak costs nothing.
    """
    if not cfg["adapt"]:
        return cfg["min_score"], COOLDOWN_S, 0
    n = int((stats.get("streak") or {}).get(underlying) or 0)
    eff = min(cfg["min_score"] + cfg["streak_score_step"] * min(n, cfg["streak_cap"]), 1.0)
    cooldown = COOLDOWN_S * (1.0 + cfg["streak_cooldown_mult"] * min(n, 3))
    return eff, cooldown, n


def _pyramid_state() -> dict[str, int]:
    """Per-position add-on counters, keyed by position id (str) in premium_pa_state."""
    st = _state()
    pyr = st.get("pyramids")
    return pyr if isinstance(pyr, dict) else {}


def ppa_config() -> dict[str, Any]:
    """The slider card payload: spec, effective values, and who owns each value.

    Shows ``"base"`` for env defaults, ``"manual"`` for human edits, ``"ai"``
    for Brain self-tuner writes, and ``"auto"`` for PPA self-tuner nudges.
    """
    cfg = load_config()
    srcs = _overrides().get("sources")
    srcs = srcs if isinstance(srcs, dict) else {}
    return {
        "sliders": [
            {
                "key": key,
                "min": float(spec["min"]),
                "max": float(spec["max"]),
                "step": float(spec["step"]),
                "int": bool(spec.get("int")),
            }
            for key, spec in PPA_SLIDERS.items()
        ],
        "values": {key: cfg[key] for key in PPA_SLIDERS},
        "sources": {key: str(srcs.get(key) or "base") for key in PPA_SLIDERS},
        "toggles": {key: bool(cfg.get(key, False)) for key in PPA_TOGGLES},
    }


@_locked
def set_overrides(values: dict[str, Any], source: str) -> tuple[dict[str, Any] | None, str]:
    """Validate and merge slider/toggle writes. Returns ``(config, error)``."""
    if not isinstance(values, dict) or not values:
        return ppa_config(), ""
    ov = _overrides()
    vals = dict(ov.get("values") or {})
    srcs = dict(ov.get("sources") or {})
    for key, raw in values.items():
        spec = PPA_SLIDERS.get(key)
        if spec is None:
            if key in PPA_TOGGLES:
                vals[key] = bool(raw)
                srcs[key] = source
                continue
            return None, f"'{key}' is not a PPA tunable"
        try:
            v = float(raw)
        except (TypeError, ValueError):
            return None, f"'{key}' must be a number"
        if v != v or v in (float("inf"), float("-inf")):
            return None, f"'{key}' must be a finite number"
        lo, hi = float(spec["min"]), float(spec["max"])
        if not lo <= v <= hi:
            return None, f"'{key}' must be between {lo:g} and {hi:g}"
        vals[key] = int(round(v)) if spec.get("int") else v
        srcs[key] = source
    st = _state()
    st["ppa_overrides"] = {"values": vals, "sources": srcs}
    _save_state(st)
    from database import brain_db as db

    shown = ", ".join(f"{k}={vals[k]}" for k in values)
    db.event("info", "ppa_tune", f"PPA sliders updated ({source}): {shown}")
    return ppa_config(), ""


@_locked
def set_ai_overrides(values: dict[str, Any]) -> tuple[dict[str, Any] | None, str]:
    """Write PPA slider overrides from the Brain AI (not human UI).

    These carry source ``"ai"`` so:
    - The PPA self-tuner respects them (won't nudge past an AI decision)
    - A human manual edit still overrides everything
    - Reset clears them along with all other overrides
    """
    if not isinstance(values, dict) or not values:
        return ppa_config(), ""
    ov = _overrides()
    vals = dict(ov.get("values") or {})
    srcs = dict(ov.get("sources") or {})
    for key, raw in values.items():
        spec = PPA_SLIDERS.get(key)
        if spec is None:
            continue  # ignore non-PPA keys silently (e.g. toggle writes go through set_overrides)
        try:
            v = float(raw)
        except (TypeError, ValueError):
            return None, f"'{key}' must be a number"
        if v != v or v in (float("inf"), float("-inf")):
            return None, f"'{key}' must be a finite number"
        lo, hi = float(spec["min"]), float(spec["max"])
        if not lo <= v <= hi:
            return None, f"'{key}' must be between {lo:g} and {hi:g}"
        # Only write if this override has lower priority than existing ("ai" < "manual")
        if srcs.get(key) == "manual":
            continue  # human owns it — skip
        vals[key] = int(round(v)) if spec.get("int") else v
        srcs[key] = "ai"
    st = _state()
    st["ppa_overrides"] = {"values": vals, "sources": srcs}
    _save_state(st)
    from database import brain_db as db

    shown = ", ".join(f"{k}={vals[k]}" for k in values)
    db.event("info", "brain_ppa_tune", f"Brain AI adjusted PPA: {shown}")
    return ppa_config(), ""


@_locked
def clear_overrides() -> dict[str, Any]:
    """Drop every override (manual, ai, and auto) back onto the .env base."""
    st = _state()
    st.pop("ppa_overrides", None)
    _save_state(st)
    from database import brain_db as db

    db.event("info", "ppa_tune", "PPA sliders reset to the .env base")
    return ppa_config()


@_locked
def _auto_tune(cfg: dict[str, Any], stats: dict[str, Any]) -> None:
    """Let PPA nudge its own edge knobs from the rolling trade outcome.

    Reads the mean R of the last few closed PPA trades. When it is underwater,
    the base edge gate rises and marginal positions are cut sooner; when it is
    comfortably positive, both relax a little. A slider the human moved by
    hand (source ``manual``) is never touched.
    """
    if not cfg.get("auto_tune"):
        return
    # Read the live knob object on every call: the POST handler replaces
    # ``CURRENT_TUNE_KNOBS`` with a new frozen instance, so a name bound at import
    # would keep the shipped defaults forever. PPA uses its own ppa_tune_* family
    # (the cheap_tune_* family belongs to the cheap/expiry sidecar).
    k = _knobs.CURRENT_TUNE_KNOBS
    recent = [float(r) for r in (stats.get("recent") or [])][-k.ppa_tune_recent_n :]
    if len(recent) < k.ppa_tune_min_samples:
        return
    mean_r = sum(recent) / len(recent)
    if abs(mean_r) <= k.ppa_tune_band_r:
        return
    srcs = _overrides().get("sources")
    srcs = srcs if isinstance(srcs, dict) else {}

    vals = dict(_overrides().get("values") or {})
    all_srcs = dict(srcs)
    changed: list[str] = []

    def _nudge(key: str, delta: float) -> None:
        spec = PPA_SLIDERS[key]
        # Respect the hierarchy: manual (human) and ai (Brain) both block
        # the PPA self-tuner. Only "auto" or "base" gets nudged further.
        if _override_priority(key) >= 2:
            return
        cur = float(vals.get(key, cfg[key]))
        new = min(max(cur + delta, float(spec["min"])), float(spec["max"]))
        if abs(new - cur) >= 1e-9:
            vals[key] = new
            all_srcs[key] = "auto"
            changed.append(f"{key} {cur:.2f} -> {new:.2f}")

    # min_score is owned by the orchestrator's Brain-AI tuner (_auto_tune_ppa);
    # two tuners writing the same slider fought each other, so this one only
    # moves the stay-or-cut threshold.
    # Underwater: be more patient (lower hold_min) so positions aren't cut on
    # the first adverse wiggle — the entry gate and the AI tuner handle edge
    # quality; this tuner only adjusts the stay-or-cut threshold. Profitable:
    # take profits a little quicker. Never touches min_score (owned by
    # _auto_tune_ppa in the orchestrator).
    if mean_r < -k.ppa_tune_band_r:
        _nudge("hold_min", -0.03)  # more patient when underwater
    else:
        _nudge("hold_min", +0.01)  # lock in gains when profitable
    if not changed:
        return
    st = _state()
    st["ppa_overrides"] = {"values": vals, "sources": all_srcs}
    _save_state(st)
    from database import brain_db as db

    db.event(
        "info",
        "ppa_autotune",
        f"PPA self-tune ({len(recent)}-trade R {mean_r:+.2f}): " + ", ".join(changed),
    )


def _pyramid_forget(pid: int) -> None:
    """Drop a position's add-on counter once it is closed."""
    st = _state()
    pyr = st.get("pyramids") if isinstance(st.get("pyramids"), dict) else {}
    if str(pid) in pyr:
        pyr.pop(str(pid), None)
        st["pyramids"] = pyr
        # Also drop the avg-tracker entry so a fresh position on reuse starts clean.
        tracker = st.get("avg_tracker") if isinstance(st.get("avg_tracker"), dict) else {}
        tracker.pop(str(pid), None)
        st["avg_tracker"] = tracker
        _save_state(st)


def _pyramid_add(
    gw: Any,
    cfg: dict[str, Any],
    pos: dict[str, Any],
    ltp: float,
    r_now: float,
    post: dict[str, Any],
) -> list[dict[str, Any]]:
    """Phase 2: pyramid — add one lot to a winner the posterior still believes in.

    Discipline:
    * paper (sandbox) only, like every PPA entry;
    * fires only at >= +R, with the trigger rising per add already taken
      (first add at +1R, second at +2R, ...), so size follows proven progress;
    * the trailed stop must already be at or above the pre-add entry, and after
      the fill the stop is raised to the new blended entry, so the whole
      position can no longer close as a loser;
    * capped by ``BRAIN_PPA_PYRAMID_MAX_ADDS`` per position.
    """
    from database import brain_db as db
    from services.brain import executor as ex
    from services.brain.orchestrator import platform_mode

    pid = int(pos["id"])
    if platform_mode() != "sandbox":
        return [{"id": pid, "action": "pyramid_skip", "why": "not paper"}]
    pyr = _pyramid_state()
    adds = int(pyr.get(f"pyr:{pid}") or 0)
    if adds >= cfg["pyramid_max_adds"]:
        return [{"id": pid, "action": "pyramid_max"}]
    trigger_r = cfg["pyramid_trigger_r"] * (adds + 1)
    if r_now < trigger_r:
        return [
            {"id": pid, "action": "pyramid_wait", "r": round(r_now, 2), "need": round(trigger_r, 2)}
        ]
    entry = float(pos.get("entry_price") or 0)
    stop = float(pos.get("stop_price") or 0)
    if stop < entry:
        # The trail has not yet locked in breakeven; the add would carry real risk.
        return [{"id": pid, "action": "pyramid_wait", "why": "stop still below entry"}]
    lot_size = int(pos.get("lot_size") or 0)
    if lot_size <= 0:
        return [{"id": pid, "action": "pyramid_skip", "why": "no lot size"}]

    ok, order_id, err = gw.dispatch(
        platform_mode(), ex._order(pos["symbol"], pos.get("exchange") or "NFO", "BUY", lot_size)
    )
    if not ok:
        db.event(
            "warn",
            "ppa_pyramid_refused",
            f"{pos['symbol']}: add-on refused: {err}",
            {"position_id": pid},
        )
        return [{"id": pid, "action": "pyramid_refused", "why": err}]
    fill = gw.fill_price(platform_mode(), order_id) or ltp
    old_qty = int(pos.get("qty") or lot_size)
    new_qty = old_qty + lot_size
    blended = (entry * old_qty + float(fill) * lot_size) / new_qty
    new_stop = max(stop, blended)
    db.position_update(
        pid,
        qty=new_qty,
        lots=int(pos.get("lots") or 1) + 1,
        entry_price=blended,
        stop_price=new_stop,
    )
    st = _state()
    pyr = st.get("pyramids") if isinstance(st.get("pyramids"), dict) else {}
    pyr[f"pyr:{pid}"] = adds + 1
    st["pyramids"] = pyr
    _save_state(st)
    db.event(
        "info",
        "ppa_pyramid",
        (
            f"{pos['symbol']}: added {lot_size} @ {fill:.2f} (add #{adds + 1}, r {r_now:+.2f}, "
            f"P(target) {post['p_target']:.2f}, stop -> {new_stop:.2f}, qty {new_qty})"
        ),
        {"position_id": pid},
    )
    return [{"id": pid, "action": "pyramid_add", "fill": round(float(fill), 2), "qty": new_qty}]


def _averaging_add(
    gw: Any,
    cfg: dict[str, Any],
    pos: dict[str, Any],
    ltp: float,
    r_now: float,
) -> list[dict[str, Any]]:
    """Phase 3: average down — buy one more lot into a losing position to lower
    the blended entry and give the trade more room to recover.

    Discipline (deliberately tighter than pyramid):
    * sandbox only by default — real-money averaging-down without manual oversight
      is how small accounts blow up; the toggle defaults OFF for this reason.
      Live is possible only with BRAIN_PPA_AVERAGING_LIVE=true AND the model at
      LIVE_ELIGIBLE maturity; otherwise the position is skipped.
    * the position must be underwater with R below zero AND have dropped by at
      least ``avg_min_drop_pct`` since the last add (or since entry on first add);
    * capped by ``avg_max_adds`` per position so you never become a bagholder;
    * stop is raised *toward* the blended entry each time (``avg_stop_adjust``
      fraction of original risk), keeping total loss bounded even when adding.
    """
    from database import brain_db as db
    from services.brain import executor as ex
    from services.brain.orchestrator import platform_mode

    if not cfg.get("averaging"):
        return []
    pid = int(pos["id"])
    mode = platform_mode()
    # Pyramid is paper-only by design (adds to winners that are already protected);
    # averaging can run in live mode when the operator has explicitly opted in via
    # BRAIN_PPA_AVERAGING_LIVE=true AND the model has reached LIVE_ELIGIBLE maturity.
    if mode != "sandbox":
        if not cfg.get("averaging_live"):
            return [{"id": pid, "action": "avg_skip", "why": "not paper"}]
        # Live gate: only after the paper record has cleared maturity — the same
        # conditions `try_enter` enforces before any live entry is allowed. Uses
        # the operator's configured limits (RiskLimits.from_env) so the stage
        # matches what the Brain page shows.
        try:
            from services.brain import learner as _learner
            from services.brain.config import RiskLimits

            m = _learner.maturity(RiskLimits.from_env())
            if m.get("stage") != "LIVE_ELIGIBLE":
                return [
                    {"id": pid, "action": "avg_skip", "why": f"model not mature ({m.get('stage')})"}
                ]
        except Exception as e:
            return [{"id": pid, "action": "avg_skip", "why": f"maturity check failed: {e}"}]
    # Read state once, before the add counter: ``st`` was read here but used
    # above it, so every averaging attempt raised NameError before reaching
    # the broker and the feature never once ran.
    st = _state()
    pyr = st.get("pyramids") if isinstance(st.get("pyramids"), dict) else {}
    adds = int(pyr.get(f"avg:{pid}") or 0)
    if adds >= cfg["avg_max_adds"]:
        return [{"id": pid, "action": "avg_max", "adds": adds}]
    entry = float(pos.get("entry_price") or 0)
    if entry <= 0:
        return [{"id": pid, "action": "avg_skip", "why": "no entry"}]
    # How far down from entry have we fallen? First add checks from entry;
    # subsequent adds check from the *last blended* entry so we don't stack
    # micro-drops.
    prev_entry = float((st.get("avg_tracker") or {}).get(str(pid)) or entry)
    drop_pct = max((prev_entry - ltp) / prev_entry, 0.0) * 100.0
    if drop_pct < cfg["avg_min_drop_pct"]:
        return [
            {
                "id": pid,
                "action": "avg_wait",
                "drop_pct": round(drop_pct, 1),
                "need": round(cfg["avg_min_drop_pct"], 1),
            }
        ]
    # Don't average into a trade that's about to hit its own stop anyway.
    stop = float(pos.get("stop_price") or 0)
    if stop > 0 and ltp <= stop:
        return [{"id": pid, "action": "avg_skip", "why": "at/below stop"}]
    # Don't add right before expiry — theta will kill the avg.
    deadline = float(pos.get("deadline_ts") or 0)
    if deadline > 0 and (deadline - time.time()) < 30 * 60:
        return [{"id": pid, "action": "avg_skip", "why": "deadline within 30 min"}]
    lot_size = int(pos.get("lot_size") or 0)
    if lot_size <= 0:
        return [{"id": pid, "action": "avg_skip", "why": "no lot size"}]
    ok, order_id, err = gw.dispatch(
        platform_mode(), ex._order(pos["symbol"], pos.get("exchange") or "NFO", "BUY", lot_size)
    )
    if not ok:
        db.event(
            "warn",
            "ppa_avg_refused",
            f"{pos['symbol']}: avg add refused: {err}",
            {"position_id": pid},
        )
        return [{"id": pid, "action": "avg_refused", "why": err}]
    fill = gw.fill_price(platform_mode(), order_id) or ltp
    old_qty = int(pos.get("qty") or lot_size)
    new_qty = old_qty + lot_size
    blended = (entry * old_qty + float(fill) * lot_size) / new_qty
    # Raise the stop toward the blended entry: new_stop = stop
    #   + adjust × (blended − old_stop). At adjust=0.6 the stop sits 60% of the
    #   way from the old stop up to the new blended entry, preserving most of
    #   the original protection while tightening enough to keep total loss
    #   smaller than an unadjusted re-entry would face. (Anchoring on
    #   ``blended`` instead put the stop above the current price — an instant
    #   force-exit of the just-doubled position.)
    new_stop = stop + cfg["avg_stop_adjust"] * (blended - stop)
    # Never lower the stop below its previous level: if the blended entry is
    # below the old stop, keep the old stop so averaging down never widens risk.
    new_stop = max(stop, new_stop)
    db.position_update(
        pid,
        qty=new_qty,
        lots=int(pos.get("lots") or 1) + 1,
        entry_price=blended,
        stop_price=new_stop,
        # The trail must re-arm from the add, not from the pre-add high: the
        # stale extreme re-armed the stop above the new LTP on the next tick.
        highest_price=fill,
        lowest_price=fill,
        # Per-unit risk is measured from the blended entry to the raised stop;
        # the stale pre-add value made every R-multiple on this position wrong.
        risk_per_unit=max(blended - new_stop, 0.0),
    )
    st = _state()
    pyr = st.get("pyramids") if isinstance(st.get("pyramids"), dict) else {}
    pyr[f"avg:{pid}"] = adds + 1
    # Track the blended entry per position so subsequent averages compute the
    # drop from the last blend rather than from the original entry.
    avg_tracker = st.get("avg_tracker") if isinstance(st.get("avg_tracker"), dict) else {}
    avg_tracker[str(pid)] = blended
    st["pyramids"] = pyr
    st["avg_tracker"] = avg_tracker
    _save_state(st)
    db.event(
        "info",
        "ppa_averaging",
        (
            f"{pos['symbol']}: averaged down {lot_size} @ {fill:.2f} (add #{adds + 1}, "
            f"drop {drop_pct:.1f}%, blended → {blended:.2f}, stop → {new_stop:.2f}, qty {new_qty})"
        ),
        {"position_id": pid},
    )
    return [
        {
            "id": pid,
            "action": "avg_add",
            "fill": round(float(fill), 2),
            "qty": new_qty,
            "blended": round(blended, 2),
            "new_stop": round(new_stop, 2),
        }
    ]


def _entry_window_ok(dte_hours: float) -> bool:
    return 0 < dte_hours < 24 * 30


def strike_liquidity(
    row: dict[str, float],
    side: str,
    lot_size: int,
    max_spread_pct: float = 2.5,
    min_premium: float = 5.0,
) -> tuple[bool, float, str]:
    """Is this strike's chosen leg tradable? (bid/ask/OI + spread gate).

    ``max_spread_pct`` and ``min_premium`` default to the old hard-coded values;
    the entry path passes the human's limits so the table and this check agree
    (the tighter of the two applies).
    """
    bid = float(row.get(f"{side.lower()}_bid") or 0)
    ask = float(row.get(f"{side.lower()}_ask") or 0)
    ltp = float(row.get(f"{side.lower()}_ltp") or 0)
    oi = float(row.get(f"{side.lower()}_oi") or 0)
    delta = abs(float(row.get(f"{side.lower()}_delta") or 0))
    if not (bid > 0 and ask > 0):
        return False, 99.0, f"{side}: no two-sided quote"
    if ltp <= 0:
        ltp = (bid + ask) / 2.0
    spread_pct = (ask - bid) / max(((bid + ask) / 2.0), 1e-9) * 100.0
    if spread_pct > max_spread_pct:
        return False, spread_pct, f"{side}: spread {spread_pct:.1f}% too wide"
    if ltp < min_premium:
        return False, spread_pct, f"{side}: premium {ltp:.1f} below the minimum"
    if oi <= 0:
        return False, spread_pct, f"{side}: zero OI"
    if not (0.15 <= delta <= 0.85):
        return False, spread_pct, f"{side}: delta {delta:.2f} outside the liquid band"
    return True, spread_pct, "ok"


# ---- orchestration hooks -----------------------------------------------------


def on_scan(
    underlying: str,
    chain: dict[str, Any] | None,
    bars: np.ndarray,
    spot: float,
    gw: Any,
    api_key: str | None,
    now: float,
) -> dict[str, Any]:
    """Called once per underlying per Brain scan (60 s cadence).

    Two jobs, in order:

    1. manage: run stop/target/trail/time plus the PPA stay-or-cut posterior
       over open premium positions of this underlying;
    2. collect: top up today's 1m premium bars for the tracked ATM contracts
       (cadence-limited) so the PA vote has fresh data; a new expiry or a big
       spot move re-points the tracked strikes.

    Both run in every mode. Collection used to stop whenever the platform was
    not in analyzer (paper) mode, which left ``_manage_all`` reading premium
    bars that had aged since the last paper session: a live-mode manage would
    trail, cut or hold a real position on a stale vote. Entries are the only
    part that belongs to paper, and ``try_enter`` gates those on its own.
    """
    from database import brain_db as db
    from services.brain.orchestrator import platform_mode

    cfg = load_config()
    out: dict[str, Any] = {}
    if not cfg["enable"]:
        return {"skipped": "disabled"}
    if not chain or not chain.get("rows"):
        return {"skipped": "no chain"}
    if not (api_key or "").strip():
        api_key = _resolve_key()
        if not (api_key or "").strip():
            return {"skipped": "no api key"}

    mode = platform_mode()
    if mode != "sandbox":
        now_d = time.strftime("%Y-%m-%d", time.gmtime(now))
        if now_d != db.state_get(_PAPER_WARN_DAY_KEY):
            db.state_set(_PAPER_WARN_DAY_KEY, now_d)
            db.event(
                "warn",
                "ppa_paper_guard",
                "premium PA stands aside: platform is not in analyzer (paper) mode; "
                "entries resume when the sandbox toggle is on",
            )
        out["mode"] = "stand-aside (not paper)"

    rows = chain["rows"]
    spot_ref = float(chain.get("spot") or spot)
    if spot_ref <= 0:
        spot_ref = spot
    centre = min(rows, key=lambda r: abs(float(r.get("strike") or 0) - spot_ref))
    expiry = str(chain.get("expiry") or "")
    st = _state()
    u_state = st.get(underlying) or {}

    # roll the tracked contracts when expiry changes or spot moved away from the ATM
    tracked_atm = float(u_state.get("atm") or 0)
    needs_roll = (
        not u_state
        or u_state.get("expiry") != expiry
        or abs(float(centre.get("strike") or 0) - tracked_atm) > max(0.004 * spot_ref, 50.0)
    )
    if needs_roll:
        u_state = {
            "expiry": expiry,
            "atm": float(centre.get("strike") or 0),
            "ce_symbol": str(centre.get("ce_symbol") or ""),
            "pe_symbol": str(centre.get("pe_symbol") or ""),
            "ce_symbol_prev": u_state.get("ce_symbol"),
            "pe_symbol_prev": u_state.get("pe_symbol"),
            "lot_size": int(chain.get("lot_size") or 1),
            "dte": float(chain.get("dte") or 0),
            "last_collect": 0.0,
        }
        st[underlying] = u_state
        _save_state(st)
        db.event(
            "info",
            "ppa_roll",
            f"{underlying}: tracking {u_state['ce_symbol']} / {u_state['pe_symbol']} "
            f"(atm {u_state['atm']:.0f}, expires {expiry}, dte {u_state['dte']:.1f}d)",
        )

    managed = _manage_all(gw, cfg, now, bars)
    out["manage"] = managed

    # incremental collection, at most every COLLECT_MIN_INTERVAL_S per underlying
    if now - float(u_state.get("last_collect") or 0) >= COLLECT_MIN_INTERVAL_S:
        got = 0
        for sym in (u_state["ce_symbol"], u_state["pe_symbol"]):
            if sym:
                got += collect_symbol(sym, api_key, _fo_exchange(underlying))
        if got:
            u_state["last_collect"] = now
            st[underlying] = u_state
            _save_state(st)
        out["collected"] = got

    # Journal this decision point and label the ones that have matured. It only
    # records training data: it never trades, sizes or vetoes anything.
    try:
        from services.brain import ppa_candidates

        out["candidates"] = ppa_candidates.observe(underlying, chain, bars, now, api_key or "")
        ppa_candidates.label_pending(now)
    except Exception:
        logger.exception("ppa: candidate journal failed for %s", underlying)
    return out


def _skip(underlying: str, reason: str, now: float) -> dict[str, Any]:
    """Stand aside, and say so in the journal (rate-limited).

    The Events tab is where the operator looks to understand what the Brain is
    doing; a silent skip is indistinguishable from a broken module.
    """
    from database import brain_db as db

    out = {"skipped": reason}
    try:
        last = _skip_log.get(underlying, 0.0)
        if now - last >= SKIP_LOG_INTERVAL_S:
            _skip_log[underlying] = now
            db.event("info", "ppa_skip", f"{underlying}: {reason}", {"underlying": underlying})
    except Exception:
        logger.exception("ppa: skip note failed for %s", underlying)
    return out


def try_enter(
    underlying: str,
    chain: dict[str, Any] | None,
    bars: np.ndarray,
    spot: float,
    gw: Any,
    now: float,
    brain: Any,
    data: Any = None,
    api_key: str = "",
) -> dict[str, Any]:
    """Paper entry: PA vote on premium + shared risk gate + paper-capital sizing.

    The decision runs under this underlying's entry claim. It reads the open
    position book, passes the risk gate and only then journals the position,
    with broker and database calls in between that yield to another pass; two
    passes on one underlying could otherwise both find room and enter twice,
    which the per-underlying caps exist to prevent. ``timeout=0`` makes the
    second pass stand aside rather than queue behind the first: the holder is
    already deciding this underlying, and the next bar re-evaluates.
    """
    from services.brain.orchestrator import entry_claim

    with entry_claim(f"ppa:{underlying}", timeout=0.0) as mine:
        if not mine:
            return {"skipped": "another pass is already entering this underlying"}
        return _try_enter_claimed(
            underlying, chain, bars, spot, gw, now, brain, data=data, api_key=api_key
        )


def _try_enter_claimed(
    underlying: str,
    chain: dict[str, Any] | None,
    bars: np.ndarray,
    spot: float,
    gw: Any,
    now: float,
    brain: Any,
    data: Any = None,
    api_key: str = "",
) -> dict[str, Any]:
    """The body of :func:`try_enter`, always called with its claim held."""
    from database import brain_db as db
    from services.brain import executor as ex
    from services.brain import risk_gate
    from services.brain.orchestrator import learner, platform_mode

    cfg = load_config()
    if not cfg["enable"]:
        return {"skipped": "paper-only"}
    # Feature drift pauses PPA too: when the Brain's model has drifted from
    # the live market, premium-PA entries stand aside until it settles. When
    # drift lifts, PPA resumes automatically on the very next scan.
    degraded = bool(db.state_get("degraded", False))
    if degraded:
        db.event(
            "warn",
            "ppa_drift_pause",
            "feature drift detected — PPA entries paused until drift settles",
        )
        return {"skipped": "feature drift: PPA paused"}
    # Live broker mode support: when platform is live, only allow entries if
    # the fusion entry_mode() also returns "live" — this means BRAIN_LIVE_ENABLED
    # is true AND the paper record has cleared maturity(). Sandbox runs freely.
    mode = platform_mode()
    if mode == "sandbox":
        pass  # sandbox entries allowed directly below
    elif mode == "live":
        m = learner.maturity(brain.limits)
        if m["stage"] != "LIVE_ELIGIBLE":
            return {"skipped": f"live trading not yet earned: {m['stage']}"}
        try:
            from services.order_router_service import should_route_to_pending

            if api_key and should_route_to_pending(api_key, "placeorder"):
                return {"skipped": "order router requires approval"}
        except Exception:
            return {"skipped": "order router unavailable; standing aside"}
    else:
        return {"skipped": "paper-only"}
    if not chain or not chain.get("rows"):
        return {}
    stats = _record_closed(now)  # fold any newly closed PPA trades into the learning stats
    st = _state()
    u_state = st.get(underlying) or {}
    ce_sym, pe_sym = u_state.get("ce_symbol") or "", u_state.get("pe_symbol") or ""
    if not (ce_sym and pe_sym):
        return {}

    # --- concurrency / discipline gates ---
    open_all = db.positions_open()
    mine = [p for p in open_all if p.get("note") == PPA_NOTE]
    if len(mine) >= cfg["max_open"]:
        return _skip(underlying, f"max open premium positions ({len(mine)})", now)
    if any(p["underlying"] == underlying for p in mine):
        return _skip(underlying, "already holding this underlying", now)
    today0 = _ist0(now)
    trades_today = [
        p
        for p in db.positions_closed(today0)
        if p.get("note") == PPA_NOTE and (p.get("exit_ts") or 0) >= today0
    ]
    if len(trades_today) >= cfg["max_trades_day"]:
        return _skip(underlying, "daily trade cap", now)
    # Daily loss circuit breaker: enough losing paper trades in one day means
    # the regime is wrong for the premium-PA read — stand aside until tomorrow.
    if cfg["adapt"]:
        losses_today = sum(1 for p in trades_today if float(p.get("pnl") or 0) < 0)
        if losses_today >= cfg["max_losses_day"]:
            return _skip(
                underlying, f"daily loss circuit breaker ({losses_today} losses today)", now
            )
    # The cooldown belongs to the underlying that traded: a cut in BANKNIFTY
    # must not stop NIFTY from qualifying a minute later. It stretches when
    # that underlying is on a loss streak.
    min_score_eff, cooldown_s, streak_u = adaptive_edge(cfg, stats, underlying)
    last_exit = max(
        (float(p.get("exit_ts") or 0) for p in trades_today if p.get("underlying") == underlying),
        default=0.0,
    )
    if now - last_exit < cooldown_s:
        return _skip(
            underlying,
            f"cooldown after its own exit ({(now - last_exit) / 60:.0f}m of {cooldown_s / 60:.0f}m left"
            + (f", loss streak {streak_u}" if streak_u else "")
            + ")",
            now,
        )

    fo_ex = _fo_exchange(underlying)
    ce_bars = premium_bars(ce_sym, _resolve_key(), exchange=fo_ex)
    pe_bars = premium_bars(pe_sym, _resolve_key(), exchange=fo_ex)
    if ce_bars is None or pe_bars is None:
        return _skip(underlying, "premium bars not ready", now)
    c5, p5 = aggregate_5m(ce_bars), aggregate_5m(pe_bars)
    if len(c5) < 25 or len(p5) < 25:
        return _skip(underlying, "premium bars not warm yet", now)

    vote = premium_vote(c5, p5, cfg)
    if vote["confidence"] < 0.40 or abs(vote["score"]) < min_score_eff:
        return _skip(
            underlying,
            f"no PA edge (score {vote['score']:+.2f} vs need {min_score_eff:.2f}"
            + (f" [base {cfg['min_score']:.2f}, streak {streak_u}]" if streak_u else "")
            + f", conf {vote['confidence']:.2f})",
            now,
        )
    side = vote["side"]
    if cfg["confirm_underlying"]:
        bmom = float(bars[-1, 4] / bars[-4, 4] - 1.0) if len(bars) >= 4 else 0.0
        want = bmom > 0 if side == "CE" else bmom < 0
        strength = abs(bmom) >= 0.0004
        if not (want and strength):
            return _skip(underlying, f"underlying disagrees ({bmom:+.4%}) for {side}", now)

    row = next(
        (r for r in chain["rows"] if str(r.get("strike")) == str(u_state.get("atm"))),
        None,
    )
    if row is None:
        return _skip(underlying, "ATM row missing from the chain", now)
    okq, spread_pct, why = strike_liquidity(
        row,
        side,
        int(u_state.get("lot_size") or 1),
        max_spread_pct=min(2.5, float(brain.limits.max_spread_pct)),
        min_premium=max(5.0, float(brain.limits.min_premium)),
    )
    if not okq:
        return _skip(underlying, why, now)
    symbol = str(row.get(f"{side.lower()}_symbol") or "")
    if not symbol:
        return _skip(underlying, "no broker symbol for the strike", now)
    bid = float(row.get(f"{side.lower()}_bid") or 0)
    ask = float(row.get(f"{side.lower()}_ask") or 0)
    mid = (bid + ask) / 2.0
    # entry near mid; the PA must justify paying it
    lv = plan_premium_levels(
        mid,
        cfg,
        (ask - bid),
        cfg["horizon_bars"],
        sigma_h=premium_sigma_h(c5 if side == "CE" else p5, cfg["horizon_bars"]),
    )

    lots = size_lots(
        lv["risk_per_unit"],
        int(u_state.get("lot_size") or 1),
        paper_equity(),
        5,  # hard cap; sizing formula keeps us cautious anyway
        float(brain.limits.risk_per_trade_pct),
    )
    if lots <= 0:
        return _skip(underlying, "risk budget too small for one lot", now)

    # Scale position size down as expiry approaches. Premium PA trades ATM
    # options whose own premium collapses toward zero in the last few days — a
    # fixed lot at 0.3 DTE risks the same absolute amount on a ₹6 premium as at
    # 15 DTE on a ₹120 premium, but the signal-to-noise is far worse up close.
    # Shrink proportionally across the first GAMMA_DTE_MAX days so we lose no
    # edge early in the expiry cycle and fade to nothing inside the blast zone.
    dte = float(u_state.get("dte") or 0)
    dte_scale = min(dte / GAMMA_DTE_MAX, 1.0) if dte > 0 else 1.0

    proposal = risk_gate.Proposal(
        mid, int(u_state.get("lot_size") or 1), spread_pct, lv["risk_per_unit"]
    )
    # --- feature gate: symbol exclusion, IV regime, momentum, drawdown halt ---
    # Runs before the risk gate so a BANKNIFTY or extreme-IV candidate is
    # refused without spending broker funds or journaling a position.
    from services.brain import gate as _gate
    from services.brain.types import Candidate, Snapshot

    try:
        source = data if data is not None else _DataShim(bars)
        state = brain.gate_state(source, gw, now, 0.0, 0.0)
    except Exception:
        logger.exception("ppa: gate state unavailable; standing aside")
        return _skip(underlying, "gate state error", now)
    iv_rank_pa = None
    try:
        atm_iv = float(chain.get("atm_iv") or 0.0)
        if atm_iv <= 0:
            from services.brain.engines import options as _options_engine

            atm_iv = float(
                _options_engine.summarize({**chain, "spot": chain.get("spot") or spot}).get(
                    "atm_iv"
                )
                or 0.0
            )
        if atm_iv > 0:
            iv_rank_pa = db.iv_rank(underlying, atm_iv)
    except Exception:
        logger.exception("ppa: IV rank unavailable; the IV gate stands down for this pass")
    snap_pa = Snapshot(
        underlying=underlying,
        ts=now,
        bars=bars,
        spot=spot,
        lot_size=int(u_state.get("lot_size") or 1),
        bench_close=None,
        chain=chain,
        iv_rank=iv_rank_pa,
        vix=None,
        minute_of_day=int(((now + 19800) // 300) % (24 * 60)),
        params=None,
    )
    cand_pa = Candidate(
        underlying=underlying,
        side="LONG",
        regime="trend",
        score=float(vote.get("score", 0.0)),
        agree=1,
        prob=float(vote.get("confidence", 0.0)),
        prob_prior=float(vote.get("confidence", 0.0)),
        ev_r=float(vote.get("score", 0.0)),
        rr=float(cfg.get("rr", 1.5)),
        sigma_h=0.0,
        k_stop=float(cfg.get("k_stop", 0.8)),
        k_target=float(cfg.get("rr", 1.5)),
        horizon_bars=int(cfg.get("horizon_bars", 12)),
        features={},
        votes={"ppa": float(vote.get("score", 0.0))},
        position_type="long",
    )
    kept, gate_reasons = _gate.apply_gate(
        [cand_pa],
        snap_pa,
        None,
        daily_pnl=state.equity,
        equity_peak=state.peak_equity,
        consecutive_losses=state.consecutive_losses,
        knobs=getattr(brain, "tune_knobs", None),
        limits=brain.limits,
    )
    if not kept:
        return _skip(underlying, "feature gate: " + "; ".join(gate_reasons.values()), now)
    try:
        verdict = risk_gate.check_entry(brain.limits, state, proposal)
    except Exception:
        logger.exception("ppa: risk gate unavailable; standing aside")
        return _skip(underlying, "risk gate error", now)
    if not verdict.allow:
        return _skip(underlying, "risk gate: " + "; ".join(verdict.reasons), now)

    # Use the gate's sized lot count, not PPA's pre-computed lots — the gate
    # is the single source of truth for how many lots the account can afford.
    # The expiry shrink is applied here, on the gate's count: it used to scale a
    # number that this line then replaced, so it never changed a position size.
    lots = max(1, int(verdict.lots * dte_scale))
    qty = lots * int(u_state.get("lot_size") or 1)
    pid = db.position_add(
        {
            "signal_id": None,
            "underlying": underlying,
            "symbol": symbol,
            # The order must go where the contract actually trades: BFO for
            # SENSEX/BANKEX, NFO for NSE indices. A BSE contract sent to NFO
            # is refused as "not found", which journals a dead 0-R trade.
            "exchange": fo_ex,
            "option_type": side,
            "side": side,
            "strike": float(u_state.get("atm") or 0),
            "expiry": str(u_state.get("expiry") or ""),
            "lots": lots,
            "qty": qty,
            "lot_size": int(u_state.get("lot_size") or 1),
            "mode": platform_mode(),
            "state": "PENDING",
            "entry_price": mid,
            "entry_ts": now,
            "entry_bar_ts": float(bars[-1, 0]),
            "initial_stop": lv["stop"],
            "stop_price": lv["stop"],
            "target_price": lv["target"],
            "trail_trigger": lv["trail_trigger"],
            "trail_gap": lv["trail_gap"],
            # Directional edge at entry (vote score in [-1, 1]): the stay-or-cut
            # posterior conditions its drift on this so a strong entry is given
            # room to run instead of being cut on the first mean-reverting dip.
            "entry_edge": float(vote.get("score", 0.0)),
            "highest_price": mid,
            "lowest_price": mid,
            "risk_per_unit": lv["risk_per_unit"],
            "deadline_ts": now + lv["deadline_s"],
            "model_version": 0,
            "note": PPA_NOTE,
        }
    )
    ok, order_id, err = gw.dispatch(platform_mode(), ex._order(symbol, fo_ex, "BUY", qty))
    if not ok:
        db.position_update(
            pid, state="CLOSED", exit_reason=f"entry refused: {err}", exit_ts=time.time(), pnl=0.0
        )
        db.event("warn", "ppa_entry_refused", f"ppa {symbol}: {err}", {"position_id": pid})
        return {"entered": False, "error": err}
    fill = gw.fill_price(platform_mode(), order_id) or mid
    db.position_update(
        pid,
        state="OPEN",
        entry_order_id=order_id or "",
        entry_price=fill,
        initial_stop=lv["stop"],
        stop_price=lv["stop"],
        target_price=lv["target"],
        trail_trigger=lv["trail_trigger"],
        trail_gap=lv["trail_gap"],
        highest_price=fill,
        lowest_price=fill,
    )
    db.event(
        "info",
        "ppa_entry",
        (
            f"ppa BUY {qty} {symbol} @ {fill:.2f} "
            f"(stop {lv['stop']:.2f}, target {lv['target']:.2f}, lots {lots}, "
            f"score {vote['score']:+.2f}, conf {vote['confidence']:.2f})"
        ),
        {"position_id": pid},
    )
    return {"entered": True, "pid": pid, "side": side, "symbol": symbol, "fill": fill}


def manage_open(gw: Any, cfg: dict[str, Any], now: float, bars: np.ndarray) -> list[dict[str, Any]]:
    """Alias kept for orchestrator readability: manage every PPA position."""
    return _manage_all(gw, cfg, now, bars)


def _manage_all(gw: Any, cfg: dict[str, Any], now: float, bars: np.ndarray) -> list[dict[str, Any]]:
    """Stop/target/trail/time via the shared risk core, plus the stay-or-cut posterior."""
    from database import brain_db as db
    from services.brain import executor as ex
    from services.brain.orchestrator import _ist  # noqa: F401 (side-effect import of tz helpers)
    from services.risk import evaluate_position

    out: list[dict[str, Any]] = []
    for pos in db.positions_open():
        if pos.get("note") != PPA_NOTE:
            continue
        pid = int(pos["id"])
        if pos["state"] == "PENDING":
            if now - float(pos["entry_ts"]) > ex.PENDING_TIMEOUT_S:
                db.event(
                    "error",
                    "ppa_pending_stuck",
                    f"{pos['symbol']}: entry unresolved after {ex.PENDING_TIMEOUT_S:.0f}s",
                    {"position_id": pid},
                )
            continue
        if pos["state"] != "OPEN":
            continue
        ltp = gw.quote(pos["symbol"], pos["exchange"])
        if ltp is None:
            out.append({"id": pid, "action": "no_quote"})
            continue
        d = evaluate_position(ex._risk(pos), ltp)
        if d.evaluated:
            move = ltp - float(pos["entry_price"])
            db.position_update(
                pid,
                stop_price=d.stop_price,
                highest_price=d.highest_price,
                lowest_price=d.lowest_price,
                mfe=max(float(pos["mfe"] or 0), move),
                mae=min(float(pos["mae"] or 0), move),
            )
            pos = {**pos, "stop_price": d.stop_price, "highest_price": d.highest_price}
        if d.breached:
            kind = "stop" if (d.reason and d.reason.value == "sl") else "target"
            done = ex.exit_position(gw, pos, kind, d.detail or kind, ltp, now)
            out.append({"id": pid, "action": kind, "closed": done})
            if done:
                _pyramid_forget(pid)
            continue
        if now >= float(pos.get("deadline_ts") or 0) > 0:
            done = ex.exit_position(gw, pos, "time", "ppa: time stop", ltp, now)
            out.append({"id": pid, "action": "time", "closed": done})
            if done:
                _pyramid_forget(pid)
            continue
        # ---- stay or cut ----------------------------------------------------
        sym_bars = premium_bars(
            pos["symbol"], _resolve_key(), exchange=pos.get("exchange") or "NFO"
        )
        if sym_bars is None or len(sym_bars) < 25:
            out.append({"id": pid, "action": "hold", "posterior": "bars-na"})
            continue
        b5 = aggregate_5m(sym_bars)
        entered_bar = float(pos.get("entry_bar_ts") or pos["entry_ts"])
        # Count market bars (5-minute completed bars) since entry, not wall-clock
        # minutes. entry_bar_ts is the bar_ts of the bar during which the position
        # was entered, so counting bars from it to the latest bar gives a true
        # market-hold duration.
        bars_since = max(int(b5[-1, 0] - entered_bar) // 300, 0)
        if bars_since < MIN_HOLD_BARS:
            # A position that was just opened has not had time to work. The
            # hard stop still guards it; the posterior does not get to cut it
            # on the same bar it was born.
            out.append({"id": pid, "action": "hold", "posterior": "min-hold"})
            continue
        if len(b5) < bars_since + 3:
            out.append({"id": pid, "action": "hold", "posterior": "warm"})
            continue
        path = b5[-(bars_since + 8) :]  # a little pre-entry history for the sigma estimate
        horizon_bars_left = int((float(pos.get("deadline_ts") or now) - now) // 300)
        entry_edge = float(pos.get("entry_edge") or 0.0)
        post = posterior_survival(
            path,
            ltp,
            float(pos["stop_price"] or 0),
            float(pos["target_price"] or 0),
            max(horizon_bars_left, 2),
            entry_edge=entry_edge,
        )
        move = ltp - float(pos["entry_price"])
        risk = max(float(pos["risk_per_unit"] or 0), 1e-9)
        r_now = move / risk
        cut = (
            post["p_target"] < cfg["hold_min"]
            and horizon_bars_left >= 2
            and r_now < 0.5  # leave trail-protected winners alone
        )
        if cut:
            done = ex.exit_position(
                gw,
                pos,
                "pp_cut",
                f"ppa cut: P(target) {post['p_target']:.2f} < {cfg['hold_min']:.2f}, r {r_now:+.2f}",
                ltp,
                now,
            )
            out.append({"id": pid, "action": "pp_cut", "posterior": post, "closed": done})
            if done:
                _pyramid_forget(pid)
            continue
        out.append(
            {
                "id": pid,
                "action": "hold",
                "posterior": round(post["p_target"], 2),
                "r": round(r_now, 2),
            }
        )
        # Phase 2: the posterior still believes in this winner — let it compound.
        if cfg["pyramid"] and post["p_target"] >= cfg["pyramid_min_post"]:
            out.extend(_pyramid_add(gw, cfg, pos, ltp, r_now, post))
        # Phase 3: averaged-down add into a loser that has dropped enough.
        # Separate guard from pyramid so the two phases don't collide on the
        # same position (one wants to add up, the other wants to add down).
        elif cfg.get("averaging") and r_now < -0.05:
            out.extend(_averaging_add(gw, cfg, pos, ltp, r_now))
    return out


class _DataShim:
    """Minimal DataSource stand-in so the shared risk gate can size paper equity.

    The Brain's gate_state only uses ``data.funds()`` and passed-in numbers; a
    shim returning None keeps everything else caller-provided.
    """

    def __init__(self, bars: np.ndarray | None = None) -> None:
        self._bars = bars

    def bars(self, underlying: str, count: int = 400) -> np.ndarray | None:
        return self._bars

    def funds(self) -> float | None:
        return None

    def chain(self, underlying: str) -> dict[str, Any] | None:
        return None


def _resolve_key() -> str:
    try:
        from services.brain.orchestrator import resolve_api_key

        k = resolve_api_key()
        return k or ""
    except Exception:
        return ""


def _ist0(now: float) -> float:
    from datetime import datetime, timedelta, timezone

    IST = timezone(timedelta(hours=5, minutes=30))
    d = datetime.fromtimestamp(now, IST)
    return datetime(d.year, d.month, d.day, tzinfo=IST).timestamp()
