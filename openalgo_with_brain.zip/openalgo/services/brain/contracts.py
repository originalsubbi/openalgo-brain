"""Contract facts about the Indian index derivatives the Brain trades.

Kept in one place because they are easy to get wrong and expensive to get
wrong: a lot size that is off by a factor makes every position the wrong size,
and the loss is not visible in the numbers until the margin call arrives.

The values are verified against the broker's own master contract, not against
memory: NIFTY moved from 50 to 65, and a hard-coded 75 would have been wrong
twice over.
"""

from __future__ import annotations

#: Contract multiplier (units per lot) for each index.
LOT_SIZES = {
    "NIFTY": 65,
    "BANKNIFTY": 35,
    "FINNIFTY": 65,
    "MIDCPNIFTY": 120,
    "SENSEX": 20,
    "BANKEX": 30,
}

#: Strike spacing in index points.
STRIDE = {
    "NIFTY": 50.0,
    "BANKNIFTY": 100.0,
    "FINNIFTY": 50.0,
    "MIDCPNIFTY": 25.0,
    "SENSEX": 100.0,
    "BANKEX": 100.0,
}

#: Which segment each index's options trade on. An NSE index's options are on
#: NFO, a BSE index's on BFO. Sending a BSE contract to NFO is refused by the
#: broker, which is what the Brain's first SENSEX trades did.
FO_EXCHANGE = {
    "NIFTY": "NFO",
    "BANKNIFTY": "NFO",
    "FINNIFTY": "NFO",
    "MIDCPNIFTY": "NFO",
    "SENSEX": "BFO",
    "BANKEX": "BFO",
}


def lot_size(symbol: str) -> int:
    return LOT_SIZES.get(symbol.upper(), 65)


def stride(symbol: str) -> float:
    return STRIDE.get(symbol.upper(), 50.0)


def fo_exchange(symbol: str) -> str:
    return FO_EXCHANGE.get(symbol.upper(), "NFO")


__all__ = ["LOT_SIZES", "STRIDE", "FO_EXCHANGE", "lot_size", "stride", "fo_exchange"]
