"""PPA backtest: replay PPA's own entry and exit rules against the candidate journal.

The ``brain_ppa_candidate`` journal records every PPA decision point (CE and PE
at the ATM strike) with the vote PPA computed (``vote_score``, ``features.vote_conf``),
the underlying momentum it saw, the exit plan (k_stop, rr, stop_pct, horizon, sigma_h,
spread) and a triple-barrier label of what a long-premium trade would have done.

This module replays those rows chronologically through the same decision path as
``premium_pa._try_enter_claimed``:

* the side PPA would pick (CE when ``vote_score >= 0``, else PE) - the journal holds
  both sides for every bar, only the voted one is a trade;
* ``confidence >= 0.40`` and ``|score| >= min_score_eff``;
* the adaptive edge: each loss on an underlying raises ``min_score_eff`` by
  ``streak_score_step`` (capped by ``streak_cap``) and stretches its cooldown;
* ``confirm_underlying``: aligned 3-bar underlying momentum of at least 0.04 %;
* one position per underlying, ``max_open``, the per-underlying cooldown, the daily
  trade cap and the daily loss circuit breaker.

Exit rules (``k_stop``, ``rr``, ``stop_pct``, ``horizon_bars``) can be overridden; the
triple-barrier label is then re-walked on the 1-minute premium bars from Historify.
The vote itself comes from the journal (it is a pure function of bars that are not
journalled), so changing the vote's internal weights is out of scope; its thresholds
are in scope.

Nothing here places, sizes, or vetoes an order. Read-only research tool.

    python -m services.brain.ppa_backtest --days 30 --underlying NIFTY
"""

from __future__ import annotations

import argparse
import time
from collections import defaultdict
from dataclasses import dataclass, replace
from typing import Any

import numpy as np

from services.brain import ppa_candidates
from services.brain.labeling import metrics

BAR_S = ppa_candidates.BAR_S
MIN_CONFIDENCE = 0.40  # premium_pa: vote["confidence"] < 0.40 -> no trade
MIN_UND_MOM = 0.0004  # premium_pa: |underlying 3-bar move| must reach 0.04 %
COOLDOWN_S = 20 * 60.0  # premium_pa.COOLDOWN_S
IST_S = 19800  # IST offset, to split sessions into days

DEFAULT_CFG: dict[str, Any] = {
    "min_score": 0.45,
    "confirm_underlying": True,
    "adapt": True,
    "streak_score_step": 0.10,
    "streak_cooldown_mult": 1.0,
    "streak_cap": 2,
    "max_open": 2,
    "max_trades_day": 6,
    "max_losses_day": 4,
}


@dataclass(frozen=True)
class Scenario:
    """One configuration to replay. ``None`` exit fields keep the journalled plan."""

    name: str = "baseline"
    cfg: dict[str, Any] | None = None  # overrides on top of the live PPA config
    k_stop: float | None = None
    rr: float | None = None
    stop_pct: float | None = None
    horizon_bars: int | None = None
    portfolio: bool = True  # apply open/cooldown/daily-cap rules

    @property
    def exit_changed(self) -> bool:
        return any(v is not None for v in (self.k_stop, self.rr, self.stop_pct, self.horizon_bars))


def live_config() -> dict[str, Any]:
    """PPA's current entry config (env + overrides), restricted to the keys replayed here."""
    from services.brain import premium_pa as ppa

    live = ppa.load_config()
    return {k: live.get(k, v) for k, v in DEFAULT_CFG.items()}


def load_rows(
    limit: int = 50000, days: int = 0, underlying: str = "", now: float | None = None
) -> list[dict[str, Any]]:
    """Labelled journal rows with their nested ``plan``/``features``, oldest first."""
    from database import brain_db as db

    rows = db.ppa_candidates_labelled(limit)
    if underlying:
        rows = [r for r in rows if str(r.get("underlying", "")).upper() == underlying.upper()]
    if days > 0:
        cutoff = (now or time.time()) - days * 86400.0
        rows = [r for r in rows if float(r.get("bar_ts") or 0) >= cutoff]
    return sorted(rows, key=lambda r: (float(r["bar_ts"]), str(r.get("underlying", ""))))


def voted_side(row: dict[str, Any]) -> str:
    """The side PPA's vote picks (``premium_vote``: CE when score >= 0)."""
    return "CE" if float(row.get("vote_score") or 0.0) >= 0.0 else "PE"


def vote_gate(
    row: dict[str, Any], min_score_eff: float, confirm_underlying: bool
) -> str | None:
    """Why PPA would stand aside on this row, or None when it would enter."""
    feats = row.get("features") or {}
    if float(feats.get("vote_conf") or 0.0) < MIN_CONFIDENCE:
        return "low_confidence"
    if abs(float(row.get("vote_score") or 0.0)) < min_score_eff:
        return "weak_score"
    if confirm_underlying:
        # und_mom3_aligned is already signed by side: > 0 means the underlying moved with it.
        if float(feats.get("und_mom3_aligned") or 0.0) < MIN_UND_MOM:
            return "underlying_disagrees"
    return None


def _edge(cfg: dict[str, Any], streak: int) -> tuple[float, float]:
    """(effective min_score, cooldown seconds) for an underlying on ``streak`` losses."""
    if not cfg["adapt"]:
        return float(cfg["min_score"]), COOLDOWN_S
    eff = min(float(cfg["min_score"]) + float(cfg["streak_score_step"]) * min(streak, int(cfg["streak_cap"])), 1.0)
    return eff, COOLDOWN_S * (1.0 + float(cfg["streak_cooldown_mult"]) * min(streak, 3))


def relabel(row: dict[str, Any], scen: Scenario, bars: np.ndarray | None, now: float) -> dict[str, Any] | None:
    """Re-walk the triple barrier with the scenario's exit parameters.

    Returns the label dict, ``{"expired": True}`` for an unobservable outcome, or
    None when the bars have not reached the new (longer) horizon yet.
    """
    plan = dict(row.get("plan") or {})
    for key, val in (
        ("k_stop", scen.k_stop),
        ("rr", scen.rr),
        ("stop_pct", scen.stop_pct),
        ("horizon_bars", scen.horizon_bars),
    ):
        if val is not None:
            plan[key] = val
    return ppa_candidates.label_candidate({**row, "plan": plan}, bars, now)


def _stored_label(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "expired": False,
        "label_outcome": int(row.get("label_outcome") or 0),
        "label_r": float(row.get("label_r") if row.get("label_r") is not None else row.get("label_r_net") or 0.0),
        "label_r_net": float(row.get("label_r_net") or 0.0),
        "label_bars": int(row.get("label_bars") or (row.get("plan") or {}).get("horizon_bars") or 12),
    }


def replay(
    rows: list[dict[str, Any]],
    scen: Scenario,
    base_cfg: dict[str, Any] | None = None,
    bars_for: Any = None,
    now: float | None = None,
) -> dict[str, Any]:
    """Replay ``rows`` (oldest first) under ``scen``. Returns metrics, counters and the trades."""
    now = now or time.time()
    cfg = {**DEFAULT_CFG, **(base_cfg or {}), **(scen.cfg or {})}
    cache: dict[tuple[str, str], np.ndarray | None] = {}

    def _bars(row: dict[str, Any]) -> np.ndarray | None:
        key = (str(row.get("symbol") or ""), str(row.get("exchange") or "NFO"))
        if key not in cache:
            if bars_for is not None:
                cache[key] = bars_for(*key)
            elif key[0]:
                from services.brain import premium_pa as ppa

                cache[key] = ppa._bars_from_historify(*key)
            else:
                cache[key] = None
        return cache[key]

    skips: dict[str, int] = defaultdict(int)
    streak: dict[str, int] = defaultdict(int)
    busy_until: dict[str, float] = {}
    last_exit: dict[str, float] = {}
    day_closed: dict[int, int] = defaultdict(int)
    day_losses: dict[int, int] = defaultdict(int)
    open_trades: list[tuple[float, str, float]] = []  # (exit_ts, underlying, r_net)
    trades: list[dict[str, Any]] = []

    def _settle(ts: float) -> None:
        """Book every trade whose exit is at or before ``ts``."""
        for t in sorted(x for x in open_trades if x[0] <= ts):
            open_trades.remove(t)
            xt, u, r = t
            day = int((xt + IST_S) // 86400)
            day_closed[day] += 1
            last_exit[u] = xt
            if r > 0:
                streak[u] = 0
            elif r < 0:
                streak[u] += 1
                day_losses[day] += 1

    for row in rows:
        if row.get("side") != voted_side(row):
            continue  # the journal holds both sides; PPA only trades the voted one
        u = str(row.get("underlying") or "")
        decision_ts = float(row["bar_ts"]) + BAR_S
        _settle(decision_ts)
        day = int((decision_ts + IST_S) // 86400)

        if scen.portfolio:
            if len(open_trades) >= int(cfg["max_open"]):
                skips["max_open"] += 1
                continue
            if busy_until.get(u, 0.0) > decision_ts:
                skips["already_holding"] += 1
                continue
            if day_closed[day] >= int(cfg["max_trades_day"]):
                skips["daily_trade_cap"] += 1
                continue
            if cfg["adapt"] and day_losses[day] >= int(cfg["max_losses_day"]):
                skips["daily_loss_breaker"] += 1
                continue
            min_score_eff, cooldown_s = _edge(cfg, streak[u])
            if decision_ts - last_exit.get(u, 0.0) < cooldown_s:
                skips["cooldown"] += 1
                continue
        else:
            min_score_eff = float(cfg["min_score"])

        why = vote_gate(row, min_score_eff, bool(cfg["confirm_underlying"]))
        if why:
            skips[why] += 1
            continue

        if scen.exit_changed:
            lab = relabel(row, scen, _bars(row), now)
            if lab is None:
                skips["label_not_ready"] += 1
                continue
            if lab.get("expired"):
                skips["unlabelable"] += 1
                continue
        else:
            lab = _stored_label(row)

        r_net = float(lab["label_r_net"])
        exit_ts = decision_ts + int(lab["label_bars"]) * BAR_S
        busy_until[u] = exit_ts
        open_trades.append((exit_ts, u, r_net))
        trades.append(
            {
                "underlying": u,
                "side": row["side"],
                "bar_ts": float(row["bar_ts"]),
                "exit_ts": exit_ts,
                "outcome": int(lab["label_outcome"]),
                "r": float(lab["label_r"]),
                "r_net": r_net,
            }
        )

    r = np.array([t["r_net"] for t in trades], dtype=float)
    outcomes = np.array([t["outcome"] for t in trades], dtype=int)
    n = len(trades)
    m = metrics([t["r_net"] for t in sorted(trades, key=lambda t: t["exit_ts"])])
    return {
        "name": scen.name,
        "journal_rows": len(rows),
        "taken": n,
        "skips": dict(skips),
        "win_rate": float((outcomes == 1).mean()) if n else 0.0,
        "stop_rate": float((outcomes == -1).mean()) if n else 0.0,
        "timeout_rate": float((outcomes == 0).mean()) if n else 0.0,
        "mean_r_net": float(r.mean()) if n else 0.0,
        "total_r_net": float(r.sum()) if n else 0.0,
        "metrics": m.as_dict(),
        "trades": trades,
    }


def format_result(res: dict[str, Any]) -> str:
    m = res["metrics"]
    return (
        f"{res['name']:28s} n={res['taken']:5d} win={res['win_rate']:5.1%} "
        f"stop={res['stop_rate']:5.1%} to={res['timeout_rate']:5.1%} "
        f"E[R]={m['expectancy_r']:+.3f} lcb={m['lcb_r']:+.3f} totR={m['total_r']:+7.2f} "
        f"PF={m['profit_factor']:5.2f} maxDD={m['max_dd_r']:.2f}R"
    )


def sweeps() -> list[tuple[str, list[Scenario]]]:
    """The standard what-if grid: entry thresholds, then each exit knob on its own."""
    return [
        (
            "Entry: min_score",
            [Scenario(f"min_score={v:.2f}", cfg={"min_score": v}) for v in (0.30, 0.40, 0.45, 0.55, 0.70)],
        ),
        (
            "Entry: confirm_underlying / adaptive edge",
            [
                Scenario("no underlying confirm", cfg={"confirm_underlying": False}),
                Scenario("adaptive edge off", cfg={"adapt": False}),
            ],
        ),
        ("Exit: rr", [Scenario(f"rr={v:.1f}", rr=v) for v in (1.0, 1.5, 2.0, 3.0)]),
        ("Exit: k_stop", [Scenario(f"k_stop={v:.1f}", k_stop=v) for v in (0.5, 0.8, 1.2, 1.6)]),
        ("Exit: stop_pct", [Scenario(f"stop_pct={v:.2f}", stop_pct=v) for v in (0.10, 0.15, 0.20, 0.30)]),
        ("Exit: horizon_bars", [Scenario(f"horizon={v}", horizon_bars=v) for v in (6, 12, 18)]),
    ]


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Replay PPA's entry and exit rules on the candidate journal.")
    ap.add_argument("--days", type=int, default=30, help="days of journal to scan (0 = all)")
    ap.add_argument("--limit", type=int, default=50000, help="max labelled rows to load")
    ap.add_argument("--underlying", default="", help="only this underlying")
    ap.add_argument("--min-score", type=float, default=None)
    ap.add_argument("--k-stop", type=float, default=None)
    ap.add_argument("--rr", type=float, default=None)
    ap.add_argument("--stop-pct", type=float, default=None)
    ap.add_argument("--horizon", type=int, default=None, help="horizon in 5-minute bars")
    ap.add_argument("--no-underlying-confirm", action="store_true")
    ap.add_argument("--no-portfolio", action="store_true", help="ignore open/cooldown/daily-cap rules")
    ap.add_argument("--no-sweeps", action="store_true", help="baseline only")
    args = ap.parse_args(argv)

    rows = load_rows(args.limit, args.days, args.underlying)
    if not rows:
        print("No labelled PPA candidates in the journal for this window.")
        return 0

    base = live_config()
    over: dict[str, Any] = {}
    if args.min_score is not None:
        over["min_score"] = args.min_score
    if args.no_underlying_confirm:
        over["confirm_underlying"] = False
    scen = Scenario(
        "your settings",
        cfg=over or None,
        k_stop=args.k_stop,
        rr=args.rr,
        stop_pct=args.stop_pct,
        horizon_bars=args.horizon,
        portfolio=not args.no_portfolio,
    )

    print(f"PPA backtest: {len(rows)} labelled journal rows, last {args.days or 'all'} day(s)")
    print(
        f"Live config: min_score={base['min_score']:.2f} adapt={base['adapt']} "
        f"confirm_underlying={base['confirm_underlying']}"
    )
    print()
    ref = replay(rows, replace(scen, name="baseline (live config)", cfg=None, k_stop=None, rr=None,
                               stop_pct=None, horizon_bars=None), base)
    print(format_result(ref))
    if ref["skips"]:
        print("  skipped:", ", ".join(f"{k}={v}" for k, v in sorted(ref["skips"].items())))
    if scen.cfg or scen.exit_changed or not scen.portfolio:
        print(format_result(replay(rows, scen, base)))
    if args.no_sweeps:
        return 0
    for title, group in sweeps():
        print()
        print(title)
        for s in group:
            s = replace(s, portfolio=scen.portfolio)
            res = replay(rows, s, base)
            print("  " + format_result(res))
            if not res["taken"] and res["skips"]:
                why = ", ".join(f"{k}={v}" for k, v in sorted(res["skips"].items()))
                print(f"      no trades - {why}")
    print()
    print("Rows with an exit override are re-walked on Historify 1m bars; rows whose bars are")
    print("missing are counted under 'unlabelable'/'label_not_ready' and left out.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
