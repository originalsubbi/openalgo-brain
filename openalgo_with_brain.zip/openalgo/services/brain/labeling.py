"""Triple-barrier labelling and trade metrics. Pure.

A signal is labelled by what the *underlying* did afterwards: did it touch the
target distance before the stop distance within the horizon. Labelling the
underlying rather than one option premium means every signal teaches the model,
including the ones the risk gate blocked and the ones the Brain never traded,
which is where most of the learning data comes from.

Ambiguity inside one bar resolves to the stop, the adverse assumption the risk
core also makes (services/risk/position.py, note 9).

A live trade never crosses a session: the Brain flattens everything at the
square-off time. A label therefore must not look past it either, or it would
score an overnight gap the live system can never hold through. The session
helpers below cut the label window at square-off.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

IST_OFFSET = 19800  # seconds, UTC+05:30
BAR_S = 300  # the Brain works in 5-minute bars


def deseam(bars: np.ndarray) -> np.ndarray:
    """Bars with every overnight gap removed, so a return never spans a session boundary.

    The gap between one day's last close and the next day's first open is not something a
    5-minute strategy can trade or hold through (everything is flat by square-off), yet every
    engine computes returns as ``diff(log(close))`` and would read it as one enormous bar:
    inflating volatility, faking drift and distorting every oscillator. Earlier days are
    rescaled so each day opens where the previous one closed. The latest day is left exactly
    as it traded, so ``bars[-1]`` is still the real last bar; returns inside a day are
    unchanged, and the first bar of a day keeps its own open-to-close move.
    """
    n = len(bars)
    if n < 2:
        return bars
    day = ((bars[:, 0] + IST_OFFSET) // 86400).astype(np.int64)
    first = np.nonzero(np.diff(day))[0] + 1  # index of each bar that opens a new day
    if first.size == 0:
        return bars
    with np.errstate(divide="ignore", invalid="ignore"):
        gap = bars[first, 1] / bars[first - 1, 4]
    gap = np.where(np.isfinite(gap) & (gap > 0), gap, 1.0)
    # A day before boundary k is scaled by the product of every gap from k onward.
    scale_after = np.cumprod(gap[::-1])[::-1]
    factor = np.ones(n)
    prev = 0
    for k, i in enumerate(first):
        factor[prev:i] = scale_after[k]
        prev = i
    out = bars.copy()
    out[:, 1:5] *= factor[:, None]
    return out


def session_end_ts(bar_ts: float, squareoff_min: int) -> float:
    """Epoch seconds of the square-off instant on the IST day that ``bar_ts`` falls in."""
    local = float(bar_ts) + IST_OFFSET
    day0 = local - (local % 86400.0)
    return day0 + squareoff_min * 60.0 - IST_OFFSET


def session_horizon(bar_ts: float, horizon: int, squareoff_min: int) -> int:
    """Whole 5-minute bars a position opened at the close of bar ``bar_ts`` may live.

    That is ``horizon`` or the bars left before square-off, whichever is smaller. Zero
    means the entry would already be at or past square-off.
    """
    left = int((session_end_ts(bar_ts, squareoff_min) - (float(bar_ts) + BAR_S)) // BAR_S)
    return max(0, min(int(horizon), left))


def in_entry_window(bar_ts: float, entry_start_min: int, entry_cutoff_min: int) -> bool:
    """Could the live Brain have opened a position on the decision made at this bar's close?

    The decision happens when the bar closes, ``BAR_S`` after its open timestamp, and the
    gate's rule is ``entry_start <= minute < entry_cutoff`` on that wall-clock minute.
    """
    local = float(bar_ts) + BAR_S + IST_OFFSET
    minute = int((local % 86400.0) // 60)
    return entry_start_min <= minute < entry_cutoff_min


def session_future(
    bars: np.ndarray, bar_ts: float, horizon: int, squareoff_min: int
) -> tuple[np.ndarray, int]:
    """The bars after ``bar_ts`` that a position could have lived through, and the horizon to use.

    Bars that open after the same-day square-off, or on a later day, are dropped. The
    returned horizon is cut to what the session allows, so ``label_triple_barrier`` will
    treat "all of the in-session bars have arrived" as decidable and "some are missing"
    as still pending.
    """
    h_eff = session_horizon(bar_ts, horizon, squareoff_min)
    if h_eff <= 0 or len(bars) == 0:
        return bars[:0], h_eff
    last_open = session_end_ts(bar_ts, squareoff_min) - BAR_S
    fut = bars[(bars[:, 0] > bar_ts) & (bars[:, 0] <= last_open)]
    return fut[:h_eff], h_eff


@dataclass(frozen=True, slots=True)
class Label:
    outcome: int  # +1 target first, -1 stop first, 0 timeout
    r: float  # result in R (risk units), before costs
    bars: int  # bars until exit


def label_triple_barrier(
    entry: float,
    sign: int,
    sigma_h: float,
    k_stop: float,
    k_target: float,
    highs: np.ndarray,
    lows: np.ndarray,
    closes: np.ndarray,
    horizon: int,
) -> Label | None:
    """None when the future is not yet long enough to decide (still pending)."""
    n = min(len(highs), horizon)
    if n == 0 or entry <= 0 or sigma_h <= 0:
        return None
    # Both prices are already sign-aware: for a SHORT the target sits below the
    # entry and the stop above it. Swapping them per side labels every short
    # backwards, which is what an earlier draft did.
    target = entry * math.exp(sign * k_target * sigma_h)
    stop = entry * math.exp(-sign * k_stop * sigma_h)
    rr = k_target / k_stop
    for i in range(n):
        hit_stop = lows[i] <= stop if sign > 0 else highs[i] >= stop
        hit_tgt = highs[i] >= target if sign > 0 else lows[i] <= target
        if hit_stop:  # checked first: adverse ordering
            return Label(-1, -1.0, i + 1)
        if hit_tgt:
            return Label(1, rr, i + 1)
    if len(highs) < horizon:
        return None
    move = sign * math.log(closes[n - 1] / entry)
    return Label(0, float(max(-1.0, min(rr, move / (k_stop * sigma_h)))), n)


def label_premium_barrier(
    entry: float,
    stop: float,
    target: float,
    highs: np.ndarray,
    lows: np.ndarray,
    closes: np.ndarray,
    horizon: int,
) -> Label | None:
    """Triple barrier on an option leg's own premium path, with absolute levels.

    This is what lets the Brain learn moneyness: an ITM, an ATM and an OTM leg
    of the same underlying signal get different premium paths (and different
    theta drag), so labelling each leg's own barrier is the learning signal that
    says which moneyness actually pays. ``label_triple_barrier`` above labels
    the *underlying*; this one labels the leg.

    None when the future is not yet long enough to decide (still pending).
    """
    n = min(len(highs), horizon)
    if n == 0 or entry <= 0 or stop <= 0 or target <= 0:
        return None
    rr = (target - entry) / (entry - stop) if entry > stop else 0.0
    for i in range(n):
        if lows[i] <= stop:  # checked first: adverse ordering
            return Label(-1, -1.0, i + 1)
        if highs[i] >= target:
            return Label(1, rr, i + 1)
    if len(highs) < horizon:
        return None
    move = closes[n - 1] - entry
    r = move / (entry - stop) if entry > stop else 0.0
    return Label(0, float(max(-1.0, min(rr, r))), n)


@dataclass(frozen=True, slots=True)
class Metrics:
    n: int = 0
    win_rate: float = 0.0
    expectancy_r: float = 0.0
    stderr_r: float = 0.0
    lcb_r: float = 0.0  # expectancy minus one standard error: the number promotion uses
    profit_factor: float = 0.0
    max_dd_r: float = 0.0
    total_r: float = 0.0

    def as_dict(self) -> dict[str, float]:
        return {k: round(float(getattr(self, k)), 4) for k in self.__slots__}


def metrics(r_net: list[float]) -> Metrics:
    """Summary of a sequence of trade results in R, oldest first."""
    n = len(r_net)
    if n == 0:
        return Metrics()
    a = np.asarray(r_net, dtype=float)
    wins, losses = a[a > 0].sum(), -a[a < 0].sum()
    pf = float(wins / losses) if losses > 1e-12 else (9.99 if wins > 0 else 0.0)
    curve = np.cumsum(a)
    dd = float((np.maximum.accumulate(np.concatenate([[0.0], curve]))[1:] - curve).max())
    se = float(a.std(ddof=1) / math.sqrt(n)) if n > 1 else 1.0
    # Lag-1 autocorrelation inflates the naive standard error: consecutive
    # trades whose label windows overlap share most of their evidence and are
    # not independent samples. Inflate by sqrt(max(1 + 2*rho, 1)) so the lower
    # confidence bound stays honest (negative rho never shrinks it).
    if n > 2 and se > 0:
        with np.errstate(invalid="ignore"):
            rho = float(np.corrcoef(a[:-1], a[1:])[0, 1])
        if not math.isnan(rho):
            se *= math.sqrt(max(1.0 + 2.0 * rho, 1.0))
    return Metrics(
        n=n,
        win_rate=float((a > 0).mean()),
        expectancy_r=float(a.mean()),
        stderr_r=se,
        lcb_r=float(a.mean() - se),
        profit_factor=min(pf, 9.99),
        max_dd_r=dd,
        total_r=float(curve[-1]),
    )
