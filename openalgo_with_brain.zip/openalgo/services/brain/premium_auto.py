"""Adaptive cheap-premium cap: an effective cap that lives below a human ceiling.

The human owns the ceiling (``BRAIN_MAX_PREMIUM`` / the slider). Inside that
boundary the Brain adapts the *effective* cap to what actually pays:

closed trades are grouped into rupee bands and the bands are walked from the
cheapest upward. The cap extends band by band while each band's own expectancy
is non-negative, and stops at the first band that loses. Profitable cheap
trades keep the cap low (the cheap-premium preference); profitable dearer
trades extend it toward the ceiling (trading need); a losing band shrinks the
cap to just below itself (profit protection). A band nobody has traded passes
through: no evidence either way, so the cap is not cut by silence.

The risk gate stays pure: this module only proposes a number. The orchestrator
applies it to the running limits and both engines (main Brain and PPA) pick it
up on their very next entry, since they read ``brain.limits`` at gate time.
"""

from __future__ import annotations

import math
from typing import Any

MIN_TRADES = 12  # closed trades inside the cap before the ladder may cut it
BAND = 50.0  # rupee width of one expectancy band
STEP = 5  # caps snap to this rupee grid (matches the UI slider step)
FLOOR = 50.0  # absolute lowest the cap may fall: keeps cheap learning alive
MIN_BAND_N = 2  # a band needs this many trades before it may cut the cap


def compute(
    closed: list[dict[str, Any]],
    ceiling: float,
    min_premium: float,
    explore: bool = False,
) -> tuple[float, str, dict[str, Any]]:
    """Return ``(effective_cap, reason, stats)`` from recent closed trades.

    ``closed`` holds closed-position dicts as ``brain_db.positions_closed``
    returns them (``entry_price``, ``r_multiple``, ``risk_per_unit``, ``qty``,
    ``pnl``). Trades taken above the ceiling (under an earlier, looser cap)
    do not vote: the ceiling is the regime the human chose, and their outcomes
    must not colour the bands the cap actually governs.

    With ``explore=True`` the first losing band is re-opened instead of cut
    (explore/exploit): the exploit cap would starve a losing band of fresh
    outcomes forever, so the caller opens it on a schedule and the next
    recompute after those trades close re-decides with current evidence.
    """
    ceiling = float(ceiling)
    if ceiling <= 0:
        return 0.0, "cap is Off (0) - nothing to adapt", {}

    floor = max(float(min_premium or 0.0), FLOOR)
    trades: list[tuple[float, float]] = []
    for row in closed:
        price = float(row.get("entry_price") or 0)
        if price <= 0 or price > ceiling:
            continue
        rm = row.get("r_multiple")
        if rm is None:
            risk_total = float(row.get("risk_per_unit") or 0) * int(row.get("qty") or 0)
            rm = (float(row.get("pnl") or 0) / risk_total) if risk_total > 0 else None
        if rm is None:
            continue
        trades.append((price, float(rm)))

    if len(trades) < MIN_TRADES:
        return (
            ceiling,
            f"only {len(trades)} closed trades inside the cap - ceiling kept while learning",
            {"n": len(trades)},
        )

    # Band the trades and walk from the cheapest upward.
    band_n = int(ceiling // BAND) + 1
    bands: list[dict[str, Any]] = [
        {"lo": i * BAND, "hi": (i + 1) * BAND, "n": 0, "sum_r": 0.0} for i in range(band_n)
    ]
    for price, rm in trades:
        b = bands[min(int(price // BAND), band_n - 1)]
        b["n"] += 1
        b["sum_r"] += rm
    for b in bands:
        b["mean_r"] = b["sum_r"] / b["n"] if b["n"] else None

    last_paid: dict[str, Any] | None = None
    failed: dict[str, Any] | None = None
    for b in bands:
        if b["n"] == 0:
            continue  # silence passes through: no evidence, no cut
        if b["n"] >= MIN_BAND_N and b["mean_r"] < 0.0:
            failed = b
            break
        last_paid = b

    stats = {
        "n": len(trades),
        "bands": [
            {
                "lo": b["lo"],
                "hi": b["hi"],
                "n": b["n"],
                "mean_r": round(b["mean_r"], 4) if b["mean_r"] is not None else None,
            }
            for b in bands
            if b["n"]
        ],
        "failing_band": [failed["lo"], failed["hi"]] if failed else None,
    }

    if failed is None:
        return ceiling, (
            f"every band with trades pays - cap at the ceiling "
            f"({len(trades)} trades, mean {sum(r for _, r in trades) / len(trades):+.2f}R)"
        ), stats

    if explore:
        # Probe: re-open just the first losing band so it can earn fresh
        # outcomes; bands above it stay closed.
        probe_eff = min(ceiling, failed["hi"])
        return probe_eff, (
            f"probe: re-opened {failed['lo']:g}-{failed['hi']:g} (was losing "
            f"{failed['mean_r']:+.2f}R) to gather fresh evidence"
        ), {**stats, "explore": True}

    if last_paid is None:
        # The cheapest traded band itself loses: nothing inside the cap pays.
        return min(ceiling, floor), (
            f"the cheapest band ({failed['lo']:g}-{failed['hi']:g}) averages "
            f"{failed['mean_r']:+.2f}R - no premium band pays, cap cut to the floor"
        ), stats

    eff = math.floor((failed["lo"] - 1e-9) / STEP) * STEP
    eff = min(ceiling, max(floor, eff))
    return eff, (
        f"trades in {failed['lo']:g}-{failed['hi']:g} average {failed['mean_r']:+.2f}R "
        f"over {failed['n']} trades - cap cut to {eff:g}, below the losing band"
    ), stats
