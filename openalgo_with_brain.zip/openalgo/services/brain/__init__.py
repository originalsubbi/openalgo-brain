"""AI Brain: a self-learning decision layer on top of OpenAlgo.

Pipeline (each layer only talks to the one below it)::

    AI Brain (orchestrator.py)            central coordinator, scan loop, EOD learning
      Engines (engines/)                  math, signal, statistical, options, market, ML
      Decision Fusion (fusion.py)         regime, probability, expected value, candidates
      Independent Risk Gate (risk_gate.py) fixed rules, human-owned limits, kill switch
      Execution (executor.py)             OpenAlgo orders, protective exits, reconciliation
      Learning & Evaluation (learner.py)  journal, labelling, backtest, challenger, rollback

Two rules shape everything here.

**Human-owned limits never move.** ``config.RiskLimits`` is read from the
environment, frozen, and imported by the risk gate only. The learner can tune
``config.TunableParams`` inside hard bounds. It has no code path to a limit.

**No I/O below the orchestrator, except the executor and the journal.** The
engines, fusion, risk gate, labeller and backtester are pure functions of their
arguments, so the same code runs live, in the backtester and in tests.

Position rules (stop, target, trailing, combined loss) are evaluated by
``services.risk`` and are never reimplemented in this package.
"""
