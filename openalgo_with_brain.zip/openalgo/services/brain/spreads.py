"""Credit-spread geometry: picking the legs and the payoff shape.

Selling premium is only a trade when the loss is bounded. A naked short option
is not: its loss is unbounded and its margin is large. So the Brain sells a
**credit spread** — one option is sold, a further out-of-the-money option of
the same type is bought with the proceeds, and the loss is capped at the
strike width.

The payoff is measured on the *spread*, not on the sold leg:

    entry  = the credit received
    stop   = the strike width (the spread is worthless beyond it)
    target = half the credit (the spread has decayed to half its entry value)
    risk   = width - credit

Because the spread's value is the sold leg's premium minus the hedge leg's
premium, the position's "price" has to be the spread's value. The risk core
then reads a short position whose price falls when the trade wins, which is
exactly its own short-side arithmetic.

Pure: no I/O, no broker.
"""

from __future__ import annotations

from typing import Any

from services.brain.config import TunableParams

EPS = 1e-12


def _num(row: dict[str, Any], key: str) -> float:
    v = row.get(key)
    try:
        f = float(v)
    except (TypeError, ValueError):
        return 0.0
    return f if f == f else 0.0  # NaN guard


def _leg_of(row: dict[str, Any], kind: str) -> dict[str, Any] | None:
    """Normalise one side of a chain row into a leg; skip rows with no usable strike."""
    try:
        strike_f = float(row.get("strike") or 0)
    except (TypeError, ValueError):
        return None
    if strike_f <= 0 or strike_f != strike_f:  # catch both zero/negative and NaN
        return None
    return {
        "symbol": row.get(f"{kind}_symbol"),
        "option_type": kind.upper(),
        "strike": strike_f,
        "ltp": _num(row, f"{kind}_ltp"),
        "bid": _num(row, f"{kind}_bid"),
        "ask": _num(row, f"{kind}_ask"),
        "delta": abs(_num(row, f"{kind}_delta")),
        "oi": _num(row, f"{kind}_oi"),
        "iv": _num(row, f"{kind}_iv"),
    }


def _spread_pct(bid: float, ask: float, ltp: float) -> float:
    if bid > 0 and ask > 0:
        mid = (bid + ask) / 2.0
        return (ask - bid) / mid * 100.0 if mid > 0 else 99.0
    return 99.0


def select_spread(
    chain: dict[str, Any] | None,
    side: str,
    spot: float,
    params: TunableParams,
    min_oi: int = 0,
) -> dict[str, Any] | None:
    """Pick the sold leg and the protective leg for a credit spread.

    ``side`` is the direction the *underlying* is expected to move: "LONG"
    (bullish) sells a put spread, "SHORT" (bearish) sells a call spread. The
    sold leg targets ``os_sell_delta`` and the protective leg
    ``os_hedge_delta``; both must be out of the money and have a usable
    two-sided quote.

    Returns None when no spread qualifies — which is the normal answer on a
    chain whose OTM wing is thin or far away.
    """
    if not chain or not chain.get("rows"):
        return None
    rows = chain.get("rows") or []
    kind = "pe" if side == "LONG" else "ce"

    sell_target = params.os_sell_delta
    hedge_target = params.os_hedge_delta

    legs: list[dict[str, Any]] = []
    for r in rows:
        leg = _leg_of(r, kind)
        if leg is None:
            continue  # NaN or non-positive strike
        if not leg["symbol"] or leg["ltp"] <= 0:
            continue
        if kind == "pe" and leg["strike"] >= spot:
            continue  # a put spread sells strikes below the index
        if kind == "ce" and leg["strike"] <= spot:
            continue  # a call spread sells strikes above the index
        if leg["delta"] <= 0:
            continue
        if min_oi and leg["oi"] < min_oi:
            continue  # a strike nobody is trading is not a strike to sell
        legs.append(leg)
    if len(legs) < 2:
        return None

    # Sold leg: closest to the target delta, with a tighter spread preferred.
    def leg_score(leg: dict[str, Any], target: float) -> tuple[float, float, float]:
        spread_pct = _spread_pct(leg["bid"], leg["ask"], leg["ltp"])
        return (-abs(leg["delta"] - target) * 10.0 - spread_pct, spread_pct, leg["delta"])

    sell = max(legs, key=lambda l: leg_score(l, sell_target))
    # Hedge leg: further out of the money than the sold leg, target delta.
    further = [
        l
        for l in legs
        if (
            (kind == "pe" and l["strike"] < sell["strike"])
            or (kind == "ce" and l["strike"] > sell["strike"])
        )
    ]
    if not further:
        return None
    hedge = max(further, key=lambda l: leg_score(l, hedge_target))

    sell_bid = sell["bid"]
    hedge_ask = hedge["ask"]
    # Reject legs without two-sided quotes: falling back to LTP would price a
    # thin leg at the last print and overstate the credit (optimistic EV).
    if sell_bid <= 0 or hedge_ask <= 0:
        return None
    credit = sell_bid - hedge_ask
    width = abs(sell["strike"] - hedge["strike"])
    if credit <= 0 or width <= 0:
        return None

    min_credit = max(
        params.os_min_credit_points,
        params.os_min_credit_pct * max(sell["ltp"], 0.0),
    )
    if credit < min_credit:
        return None

    max_loss = width - credit
    if max_loss <= 0:
        return None

    # Target: take half the credit back. In units of the risk (width - credit).
    target_value = credit * 0.5
    rr = target_value / max_loss

    lot_size = int(chain.get("lot_size") or 1)
    return {
        "side": side,
        "kind": kind,
        "sell": sell,
        "hedge": hedge,
        "credit": float(credit),
        "width": float(width),
        "max_loss": float(max_loss),
        "target_value": float(target_value),
        "rr": float(rr),
        "lot_size": lot_size,
        "sell_spread_pct": _spread_pct(sell["bid"], sell["ask"], sell["ltp"]),
        "hedge_spread_pct": _spread_pct(hedge["bid"], hedge["ask"], hedge["ltp"]),
        "net_delta": float(sell["delta"] - hedge["delta"]),
    }


def spread_value(sell_ltp: float | None, hedge_ltp: float | None) -> float | None:
    """The current value of the spread: sold leg minus hedge leg.

    The position's price is this number. A short position whose price falls
    when the trade wins is what the risk core's short-side arithmetic expects.
    """
    if sell_ltp is None or hedge_ltp is None:
        return None
    try:
        v = float(sell_ltp) - float(hedge_ltp)
    except (TypeError, ValueError):
        return None
    # The value must be positive to describe a live spread. A zero or negative
    # result means one leg has collapsed and the spread contract is no longer
    # tradeable — returning None tells the caller "no usable value" instead of
    # lying with 0.0.
    return v if v > 0 else None


__all__ = ["select_spread", "spread_value"]
