"""Learning & Evaluation: label, retrain, tune, compare, promote, roll back.

The loop, once a day after the close (or on demand):

1. **Label** every signal whose horizon has elapsed, traded or not, from the
   bars that followed (triple barrier on the underlying).
2. **Retrain** a *challenger* model on the recent labelled window, calibrated on
   its newest quarter.
3. **Tune** the decision thresholds on stored signals, inside hard bounds, one
   bounded step at a time, scored by the lower confidence bound of expectancy.
4. **Compare** challenger and champion on the same untouched newest slice.
   Promotion needs a better lower bound, enough trades and no worse drawdown.
5. **Watch** the champion's realised record and feature drift; roll back to the
   last known good version if it degrades.

Nothing here touches ``RiskLimits``. The learner moves ``TunableParams`` inside
``PARAM_BOUNDS`` and swaps model versions, and that is all it can do.
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import threading
import time
from collections.abc import Callable
from dataclasses import replace
from typing import Any

import numpy as np

from database import brain_db as db
from services.brain import fusion, knobs
from services.brain.backtest import SignalRow, train_model
from services.brain.config import (
    ENGINE_NAMES,
    INT_PARAMS,
    PARAM_BOUNDS,
    RiskLimits,
    TunableParams,
)
from services.brain.engines.ml import OnlineLogit, effective_sample_size, model_names, psi
from services.brain.labeling import (
    BAR_S,
    Metrics,
    in_entry_window,
    label_premium_barrier,
    label_triple_barrier,
    metrics,
    session_future,
)
from services.brain.risk_gate import live_eligible
from utils.logging import get_logger

logger = get_logger(__name__)

MIN_TRAIN = 200  # labelled signals before a challenger is even trained
OPTIONS_MIN_LABELLED = 200  # labelled signals that saw a live chain before options may vote
MIN_LABELLED_TOTAL = 334  # MIN_TRAIN / 0.6: the fit slice must still hold MIN_TRAIN after purging
FIT_FRAC, VAL_FRAC = 0.6, 0.2  # chronological: fit | validate (select) | confirm (touched once)
MIN_CONFIRM_TRADES = 5
MIN_ENGINE_VOTES = 60  # labelled votes an engine needs before its weight is nudged
_OPT_CACHE: dict[str, float] = {"ts": 0.0, "n": 0.0}
_OPT_CACHE_LOCK = threading.Lock()
OPT_CACHE_TTL = 600.0
MIN_TRADES_TO_JUDGE = 20
PROMOTE_MARGIN_R = 0.005
PROMOTE_SIGMAS = 2.0  # promotion needs a 2-sigma lower bound: one sigma promotes noise too often
# Reuse of the holdout across many searches is itself a leak: a challenger can
# be lucky on it once. The newest signals are embargoed out of the ENTIRE
# search and act as an extra, never-before-touched gate on promotion.
HOLDOUT_EMBARGO_DAYS = 7
# Skill test: does the model's probability beat the incumbent's on log-loss? Unlike the trade-based
# test it uses every holdout row, not just the ~20 that clear the thresholds, so it has the
# power to say yes when there is something to find. Three sigmas because it runs every night.
SKILL_SIGMAS = 3.0
SKILL_MIN_EFF = 40.0  # effective (non-overlapping) holdout rows needed to judge skill
ROLLBACK_MIN_TRADES = 20
ROLLBACK_LCB_R = -0.15
DRIFT_LIMIT = 0.5  # PSI on autocorrelated market data is noisy; only a large, broad shift counts
DRIFT_MIN_FEATURES = 2
RECENT_N = 300
TRAIN_WINDOW = 6000
KEY_DRIFT_FEATURES = [
    "market.adx",
    "stat.vol_ratio",
    "signal.perm_entropy",
    "market.atr_pct",
    "fused",
]

LIVE_MIN_MODEL_NEFF = 60.0  # effective samples a champion needs before it may unlock real money
# (60 is the point where model and prior carry equal weight, fusion.CREDIBILITY_K)

BarsFetcher = Callable[[str, float], "np.ndarray | None"]  # (underlying, since_ts) -> bars array


def session_rules() -> tuple[tuple[int, int], int]:
    """((entry_start, entry_cutoff), squareoff) in IST minutes, read from the human-owned limits.

    Read only: the learner uses them to decide which signals the live gate could ever have let
    through and where a label's window must stop. It cannot change them.
    """
    lim = RiskLimits.from_env()
    return (lim.entry_start_min, lim.entry_cutoff_min), lim.squareoff_min


def takeable(sigs: list[dict[str, Any]], window: tuple[int, int]) -> list[dict[str, Any]]:
    """Signals made at a time the live Brain was allowed to open a position."""
    return [s for s in sigs if in_entry_window(float(s["bar_ts"]), *window)]


def load_champion() -> tuple[TunableParams, OnlineLogit | None, int]:
    row = db.model_by_role("champion")
    if not row:
        return TunableParams(), None, 0
    params = TunableParams.from_dict(row["params"])
    m = row["model"] or {}
    model = OnlineLogit.from_dict(m, model_names(fusion.FEATURE_NAMES)) if m.get("names") else None
    return params, model, int(row["id"])


# --- tuner working state ----------------------------------------------------
# Where the parameter search has got to. This is research state, not the live
# config: the champion alone decides what trades (see load_champion), and the
# promotion gate decides what may become the champion. The tuner state only
# says where the next search starts from.
#
# It lives in brain_state so it survives a restart. Without it the search
# started from the defaults on every cycle, which turned a bounded hill-climb
# (tune_weights multiplies the weights it is given; tune_thresholds moves one
# bounded step) into a one-step random walk around a fixed origin, re-evaluated
# dozens of times a day. On a database with no champion the origin was always
# the defaults, so the walk never went anywhere.
_TUNER_STATE_KEY = "tuner_state"


def load_tuner_state() -> tuple[TunableParams | None, str | None, int | None]:
    """The tuner's working position, the fit-slice fingerprint behind it, and
    the champion it was derived against.

    Returns ``(None, None, None)`` when there is no usable state, which is the
    correct first-run answer: the search then starts from the champion.
    """
    raw = db.state_get(_TUNER_STATE_KEY) or {}
    if not isinstance(raw, dict):
        return None, None, None
    params = raw.get("params")
    if not isinstance(params, dict) or not params:
        return None, None, None
    fp = raw.get("fingerprint")
    champ = raw.get("champion_id")
    # from_dict clamps into PARAM_BOUNDS, so a hand-edited or stale state can
    # never come back outside the bounds the learner is allowed to move in.
    return (
        TunableParams.from_dict(params),
        (str(fp) if fp else None),
        (int(champ) if champ is not None else None),
    )


def save_tuner_state(params: TunableParams, fingerprint: str, champion_id: int) -> None:
    """Persist where the search has got to, so a restart does not lose it."""
    db.state_set(
        _TUNER_STATE_KEY,
        {
            "params": params.to_dict(),
            "fingerprint": fingerprint,
            "champion_id": int(champion_id),
            "updated": time.time(),
        },
    )


def _fit_fingerprint(rows: list[dict[str, Any]]) -> str:
    """A cheap signature of the fit slice.

    Two searches over the same fit slice train the same model, so the second
    one is pure waste. The signature moves as soon as a label lands or the
    window slides, so a slice that changed is never mistaken for one that did
    not. (42 challengers were trained over 28 hours and the last six carried
    byte-identical metrics.)
    """
    if not rows:
        return ""
    h = hashlib.blake2b(digest_size=8)
    h.update(str(len(rows)).encode())
    h.update(str(int(rows[-1]["bar_ts"])).encode())
    h.update(str(sum(int(r.get("label_outcome") or 0) for r in rows)).encode())
    h.update(str(round(sum(float(r.get("label_r") or 0.0) for r in rows), 4)).encode())
    return h.hexdigest()


def options_ready(force: bool = False) -> tuple[bool, int]:
    """May the options engine vote?

    Only once the training population can actually teach the features the
    engine votes with. A replayed row has no option chain, so all fifteen
    ``options.*`` features are zero on every replay row; while the replay
    carries the training set the model learns to ignore those features, and
    the engine would then vote with real values the model has never seen - a
    train/serve skew. So the engine waits until the live rows lead the
    training set, the same switch ``training_population`` uses.

    It is observed and journalled either way, so the learner can judge it once
    there is something to judge it with.
    """
    now = time.time()
    with _OPT_CACHE_LOCK:
        if force or now - _OPT_CACHE["ts"] > OPT_CACHE_TTL:
            _OPT_CACHE["n"] = float(db.signals_labeled_with_chain())
            _OPT_CACHE["ts"] = now
        n = int(_OPT_CACHE["n"])
    live = float(db.signals_labeled_live_count())
    return (live >= LIVE_TRAIN_MIN_ROWS and n >= OPTIONS_MIN_LABELLED), n


# --- 1. label ---------------------------------------------------------------
def label_pending(fetch: BarsFetcher, now: float | None = None, api_key: str = "") -> int:
    now = now or time.time()
    done = 0
    cache: dict[str, np.ndarray | None] = {}
    _, squareoff = session_rules()
    for sig in db.signals_unlabeled(before_ts=now - 300):
        h = int(sig["horizon_bars"])
        if sig["bar_ts"] + (h + 1) * 300 > now:
            continue  # horizon not fully elapsed
        u = sig["underlying"]
        if u not in cache:
            cache[u] = fetch(u, sig["bar_ts"] - 3600)
        bars = cache[u]
        if bars is None or not len(bars):
            continue
        # A position is flattened at square-off, so its label may not look past it.
        fut, h_eff = session_future(bars, float(sig["bar_ts"]), h, squareoff)
        if h_eff <= 0:
            # Made at or after square-off: the live Brain can never take it. Close it out with a
            # neutral label so it does not sit unlabelled forever; the entry-window filter keeps
            # it out of training and scoring.
            db.signal_update(
                int(sig["id"]), label_outcome=0, label_r=0.0, label_bars=0, labeled_at=now
            )
            done += 1
            continue
        sign = 1 if sig["side"] == "LONG" else -1
        lab = label_triple_barrier(
            float(sig["entry_spot"]),
            sign,
            float(sig["sigma_h"]),
            float(sig["k_stop"]),
            float(sig["k_target"]),
            fut[:, 2],
            fut[:, 3],
            fut[:, 4],
            h_eff,
        )
        if lab is None:
            continue
        db.signal_update(
            int(sig["id"]),
            label_outcome=lab.outcome,
            label_r=lab.r,
            label_bars=lab.bars,
            labeled_at=now,
        )
        done += 1
    done += label_legs_pending(now - 300, squareoff, api_key)
    return done


def label_legs_pending(before_ts: float, squareoff: int, api_key: str = "") -> int:
    """Label band signals by their own option leg's premium path.

    This is the moneyness learning signal: the ITM, ATM and OTM rows of one
    decision share the underlying label, but each leg's premium walked its own
    path (different delta, different theta), so labelling each leg's barrier is
    what tells the band picker which moneyness actually pays.
    """
    from services.brain import premium_pa
    from services.brain.premium_pa import aggregate_5m

    done = 0
    now = before_ts + 300  # the caller's `now`
    max_age = getattr(db, "MAX_LEG_LABEL_AGE_S", 5 * 24 * 3600)
    for sig in db.signals_leg_unlabeled(before_ts=before_ts):
        # Abandon legs whose contract has expired or whose premium path can no
        # longer be observed: mark them terminal so they are never scanned
        # again and cannot clog the unlabeled-leg window forever.
        if now - float(sig["bar_ts"]) > max_age:
            db.signal_update(
                int(sig["id"]),
                leg_label_outcome=-2,
                leg_label_r=0.0,
                leg_label_bars=0,
            )
            done += 1
            continue
        h = int(sig["horizon_bars"])
        if sig["bar_ts"] + (h + 1) * 300 > now:
            continue  # horizon not fully elapsed
        bars_1m = premium_pa.premium_bars(sig["symbol"], api_key)
        if bars_1m is None or len(bars_1m) < 5:
            continue  # bars not warm yet; retried on a later cycle
        p5 = aggregate_5m(bars_1m)
        fut, h_eff = session_future(p5, float(sig["bar_ts"]), h, squareoff)
        if h_eff <= 0:
            db.signal_update(int(sig["id"]), leg_label_outcome=0, leg_label_r=0.0, leg_label_bars=0)
            done += 1
            continue
        lab = label_premium_barrier(
            float(sig["leg_entry"]),
            float(sig["leg_stop"]),
            float(sig["leg_target"]),
            fut[:, 2],
            fut[:, 3],
            fut[:, 4],
            h_eff,
        )
        if lab is None:
            continue
        db.signal_update(
            int(sig["id"]),
            leg_label_outcome=lab.outcome,
            leg_label_r=lab.r,
            leg_label_bars=lab.bars,
        )
        done += 1
    return done


# --- scoring stored signals ----------------------------------------------------
def _rows(sigs: list[dict[str, Any]]) -> list[SignalRow]:
    return [
        SignalRow(
            i,
            _FakeCand(s),
            None,
            1.0 if s["label_outcome"] == 1 else 0.0,
            float(s["label_r"]) - fusion.COST_R,
            key=int(float(s["bar_ts"]) // BAR_S),
            span=int(s.get("label_bars") or s.get("horizon_bars") or 12),
        )
        for i, s in enumerate(sigs)
    ]


class _FakeCand:
    """Adapter so a stored signal can stand where a Candidate is expected."""

    def __init__(self, s: dict[str, Any]) -> None:
        self.features = s["features"]
        self.score, self.agree, self.prob_prior = (
            float(s["score"]),
            int(s["agree"]),
            float(s["prob_prior"]),
        )
        self.rr = float(s["rr"])
        self.ev_r, self.prob = float(s["ev_r"]), float(s["prob"])


def _trade_r(s: dict[str, Any]) -> float:
    """The R-multiple this stored trade would have earned under its own basis.

    Long rows are labelled on the underlying's triple barrier, which pays
    ``k_target / k_stop`` (the stored ``rr``) on a target and −1R on a stop —
    the stored ``label_r`` already is that R. A short row (a credit spread) is
    labelled on the same underlying barrier, but its own payoff is bounded: a
    win earns the spread's reward-to-risk (the stored ``rr``, ~0.1–0.3), a stop
    loses the full risk (−1R), and a timeout is conservatively worth nothing
    before costs (fusion prices them the same way, ``mean_r_timeout = 0``).
    Scoring a short at the underlying payoff credited ~+2R for a trade worth
    ~+0.17R and skewed threshold tuning toward credit spreads.
    """
    if str(s.get("position_type") or "long").lower() != "short":
        return float(s["label_r"])
    rr = float(s.get("rr") or 0.0)
    outcome = s.get("label_outcome")
    if outcome == 1:
        return rr
    if outcome == -1:
        return -1.0
    return 0.0


def purge(rows: list[dict[str, Any]], cutoff_ts: float) -> list[dict[str, Any]]:
    """Drop rows whose label window reaches into the later set (no leakage across the split)."""
    out = []
    for s in rows:
        bars = int(s.get("label_bars") or s.get("horizon_bars") or 12)
        if float(s["bar_ts"]) + (bars + 1) * 300.0 <= cutoff_ts:
            out.append(s)
    return out


def _score_agree(s: dict[str, Any], params: TunableParams, use_options: bool) -> tuple[float, int]:
    """Side score and agreement under ``params``; stored values for legacy rows."""
    f, votes = s.get("features") or {}, s.get("votes") or {}
    confs = {e: f.get(f"conf.{e}") for e in ENGINE_NAMES}
    if votes and all(v is not None for v in confs.values()):
        return fusion.rescore(votes, confs, s["regime"], s["side"], params, use_options)
    return float(s["score"]), int(s["agree"])


def score_on_signals(
    sigs: list[dict[str, Any]],
    params: TunableParams,
    model: OnlineLogit | None,
    use_options: bool = True,
) -> Metrics:
    """What the chosen thresholds and model would have earned on labelled history.

    Uses the stored features and prior, so no engine is re-run. The geometry
    (k_stop, k_target, horizon) is fixed by how each signal was labelled, which
    is why live tuning is restricted to thresholds.
    """
    taken: list[float] = []
    busy: dict[str, float] = {}
    for s in sorted(sigs, key=lambda r: r["bar_ts"]):
        if s["label_outcome"] is None:
            continue
        score, agree = _score_agree(s, params, use_options)
        if score < params.min_confluence or agree < params.min_agree:
            continue
        p_prior = float(s["prob_prior"])
        p, z = p_prior, 0.0
        if model is not None and model.credibility_n > 0:
            z = fusion.model_weight(model)
            p = z * model.predict(s["features"]) + (1 - z) * p_prior
        rr = float(s["rr"])
        # Fusion split the non-win mass between stops (-1R) and timeouts (~0R). Recover that
        # split from what was stored at decision time so evaluation matches live decisions.
        pr = float(s["prob"])
        stop_share = (pr * rr - fusion.COST_R - float(s["ev_r"])) / max(1.0 - pr, 1e-6)
        stop_share = min(max(stop_share, 0.0), 1.0)
        ev = p * rr - (1 - p) * stop_share - fusion.COST_R
        # NaN-safe: NaN comparisons always return False, so a NaN expectancy would
        # silently pass the filter and contaminate champion scoring. Reject it.
        if p < params.min_prob or ev < params.min_ev_r or p != p or ev != ev:
            continue
        if busy.get(s["underlying"], 0) > s["bar_ts"]:
            continue  # one position at a time per underlying
        busy[s["underlying"]] = s["bar_ts"] + float(s["label_bars"] or 1) * 300
        taken.append(_trade_r(s) - fusion.COST_R)
    return metrics(taken)


# --- 3. tuning --------------------------------------------------------------
# How far one trial moves a parameter. Float entries are fractions of that
# parameter's own range, because the ranges differ by two orders of magnitude and
# one absolute number cannot be right for both. Whole-number parameters are in
# units: a fraction of a three-engine range rounds back to the value it started
# from, so ``min_agree`` could never move at all.
_GRID = {
    "min_prob": [-0.04, 0.0, 0.04],
    "min_ev_r": [-0.05, 0.0, 0.05],
    "min_confluence": [-0.06, 0.0, 0.06],
    "min_agree": [-1, 0, 1],
}
MAX_STEP_FRACTION = 0.2  # no threshold moves more than 20% of its range per cycle
BOOT_STEP_FRACTION = 0.5  # the first cycle after a bootstrap may move further, once


def _c(name: str) -> float:
    """Runtime value of a learner tune-knob.

    The Brain page / POST /brain/api/tune-knobs writes ``knobs.CURRENT_TUNE_KNOBS``;
    the module constants above are the shipped defaults. A knob a human (or test)
    left at its default falls through to the module constant, so patching the
    constant still works; a knob that was moved wins.
    """
    const = globals()[name.upper()]
    cur = getattr(knobs.CURRENT_TUNE_KNOBS, name)
    if cur == getattr(knobs.DEFAULT_TUNE_KNOBS, name):
        return const
    return int(cur) if name in knobs.BrainTuneParams().INT_TUNE_PARAMS else float(cur)



def tune_thresholds(
    sigs: list[dict[str, Any]],
    params: TunableParams,
    model: OnlineLogit | None,
    bootstrap: bool = False,
    use_options: bool = True,
) -> tuple[TunableParams, Metrics]:
    best, best_m = params, score_on_signals(sigs, params, model, use_options)
    frac = _c('boot_step_fraction') if bootstrap else _c('max_step_fraction')
    for name, steps in _GRID.items():
        lo, hi = PARAM_BOUNDS[name]
        whole = name in INT_PARAMS
        rng = hi - lo
        # A whole-number parameter moves by at least one, so its cap is one.
        cap = max(1.0, rng * frac) if whole else rng * frac
        for step_frac in steps:
            step = float(step_frac) if whole else float(step_frac) * rng
            if step == 0 or abs(step) > cap + 1e-9:
                continue
            trial = replace(best, **{name: getattr(best, name) + step}).clamp()
            if getattr(trial, name) == getattr(best, name):
                # A whole-number parameter pinned at a bound rounds back to where
                # it started. Scoring the same point twice would let the
                # tie-break read as a move.
                continue
            m = score_on_signals(sigs, trial, model, use_options)
            if m.n >= _c('min_trades_to_judge') and (
                best_m.n < _c('min_trades_to_judge') or m.lcb_r > best_m.lcb_r + 0.005
            ):
                best, best_m = trial, m
    return best, best_m


def tune_weights(sigs: list[dict[str, Any]], params: TunableParams) -> TunableParams:
    """Nudge engine weights by how well each engine's vote predicted its own signal.

    A signal's stored vote has the *engine's* direction, the label tells whether
    the traded side won. Engines that voted with winners are up-weighted, those
    that voted with losers down-weighted, per regime, at most 10% per cycle.
    """
    new = {r: dict(w) for r, w in params.weights.items()}
    for regime in new:
        rs = [s for s in sigs if s["regime"] == regime and s["label_r"] is not None]
        if len(rs) < 60:
            continue
        for e in new[regime]:
            num, n_e = 0.0, 0
            for s in rs:
                v = float(s["votes"].get(e, 0.0)) * (1 if s["side"] == "LONG" else -1)
                if abs(v) < 1e-9:
                    continue  # the engine abstained here (e.g. no chain): no evidence either way
                num += np.sign(v) * float(s["label_r"]) * min(abs(v), 1.0)
                n_e += 1
            if n_e < MIN_ENGINE_VOTES:
                continue
            edge = num / n_e
            new[regime][e] *= float(np.clip(1.0 + 0.5 * edge, 0.9, 1.1))
    return replace(params, weights=new).clamp()


# --- 3b. engine parameter search ---------------------------------------------
# The engines own thresholds now: the VWAP overextension band, the PCR panic
# and euphoria lines, the opening-range floor, the volatility-expansion
# multiple. A stored vote cannot be re-fused into a different engine output —
# a different VWAP band produces a different vote, not a different weight on
# the same one — so these are tuned the only honest way: re-run the engines
# over the historical bars with the candidate setting and score what the Brain
# would have earned.
#
# One parameter moves per cycle, and by at most a fifth of its range, so a
# single bad night cannot rewrite the whole configuration.

#: name -> the two steps tried (down, up), in the parameter's own units.
ENGINE_PARAM_STEPS: dict[str, tuple[float, float]] = {
    "oi_pcr_panic": (-0.10, 0.10),
    "oi_pcr_euphoria": (-0.05, 0.05),
    "vwap_dev_atr": (-0.40, 0.40),
    "vwap_pullback_atr": (-0.10, 0.10),
    "orb_range_atr_min": (-0.15, 0.15),
    "orb_decay_min": (-30.0, 30.0),
    "vol_breakout_atr_mult": (-0.20, 0.20),
    # Swing / positional engine parameters
    "swing_k_stop": (-0.30, 0.30),
    "swing_k_target": (-0.30, 0.30),
    "positional_k_stop": (-0.30, 0.30),
    "positional_k_target": (-0.30, 0.30),
}
#: The order the search works through. Round-robin, so every knob gets its turn.
ENGINE_PARAM_ORDER: tuple[str, ...] = tuple(ENGINE_PARAM_STEPS)
#: Wall-clock budget for the whole search. The engines are the expensive part.
ENGINE_PARAM_SEARCH_BUDGET_S = 150.0
#: A candidate is only accepted with at least this many simulated trades.
ENGINE_PARAM_MIN_TRADES = 40
#: How many underlyings take part. More is better evidence and slower.
ENGINE_PARAM_UNDERLYINGS = 2


def _replay_slice(
    bars: np.ndarray,
    params: TunableParams,
    model: OnlineLogit | None,
    squareoff: int,
    window: tuple[int, int],
    underlying: str,
    step: int = 6,
) -> tuple[list[Any], list[float]]:
    """Re-run the engines over one underlying's bars and score the trades.

    Returns the replayed rows (so the journal's stored votes can be refreshed)
    and the R of each trade the Brain would have taken.
    """
    from services.brain import backtest as bt

    pre = bt.precompute(
        bars,
        underlying=underlying,
        warmup=min(150, max(60, len(bars) // 4)),
        step=step,
        horizon=params.horizon_bars,
        entry_window=window,
        params=params,
    )
    rows, traded = bt.replay_traded(
        pre, bars, params, model, underlying=underlying, squareoff_min=squareoff
    )
    return rows, traded


def tune_engine_params(
    sigs: list[dict[str, Any]],
    params: TunableParams,
    model: OnlineLogit | None,
    fetch: Any,
    budget_s: float | None = None,
) -> tuple[TunableParams, dict[str, Any]]:
    """Move one engine threshold, if the evidence says it should move.

    The search is deliberately small: one parameter, one step, a bounded time
    budget and a minimum number of simulated trades before anything is
    accepted. A knob that improves the lower confidence bound of the replayed
    expectancy moves; everything else stays where it is.
    """
    out: dict[str, Any] = {"searched": False}
    if budget_s is None:
        budget_s = float(_c('engine_param_search_budget_s'))
    if fetch is None or len(sigs) < MIN_LABELLED_TOTAL:
        return params, out

    window, squareoff = session_rules()
    # The underlyings present in the fit slice, and the bars they need.
    underlyings = sorted({str(s["underlying"]) for s in sigs})
    if not underlyings:
        return params, out
    start_ts = min(float(s["bar_ts"]) for s in sigs)
    end_ts = max(float(s["bar_ts"]) for s in sigs)

    bar_sets: list[tuple[str, Any]] = []
    for u in underlyings[:_c('engine_param_underlyings')]:
        try:
            bars = fetch(u, start_ts)
        except Exception:
            logger.exception("brain: engine-param search could not fetch bars for %s", u)
            continue
        if bars is None or len(bars) < 220:
            continue
        # Only the bars up to the end of the fit slice, so nothing from the
        # holdout leaks into the search.
        keep = bars[bars[:, 0] <= end_ts]
        if len(keep) < 220:
            continue
        bar_sets.append((u, keep))
    if not bar_sets:
        out["why"] = "not enough history for an engine-parameter search"
        return params, out

    # Which knob this cycle works on. The search rotates through them so no
    # single one gets all the attention.
    cursor = int(db.state_get("engine_param_cursor", 0)) % len(ENGINE_PARAM_ORDER)
    name = ENGINE_PARAM_ORDER[cursor]
    db.state_set("engine_param_cursor", cursor + 1)

    def score(trial: TunableParams) -> tuple[list[float], list[tuple[str, Any]]]:
        traded_all: list[float] = []
        rows_all: list[tuple[str, Any]] = []
        for u, bars in bar_sets:
            rows, traded = _replay_slice(bars, trial, model, squareoff, window, u)
            traded_all.extend(traded)
            rows_all.extend((u, r) for r in rows)
        return traded_all, rows_all

    started = time.time()
    try:
        base_traded, _ = score(params)
    except Exception:
        logger.exception("brain: engine-parameter search failed on the base parameters")
        return params, out
    base_m = metrics(base_traded)
    out.update(
        {
            "searched": True,
            "param": name,
            "base_lcb": round(base_m.lcb_r, 4),
            "base_trades": base_m.n,
        }
    )
    if base_m.n < _c('engine_param_min_trades'):
        out["why"] = f"only {base_m.n} simulated trades, need {_c('engine_param_min_trades')}"
        return params, out

    lo, hi = PARAM_BOUNDS[name]
    best, best_m = params, base_m
    for step in ENGINE_PARAM_STEPS[name]:
        if time.time() - started > budget_s:
            out["why"] = "time budget reached"
            break
        value = float(getattr(params, name)) + step
        if not (lo <= value <= hi):
            continue
        trial = replace(params, **{name: value}).clamp()
        if float(getattr(trial, name)) == float(getattr(params, name)):
            continue
        try:
            traded, _ = score(trial)
        except Exception:
            logger.exception("brain: engine-parameter trial failed for %s", name)
            continue
        m = metrics(traded)
        if m.n >= _c('engine_param_min_trades') and m.lcb_r > best_m.lcb_r + 0.005:
            best, best_m = trial, m

    if best is params:
        out["why"] = "no step improved the lower bound"
        return params, out

    out["new_value"] = float(getattr(best, name))
    out["new_lcb"] = round(best_m.lcb_r, 4)
    out["new_trades"] = best_m.n
    out["changed"] = True
    return best, out


# --- 2/4. challenger, promotion ---------------------------------------------
def train_challenger(sigs: list[dict[str, Any]]) -> tuple[OnlineLogit | None, dict[str, float]]:
    if len(sigs) < MIN_TRAIN:
        return None, {"reason": f"{len(sigs)}/{MIN_TRAIN} labelled signals"}
    rows = _rows(sigs[-TRAIN_WINDOW:])
    return train_model(rows, model_names(fusion.FEATURE_NAMES))


def _logloss(y: np.ndarray, p: np.ndarray) -> np.ndarray:
    p = np.clip(p, 0.01, 0.99)
    return -(y * np.log(p) + (1.0 - y) * np.log(1.0 - p))


def model_skill(
    sigs: list[dict[str, Any]], model: OnlineLogit | None, champ_model: OnlineLogit | None
) -> dict[str, float]:
    """Log-loss gain of the challenger's own probability over what the incumbent was using.

    The incumbent's probability is what live trading would have used: its prior/model blend.
    Positive ``mean_gain`` means the challenger predicts outcomes better. The standard error
    uses the effective number of rows, since signals one bar apart share most of their label
    window and are not independent evidence.
    """
    rows = [s for s in sigs if s["label_outcome"] is not None]
    if model is None or len(rows) < 2:
        return {"n": len(rows), "n_eff": 0.0, "mean_gain": 0.0, "se": 1.0, "lb": -1.0}
    y = np.array([1.0 if s["label_outcome"] == 1 else 0.0 for s in rows])
    p_prior = np.array([float(s["prob_prior"]) for s in rows])
    p_mod = np.array([model.predict(s["features"]) for s in rows])
    if champ_model is not None and champ_model.credibility_n > 0:
        z = fusion.model_weight(champ_model)
        p_base = (
            z * np.array([champ_model.predict(s["features"]) for s in rows]) + (1 - z) * p_prior
        )
    else:
        p_base = p_prior
    d = _logloss(y, p_base) - _logloss(y, p_mod)
    keys = [int(float(s["bar_ts"]) // BAR_S) for s in rows]
    spans = [int(s.get("label_bars") or s.get("horizon_bars") or 12) for s in rows]
    n_eff = effective_sample_size(keys, spans)
    se = float(np.std(d, ddof=1)) / math.sqrt(max(n_eff, 1.0))
    mean = float(d.mean())
    return {
        "n": len(rows),
        "n_eff": round(n_eff, 1),
        "mean_gain": round(mean, 5),
        "se": round(se, 5),
        "lb": round(mean - _c('skill_sigmas') * se, 5),
    }


def compare_and_promote(
    sigs: list[dict[str, Any]],
    now: float | None = None,
    fetch: Any = None,
) -> dict[str, Any]:
    """Run steps 2-4. Returns a report that is also written to the audit trail."""
    now = now or time.time()
    out: dict[str, Any] = {"labelled": len(sigs)}
    champ_params, champ_model, champ_id = load_champion()
    out["champion_id"] = champ_id
    # The search resumes from where it got to, not from the champion. The
    # champion is what drives trading; the tuner state is where the search
    # is. With no champion the search would otherwise restart from the
    # defaults on every cycle and never climb anywhere.
    tuner_params, last_fp, last_champ = load_tuner_state()
    tune_from = tuner_params if tuner_params is not None else champ_params
    out["tuner_state"] = "resumed" if tuner_params is not None else "fresh"
    # Learn from, and judge on, only what the live gate could ever have let through.
    window, _ = session_rules()
    all_labelled = len(sigs)
    sigs = takeable(sigs, window)
    out["labelled"] = len(sigs)
    out["outside_entry_window"] = all_labelled - len(sigs)
    if len(sigs) < MIN_LABELLED_TOTAL:
        out["action"] = "wait"
        out["why"] = f"{len(sigs)}/{MIN_LABELLED_TOTAL} labelled signals"
        return out
    sigs = sorted(sigs, key=lambda r: r["bar_ts"])
    # Embargo the newest signals out of the whole search before the slices are
    # cut: every challenger compares on the same holdout, so a promotion gate
    # reused search after search stops being fresh evidence. The embargoed
    # tail is judged once, on promotion only. It must not starve the search,
    # though: when the labelled history is shorter than the embargo window
    # (young installations, sparse signals), cap the embargo so what remains
    # still meets MIN_LABELLED_TOTAL — the fresh gate simply shrinks with it.
    embargo_start_ts = float(sigs[-1]["bar_ts"]) - _c('holdout_embargo_days') * 86400.0
    embargo = [s for s in sigs if float(s["bar_ts"]) >= embargo_start_ts]
    max_embargo = max(len(sigs) - MIN_LABELLED_TOTAL, 0)
    if len(embargo) > max_embargo:
        embargo = embargo[len(embargo) - max_embargo :]  # keep the newest rows
    if embargo:
        cut = float(embargo[0]["bar_ts"])
        sigs = [s for s in sigs if float(s["bar_ts"]) < cut]
    n = len(sigs)
    c1, c2 = int(n * FIT_FRAC), int(n * (FIT_FRAC + VAL_FRAC))
    fit_raw, val_raw, confirm = sigs[:c1], sigs[c1:c2], sigs[c2:]
    # Guard: need at least one row in fit/val/confirm to search; otherwise bail.
    if len(fit_raw) == 0 or len(val_raw) == 0 or len(confirm) == 0:
        out["action"] = "skip"
        out["why"] = "too few closed signals to split into fit/validate/confirm slices"
        db.event("info", "search_skipped", out["why"], out)
        return out
    # Purge: a training row whose label window overlaps the next slice would leak the future.
    train_part = purge(fit_raw, float(val_raw[0]["bar_ts"]))
    holdout = purge(val_raw, float(confirm[0]["bar_ts"]))
    use_opt, _ = options_ready(force=True)

    # Nothing to search if the fit slice has not moved since the last search
    # and the champion has not changed under it. The fingerprint is kept with
    # the tuner state, so this holds across a restart as well as within one.
    fp = _fit_fingerprint(train_part)
    if fp and fp == last_fp and champ_id == last_champ:
        out["action"] = "no_new_data"
        out["why"] = "the fit slice has not changed since the last search"
        # Leave a trace: a search that did not run must be visible in the
        # journal, or a quiet brain and a stuck one look the same.
        db.event("info", "search_skipped", out["why"], out)
        return out

    cand_model, stats = train_challenger(train_part)
    cand_params = tune_weights(train_part, tune_from)
    cand_params, _ = tune_thresholds(
        train_part,
        cand_params,
        cand_model,
        bootstrap=(champ_id == 0 and tuner_params is None),
        use_options=use_opt,
    )
    # Engine thresholds last: they change what the engines say, so they are
    # tuned against a replay rather than against the stored votes.
    if fetch is not None:
        cand_params, engine_report = tune_engine_params(train_part, cand_params, cand_model, fetch)
        out["engine_params"] = engine_report
    m_ch = score_on_signals(holdout, cand_params, cand_model, use_opt)
    m_cp = score_on_signals(holdout, champ_params, champ_model, use_opt)
    # The confirm slice is only ever read here, after the winner is already chosen on `holdout`.
    m_ch_c = score_on_signals(confirm, cand_params, cand_model, use_opt)
    m_cp_c = score_on_signals(confirm, champ_params, champ_model, use_opt)
    out.update(
        champion=m_cp.as_dict(),
        challenger=m_ch.as_dict(),
        confirm={"challenger": m_ch_c.as_dict(), "champion": m_cp_c.as_dict()},
        model_stats=stats,
        split={"fit": len(train_part), "validate": len(holdout), "confirm": len(confirm)},
    )

    lb = lambda m: m.expectancy_r - _c('promote_sigmas') * m.stderr_r  # noqa: E731
    out["bounds"] = {"challenger": round(lb(m_ch), 4), "champion": round(lb(m_cp), 4)}
    better = (
        m_ch.n >= _c('min_trades_to_judge')
        and lb(m_ch) > lb(m_cp) + _c('promote_margin_r')
        and m_ch.max_dd_r <= max(m_cp.max_dd_r * 1.25, 3.0)
    )
    # An untrained champion trades on the prior alone; require the challenger to be positive outright.
    if champ_id == 0:
        better = better and lb(m_ch) > 0
    # Second, untouched look: it must also be profitable and no worse than the champion there.
    better = (
        better
        and m_ch_c.n >= MIN_CONFIRM_TRADES
        and m_ch_c.expectancy_r > 0
        and m_ch_c.expectancy_r >= m_cp_c.expectancy_r
    )
    via = "strategy" if better else None
    # Second route, for when the strategy test cannot speak: a challenger that takes under 20
    # holdout trades can never be judged by them, however good its probabilities are. Judge the
    # probabilities themselves on every holdout row, and confirm on the untouched slice. It may
    # not promote a challenger whose trades, where there are enough to see, are clearly worse.
    sk_h, sk_c = (
        model_skill(holdout, cand_model, champ_model),
        model_skill(confirm, cand_model, champ_model),
    )
    out["skill"] = {"holdout": sk_h, "confirm": sk_c}
    strategy_clearly_worse = (
        m_ch.n >= _c('min_trades_to_judge') and lb(m_ch) < lb(m_cp) - _c('promote_margin_r')
    )
    if (
        not better
        and cand_model is not None
        and sk_h["n_eff"] >= _c('skill_min_eff')
        and sk_h["lb"] > 0
        and sk_c["n_eff"] >= _c('skill_min_eff') / 2
        and sk_c["mean_gain"] > 0
        and not strategy_clearly_worse
    ):
        better, via = True, "skill"
    # Fresh gate: a challenger that survived the search must also clear the
    # embargoed tail — rows no part of the search ever saw. Only asked when
    # the tail holds enough trades to judge; otherwise the existing gates
    # stand alone.
    if better and len(embargo) >= MIN_CONFIRM_TRADES:
        m_ch_e = score_on_signals(embargo, cand_params, cand_model, use_opt)
        m_cp_e = score_on_signals(embargo, champ_params, champ_model, use_opt)
        out["embargo"] = {"challenger": m_ch_e.as_dict(), "champion": m_cp_e.as_dict()}
        if not (
            m_ch_e.n >= MIN_CONFIRM_TRADES
            and m_ch_e.expectancy_r > 0
            and m_ch_e.expectancy_r >= m_cp_e.expectancy_r
        ):
            better = False
            out["why"] = "failed the embargoed fresh gate"
    db.model_add(
        "retired",
        cand_params.to_dict(),
        cand_model.to_dict() if cand_model else {},
        {"holdout": m_ch.as_dict(), "vs": m_cp.as_dict(), **stats},
        note="challenger",
    )
    old = db.model_by_role("champion")
    new_id = None
    if better and cand_model is not None:
        # Refit on everything labelled so far, then install as the one champion row.
        final_model, _ = train_challenger(sigs)
        old = db.model_by_role("champion")
        if old:
            db.model_set_role(int(old["id"]), "retired")
        new_id = db.model_add(
            "champion",
            cand_params.to_dict(),
            (final_model or cand_model).to_dict(),
            {"holdout": m_ch.as_dict(), "vs": m_cp.as_dict(), "skill": sk_h, "via": via},
            note=f"promoted ({via})",
        )
        out.update(action="promoted", new_champion_id=new_id, promoted_via=via)
        db.event("info", "promotion", f"challenger promoted to champion #{new_id}", out)
    else:
        out["action"] = "kept_champion"
        db.event("info", "no_promotion", "champion kept", out)
    # Keep the position the search reached, so the next one starts here rather
    # than at the defaults, and so a restart does not lose it. The champion id
    # stored is the one the tuner params were derived against (the old champ
    # before this promotion), so the next search's fingerprint check compares
    # against the right baseline.
    # ``0`` is the "no champion yet" sentinel ``load_champion`` reports, and it
    # must be stored like any other id: an installation whose first searches
    # never promote is exactly the one that has to resume where it left off.
    # Skipping the save when there is no champion dropped the position on every
    # restart until something was promoted, and left nothing for the next
    # search's fingerprint to compare with — so it retrained the same slice.
    champion_id_for_tuner = (old["id"] if old else new_id) or 0
    save_tuner_state(cand_params, fp, champion_id_for_tuner)
    _record_param_sources(cand_params, tune_from)
    # Persist the engine-parameter search result so the dashboard can read it
    # from the status endpoint without having to wait for a learn_now trigger.
    try:
        ep = out.get("engine_params") or {}
        db.state_set("engine_param_last_result", json.dumps(ep))
    except Exception:
        pass
    return out


def _record_param_sources(new_params: TunableParams, previous: TunableParams) -> None:
    """Note which parameters the search moved on its own.

    A parameter the search changed is the Brain's, and the dashboard says so.
    A parameter the search left alone keeps whatever source it had, so a
    human's slider edit stays marked as the human's.
    """
    try:
        stored = db.state_get("param_sources", {}) or {}
        if not isinstance(stored, dict):
            stored = {}
        for name in new_params.to_dict():
            if name == "weights":
                continue
            try:
                changed = float(getattr(new_params, name)) != float(getattr(previous, name))
            except (AttributeError, TypeError, ValueError):
                continue
            if changed and stored.get(name) != "manual":
                stored[name] = "learner"
        db.state_set("param_sources", stored)
    except Exception:
        logger.exception("brain: could not record the parameter sources")


# --- 5. watch, roll back -----------------------------------------------------
def feature_drift(sigs: list[dict[str, Any]], recent_n: int = RECENT_N) -> dict[str, float]:
    """How far the market has moved from the population the model learned on.

    Replayed rows and live rows are *different populations*: a replay carries
    no option chain (its features say so) and was produced by the pipeline of
    the day it was written. A PSI between the two measures that difference, not
    a market shift, so the comparison stays inside one population: live rows
    against live rows once there are enough of them, the replay against itself
    until then.
    """
    if len(sigs) < recent_n + 300:
        return {}
    sigs = sorted(sigs, key=lambda r: r["bar_ts"])
    live = [r for r in sigs if r.get("status") != "BACKTEST"]
    replay = [r for r in sigs if r.get("status") == "BACKTEST"]
    if len(live) >= recent_n + 300:
        population = live
    elif len(replay) >= recent_n + 300:
        population = replay
    else:
        return {}
    base, recent = population[:-recent_n], population[-recent_n:]
    return {
        f: round(
            psi(
                np.array([s["features"].get(f, 0.0) for s in base]),
                np.array([s["features"].get(f, 0.0) for s in recent]),
                bins=5,
            ),
            3,
        )
        for f in KEY_DRIFT_FEATURES
    }


def watch_champion(sigs: list[dict[str, Any]], rollback: bool = True) -> dict[str, Any]:
    """Realised-trade check and drift check. May roll back; may mark the Brain degraded.

    The drift half runs on every cycle: it is what pauses a degraded Brain, so
    it must not wait for the daily search. The rollback half only runs on a
    search cycle - with a handful of closed trades the lower bound of
    expectancy swings far enough to trigger a rollback on noise.
    """
    _, _, champ_id = load_champion()
    out: dict[str, Any] = {"champion_id": champ_id}
    drift = feature_drift(sigs)
    out["drift"] = drift
    drifted = sum(1 for v in drift.values() if v > _c('drift_limit')) >= _c('drift_min_features')
    trades = [
        p
        for p in db.positions_closed()
        if p["model_version"] == champ_id
        and p["r_multiple"] is not None
        and math.isfinite(float(p["r_multiple"]))
        # Exclude bootstrap-era rows (model_version == 0) from realised metrics:
        # they belong to the default "no-champion" regime, not the live champion.
        and (champ_id > 0 or p["model_version"] > 0)
    ]
    m = metrics([float(p["r_multiple"]) for p in trades])
    out["realised"] = m.as_dict()
    degraded = drifted
    if rollback and champ_id and m.n >= _c('rollback_min_trades') and m.lcb_r < _c('rollback_lcb_r'):
        prev = [
            r
            for r in db.models_list(50)
            if r["role"] == "retired"
            and int(r["id"]) < champ_id
            and (str(r["note"]).split(" ")[0] == "promoted" or r["note"] == "bootstrap")
        ]
        prev.sort(key=lambda r: int(r["id"]), reverse=True)
        if prev:
            db.model_set_role(champ_id, "retired")
            db.model_set_role(int(prev[0]["id"]), "champion")
            out["action"] = "rolled_back"
            db.event("warn", "rollback", f"champion {champ_id} rolled back to {prev[0]['id']}", out)
        else:
            degraded = True
            out["action"] = "degraded_no_previous"
    db.state_set("degraded", degraded)
    if drifted:
        db.event(
            "warn",
            "drift",
            f"feature drift above {_c('drift_limit')}: auto-trading paused until it settles",
            drift,
        )
    return out


def paper_record() -> Metrics:
    """The sandbox trades only: the evidence live trading is judged on."""
    return metrics(
        [
            float(p["r_multiple"])
            for p in db.positions_closed()
            if p["mode"] == "sandbox"
            and p["r_multiple"] is not None
            and math.isfinite(float(p["r_multiple"]))
            # NaN < x is False, so a non-finite R would silently pass every
            # live_eligible threshold (NaN-transparent blocker checks).
        ]
    )


def model_validated() -> tuple[bool, dict[str, Any]]:
    """Does a promoted champion model stand behind the probabilities the Brain trades on?

    Without one, every probability is the prior alone, and the prior has not shown it can rank
    trades. A champion exists only after it beat the previous one on untouched data, so it is the
    only probability worth risking real money on. Its credibility is its effective sample size.
    """
    _, model, champ_id = load_champion()
    n_eff = float(model.credibility_n) if model is not None else 0.0
    ok = champ_id > 0 and model is not None and n_eff >= _c('live_min_model_neff')
    return ok, {
        "champion_id": champ_id,
        "n_rows": int(model.n_rows) if model is not None else 0,
        "n_eff": round(n_eff, 1),
        "needed_n_eff": _c('live_min_model_neff'),
        "validated": ok,
    }


def maturity(limits: RiskLimits) -> dict[str, Any]:
    counts = db.signal_counts()
    m = paper_record()
    ok, why = live_eligible(
        limits, m.n, m.expectancy_r, m.profit_factor, m.max_dd_r, stderr_r=m.stderr_r
    )
    model_ok, model_info = model_validated()
    if not model_ok:
        ok = False
        why = (
            *why,
            "no validated model: probabilities are the prior alone "
            f"(champion effective samples {model_info['n_eff']:.0f}/{_c('live_min_model_neff'):.0f})",
        )
    stage = (
        "LEARNING"
        if counts["labeled"] < MIN_TRAIN
        else ("LIVE_ELIGIBLE" if ok else "PAPER_VALIDATING")
    )
    opt_ok, opt_n = options_ready()
    return {
        "stage": stage,
        "labelled_signals": counts["labeled"],
        "paper": m.as_dict(),
        "live_blockers": list(why),
        "model": model_info,
        "options_engine": {
            "voting": opt_ok,
            "chain_labelled": opt_n,
            "needed": OPTIONS_MIN_LABELLED,
        },
    }


def learn_cycle(
    fetch: BarsFetcher, now: float | None = None, search: bool = True, api_key: str = ""
) -> dict[str, Any]:
    """The whole nightly loop.

    ``search=False`` runs the cheap half only: label what has elapsed, watch
    for drift, prune the journal. The parameter search, the challenger
    training, the promotion decision and the rollback belong to the daily
    cycle, on a settled population. Re-searching every half hour on a
    population that had barely moved trained the same challenger over and
    over and put a promotion decision on a handful of trades.
    """
    now = now or time.time()
    labelled = label_pending(fetch, now, api_key=api_key)
    sigs = training_population()
    out: dict[str, Any] = {"newly_labelled": labelled, "searched": bool(search)}
    if search:
        out.update(compare_and_promote(sigs, now, fetch=fetch))
    out["watch"] = watch_champion(sigs, rollback=search)
    db.state_set("last_learn", now)
    if search:
        db.eval_upsert(time.strftime("%Y-%m-%d", time.gmtime(now + 19800)), out)
    out["prune"] = _prune_journal(now)
    return out


def _live_train_min_rows() -> int:
    # The population has to be big enough to split: the fit slice needs at least
    # MIN_TRAIN rows, and after purging the overlapping label windows a
    # validate and a confirm slice have to survive as well. Below ~1000 live
    # rows the split collapses (fit 120, validate 0) and no challenger can be
    # trained at all, so the replay keeps carrying the training set until then.
    try:
        return max(int(os.getenv("BRAIN_LIVE_TRAIN_MIN", "1000")), 200)
    except (TypeError, ValueError):
        return 1000


LIVE_TRAIN_MIN_ROWS = _live_train_min_rows()  # live rows needed before they lead the training set


def training_population(limit: int = 20000) -> list[dict[str, Any]]:
    """The rows the trainer learns from.

    A replayed row has no option chain, so all fifteen ``options.*`` features
    are zero on every replay row; only live rows carry what the chain
    contributes (GEX, walls, IV, delta). The replay rows give depth, but they
    cannot teach the model the features that decide a premium trade.

    So: while there are few live rows, the replay carries the training set.
    Once there are enough live rows to learn from (a few sessions' worth), they
    lead it — the population becomes the live rows in chronological order, so
    the fit slice holds them and the confirm slice stays untouched.
    """
    live = db.signals_labeled_live(limit=limit)
    if len(live) <= _live_train_min_rows():
        return db.signals_labeled(limit=limit)
    return live


def _prune_journal(now: float) -> dict[str, Any]:
    """Keep the signal journal bounded: once a day drop the oldest replay rows.

    The trainer reads the newest rows, so this costs the model nothing and keeps
    a long-lived process from growing a multi-gigabyte SQLite file. Live rows
    are never touched.
    """
    day = time.strftime("%Y-%m-%d", time.gmtime(now + 19800))
    if db.state_get("journal_pruned_day") == day:
        return {"skipped": "already pruned today"}
    try:
        result = db.prune_backtest_signals()
        db.state_set("journal_pruned_day", day)
        if result.get("deleted"):
            logger.info(
                "brain: pruned %s replay signals from the journal (%s left)",
                result["deleted"],
                result["remaining"],
            )
            # Reclaim the space pruned rows left behind so a long-lived process
            # does not keep a multi-gigabyte SQLite file. VACUUM needs its own
            # autocommit connection (db.vacuum opens one), so it is safe to run
            # while the Brain is running; the file is briefly locked.
            try:
                db.vacuum()
                logger.info("brain: vacuumed journal after prune")
            except Exception:
                logger.exception("brain: journal vacuum failed")
        return result
    except Exception:
        logger.exception("brain: journal prune failed")
        return {"error": "prune failed"}


# --- bootstrap from history ----------------------------------------------------
def bootstrap_from_bars(
    bars: np.ndarray, underlying: str, params: TunableParams | None = None, step: int = 3
) -> int:
    """Seed the journal with labelled signals replayed from historical bars.

    They are stored exactly like live signals (status BACKTEST), so the normal
    learning cycle trains, tunes and judges on them with no second code path.
    The options engine abstains in a replay, which is stated in the signal's
    features (``options.opt_available`` = 0) and so the model can tell.

    A bulk insert is used for the write path: thousands of individual commits
    would make the bootstrap take minutes per underlying rather than seconds.
    """
    from services.brain import backtest as bt

    params = params or load_champion()[0]
    # Replay only what the live gate could have taken, and stop every label at square-off.
    window, squareoff = session_rules()
    pre = bt.precompute(
        bars,
        underlying=underlying,
        step=step,
        horizon=params.horizon_bars,
        entry_window=window,
        params=params,
    )
    rows, metric = bt.replay(
        pre, bars, params, None, underlying=underlying, squareoff_min=squareoff
    )
    if not rows:
        return 0

    # Read every (side, bar_ts) already in the journal once, so we never hit
    # the DB in the hot loop. Deduplication becomes a set lookup and the
    # insert stays as one ``add_all`` call. The replay journals band-less
    # rows, so the probe is scoped to band=""; the DB-side UNIQUE key in
    # signal_bulk_add is the backstop for anything that slips past this.
    seen = {(side, bar_ts) for side, bar_ts in db.signals_already_journaled(underlying)}
    batches: list[list[dict[str, Any]]] = []
    current: list[dict[str, Any]] = []
    for r in rows:
        c = r.candidate
        bar_ts = float(bars[r.index, 0])
        key = (c.side, bar_ts)
        if key in seen:
            continue
        seen.add(key)
        current.append(
            {
                "ts": bar_ts,
                "bar_ts": bar_ts,
                "underlying": underlying,
                "side": c.side,
                "regime": c.regime,
                "score": round(c.score, 6),
                "agree": c.agree,
                "prob": round(c.prob, 6),
                "prob_prior": round(c.prob_prior, 6),
                "ev_r": round(c.ev_r, 6),
                "rr": round(c.rr, 6),
                "sigma_h": round(c.sigma_h, 8),
                "k_stop": c.k_stop,
                "k_target": c.k_target,
                "horizon_bars": c.horizon_bars,
                "entry_spot": float(bars[r.index, 4]),
                "passed": c.passed,
                "reject": c.reject or "",
                "status": "BACKTEST",
                "path": "Fusion",
                "features": json.dumps(c.features),
                "votes": json.dumps({k: round(v, 6) for k, v in c.votes.items()}),
                "reasons": json.dumps(list(c.reasons)),
                "model_version": 0,
                "band": "",
                "position_type": c.position_type,
                "symbol": "",
                "dte": 0.0,
                "gamma": 0.0,
                "leg_delta": 0.0,
                "leg_entry": 0.0,
                "leg_stop": 0.0,
                "leg_target": 0.0,
                "label_outcome": r.label.outcome if r.label else None,
                "label_r": round(r.label.r, 6) if r.label else None,
                "label_bars": r.label.bars if r.label else None,
                "labeled_at": time.time(),
            }
        )
        if len(current) >= 500:
            batches.append(current)
            current = []
    if current:
        batches.append(current)

    added = 0
    for batch in batches:
        added += db.signal_bulk_add(batch)
    db.event(
        "info",
        "bootstrap",
        f"{underlying}: {added} labelled signals replayed from {len(bars)} bars ({metric})",
    )
    return added
