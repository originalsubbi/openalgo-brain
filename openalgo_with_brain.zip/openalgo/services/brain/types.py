"""Plain value types shared across the Brain. No behaviour, no I/O."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import numpy as np

if TYPE_CHECKING:  # pragma: no cover - typing only, avoids an import cycle
    from services.brain.config import TunableParams

IST_OFFSET = 19800  # seconds, UTC+05:30


def param(snap: Any, name: str, default: float) -> float:
    """Read one tunable parameter off the snapshot, falling back to ``default``.

    Every engine that owns a threshold reads it through here, so a slider moved
    in the UI (or by the learner) reaches the engine that actually uses it. An
    engine run without a parameter set — a replay, a unit test — keeps its
    built-in default instead of failing.
    """
    p = getattr(snap, "params", None)
    if p is None:
        return default
    value = getattr(p, name, None)
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def session_slice(bars: np.ndarray) -> np.ndarray:
    """Only the bars of the current IST session (day), oldest first.

    The intraday engines that reason about "this session" — VWAP and the opening
    range — must not read yesterday's bars. The split is on the IST day
    boundary, which is what the Indian session actually runs on.
    """
    if len(bars) == 0:
        return bars
    day = ((bars[:, 0] + IST_OFFSET) // 86400).astype(np.int64)
    today = day == day[-1]
    return bars[int(len(bars) - today.sum()) :]


@dataclass(frozen=True, slots=True)
class Snapshot:
    """Everything the engines may look at for one underlying at one moment.

    ``bars`` is an (n, 6) array of ``[t, open, high, low, close, volume]`` in
    5-minute bars, oldest first, last row being the most recent *completed* bar.
    ``chain`` is the normalised option summary built by ``orchestrator`` (or
    ``None`` when unavailable, as in a backtest), see ``engines.options``.
    ``params`` is the live :class:`~services.brain.config.TunableParams`, so an
    engine reads the thresholds it owns instead of hard-coding them.
    """

    underlying: str
    ts: float
    bars: np.ndarray
    spot: float
    lot_size: int = 1
    bench_close: np.ndarray | None = None
    chain: dict[str, Any] | None = None
    iv_rank: float | None = None
    vix: float | None = None
    minute_of_day: int = 0  # IST, drives time-of-day features
    params: "TunableParams | None" = None


@dataclass(frozen=True, slots=True)
class EngineReport:
    """One engine's opinion.

    ``vote`` is directional: +1 bullish, -1 bearish. ``signed`` holds features
    that flip sign with the side being evaluated, ``neutral`` holds those that
    do not. Splitting them is what lets one model serve both long and short.
    """

    name: str
    vote: float
    confidence: float
    signed: dict[str, float] = field(default_factory=dict)
    neutral: dict[str, float] = field(default_factory=dict)
    notes: tuple[str, ...] = ()
    extras: dict[str, Any] = field(default_factory=dict)  # raw values, never model features


@dataclass(frozen=True, slots=True)
class Candidate:
    """A trade the Brain would take, before the risk gate sees it."""

    underlying: str
    side: str  # "LONG" or "SHORT" on the underlying; options are bought either way
    regime: str
    score: float  # fused directional score in [-1, 1], signed toward the side
    agree: int
    prob: float  # calibrated probability the target is reached before the stop
    prob_prior: float
    ev_r: float  # expected value in R after costs
    rr: float
    sigma_h: float  # horizon sigma as a fraction of spot
    k_stop: float
    k_target: float
    horizon_bars: int
    features: dict[str, float]
    votes: dict[str, float]
    # "long" = buy one option; "short" = sell a credit spread.
    position_type: str = "long"
    reasons: tuple[str, ...] = ()
    passed: bool = False
    reject: str = ""
