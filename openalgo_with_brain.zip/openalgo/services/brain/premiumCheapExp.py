"""Cheap-premium / expiry-day mode for the AI Brain.

Unlike the main Brain (which trades ITM/ATM/OTM bands from ``bands.py``) and
PPA (which trades ATM premium price-action), this module lets the Brain buy
**cheap far-OTM options** whose premium sits in a user-configured range (default
₹15–₹50). These are the contracts that sit roughly delta 0.08–0.25 and can cost
₹20–₹50 at 3–5 DTE, or even cheaper on expiry day itself — ranges the existing
gates drop because they require delta >= 0.20 and a strike within ±5 of spot.

The mode starts paper-only and auto-promotes to live once the cheap/expiry
journal passes the same ``live_eligible`` graduation test as the main Brain
(150 trades, lower confidence bound ≥ 0, profit factor ≥ 1.15, drawdown under
the limit). Until then sandbox entries run freely and live entries are refused.
After promotion, live entries still require ``BRAIN_LIVE_ENABLED`` — the global
live switch — so nothing trades real money without both maturity and that switch
on.

Everything shares the same pipes as the rest of the Brain: positions live in
``brain_position`` tagged ``note='cheap_expiry'`` (the shared executor loop
skips them; this module manages their exits), orders use
``executor.dispatch`` / ``executor.exit_position``, history comes from the
broker via Historify, and chain data arrives through the scan the Brain already
runs -- no second fetch. The maturity meter, auto-tuning and the dashboard
panel all read from this module's own state keys so they never overlap PPA's.

Config layout mirrors ``premium_pa.py`` closely so a future reader can trace
one into the other without surprise. New knobs land in four places simultaneously:
``config.RiskLimits`` (+ its ``from_env`` reader),
``blueprints.brain.LIMIT_WRITES``, ``BrainDashboard.tsx`` slider spec, and
``lib/brainKnobMeta.ts`` label map.
"""

from __future__ import annotations

import os
import time
from typing import Any

import numpy as np
from cachetools import TTLCache

from services.brain import knobs as _knobs
from services.brain.bands import GAMMA_DTE_MAX, band_of  # pylint: disable=Cyclic import
from services.brain.config import RiskLimits
from utils.logging import get_logger

logger = get_logger(__name__)

NOTE = "cheap_expiry"
SKIP_LOG_INTERVAL_S = 15 * 60.0
_skip_log: dict[str, float] = {}
COOLDOWN_S = 20 * 60.0
MIN_HOLD_BARS = 3
BARS_TTL = 60.0
COLLECT_MIN_INTERVAL_S = 120.0
PAPER_WARN_DAY_KEY = "cheap_paper_warn_day"


# ---- configuration -----------------------------------------------------------


def _f(name: str, dflt: float) -> float:
    try:
        return float(os.getenv(name, dflt))
    except (TypeError, ValueError):
        return dflt


def _i(name: str, dflt: int) -> int:
    try:
        return int(float(os.getenv(name, dflt)))
    except (TypeError, ValueError):
        return dflt


def load_config() -> dict[str, Any]:
    """One knob bundle per call so .env edits apply without a restart."""
    cfg = {
        "enable": os.getenv("BRAIN_CHEAP_MODE", "0").strip().lower() in ("1", "true", "yes", "on"),
        "auto_tune": os.getenv("BRAIN_CHEAP_AUTO_TUNE", "1").strip().lower() not in ("0", "false", "off"),
        # Human-owned ceilings.
        "premium_max": max(_f("BRAIN_CHEAP_PREMIUM_MAX", 50.0), 5.0),
        "premium_min": min(max(_f("BRAIN_CHEAP_PREMIUM_MIN", 15.0), 1.0), 99.0),
        "risk_rupees": max(_f("BRAIN_CHEAP_RISK_RUPEES", 500.0), 50.0),
        "max_lots": max(_i("BRAIN_CHEAP_MAX_LOTS", 2), 1),
        "max_daily_risk_pct": min(max(_f("BRAIN_CHEAP_MAX_DAILY_RISK_PCT", 2.0), 0.5), 10.0),
        "expiry_start": _hhmm(os.getenv("BRAIN_CHEAP_EXPIRY_START", "10:00")),
        "expiry_cutoff": _hhmm(os.getenv("BRAIN_CHEAP_EXPIRY_CUTOFF", "14:00")),
        "max_spread_ticks": max(_i("BRAIN_CHEAP_MAX_SPREAD_TICKS", 2), 1),
        # Learner-tunable (bounded below).
        "reach_sigma": min(max(_f("BRAIN_CHEAP_REACH_SIGMA", 1.0), 0.5), 2.0),
        "stop_pct": min(max(_f("BRAIN_CHEAP_STOP_PCT", 0.25), 0.15), 0.45),
    }
    return _apply_overrides(cfg)


def _hhmm(text: str) -> int:
    hh, mm = text.strip().split(":")
    return int(hh) * 60 + int(mm)


# ---- tunable sliders (dashboard card) ----------------------------------------

SLIDERS: dict[str, dict[str, Any]] = {
    "premium_max": {"min": 5.0, "max": 200.0, "step": 5.0},
    "premium_min": {"min": 1.0, "max": 100.0, "step": 1.0},
    "risk_rupees": {"min": 50.0, "max": 5000.0, "step": 50.0},
    "max_lots": {"min": 1, "max": 5, "step": 1, "int": True},
    "max_daily_risk_pct": {"min": 0.5, "max": 10.0, "step": 0.5},
    "expiry_start": {"min": 9 * 60, "max": 14 * 60, "step": 15, "int": True, "timeFormat": True},
    "expiry_cutoff": {"min": 10 * 60, "max": 15 * 60, "step": 15, "int": True, "timeFormat": True},
    "max_spread_ticks": {"min": 1, "max": 10, "step": 1, "int": True},
    # Learner/self-tuned. They were missing here, so _auto_tune's nudges (which
    # look the key up in this table) were silently dropped.
    "reach_sigma": {"min": 0.5, "max": 2.0, "step": 0.05},
    "stop_pct": {"min": 0.15, "max": 0.45, "step": 0.01},
}
TOGGLES = ("enable", "auto_tune")

_SOURCE_HIERARCHY = {"manual": 3, "ai": 2, "auto": 1, "base": 0}
_AUTO_TUNE_MIN_SAMPLES = 8
_AUTO_TUNE_BAND_R = 0.25
_AUTO_TUNE_RECENT_N = 10
_AUTO_TUNE_THROTTLE_S = 5 * 60.0  # one change per knob per 5 minutes at most


def _overrides() -> dict[str, Any]:
    st = _state()
    ov = st.get("cheap_overrides")
    return ov if isinstance(ov, dict) else {}


def _override_priority(key: str) -> int:
    srcs = _overrides().get("sources")
    srcs = srcs if isinstance(srcs, dict) else {}
    raw_src = srcs.get(key)
    return _SOURCE_HIERARCHY.get(raw_src or "base", 0)


def _apply_overrides(cfg: dict[str, Any]) -> dict[str, Any]:
    vals = _overrides().get("values")
    if not isinstance(vals, dict):
        return cfg
    for key, raw in vals.items():
        spec = SLIDERS.get(key)
        if spec is None:
            if key in TOGGLES:
                cfg[key] = bool(raw)
            continue
        try:
            v = float(raw)
        except (TypeError, ValueError):
            continue
        v = min(max(v, float(spec["min"])), float(spec["max"]))
        cfg[key] = int(round(v)) if spec.get("int") else v
    return cfg


# ---- status / stats ----------------------------------------------------------


def cheap_status() -> dict[str, Any]:
    """Whether the cheap/expiry sidecar can enter right now."""
    from database import brain_db as db
    cfg = load_config()
    from services.brain.orchestrator import platform_mode

    mode = platform_mode()
    # Maturity (lower-confidence-bound test on the cheap/expiry journal) gates
    # live entries; sandbox entries never require maturity.
    mature = bool(_maturity_snapshot().get("eligible", False))
    drift_paused = bool(db.state_get("degraded", False))
    st = _state()
    stats = st.get("stats") if isinstance(st.get("stats"), dict) else {}
    if mode == "sandbox":
        can_enter = bool(cfg["enable"] and not drift_paused)
    elif mode == "live":
        can_enter = bool(cfg["enable"] and not drift_paused and mature)
    else:
        can_enter = False
    return {
        "enabled": bool(cfg["enable"] and not drift_paused),
        "drift_paused": drift_paused,
        "mode": mode,
        "can_enter": can_enter,
        "max_lots": cfg["max_lots"],
        "max_trades_day": cfg.get("max_trades_day", 6),
        "auto_tune": bool(cfg["auto_tune"]),
        "maturity": _maturity_snapshot(),
        "recent_r": list(stats.get("recent") or []),
    }


def cheap_stats() -> dict[str, Any]:
    """Detailed stats consumed by the Dashboard maturity panel."""
    from database import brain_db as db

    cfg = load_config()
    st = _state()
    stats = st.get("stats") if isinstance(st.get("stats"), dict) else {}
    recent = list(stats.get("recent") or [])
    recent_n = min(len(recent), _AUTO_TUNE_RECENT_N)
    recent_slice = recent[-recent_n:] if recent else []
    mean_r = sum(recent_slice) / len(recent_slice) if recent_slice else None

    today0 = _ist0(time.time())
    all_today = [
        p
        for p in db.positions_closed(today0)
        if p.get("note") == NOTE and (p.get("exit_ts") or 0) >= today0
    ]
    wins = [p for p in all_today if float(p.get("net_pnl") or 0) > 0]
    losses = [p for p in all_today if float(p.get("net_pnl") or 0) < 0]
    total_net = sum(float(p.get("net_pnl") or 0) for p in all_today)

    return {
        "enabled": bool(cfg["enable"]),
        "drift_paused": bool(db.state_get("degraded", False)),
        "mean_r": round(mean_r, 4) if mean_r is not None else None,
        "mean_r_samples": recent_n,
        "today_closes": len(all_today),
        "today_wins": len(wins),
        "today_losses": len(losses),
        "today_net_pnl": round(total_net, 2),
        "auto_tune_active": bool(cfg["auto_tune"])
        and mean_r is not None
        and abs(mean_r) > _AUTO_TUNE_BAND_R,
        "maturity": _maturity_snapshot(),
        "cells": cheap_cell_stats(),
    }


def cheap_cell_stats() -> dict[str, dict[str, float]]:
    """Per (dte_bucket, premium_bucket) stats for the cheap/expiry learner.

    Reads from ``brain_position`` rows tagged with ``note='cheap_expiry'`` so
    the same closed-trade ledger feeds both the maturity meter and the cell
    grid. Returns ``{cell_key: {n, mean_r}}`` where ``cell_key`` is
    ``"D0_P5-10"`` etc. Cells with fewer than 3 samples are dropped — the
    dashboard only shows cells that have enough history to be trustworthy.
    """
    from datetime import datetime

    from database import brain_db as db

    thirty_days_ago = _ist0(time.time()) - 30 * 86400
    with db.session_scope() as s:
        rows = (
            s.query(
                db.BrainPosition.expiry,
                db.BrainPosition.entry_price,
                db.BrainPosition.net_pnl,
                db.BrainPosition.risk_per_unit,
                db.BrainPosition.qty,
            )
            .filter(db.BrainPosition.note == NOTE)
            .filter((db.BrainPosition.exit_ts or 0) >= thirty_days_ago)
            .filter(db.BrainPosition.net_pnl.isnot(None))
            .all()
        )
    buckets: dict[str, dict[str, float]] = {}
    for row in rows:
        pnl = float(row.net_pnl or 0)
        risk_total = float(row.risk_per_unit or 0) * int(row.qty or 1)
        r_mult = (pnl / risk_total) if risk_total > 0 else None
        if r_mult is None:
            continue
        premium = float(row.entry_price or 0)
        # Compute DTE from the stored expiry string against today's IST date.
        try:
            exp_date = datetime.strptime(str(row.expiry or ""), "%d%b%y").date()
            dte = max((exp_date - datetime.now().date()).days, 0)
        except (ValueError, AttributeError):
            dte = 0
        dte_key = "0" if dte < 1 else ("1" if dte < 2 else ("2" if dte < 3 else ("3+" if dte < 5 else "5+")))
        prem_key = f"{int(premium // 5) * 5}-{int(premium // 5) * 5 + 5}"
        key = f"D{dte_key}_P{prem_key}"
        acc = buckets.setdefault(key, {"n": 0, "sum_r": 0.0})
        acc["n"] += 1
        acc["sum_r"] += r_mult
    out: dict[str, dict[str, float]] = {}
    for key, acc in buckets.items():
        if acc["n"] < 3:
            continue
        out[key] = {"n": acc["n"], "mean_r": round(acc["sum_r"] / acc["n"], 4)}
    return out


def _maturity_snapshot() -> dict[str, Any]:
    """Trades-to-date, LCB, PF, drawdown — the numbers that decide live eligibility."""
    from database import brain_db as db
    from services.brain.risk_gate import daily_loss_limit

    closed = db.positions_closed_realized()
    rows = [r for r in closed if r.get("note") == NOTE]
    n = len(rows)
    pnl_values = [float(r.get("net_pnl") or 0) for r in rows]
    gross = sum(max(p, 0.0) for p in pnl_values)
    net = sum(p for p in pnl_values)
    profit_factor = gross / abs(min(sum(p for p in pnl_values if p < 0), -1e-9)) if gross > 0 else 0.0
    expectancy_r = net / max(n, 1)
    # Lower confidence bound via the same Student-t correction live_eligible uses.
    if n >= 2:
        import math as _math

        std = (
            _math.sqrt(sum((p - expectancy_r) ** 2 for p in pnl_values) / (n - 1))
            if n > 1
            else 0.0
        )
        stderr = std / _math.sqrt(n)
        z = 1.645
        df = max(n - 1, 1)
        t_crit = z + (z ** 3 + z) / (4.0 * df)
        lcb = expectancy_r - t_crit * stderr
    else:
        lcb = 0.0
        stderr = None
    # Drawdown computed on running equity curve.
    equity_peak = 0.0
    equity_current = 0.0
    peak_dd = 0.0
    for r in sorted(rows, key=lambda x: float(x.get("exit_ts") or 0)):
        pnl = float(r.get("net_pnl") or 0)
        equity_current += pnl
        if equity_current > equity_peak:
            equity_peak = equity_current
        dd = equity_peak - equity_current
        if dd > peak_dd:
            peak_dd = dd
    limit = RiskLimits.from_env()
    eligible, why = _live_eligible(n, expectancy_r, profit_factor, peak_dd, stderr)
    return {
        "trades": n,
        "trades_target": limit.cheap_graduation_min_trades,
        "expectancy_r": round(expectancy_r, 4),
        "lcb_r": round(lcb, 4),
        "profit_factor": round(profit_factor, 4),
        "drawdown_r": round(peak_dd / max(limit.capital_base, 1.0), 4) if limit.capital_base else 0.0,
        "eligible": eligible,
        "ineligible_reasons": why,
        "stderr_r": round(stderr, 4) if stderr is not None else None,
    }


def _live_eligible(
    n: int,
    expectancy_r: float,
    profit_factor: float,
    max_dd_r: float,
    stderr_r: float | None,
) -> tuple[bool, tuple[str, ...]]:
    """Mirror of risk_gate.live_eligible scoped to the cheap-expiry record."""
    limits = RiskLimits.from_env()
    why: list[str] = []
    if n < limits.cheap_graduation_min_trades:
        why.append(f"{n}/{limits.cheap_graduation_min_trades} paper trades")
    if expectancy_r < limits.live_min_expectancy_r:
        why.append(f"expectancy {expectancy_r:+.2f}R < {limits.live_min_expectancy_r:+.2f}R")
    if stderr_r is None:
        why.append("no standard error supplied")
    else:
        z = limits.live_lcb_sigmas
        df = max(n - 1, 1)
        t_crit = z + (z ** 3 + z) / (4.0 * df)
        lcb = expectancy_r - t_crit * stderr_r
        if lcb < limits.live_min_lcb_r:
            why.append(
                f"LCB {lcb:+.2f}R < {limits.live_min_lcb_r:+.2f}R "
                f"({t_crit:.3f} t-corrected stderr of {stderr_r:.2f}R over {n} trades)"
            )
    if profit_factor < limits.live_min_profit_factor:
        why.append(f"profit factor {profit_factor:.2f} < {limits.live_min_profit_factor:.2f}")
    if max_dd_r > limits.live_max_drawdown_r:
        why.append(f"drawdown {max_dd_r:.1f}R > {limits.live_max_drawdown_r:.1f}R")
    return (not why), tuple(why)


# ---- pure math ---------------------------------------------------------------


def compute_reach_sigma(premium: float, delta: float, dte_days: float) -> float:
    """Underlying move (in sigma units of the premium) needed to double the premium.

    Roughly ``premium / (delta * spot_move_in_rs)`` but collapsed to sigmas of the
    premium itself. Cheap strikes with high gamma need less underlying movement
    relative to the premium's noise band; far OTM with low gamma need more. A
    result above ``reach_sigma`` means the underlying must move farther than the
    trader's expected horizon justifies.
    """
    if premium <= 0 or delta <= 0 or dte_days <= 0:
        return float("inf")
    # Gamma approx: d(premium)/d(spot) ≈ delta / spot, so a 1% spot move moves
    # premium by about delta * 1%. To double premium we need a move of premium/delta.
    # Express that move in terms of the premium's own volatility band.
    base = premium / delta
    # Normalise by a rough implied sigma for the window: at 1 DTE a 1% index move
    # costs about delta*1% in premium; at higher DTE the same move costs less.
    sigma_adjust = max(dte_days / GAMMA_DTE_MAX, 0.25)
    return (base / premium) / sigma_adjust


def effective_premium_ceiling(
    cfg: dict[str, Any], dte: float, ist_minute: int
) -> float:
    """The dynamic premium ceiling that tightens near expiry and late in the day.

    At 5+ DTE the full ``premium_max`` is allowed — those strikes have enough
    time for gamma to matter. Inside the gamma zone the ceiling collapses toward
    a floor of ``premium_min * 0.4`` so the Brain only trades strikes whose
    premium is meaningfully cheap relative to the underlying move still available.
    After ``expiry_cutoff - 120 min`` the ceiling drops further because theta
    drag accelerates and fills are worse in the last hour.
    """
    base = cfg["premium_max"]
    floor = cfg["premium_min"] * 0.4
    # DTE factor: linear ramp from floor at DTE=0 up to base at DTE=5.
    if dte <= 0:
        dte_factor = 0.0
    elif dte <= 5.0:
        dte_factor = floor + (base - floor) * (dte / 5.0)
    else:
        dte_factor = base
    # Time-of-day factor: after cutoff-120min start tapering toward floor.
    tail_start = cfg["expiry_cutoff"] - 120
    if ist_minute >= tail_start:
        tail_fade = max(0.0, 1.0 - (ist_minute - tail_start) / 120.0)
        time_factor = floor + (dte_factor - floor) * tail_fade
    else:
        time_factor = dte_factor
    return max(time_factor, floor)


def plan_levels(
    entry: float,
    cfg: dict[str, Any],
    spread: float,
    premium_sigma: float | None,
) -> dict[str, float]:
    """Stop/target geometry tuned for tiny premiums.

    Replaces the 8–45% clamp in executor.plan_levels with a floor based on ticks
    or a wider percentage — whichever is larger — so a ₹20 option isn't stopped
    out by one tick of noise. Risk per unit stays inside the configured rupee cap
    when possible.
    """
    tick_size = 0.05  # NSE index options step; conservative across underlyings
    min_stop_risk = max(entry * cfg["stop_pct"], 3.0 * tick_size)
    risk = min(max(min_stop_risk, entry * 0.08), entry * 0.45)
    if premium_sigma and premium_sigma > 0:
        vol_risk = entry * cfg.get("k_stop_ppa", 0.8) * premium_sigma
        risk = max(risk, vol_risk)
        risk = min(risk, entry * 0.45)
    stop = max(entry - risk, entry * 0.30)
    risk = entry - stop
    rr = cfg.get("rr", 1.5)
    return {
        "entry": entry,
        "risk_per_unit": float(risk),
        "stop": float(stop),
        "target": float(entry + risk * rr),
        "trail_trigger": 0.8 * risk,
        "trail_gap": 0.4 * risk,
        "deadline_s": 14 * 3600.0,  # hard exit by market close
    }


def size_lots(
    risk_per_unit: float,
    lot_size: int,
    capital: float,
    max_lots: int,
    risk_rupees: float,
) -> tuple[int, str]:
    """Lots sized by a fixed rupee risk cap, not by percent-of-capital.

    Returns ``(lots, reason)``. When capital is too small for one lot the reason
    names the shortfall so the operator can act: "capital needed ₹X for one lot".
    """
    if risk_per_unit <= 0 or lot_size <= 0:
        return 0, "cannot size: risk per lot is not positive"
    budget = risk_rupees
    lots = int(budget // (risk_per_unit * lot_size))
    lots = max(0, min(lots, max_lots))
    if lots <= 0:
        needed = risk_per_unit * lot_size
        # Round up to the nearest 50 so the message is actionable.
        needed_rounded = int(_math.ceil(needed / 50.0) * 50)
        return 0, f"capital needed ₹{needed_rounded} for one lot"
    return lots, "ok"


import math as _math  # noqa: E402

# ---- market-data helpers (cached) --------------------------------------------

_bars_cache: TTLCache[str, tuple[float, np.ndarray | None]] = TTLCache(maxsize=64, ttl=BARS_TTL)
_collect_state: TTLCache[str, float] = TTLCache(maxsize=64, ttl=3600.0)


def _fo_exchange(underlying: str) -> str:
    try:
        from services.brain.orchestrator import get_underlyings

        return get_underlyings().get(underlying, ("", "NFO"))[1] or "NFO"
    except Exception:
        return "NFO"


def _bars_from_historify(symbol: str, exchange: str = "NFO") -> np.ndarray | None:
    try:
        from database.historify_db import get_connection

        with get_connection() as conn:
            rows = conn.execute(
                "SELECT timestamp, open, high, low, close, volume, oi FROM market_data "
                "WHERE symbol = ? AND exchange = ? AND interval = '1m' ORDER BY timestamp",
                [symbol.upper(), exchange.upper()],
            ).fetchall()
        if not rows or len(rows) < 30:
            return None
        return np.array([[float(v) for v in row] for row in rows], dtype=float)
    except Exception:
        logger.exception("cheap: premium bars fetch failed for %s", symbol)
        return None


def premium_bars(symbol: str, api_key: str, days: int = 2, exchange: str = "NFO") -> np.ndarray | None:
    now = time.time()
    key = f"{exchange}:{symbol}"
    hit = _bars_cache.get(key)
    if hit and now - hit[0] < BARS_TTL:
        return hit[1]
    arr = _bars_from_historify(symbol, exchange)
    if arr is None:
        arr = _bars_from_broker(symbol, api_key, days, exchange)
    _bars_cache[key] = (now, arr)
    return arr


def _bars_from_broker(symbol: str, api_key: str, days: int = 2, exchange: str = "NFO") -> np.ndarray | None:
    arr = None
    try:
        from datetime import datetime, timedelta, timezone

        from services.history_service import get_history

        IST = timezone(timedelta(hours=5, minutes=30))
        today = datetime.now(IST).date()
        ok, resp, _ = get_history(
            symbol,
            exchange,
            "1m",
            (today - timedelta(days=days)).isoformat(),
            today.isoformat(),
            api_key=api_key,
            source="api",
        )
        if ok and isinstance(resp, dict):
            rows = resp.get("data") or []
            if len(rows) >= 30:
                arr = np.array(
                    [
                        [
                            float(r["timestamp"]),
                            float(r["open"]),
                            float(r["high"]),
                            float(r["low"]),
                            float(r["close"]),
                            float(r.get("volume") or 0),
                            float(r.get("oi") or 0),
                        ]
                        for r in rows
                    ]
                )
    except Exception:
        logger.exception("cheap: premium bars broker fetch failed for %s", symbol)
    return arr


def collect_symbol(symbol: str, api_key: str, exchange: str = "NFO") -> int:
    try:
        from datetime import datetime, timedelta, timezone

        import pandas as pd

        from database.historify_db import upsert_market_data
        from services.history_service import get_history

        IST = timezone(timedelta(hours=5, minutes=30))
        today = datetime.now(IST).date().isoformat()
        ok, resp, _ = get_history(symbol, exchange, "1m", today, today, api_key=api_key, source="api")
        if not ok or not isinstance(resp, dict):
            return 0
        rows = resp.get("data") or []
        if not rows:
            return 0
        df = pd.DataFrame(rows)
        n = upsert_market_data(df, symbol, exchange, "1m")
        return int(n)
    except Exception:
        logger.exception("cheap: collect failed for %s", symbol)
        return 0


# ---- paper equity ------------------------------------------------------------


def paper_equity() -> float:
    base = _paper_base()
    try:
        from sandbox.fund_manager import get_user_funds
        from services.brain.orchestrator import resolve_api_key
        from services.sandbox_service import get_user_id_from_apikey

        key = resolve_api_key()
        user_id = get_user_id_from_apikey(key) if key else None
        if user_id:
            funds = get_user_funds(user_id)
            if funds:
                realized = funds.get("total_realized_pnl")
                if realized is not None:
                    return base + float(realized)
    except Exception:
        logger.debug("cheap: sandbox funds unavailable; falling back to ledger")
    from database import brain_db as db

    closed = db.positions_closed_realized()
    realized = sum(
        float(p["net_pnl"]) if p.get("net_pnl") is not None else float(p.get("pnl") or 0)
        for p in closed
        if p.get("note") == NOTE
    )
    return base + realized


def _paper_base() -> float:
    from database.sandbox_db import get_config
    from utils.env_config import paper_capital

    try:
        configured = float(get_config("starting_capital", "1000000.00") or 0)
    except (TypeError, ValueError):
        configured = 0.0
    return paper_capital(configured)


# ---- state -------------------------------------------------------------------


def _state() -> dict[str, Any]:
    from database import brain_db as db

    raw = db.state_get("cheap_expiry_state", {}) or {}
    return raw if isinstance(raw, dict) else {}


def _save_state(s: dict[str, Any]) -> None:
    from database import brain_db as db

    db.state_set("cheap_expiry_state", s)


STATS_TRADES_WINDOW = 20


def _record_closed(now: float) -> dict[str, Any]:
    from database import brain_db as db

    st = _state()
    stats = st.get("stats") if isinstance(st.get("stats"), dict) else {}
    last_ts = float(stats.get("last_ts") or 0)
    rows = [
        r
        for r in db.positions_closed(since_ts=last_ts)
        if r.get("note") == NOTE and last_ts < float(r.get("exit_ts") or 0) <= now
    ]
    if not rows and isinstance(st.get("stats"), dict):
        return stats
    recent = list(stats.get("recent") or [])
    for r in sorted(rows, key=lambda x: float(x.get("exit_ts") or 0)):
        xt = float(r.get("exit_ts") or 0)
        pnl = float(r["net_pnl"]) if r.get("net_pnl") is not None else float(r.get("pnl") or 0.0)
        if abs(pnl) < 1e-9:
            last_ts = max(last_ts, xt)
            continue
        rm = r.get("r_multiple")
        if rm is None:
            risk_total = float(r.get("risk_per_unit") or 0) * int(r.get("qty") or 0)
            rm = (pnl / risk_total) if risk_total > 0 else None
        if rm is not None:
            recent.append(round(float(rm), 3))
            recent = recent[-STATS_TRADES_WINDOW:]
        last_ts = max(last_ts, xt)
    stats = {"last_ts": last_ts, "recent": recent}
    st["stats"] = stats
    _save_state(st)
    _auto_tune(load_config(), stats)
    return stats


def _ist0(ts: float) -> float:
    """IST midnight epoch for today's bucketing."""
    from services.brain.orchestrator import _ist

    return float(_ist(ts).replace(hour=0, minute=0, second=0, microsecond=0).timestamp())


# ---- auto-tune ---------------------------------------------------------------


def _auto_tune(cfg: dict[str, Any], stats: dict[str, Any]) -> None:
    if not cfg.get("auto_tune"):
        return
    k = _knobs.CURRENT_TUNE_KNOBS  # live read: the POST swaps the object
    recent = [float(r) for r in (stats.get("recent") or [])][-k.cheap_tune_recent_n:]
    if len(recent) < k.cheap_tune_min_samples:
        return
    mean_r = sum(recent) / len(recent)
    if abs(mean_r) <= k.cheap_tune_band_r:
        return
    srcs = _overrides().get("sources")
    srcs = srcs if isinstance(srcs, dict) else {}
    vals = dict(_overrides().get("values") or {})
    all_srcs = dict(srcs)
    # Throttle: read last tune times so a knob can't be nudged twice within the
    # interval. Persisted in state so it survives restarts.
    last_tune = _state().get("cheap_tune_times")
    last_tune = last_tune if isinstance(last_tune, dict) else {}
    now = time.time()
    changed: list[str] = []

    def _nudge(key: str, delta: float) -> None:
        spec = SLIDERS.get(key)
        if spec is None:
            return
        if _override_priority(key) >= 2:
            return
        last = float(last_tune.get(key, 0))
        if now - last < k.cheap_tune_throttle_s:
            return
        cur = float(vals.get(key, cfg[key]))
        new = min(max(cur + delta, float(spec["min"])), float(spec["max"]))
        if abs(new - cur) >= 1e-9:
            vals[key] = new
            all_srcs[key] = "auto"
            last_tune[key] = now
            changed.append(f"{key} {cur:.2f} -> {new:.2f}")

    if mean_r < -k.cheap_tune_band_r:
        _nudge("stop_pct", +0.02)  # widen stop
        _nudge("reach_sigma", -0.05)  # demand closer targets
    else:
        _nudge("stop_pct", -0.01)
        _nudge("reach_sigma", +0.02)
    if not changed:
        return
    st = _state()
    st["cheap_overrides"] = {"values": vals, "sources": all_srcs}
    st["cheap_tune_times"] = last_tune
    _save_state(st)
    from database import brain_db as db

    db.event(
        "info",
        "cheap_autotune",
        f"cheap/expiry self-tune ({len(recent)}-trade R {mean_r:+.2f}): " + ", ".join(changed),
    )


# ---- public API --------------------------------------------------------------


def config() -> dict[str, Any]:
    cfg = load_config()
    return {
        "sliders": [
            {"key": k, "min": float(s["min"]), "max": float(s["max"]), "step": float(s["step"]), "int": bool(s.get("int"))}
            for k, s in SLIDERS.items()
        ],
        "values": {k: cfg[k] for k in SLIDERS},
        "sources": {k: str(_overrides().get("sources", {}).get(k) or "base") for k in SLIDERS},
        "toggles": {k: bool(cfg.get(k, False)) for k in TOGGLES},
    }


def set_overrides(values: dict[str, Any], source: str) -> tuple[dict[str, Any] | None, str]:
    if not isinstance(values, dict) or not values:
        return config(), ""
    ov = _overrides()
    vals = dict(ov.get("values") or {})
    srcs = dict(ov.get("sources") or {})
    for key, raw in values.items():
        spec = SLIDERS.get(key)
        if spec is None:
            if key in TOGGLES:
                vals[key] = bool(raw)
                srcs[key] = source
                continue
            return None, f"'{key}' is not a cheap/expiry tunable"
        try:
            v = float(raw)
        except (TypeError, ValueError):
            return None, f"'{key}' must be a number"
        if v != v or v in (float("inf"), float("-inf")):
            return None, f"'{key}' must be a finite number"
        lo, hi = float(spec["min"]), float(spec["max"])
        if not lo <= v <= hi:
            return None, f"'{key}' must be between {lo:g} and {hi:g}"
        vals[key] = int(round(v)) if spec.get("int") else v
        srcs[key] = source
    st = _state()
    st["cheap_overrides"] = {"values": vals, "sources": srcs}
    _save_state(st)
    from database import brain_db as db

    shown = ", ".join(f"{k}={vals[k]}" for k in values)
    db.event("info", "cheap_tune", f"cheap/expiry sliders updated ({source}): {shown}")
    return config(), ""


def clear_overrides() -> dict[str, Any]:
    st = _state()
    st.pop("cheap_overrides", None)
    _save_state(st)
    from database import brain_db as db

    db.event("info", "cheap_tune", "cheap/expiry sliders reset to the .env base")
    return config()


def set_ai_overrides(values: dict[str, Any]) -> tuple[dict[str, Any] | None, str]:
    if not isinstance(values, dict) or not values:
        return config(), ""
    ov = _overrides()
    vals = dict(ov.get("values") or {})
    srcs = dict(ov.get("sources") or {})
    for key, raw in values.items():
        spec = SLIDERS.get(key)
        if spec is None:
            continue
        try:
            v = float(raw)
        except (TypeError, ValueError):
            return None, f"'{key}' must be a number"
        if v != v or v in (float("inf"), float("-inf")):
            return None, f"'{key}' must be a finite number"
        lo, hi = float(spec["min"]), float(spec["max"])
        if not lo <= v <= hi:
            return None, f"'{key}' must be between {lo:g} and {hi:g}"
        if srcs.get(key) == "manual":
            continue
        vals[key] = int(round(v)) if spec.get("int") else v
        srcs[key] = "ai"
    st = _state()
    st["cheap_overrides"] = {"values": vals, "sources": srcs}
    _save_state(st)
    from database import brain_db as db

    shown = ", ".join(f"{k}={vals[k]}" for k in values)
    db.event("info", "cheap_ai_tune", f"Brain AI adjusted cheap/expiry: {shown}")
    return config(), ""


# ---- orchestration hooks -----------------------------------------------------


def on_scan(
    underlying: str,
    chain: dict[str, Any] | None,
    bars: np.ndarray,
    spot: float,
    gw: Any,
    api_key: str | None,
    now: float,
) -> dict[str, Any]:
    """Called once per underlying per Brain scan. Manages open positions and
    collects premium bars; entries run through :func:`try_enter` separately."""
    from database import brain_db as db
    from services.brain.orchestrator import platform_mode

    cfg = load_config()
    out: dict[str, Any] = {}
    if not cfg["enable"]:
        return {"skipped": "disabled"}
    if not chain or not chain.get("rows"):
        return {"skipped": "no chain"}
    if not (api_key or "").strip():
        api_key = _resolve_key()
        if not (api_key or "").strip():
            return {"skipped": "no api key"}

    mode = platform_mode()
    if mode != "sandbox":
        now_d = time.strftime("%Y-%m-%d", time.gmtime(now))
        if now_d != db.state_get(PAPER_WARN_DAY_KEY):
            db.state_set(PAPER_WARN_DAY_KEY, now_d)
            mature = bool(_maturity_snapshot().get("eligible", False))
            if mode == "live" and mature:
                db.event(
                    "info",
                    "cheap_live_ready",
                    "cheap/expiry mature for live: entries permitted behind BRAIN_LIVE_ENABLED",
                )
            else:
                db.event(
                    "warn",
                    "cheap_paper_guard",
                    "cheap/expiry entries gated: platform not in analyzer mode and "
                    "cheap/expiry journal not yet mature for live (or live switch off)",
                )
        out["mode"] = mode

    managed = _manage_all(gw, cfg, now, bars)
    out["manage"] = managed

    if now - float(_collect_state.get(f"{underlying}:last", 0) or 0) >= COLLECT_MIN_INTERVAL_S:
        got = 0
        for sym in (chain.get("ce_symbol"), chain.get("pe_symbol")):
            if sym:
                got += collect_symbol(sym, api_key, _fo_exchange(underlying))
        if got:
            _collect_state[f"{underlying}:last"] = now
        out["collected"] = got
    return out


def _resolve_key() -> str:
    try:
        from services.brain.orchestrator import resolve_api_key

        return resolve_api_key() or ""
    except Exception:
        return ""


def _skip(underlying: str, reason: str, now: float) -> dict[str, Any]:
    from database import brain_db as db

    out = {"skipped": reason}
    try:
        last = _skip_log.get(underlying, 0.0)
        if now - last >= SKIP_LOG_INTERVAL_S:
            _skip_log[underlying] = now
            db.event("info", "cheap_skip", f"{underlying}: {reason}", {"underlying": underlying})
    except Exception:
        logger.exception("cheap: skip note failed for %s", underlying)
    return out


def try_enter(
    underlying: str,
    chain: dict[str, Any] | None,
    bars: np.ndarray,
    spot: float,
    gw: Any,
    now: float,
    brain: Any,
    data: Any = None,
    api_key: str = "",
) -> dict[str, Any]:
    """Paper entry: choose cheapest strike in range, size by rupee risk, dispatch."""
    from services.brain.orchestrator import entry_claim

    with entry_claim(f"cheap:{underlying}", timeout=0.0) as mine:
        if not mine:
            return {"skipped": "another pass is already entering this underlying"}
        return _try_enter_claimed(underlying, chain, bars, spot, gw, now, brain, data=data, api_key=api_key)


def _try_enter_claimed(
    underlying: str,
    chain: dict[str, Any] | None,
    bars: np.ndarray,
    spot: float,
    gw: Any,
    now: float,
    brain: Any,
    data: Any = None,
    api_key: str = "",
) -> dict[str, Any]:
    from database import brain_db as db
    from services.brain import executor as ex
    from services.brain import risk_gate
    from services.brain.orchestrator import learner, platform_mode

    cfg = load_config()
    if not cfg["enable"]:
        return {"skipped": "disabled"}
    degraded = bool(db.state_get("degraded", False))
    if degraded:
        db.event("warn", "cheap_drift_pause", "feature drift detected — cheap/expiry paused until drift settles")
        return {"skipped": "feature drift: cheap/expiry paused"}

    mode = platform_mode()
    if mode == "sandbox":
        pass  # paper entries allowed directly below; no maturity required
    elif mode == "live":
        # Cheap/expiry live trading requires the global live switch AND maturity
        # earned on the cheap/expiry journal alone. Auto-promotion: once the
        # cheap/expiry paper record passes live_eligible, live entries are
        # permitted behind BRAIN_LIVE_ENABLED — no separate code change needed.
        if not brain.limits.live_enabled:
            return {"skipped": "BRAIN_LIVE_ENABLED is false"}
        m = _maturity_snapshot()
        if not m["eligible"]:
            return {"skipped": f"cheap/expiry not yet mature for live: {', '.join(m['ineligible_reasons'])}"}
        try:
            from services.order_router_service import should_route_to_pending

            if api_key and should_route_to_pending(api_key, "placeorder"):
                return {"skipped": "order router requires approval"}
        except Exception:
            return {"skipped": "order router unavailable; standing aside"}
    else:
        return {"skipped": "paper-only"}

    if not chain or not chain.get("rows"):
        return {}
    _record_closed(now)

    open_all = db.positions_open()
    mine = [p for p in open_all if p.get("note") == NOTE]
    if len(mine) >= cfg["max_lots"]:
        return _skip(underlying, f"max open cheap positions ({len(mine)})", now)
    if any(p["underlying"] == underlying for p in mine):
        return _skip(underlying, "already holding this underlying", now)
    today0 = _ist0(now)
    trades_today = [
        p
        for p in db.positions_closed(today0)
        if p.get("note") == NOTE and (p.get("exit_ts") or 0) >= today0
    ]
    max_trades_day = cfg.get("max_trades_day", 6)
    if len(trades_today) >= max_trades_day:
        return _skip(underlying, "daily trade cap", now)

    # Entry window check.
    ist_minute = int((now + 19800) % 86400 / 60)  # IST offset
    if not (cfg["expiry_start"] <= ist_minute < cfg["expiry_cutoff"]):
        return _skip(underlying, f"outside cheap/expiry entry window ({cfg['expiry_start']}-{cfg['expiry_cutoff']} min)", now)

    fo_ex = _fo_exchange(underlying)
    dte = float(chain.get("dte") or 0)
    # The premium ceiling tightens near expiry and late in the day; this is the
    # live value used for filtering candidates each scan tick.
    premium_ceiling = effective_premium_ceiling(cfg, dte, ist_minute)

    # Select best strike: cheapest row whose mid falls in the target band.
    rows = chain["rows"]
    candidates: list[dict[str, Any]] = []
    for r in rows:
        for side, kind in (("CE", "ce"), ("PE", "pe")):
            bid = float(r.get(f"{kind}_bid") or 0)
            ask = float(r.get(f"{kind}_ask") or 0)
            ltp = float(r.get(f"{kind}_ltp") or 0)
            mid = (bid + ask) / 2.0 if bid > 0 and ask > 0 else ltp
            if mid <= 0:
                continue
            delta_raw = float(r.get(f"{kind}_delta") or 0)
            # Accept both CE (positive) and PE (negative); band_of uses abs.
            delta_abs = abs(delta_raw)
            if not (cfg["premium_min"] <= mid <= premium_ceiling):
                continue
            oi = float(r.get(f"{kind}_oi") or 0)
            if oi <= 0:
                continue
            spread = ask - bid if bid > 0 and ask > 0 else 0.0
            spread_pct = spread / mid * 100.0 if mid > 0 else 99.0
            # Spread gate: percentage OR tick-based, whichever is tighter.
            tick_value = (r.get(f"{kind}_tick_size") or 0.05)
            max_allowed = max(cfg["max_spread_ticks"] * tick_value, mid * 0.03)
            if spread > max_allowed:
                continue
            candidates.append(
                {
                    "side": side,
                    "mid": mid,
                    "delta_abs": delta_abs,
                    "spread_pct": spread_pct,
                    "spread": spread,
                    "oi": oi,
                    "row": r,
                    "reach_sigma": compute_reach_sigma(mid, delta_abs, dte),
                }
            )
    if not candidates:
        return _skip(underlying, "no candidate in premium band", now)
    # Prefer candidates with lower reach_sigma (cheaper to double) and adequate OI.
    candidates.sort(key=lambda c: (c["reach_sigma"], -c["oi"]))
    cand = candidates[0]
    row = cand["row"]
    side = cand["side"]
    symbol = str(row.get(f"{side.lower()}_symbol") or "")
    if not symbol:
        return _skip(underlying, "no broker symbol for the strike", now)
    bid = float(row.get(f"{side.lower()}_bid") or 0)
    ask = float(row.get(f"{side.lower()}_ask") or 0)
    mid = (bid + ask) / 2.0 if bid > 0 and ask > 0 else float(row.get(f"{side.lower()}_ltp") or 0)
    lot_size = int(row.get(f"{side.lower()}_lotsize") or chain.get("lot_size") or 1)

    # Premium sigma for the chosen contract.
    pbars = premium_bars(symbol, _resolve_key(), exchange=fo_ex)
    sigma_h = _premium_sigma_h(pbars, cfg.get("horizon_bars", 12)) if pbars is not None else None

    lv = plan_levels(mid, cfg, cand["spread"], sigma_h)
    capital = paper_equity()
    lots, size_reason = size_lots(lv["risk_per_unit"], lot_size, capital, cfg["max_lots"], cfg["risk_rupees"])
    if lots <= 0:
        return _skip(underlying, f"sizing failed: {size_reason}", now)

    proposal = risk_gate.Proposal(
        mid, lot_size, cand["spread_pct"], lv["risk_per_unit"], band=band_of(cand["delta_abs"]), dte=dte
    )
    # --- feature gate: symbol exclusion, IV regime, momentum, drawdown halt ---
    from services.brain import gate as _gate
    from services.brain.types import Candidate, Snapshot
    try:
        source = data if data is not None else _DataShim(bars)
        state = brain.gate_state(source, gw, now, 0.0, 0.0)
    except Exception:
        logger.exception("cheap: gate state unavailable; standing aside")
        return _skip(underlying, "gate state error", now)
    snap_cheap = Snapshot(
        underlying=underlying,
        ts=now,
        bars=bars,
        spot=spot,
        lot_size=lot_size,
        bench_close=None,
        chain=chain,
        iv_rank=None,
        vix=None,
        minute_of_day=int(((now + 19800) // 300) % (24 * 60)),
        params=None,
    )
    cand_cheap = Candidate(
        underlying=underlying,
        side="LONG",
        regime="trend",
        score=float(cand.get("mid", 0.0) and 0.5),
        agree=1,
        prob=0.5,
        prob_prior=0.5,
        ev_r=0.0,
        rr=float(cfg.get("rr", 1.5)),
        sigma_h=0.0,
        k_stop=float(cfg.get("k_stop", 0.8)),
        k_target=float(cfg.get("rr", 1.5)),
        horizon_bars=int(cfg.get("horizon_bars", 12)),
        features={},
        votes={"cheap": 0.5},
        position_type="long",
    )
    kept, gate_reasons = _gate.apply_gate(
        [cand_cheap],
        snap_cheap,
        None,
        daily_pnl=state.equity,
        equity_peak=state.peak_equity,
        consecutive_losses=state.consecutive_losses,
        knobs=_knobs.CURRENT_TUNE_KNOBS,
        limits=brain.limits,
    )
    if not kept:
        return _skip(underlying, "feature gate: " + "; ".join(gate_reasons.values()))
    try:
        verdict = risk_gate.check_entry(brain.limits, state, proposal)
    except Exception:
        logger.exception("cheap: risk gate unavailable; standing aside")
        return _skip(underlying, "risk gate error", now)
    if not verdict.allow:
        return _skip(underlying, "risk gate: " + "; ".join(verdict.reasons), now)

    lots = verdict.lots
    qty = lots * lot_size
    pid = db.position_add(
        {
            "signal_id": None,
            "underlying": underlying,
            "symbol": symbol,
            "exchange": fo_ex,
            "option_type": side,
            "side": side,
            "strike": float(row.get("strike") or 0),
            "expiry": str(chain.get("expiry") or ""),
            "lots": lots,
            "qty": qty,
            "lot_size": lot_size,
            "mode": platform_mode(),
            "state": "PENDING",
            "entry_price": mid,
            "entry_ts": now,
            "entry_bar_ts": float(bars[-1, 0]),
            "initial_stop": lv["stop"],
            "stop_price": lv["stop"],
            "target_price": lv["target"],
            "trail_trigger": lv["trail_trigger"],
            "trail_gap": lv["trail_gap"],
            "highest_price": mid,
            "lowest_price": mid,
            "risk_per_unit": lv["risk_per_unit"],
            "deadline_ts": now + lv["deadline_s"],
            "model_version": 0,
            "note": NOTE,
            "band": band_of(cand["delta_abs"]),
        }
    )
    ok, order_id, err = gw.dispatch(platform_mode(), ex._order(symbol, fo_ex, "BUY", qty))
    if not ok:
        db.position_update(pid, state="CLOSED", exit_reason=f"entry refused: {err}", exit_ts=time.time(), pnl=0.0)
        db.event("warn", "cheap_entry_refused", f"cheap {symbol}: {err}", {"position_id": pid})
        return {"entered": False, "error": err}
    fill = gw.fill_price(platform_mode(), order_id) or mid
    db.position_update(
        pid,
        state="OPEN",
        entry_order_id=order_id or "",
        entry_price=fill,
        initial_stop=lv["stop"],
        stop_price=lv["stop"],
        target_price=lv["target"],
        trail_trigger=lv["trail_trigger"],
        trail_gap=lv["trail_gap"],
        highest_price=fill,
        lowest_price=fill,
    )
    db.event(
        "info",
        "cheap_entry",
        (
            f"cheap BUY {qty} {symbol} @ {fill:.2f} "
            f"(stop {lv['stop']:.2f}, target {lv['target']:.2f}, lots {lots}, "
            f"premium {mid:.2f}, delta {cand['delta_abs']:.2f}, dte {dte:.1f})"
        ),
        {"position_id": pid},
    )
    return {"entered": True, "pid": pid, "side": side, "symbol": symbol, "fill": fill}


def _premium_sigma_h(bars5: np.ndarray | None, horizon_bars: int) -> float | None:
    if bars5 is None or len(bars5) < 10:
        return None
    closes = np.asarray(bars5[:, 4], dtype=float)
    if np.any(closes <= 0):
        return None
    rets = np.diff(np.log(closes))
    tail = rets[-40:] if len(rets) >= 10 else rets
    if len(tail) < 5:
        return None
    sigma_bar = float(np.std(tail))
    return float(sigma_bar * np.sqrt(max(int(horizon_bars), 1)))


def _manage_all(gw: Any, cfg: dict[str, Any], now: float, bars: np.ndarray) -> list[dict[str, Any]]:
    """Stop/target/trail/time via the shared risk core plus our own deadline check."""
    from database import brain_db as db
    from services.brain import executor as ex
    from services.brain.orchestrator import _ist
    from services.risk import evaluate_position

    out: list[dict[str, Any]] = []
    for pos in db.positions_open():
        if pos.get("note") != NOTE:
            continue
        pid = int(pos["id"])
        if pos["state"] == "PENDING":
            if now - float(pos["entry_ts"]) > ex.PENDING_TIMEOUT_S:
                db.event(
                    "error",
                    "cheap_pending_stuck",
                    f"{pos['symbol']}: entry unresolved after {ex.PENDING_TIMEOUT_S:.0f}s",
                    {"position_id": pid},
                )
            continue
        if pos["state"] != "OPEN":
            continue
        ltp = gw.quote(pos["symbol"], pos["exchange"])
        if ltp is None:
            out.append({"id": pid, "action": "no_quote"})
            continue
        d = evaluate_position(ex._risk(pos), ltp)
        if d.evaluated:
            move = ltp - float(pos["entry_price"])
            db.position_update(
                pid,
                stop_price=d.stop_price,
                highest_price=d.highest_price,
                lowest_price=d.lowest_price,
                mfe=max(float(pos.get("mfe") or 0), move),
                mae=min(float(pos.get("mae") or 0), move),
            )
        # Hard deadline: cheap/expiry positions never carry overnight — exit by
        # expiry_squareoff_min or whenever the bar clock passes the configured
        # cutoff, whichever comes first. This avoids theta bleed eating into
        # thin premiums.
        deadline_ts = float(pos.get("deadline_ts") or 0)
        if deadline_ts > 0 and now >= deadline_ts:
            db.event("info", "cheap_deadline_exit", f"{pos['symbol']}: deadline reached, closing", {"position_id": pid})
            _, _, reason = ex.exit_position(
                gw, pid, "deadline", ltp, None, now
            )
            out.append({"id": pid, "action": "deadline_exit", "reason": reason})
            continue
        # Stop/target via risk core.
        if d.evaluated and d.action in ("STOP", "TARGET"):
            action = "target" if d.action == "TARGET" else "stop"
            _, _, reason = ex.exit_position(gw, pid, action, ltp, None, now)
            out.append({"id": pid, "action": action, "reason": reason})
        # Time decay: cut any position older than horizon_bars * 5 minutes.
        entry_ts = float(pos.get("entry_ts") or 0)
        hold_bars = cfg.get("horizon_bars", 12)
        max_hold_s = hold_bars * 300.0
        if now - entry_ts > max_hold_s:
            _, _, reason = ex.exit_position(gw, pid, "time", ltp, None, now)
            out.append({"id": pid, "action": "time", "reason": reason})
    return out


class _DataShim:
    """Thin wrapper so ``brain.gate_state`` gets something iterable when called from tests."""

    def __init__(self, bars: np.ndarray) -> None:
        self.bars = bars
