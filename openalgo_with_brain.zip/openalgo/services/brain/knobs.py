"""Tune-knobs: the control parameters the Brain's auto-tuners and self-tuners
read at runtime.

Unlike ``RiskLimits`` (human-owned, editable via /brain/api/limits) and
``TunableParams`` (machine-owned, set by the learner via /brain/api/params),
these knobs govern *how* the self-tuners behave: throttles, bands, sample
sizes, probe intervals, and the hard floors/ceilings that keep auto-tuning
from collapsing into noise.

Every field is editable at runtime via
``POST /brain/api/tune-knobs`` and takes effect on the next tick — no restart,
no .env write. A human edit marks the knob "manual" so the corresponding
self-tuner stops nudging it.

The learner and the cheap/expiry sidecar have their own auto-tuners; those
read these knobs too, so one control surface governs every self-tuner in the
Brain.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any


@dataclass(frozen=True, slots=True)
class BrainTuneParams:
    # ── Brain auto-tune: _auto_tune_brain_limits (orchestrator) ──────────
    auto_tune_recent_n: int = 10
    auto_tune_min_samples: int = 5
    auto_tune_loosen_min_samples: int = 8
    auto_tune_loosen_sigmas: float = 1.645
    auto_tune_band_r: float = 0.10
    auto_tune_throttle_s: float = 300.0

    # ── Premium auto-cap: _auto_tune_premium_cap (orchestrator) ──────────
    premium_cap_throttle_s: float = 300.0
    premium_cap_probe_interval_s: float = 4.0 * 3600.0
    premium_cap_probe_window_s: float = 90.0 * 60.0

    # ── IV band tuning: _auto_tune_iv_band (orchestrator) + gate.iv_band ──
    iv_tune_throttle_s: float = 600.0
    iv_tune_min_samples: int = 20
    iv_band_hard_floor: float = 0.05
    iv_band_hard_ceiling: float = 0.95

    # ── Adaptive bar-lag ceiling: _adaptive_bar_lag_threshold ────────────
    bar_lag_tune_window: int = 20
    bar_lag_tune_buffer_s: float = 60.0

    # ── PPA auto-tune: _auto_tune_ppa (orchestrator) ─────────────────────
    ppa_tune_min_samples: int = 30
    ppa_tune_band_r: float = 0.25
    ppa_tune_recent_n: int = 30

    # ── Cheap/expiry auto-tune: _auto_tune (premiumCheapExp) ─────────────
    cheap_tune_min_samples: int = 8
    cheap_tune_band_r: float = 0.25
    cheap_tune_recent_n: int = 10
    cheap_tune_throttle_s: float = 5.0 * 60.0

    # ── Learner constants ────────────────────────────────────────────────
    min_trades_to_judge: int = 20
    promote_margin_r: float = 0.005
    promote_sigmas: float = 2.0
    holdout_embargo_days: int = 7
    skill_sigmas: float = 3.0
    skill_min_eff: float = 40.0
    rollback_min_trades: int = 20
    rollback_lcb_r: float = -0.15
    drift_limit: float = 0.5
    drift_min_features: int = 2
    live_min_model_neff: float = 60.0

    # ── Engine parameter search ──────────────────────────────────────────
    engine_param_search_budget_s: float = 150.0
    engine_param_min_trades: int = 40
    engine_param_underlyings: int = 2

    # ── Tuner grid step fractions ────────────────────────────────────────
    max_step_fraction: float = 0.2
    boot_step_fraction: float = 0.5

    # ── name -> (low, high) bounds for slider validation ─────────────────
    TUNE_BOUNDS: dict[str, tuple[float, float]] = field(
        default_factory=lambda: {
            "auto_tune_recent_n": (1, 100),
            "auto_tune_min_samples": (1, 50),
            "auto_tune_loosen_min_samples": (1, 50),
            "auto_tune_loosen_sigmas": (0.5, 5.0),
            "auto_tune_band_r": (0.01, 1.0),
            "auto_tune_throttle_s": (30.0, 3600.0),
            "premium_cap_throttle_s": (30.0, 3600.0),
            "premium_cap_probe_interval_s": (300.0, 86400.0),
            "premium_cap_probe_window_s": (60.0, 86400.0),
            "iv_tune_throttle_s": (60.0, 3600.0),
            "iv_tune_min_samples": (5, 200),
            "iv_band_hard_floor": (0.01, 0.50),
            "iv_band_hard_ceiling": (0.50, 0.99),
            "bar_lag_tune_window": (3, 200),
            "bar_lag_tune_buffer_s": (0.0, 600.0),
            "ppa_tune_min_samples": (5, 200),
            "ppa_tune_band_r": (0.01, 1.0),
            "ppa_tune_recent_n": (1, 100),
            "cheap_tune_min_samples": (1, 50),
            "cheap_tune_band_r": (0.01, 1.0),
            "cheap_tune_recent_n": (1, 100),
            "cheap_tune_throttle_s": (30.0, 3600.0),
            "min_trades_to_judge": (5, 200),
            "promote_margin_r": (0.001, 0.10),
            "promote_sigmas": (0.5, 5.0),
            "holdout_embargo_days": (0, 30),
            "skill_sigmas": (0.5, 5.0),
            "skill_min_eff": (5.0, 500.0),
            "rollback_min_trades": (5, 200),
            "rollback_lcb_r": (-2.0, 0.0),
            "drift_limit": (0.01, 5.0),
            "drift_min_features": (1, 20),
            "live_min_model_neff": (5.0, 500.0),
            "engine_param_search_budget_s": (10.0, 900.0),
            "engine_param_min_trades": (5, 200),
            "engine_param_underlyings": (1, 10),
            "max_step_fraction": (0.01, 1.0),
            "boot_step_fraction": (0.01, 1.0),
        }
    )

    INT_TUNE_PARAMS: frozenset[str] = field(
        default_factory=lambda: frozenset(
            {
                "auto_tune_recent_n",
                "auto_tune_min_samples",
                "auto_tune_loosen_min_samples",
                "iv_tune_min_samples",
                "bar_lag_tune_window",
                "ppa_tune_min_samples",
                "ppa_tune_recent_n",
                "cheap_tune_min_samples",
                "cheap_tune_recent_n",
                "min_trades_to_judge",
                "holdout_embargo_days",
                "drift_min_features",
                "engine_param_min_trades",
                "engine_param_underlyings",
            }
        )
    )

    def clamp(self) -> BrainTuneParams:
        """Return a copy with every value forced inside its hard bounds."""
        updates: dict[str, Any] = {}
        for name, (lo, hi) in self.TUNE_BOUNDS.items():
            value = float(getattr(self, name))
            value = min(max(value, lo), hi)
            if name in self.INT_TUNE_PARAMS:
                updates[name] = int(round(value))
            else:
                updates[name] = float(value)
        return replace(self, **updates)

    def to_dict(self) -> dict[str, Any]:
        return {n: getattr(self, n) for n in self.TUNE_BOUNDS}

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> BrainTuneParams:
        data = data or {}
        known = {k: data[k] for k in cls.TUNE_BOUNDS if k in data}
        return cls(**known).clamp()


#: Singleton default — used before BrainService creates its own instance.
DEFAULT_TUNE_KNOBS = BrainTuneParams()

#: Current tune-knobs in effect across all modules. BrainService replaces this
#: with its own instance on startup; the API writes here so every module that
#: reads ``knobs.CURRENT_TUNE_KNOBS`` picks up the change on the next call.
CURRENT_TUNE_KNOBS: BrainTuneParams = BrainTuneParams()
