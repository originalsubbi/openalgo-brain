"""Execution & Position Management.

Turns an approved candidate into an option order and then looks after it until
it is closed. Three things from CLAUDE.md shape this file:

* **Mode is per position, fixed at entry.** A position remembers whether it was
  opened in the sandbox or live and every later order for it goes to that pipe.
  The global analyzer toggle is never consulted for an exit, so flipping it
  cannot divert a live position's stop into the sandbox.
* **A live position is bound to its broker.** The broker (and account) that took
  the entry is recorded on the position row before the order goes out, and every
  later order and fill read for it carries that binding: order_dispatch refuses
  one whose session is on another broker, so a position is only ever managed
  through the broker that holds it.
* **Claim, then dispatch, and a refused dispatch releases.** The exit marker is
  written by one compare-and-set before the order is sent. If the broker
  refuses, the claim is released and the position goes back under management,
  because it is still held.
* **Stops come from ``services.risk``.** ``evaluate_position`` decides stop,
  target and trailing. Nothing here reimplements them.

All broker access goes through a ``Gateway`` so the logic is testable without a
broker. ``OpenAlgoGateway`` is the production one.
"""

from __future__ import annotations

import math
import re
import time
from datetime import date, datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any, Protocol

from database import brain_db as db
from services.brain.bands import BANDS
from services.brain.config import RiskLimits, TunableParams
from services.brain.spreads import spread_value
from services.brain.types import Candidate
from services.risk import PositionRisk, Side, TrailMode, evaluate_position
from utils.logging import get_logger

if TYPE_CHECKING:
    from services.strategy_module.order_dispatch import BrokerBinding

logger = get_logger(__name__)

STRATEGY_TAG = "AIBrain"
MIN_RETRY_S = 15.0  # between attempts to close one position after a refusal
PENDING_TIMEOUT_S = 90.0
# CLOSING means an exit was claimed and dispatched; unless the dispatch completes
# within a few seconds the row is stuck (crash mid-flight) and must be released
# back to OPEN so manage() can take over again.
CLOSING_STALE_S = 300.0
# A position whose deadline has passed but remains OPEN is a dead feed symptom:
# manage() never received an LTP, so the time-stop never fired and the row sits
# forever. Force-close it as "stale_broker_session" rather than letting it drift
# while the broker session is actually live elsewhere.
STALE_DEADLINE_S = 600.0
# Reconcile runs every 5 min, but on a fresh boot the gateway book may not have
# fully repopulated yet (broker WS reconnect, sandbox bridge init, etc.). Skip
# the aggressive "closed outside" close for the first RECONCILE_BOOTSTRAP_S
# seconds after the first reconcile call so existing positions survive a restart.
RECONCILE_BOOTSTRAP_S = 90.0
_reconcile_boot_ts: float = 0.0
_last_exit_attempt: dict[int, float] = {}

# --- horizon & expiry arithmetic ---------------------------------------------
#: 5-minute market bars in one trading day (6.5 h x 12). A horizon expressed in
#: bars is market time, not wall time: turning it into a deadline needs this
#: and CALENDAR_DAYS_PER_TRADING_DAY below, never a plain ``bars x 300 s``.
BARS_PER_TRADING_DAY = 78.0
#: Five trading sessions span seven calendar days. The old arithmetic treated
#: every 300-second bar as continuous wall time, which compressed a "20 trading
#: day" positional hold into 5.4 calendar days — the deadline fired while the
#: trade was still in its first week.
CALENDAR_DAYS_PER_TRADING_DAY = 7.0 / 5.0
#: On expiry day an open option is out by this IST minute: after the settlement-pin
#: and gamma behaviour of the last minutes is not something a stop/target policy
#: built for multi-day holds can price. Human-owned via ``BRAIN_EXPIRY_SQUAREOFF``;
#: the default mirrors intraday entry cut-off so both gates agree unless you change it.
EXPIRY_EXIT_MIN_DEFAULT = 14 * 60 + 45
#: An expiry the Brain is allowed to reach when a hold horizon demands a farther
#: contract than the tunable DTE band allows (hard cap, not a preference).
MAX_HORIZON_DTE_CAP = 45

_SYMBOL_EXPIRY_RE = re.compile(r"(\d{1,2}[A-Z]{3}\d{2})")


def _ist_now(now: float) -> datetime:
    return datetime.fromtimestamp(now, tz=timezone(timedelta(hours=5, minutes=30)))


def horizon_deadline(now: float, horizon_bars: int) -> float:
    """A market-bar horizon as a wall-clock deadline.

    ``horizon_bars`` counts 5-minute market bars (BARS_PER_TRADING_DAY of them
    to a session). Trading days expand to calendar days at 7/5, so a swing
    trade that means to live 10 sessions gets a deadline two weeks out rather
    than one that fires mid-week-one.
    """
    trading_days = max(float(horizon_bars), 0.0) / BARS_PER_TRADING_DAY
    return now + trading_days * CALENDAR_DAYS_PER_TRADING_DAY * 86400.0


def _pos_expiry_date(pos: dict[str, Any]) -> date | None:
    """The calendar date the position's contract expires, or None when unknown.

    Prefers the recorded ``expiry`` column; positions opened before that column
    was populated are recovered from the symbol itself — option symbols carry
    the expiry right after the underlying name (SENSEX19NOV2682000CE).
    """
    raw = str(pos.get("expiry") or "").strip().upper().replace("-", "")
    if not raw:
        m = _SYMBOL_EXPIRY_RE.search(str(pos.get("symbol") or "").upper())
        raw = m.group(1) if m else ""
    if not raw:
        return None
    try:
        return datetime.strptime(raw, "%d%b%y").date()
    except ValueError:
        return None


def _force_close_expired(pos: dict[str, Any], now: float) -> bool:
    """Ledger-close a position whose contract can no longer trade.

    A expired option cannot be sold: the venue refuses the order, so the row
    would otherwise sit OPEN forever, quoting nothing, while reconcile keeps
    reporting it. The close is written without a P&L — no fabricated mark-out
    for the learner to train on; the note points at the settlement.
    """
    pid = int(pos["id"])
    if not db.position_claim_exit(pid, "expiry"):
        return False  # an exit is already in flight
    _last_exit_attempt.pop(pid, None)  # the row is dead; its retry stamp must not linger
    db.position_update(
        pid,
        state="CLOSED",
        exit_reason="contract expired; unfillable at the venue",
        exit_ts=now,
        note="expired; premium lost to settlement, P&L left to reconciliation",
    )
    db.event(
        "warn",
        "expired_position_closed",
        f"{pos['symbol']}: contract expired under management; ledger closed without a mark-out",
        {"position_id": pid},
    )
    return True


class Gateway(Protocol):
    def quote(self, symbol: str, exchange: str) -> float | None: ...
    def dispatch(
        self, mode: str, order: dict[str, Any], binding: BrokerBinding | None = None
    ) -> tuple[bool, str | None, str | None]: ...
    def fill_price(
        self, mode: str, order_id: str | None, binding: BrokerBinding | None = None
    ) -> float | None: ...
    def positionbook(self, mode: str) -> list[dict[str, Any]] | None: ...
    def session_binding(self) -> BrokerBinding | None: ...


class OpenAlgoGateway:
    """The production gateway: OpenAlgo's own services, no broker code of ours."""

    def __init__(self, api_key: str) -> None:
        self.api_key = api_key

    def quote(self, symbol: str, exchange: str) -> float | None:
        from services.quotes_service import get_quotes

        ok, resp, _ = get_quotes(symbol, exchange, api_key=self.api_key)
        if not ok:
            return None
        try:
            v = float((resp.get("data") or {}).get("ltp"))
        except (TypeError, ValueError):
            return None
        return v if v > 0 else None

    def dispatch(
        self, mode: str, order: dict[str, Any], binding: BrokerBinding | None = None
    ) -> tuple[bool, str | None, str | None]:
        from services.strategy_module.order_dispatch import dispatch_order

        r = dispatch_order(mode=mode, api_key=self.api_key, order=order, binding=binding)
        return r.ok, r.broker_order_id, r.error

    def fill_price(
        self, mode: str, order_id: str | None, binding: BrokerBinding | None = None
    ) -> float | None:
        if not order_id:
            return None
        from services.strategy_module.order_dispatch import fetch_order_status

        r = fetch_order_status(
            mode=mode, api_key=self.api_key, broker_order_id=order_id, binding=binding
        )
        if not r.ok or not r.order:
            return None
        for key in ("average_price", "price"):
            try:
                v = float(r.order.get(key))
                if v > 0:
                    return v
            except (TypeError, ValueError):
                continue
        return None

    def session_binding(self) -> BrokerBinding | None:
        """The broker (and account) logged in for this key, as a record for a live entry.

        A binding whose broker is "" means no usable session: an entry journalled
        with it is refused by ``dispatch_order`` with its own message, fail-safe,
        until a broker is logged in again.
        """
        from services.strategy_module.order_dispatch import BrokerBinding, resolve_session

        _token, broker, account, _error = resolve_session(self.api_key)
        return BrokerBinding(broker=broker or "", account=account)

    def positionbook(self, mode: str) -> list[dict[str, Any]] | None:
        # get_positionbook routes to the sandbox book when the analyzer is on and to
        # the broker otherwise; the caller only reconciles positions of the matching mode.
        from services.positionbook_service import get_positionbook

        ok, resp, _ = get_positionbook(api_key=self.api_key)
        if not ok:
            return None
        data = resp.get("data")
        return data if isinstance(data, list) else None


# --- pure planning -----------------------------------------------------------
def select_leg(chain: dict[str, Any], side: str, spot: float) -> dict[str, Any] | None:
    """Pick the option to buy: CE for LONG, PE for SHORT, near the money, liquid.

    Prefers a delta near 0.55 (responsive, not all time value) and punishes a wide
    bid-ask spread. Returns None when no leg has a usable two-sided quote.
    """
    legs = select_legs(chain, side, spot)
    return legs.get("ATM") or (next(iter(legs.values())) if legs else None)


def select_legs(
    chain: dict[str, Any],
    side: str,
    spot: float,
    min_oi: int = 0,
) -> dict[str, dict[str, Any]]:
    """Pick one liquid option leg per moneyness band (ITM / ATM / OTM).

    Every band is scored the same way ``select_leg`` always scored its near-ATM
    candidates: distance from the band's target delta plus a spread penalty. The
    result carries each leg's gamma and the chain's DTE so the signal journal and
    the band learner can grade which moneyness actually pays. A band with no row
    that has a usable two-sided quote is simply absent from the result.

    ``min_oi`` is an open-interest floor: a strike with a handful of contracts
    outstanding is not a strike to put real money on, whatever its spread says.
    """
    kind = "ce" if side == "LONG" else "pe"
    sign = 1.0 if kind == "ce" else -1.0  # puts carry negative delta
    rows = sorted(chain.get("rows") or [], key=lambda r: abs(float(r.get("strike", 0)) - spot))[:10]
    dte = float(chain.get("dte") or 0.0)
    out: dict[str, dict[str, Any]] = {}
    for band, (lo, hi, target) in BANDS.items():
        best, best_score = None, -1e9
        for r in rows:
            bid, ask, ltp = (
                float(r.get(f"{kind}_bid") or 0),
                float(r.get(f"{kind}_ask") or 0),
                float(r.get(f"{kind}_ltp") or 0),
            )
            symbol = r.get(f"{kind}_symbol")
            if not symbol or ltp <= 0:
                continue
            oi = float(r.get(f"{kind}_oi") or 0)
            if min_oi and oi < min_oi:
                continue
            delta = abs(float(r.get(f"{kind}_delta") or 0) or 0)
            if not (lo <= delta <= hi):
                continue
            mid = (bid + ask) / 2.0 if bid > 0 and ask > 0 else ltp
            spread_pct = (ask - bid) / mid * 100.0 if bid > 0 and ask > 0 else 99.0
            score = -abs(delta - target) * 10.0 - spread_pct
            if score > best_score:
                best_score = score
                out[band] = {
                    "band": band,
                    "symbol": symbol,
                    "strike": float(r["strike"]),
                    "option_type": kind.upper(),
                    "expiry": str(chain.get("expiry") or ""),
                    "ltp": ltp,
                    "bid": bid,
                    "ask": ask,
                    "entry": ask if ask > 0 else ltp,
                    "delta": delta if kind == "ce" else abs(delta) * sign,
                    "gamma": float(r.get(f"{kind}_gamma") or 0.0),
                    "dte": dte,
                    "oi": oi,
                    "spread_pct": spread_pct,
                    "lot_size": int(chain.get("lot_size") or r.get(f"{kind}_lotsize") or 1),
                }
    return out


def plan_levels(
    cand: Candidate, leg: dict[str, Any], spot: float, params: TunableParams
) -> dict[str, float]:
    """Translate the underlying's barrier geometry into option-premium levels.

    First-order: premium risk = |delta| x the underlying's stop distance, clamped
    to between 8% and 45% of the premium so a tiny delta or a huge sigma cannot
    produce a stop that is either inside the spread or past zero.
    """
    entry = float(leg["entry"])
    stop_dist_underlying = spot * cand.k_stop * cand.sigma_h
    risk = abs(leg["delta"]) * stop_dist_underlying
    risk = min(max(risk, 0.08 * entry), 0.45 * entry)
    return {
        "entry": entry,
        "risk_per_unit": risk,
        "stop": entry - risk,
        "target": entry + risk * cand.rr,
        "trail_trigger": params.trail_trigger_r * risk,
        "trail_gap": params.trail_gap_r * risk,
    }


def plan_levels_short(geo: dict[str, Any], params: TunableParams) -> dict[str, float]:
    """The levels of a credit spread, measured on the spread's own price.

    Entry is the credit received. The stop is the strike width — past it the
    spread is worth nothing. The target is half the credit back. The risk unit
    is the width minus the credit, which is what a short spread can actually
    lose.
    """
    credit = float(geo["credit"])
    max_loss = float(geo["max_loss"])
    target = float(geo["target_value"])
    return {
        "entry": credit,
        "risk_per_unit": max_loss,
        "stop": max_loss,
        "target": target,
        "trail_trigger": params.trail_trigger_r * credit,
        "trail_gap": params.trail_gap_r * credit,
    }


def _order(symbol: str, exchange: str, action: str, qty: int) -> dict[str, Any]:
    from services.strategy_module.order_dispatch import build_order

    return build_order(
        symbol=symbol,
        exchange=exchange,
        action=action,
        quantity=qty,
        product="MIS",
        strategy_name=STRATEGY_TAG,
    )


def _binding_of(pos: dict[str, Any]) -> BrokerBinding | None:
    """The binding a position's live orders are held to, from its own record.

    A live row holding "" (a session that had expired at entry, or a position
    opened before the record existed) stays unbound: order_dispatch refuses its
    orders rather than sending them to whichever broker is logged in. No live
    position could have opened before the record did — the unbound refusal is
    older than it — so nothing live is stranded by an empty record in practice.
    """
    if pos.get("mode") != "live":
        return None
    from services.strategy_module.order_dispatch import BrokerBinding

    return BrokerBinding(broker=str(pos.get("broker") or ""), account=pos.get("broker_account"))


# --- entry -------------------------------------------------------------------
def enter(
    gw: Gateway,
    cand: Candidate,
    leg: dict[str, Any],
    lots: int,
    mode: str,
    signal_id: int,
    spot: float,
    params: TunableParams,
    model_version: int,
    exchange: str = "NFO",
    now: float | None = None,
) -> tuple[bool, int | None, str]:
    """Open a long-premium position: buy one option leg.

    For a short-premium candidate use :func:`enter_spread`, which sells one leg
    and buys a protective one.
    """
    now = now or time.time()
    qty = lots * int(leg["lot_size"])
    lv = plan_levels(cand, leg, spot, params)
    # A live entry binds the position to the broker logged in now. The record is
    # journalled with the row, before the order, so even a crash leaves behind
    # what the position trades on. With no session the row records "" and the
    # dispatch is refused with its own message — the entry is journalled failed.
    binding = None
    if mode == "live":
        from services.strategy_module.order_dispatch import BrokerBinding

        binding = gw.session_binding() or BrokerBinding(broker="", account=None)
    # Journal the intent first. If the process dies between dispatch and the next
    # write, reconcile() finds a PENDING row instead of an unexplained broker position.
    pid = db.position_add(
        {
            "signal_id": signal_id,
            "underlying": cand.underlying,
            "symbol": leg["symbol"],
            "exchange": exchange,
            "option_type": leg["option_type"],
            "strike": leg["strike"],
            "lots": lots,
            "qty": qty,
            "lot_size": int(leg["lot_size"]),
            "mode": mode,
            "broker": (binding.broker if binding else "") or "",
            "broker_account": binding.account if binding else None,
            "state": "PENDING",
            "entry_price": lv["entry"],
            "entry_ts": now,
            "initial_stop": lv["stop"],
            "stop_price": lv["stop"],
            "target_price": lv["target"],
            "trail_trigger": lv["trail_trigger"],
            "trail_gap": lv["trail_gap"],
            "highest_price": lv["entry"],
            "lowest_price": lv["entry"],
            "risk_per_unit": lv["risk_per_unit"],
            "expiry": str(leg.get("expiry") or ""),
            "deadline_ts": horizon_deadline(now, cand.horizon_bars),
            "model_version": model_version,
            "side": cand.side,
            "position_type": cand.position_type,
            "band": leg.get("band") or "",
        }
    )
    ok, order_id, err = gw.dispatch(
        mode, _order(leg["symbol"], exchange, "BUY", qty), binding=binding
    )
    if not ok:
        db.position_update(
            pid,
            state="CLOSED",
            exit_reason=f"entry refused: {err}",
            exit_ts=time.time(),
            pnl=0.0,
            note="never filled",
        )
        db.event("warn", "entry_refused", f"{leg['symbol']}: {err}", {"signal_id": signal_id})
        # The signal led nowhere: mark it BLOCKED so it does not sit in SUGGESTED
        # forever and the UI shows the attempt was made.
        db.signal_update(signal_id, status="BLOCKED")
        return False, None, err or "order refused"
    fill = gw.fill_price(mode, order_id, binding) or lv["entry"]
    shift = (
        fill - lv["entry"]
    )  # keep the stop and target the planned distance from the *actual* fill
    db.position_update(
        pid,
        state="OPEN",
        entry_order_id=order_id or "",
        entry_price=fill,
        initial_stop=lv["stop"] + shift,
        stop_price=lv["stop"] + shift,
        target_price=lv["target"] + shift,
        highest_price=fill,
        lowest_price=fill,
    )
    db.signal_update(signal_id, status="TRADED", position_id=pid)
    db.event(
        "info",
        "entry",
        f"{mode} BUY {qty} {leg['symbol']} @ {fill:.2f}",
        {"position_id": pid, "signal_id": signal_id},
    )
    return True, pid, "ok"


def enter_spread(
    gw: Gateway,
    cand: Candidate,
    geo: dict[str, Any],
    lots: int,
    mode: str,
    signal_id: int,
    params: TunableParams,
    model_version: int,
    exchange: str = "NFO",
    now: float | None = None,
) -> tuple[bool, int | None, str]:
    """Open a credit spread: sell one leg, buy a further out-of-the-money one.

    The row's prices are the SPREAD's prices, so the risk core reads the
    position as a short whose value falls when the trade wins. The sold leg is
    the row's ``symbol``; the protective leg is carried alongside it.

    If the sell leg goes out but the protective leg does not, the position is
    closed immediately: an unbounded short option is exactly the exposure this
    structure exists to avoid, so a half-done spread is flattened rather than
    held.
    """
    now = now or time.time()
    sell = geo["sell"]
    hedge = geo["hedge"]
    lot_size = int(geo.get("lot_size") or 1)
    qty = lots * lot_size
    lv = plan_levels_short(geo, params)

    binding = None
    if mode == "live":
        from services.strategy_module.order_dispatch import BrokerBinding

        binding = gw.session_binding() or BrokerBinding(broker="", account=None)

    pid = db.position_add(
        {
            "signal_id": signal_id,
            "underlying": cand.underlying,
            "symbol": sell["symbol"],
            "exchange": exchange,
            "option_type": sell["option_type"],
            "strike": float(sell["strike"]),
            "lots": lots,
            "qty": qty,
            "lot_size": lot_size,
            "mode": mode,
            "broker": (binding.broker if binding else "") or "",
            "broker_account": binding.account if binding else None,
            "state": "PENDING",
            "entry_price": lv["entry"],
            "entry_ts": now,
            "initial_stop": lv["stop"],
            "stop_price": lv["stop"],
            "target_price": lv["target"],
            "trail_trigger": lv["trail_trigger"],
            "trail_gap": lv["trail_gap"],
            "highest_price": lv["entry"],
            "lowest_price": lv["entry"],
            "risk_per_unit": lv["risk_per_unit"],
            "expiry": str((geo.get("sell") or {}).get("expiry") or ""),
            "deadline_ts": horizon_deadline(now, cand.horizon_bars),
            "model_version": model_version,
            "side": cand.side,
            "band": "",
            "position_type": "short",
            "hedge_symbol": hedge["symbol"],
            "hedge_exchange": exchange,
            "hedge_option_type": hedge["option_type"],
            "hedge_strike": float(hedge["strike"]),
            "hedge_qty": qty,
            "hedge_entry_price": float(hedge["ask"] or hedge["ltp"]),
            "spread_credit": float(geo["credit"]),
            "spread_width": float(geo["width"]),
        }
    )

    # The protective leg goes out FIRST: the account is never a naked short,
    # even for a moment. Only once the hedge is confirmed do we sell the leg.
    hedge_ok, hedge_order_id, hedge_err = gw.dispatch(
        mode, _order(hedge["symbol"], exchange, "BUY", qty), binding=binding
    )
    if not hedge_ok:
        db.position_update(
            pid,
            state="CLOSED",
            exit_reason=f"hedge refused: {hedge_err}",
            exit_ts=time.time(),
            pnl=0.0,
            note="nothing was sold; protective leg refused before the sell leg",
        )
        db.event(
            "warn",
            "entry_refused",
            f"{sell['symbol']}: protective leg refused ({hedge_err}); nothing was sold",
            {"signal_id": signal_id},
        )
        db.signal_update(signal_id, status="BLOCKED")
        return False, None, f"protective leg refused: {hedge_err}; nothing was sold"

    ok, order_id, err = gw.dispatch(
        mode, _order(sell["symbol"], exchange, "SELL", qty), binding=binding
    )
    if not ok:
        # The sell leg was refused after the hedge was bought: sell the hedge
        # back so the account is flat again. If that is also refused the row
        # stays OPEN with an unmissable alarm — reconcile keeps verifying.
        bb_ok, _bb_order_id, bb_err = gw.dispatch(
            mode, _order(hedge["symbol"], exchange, "SELL", qty), binding=binding
        )
        if bb_ok:
            db.position_update(
                pid,
                state="CLOSED",
                exit_reason=f"sell leg refused: {err}",
                exit_ts=time.time(),
                pnl=0.0,
                note="sell leg refused; hedge leg sold back",
            )
            db.event(
                "warn",
                "sale_refused",
                f"{sell['symbol']}: sell leg refused ({err}); hedge leg sold back",
                {"position_id": pid},
            )
        else:
            db.position_update(
                pid,
                state="CLOSED",
                exit_reason="sell leg refused and hedge sell-back also refused: orphan hedge",
                exit_ts=time.time(),
                pnl=0.0,
                note="ORPHAN HEDGE: hedge bought but sell leg refused and hedge sell-back "
                f"also refused ({bb_err or 'refused'}); flatten manually or let reconcile verify",
            )
            db.event(
                "error",
                "hedge_unwind_refused",
                f"{sell['symbol']}: sell leg refused ({err}) AND hedge sell-back ALSO refused "
                f"({bb_err or 'refused'}). The account may hold an unhedged long option — flatten it.",
                {"position_id": pid},
            )
        db.signal_update(signal_id, status="BLOCKED", position_id=pid)
        return False, None, f"sell leg refused: {err}"

    sell_fill = gw.fill_price(mode, order_id, binding) or float(geo["credit"])
    hedge_fill = gw.fill_price(mode, hedge_order_id, binding) or float(hedge["ask"] or hedge["ltp"])
    # The credit is what was actually received, not what was planned.
    credit = max(sell_fill - hedge_fill, 0.0)
    width = float(geo["width"])
    max_loss = max(width - credit, 0.0)
    lv = plan_levels_short(
        {**geo, "credit": credit, "max_loss": max_loss, "target_value": credit * 0.5},
        params,
    )
    db.position_update(
        pid,
        state="OPEN",
        entry_order_id=order_id or "",
        entry_price=credit,
        initial_stop=lv["stop"],
        stop_price=lv["stop"],
        target_price=lv["target"],
        highest_price=credit,
        lowest_price=credit,
        risk_per_unit=lv["risk_per_unit"],
        hedge_entry_price=hedge_fill,
        spread_credit=credit,
    )
    db.signal_update(signal_id, status="TRADED", position_id=pid)
    db.event(
        "info",
        "entry",
        f"{mode} credit spread SELL {qty} {sell['symbol']} / BUY {qty} {hedge['symbol']} "
        f"@ credit {credit:.2f} (max loss {max_loss:.2f})",
        {"position_id": pid, "signal_id": signal_id},
    )
    return True, pid, "ok"


# --- management --------------------------------------------------------------
def _risk(pos: dict[str, Any], limits: RiskLimits | None = None) -> PositionRisk:
    """The position as the risk core sees it.

    ``target_buffer_pct`` is threaded from ``limits`` (the human-configured
    near-target buffer) so ``evaluate_position`` treats a price within
    ``buffer_pct`` of target as a target hit.

    A short position is a short: its price is the SPREAD's price and it falls
    when the trade wins, which is the risk core's own short-side arithmetic.
    """
    short = str(pos.get("position_type") or "long").lower() == "short"
    buffer_pct = float(
        pos.get("target_buffer_pct")
        if pos.get("target_buffer_pct") is not None
        else (limits.target_buffer_pct if limits is not None else 0.0)
    )
    return PositionRisk(
        identifier=str(pos["id"]),
        side=Side.SELL if short else Side.BUY,
        entry_price=float(pos["entry_price"]),
        quantity=float(pos["qty"]),
        stop_price=pos["stop_price"],
        initial_stop_price=pos["initial_stop"],
        target_price=pos["target_price"],
        target_buffer_pct=buffer_pct,
        trailing_enabled=float(pos["trail_gap"] or 0) > 0,
        trail_step=float(pos["trail_gap"] or 0),
        trail_trigger=float(pos["trail_trigger"] or 0),
        trail_mode=TrailMode.CONTINUOUS,
        highest_price=pos["highest_price"],
        lowest_price=pos["lowest_price"],
    )


def mark_positions(
    gw: Gateway, rows: list[dict[str, Any]] | None = None
) -> list[dict[str, Any]]:
    """Mark open positions to the market using ``gw`` for quotes.

    Returns each position row augmented with ``ltp``, ``pnl``, ``pnl_pct``,
    ``r`` and ``closable``. Unpriced or pending rows keep ``ltp``/``pnl`` as
    ``None`` and are not closable. For a short spread the mark is the net
    spread (sell leg minus hedge leg) and P&L is credit minus spread value.
    """
    if rows is None:
        rows = db.positions_open()
    return [_mark_one(gw, pos) for pos in rows]


def _mark_one(gw: Gateway, pos: dict[str, Any]) -> dict[str, Any]:
    row = dict(pos)
    ptype = str(pos.get("position_type") or "long").lower()
    state = pos.get("state")
    if state != "OPEN":
        row.update(ltp=None, pnl=None, pnl_pct=None, r=None, closable=False)
        return row
    symbol = pos["symbol"]
    exchange = pos.get("exchange", "NFO")
    quote = gw.quote(symbol, exchange)
    if quote is None:
        row.update(ltp=None, pnl=None, pnl_pct=None, r=None, closable=False)
        return row
    ltp = float(quote)
    entry = float(pos["entry_price"])
    qty = float(pos["qty"])
    capital = abs(entry) * qty
    if ptype == "short":
        hedge_symbol = pos.get("hedge_symbol")
        hedge_exchange = pos.get("hedge_exchange", exchange)
        if hedge_symbol:
            hedge_quote = gw.quote(hedge_symbol, hedge_exchange)
            if hedge_quote is None:
                row.update(ltp=None, pnl=None, pnl_pct=None, r=None, closable=False)
                return row
            ltp = ltp - float(hedge_quote)  # net spread value
        credit = float(pos.get("entry_price") or 0.0)
        pnl = (credit - ltp) * qty
    else:
        pnl = (ltp - entry) * qty
    pnl_pct = (pnl / capital * 100.0) if capital else None
    risk_per_unit = float(pos.get("risk_per_unit") or 0.0)
    r = (pnl / (risk_per_unit * qty)) if risk_per_unit and qty else None
    row.update(ltp=ltp, pnl=pnl, pnl_pct=pnl_pct, r=r, closable=True)
    return row


def exit_position(
    gw: Gateway,
    pos: dict[str, Any],
    kind: str,
    reason: str,
    ltp: float | None,
    now: float | None = None,
) -> bool:
    """Close one position. True only if it is now CLOSED."""
    now = now or time.time()
    pid = int(pos["id"])
    if now - _last_exit_attempt.get(pid, 0.0) < MIN_RETRY_S:
        return False
    _last_exit_attempt[pid] = now
    if not db.position_claim_exit(pid, kind):
        return False  # another path already owns this exit
    binding = _binding_of(pos)
    short = str(pos.get("position_type") or "long").lower() == "short"
    hedge_ok, hedge_order_id, hedge_err = False, None, ""
    if short:
        # Close a credit spread: buy back the sold leg, sell the protective one.
        ok, order_id, err = gw.dispatch(
            pos["mode"],
            _order(pos["symbol"], pos["exchange"], "BUY", int(pos["qty"])),
            binding=binding,
        )
        if ok:
            hedge_ok, hedge_order_id, hedge_err = gw.dispatch(
                pos["mode"],
                _order(
                    str(pos.get("hedge_symbol") or ""),
                    str(pos.get("hedge_exchange") or pos["exchange"]),
                    "SELL",
                    int(pos.get("hedge_qty") or pos["qty"]),
                ),
                binding=binding,
            )
            if not hedge_ok:
                # A refused hedge close leaves a live long option on the broker
                # book that nothing tracks. Most refusals are transient (rate
                # limit, margin recalculation), so retry briefly before giving
                # up and flagging it.
                for _ in range(3):
                    time.sleep(0.75)
                    hedge_ok, hedge_order_id, hedge_err = gw.dispatch(
                        pos["mode"],
                        _order(
                            str(pos.get("hedge_symbol") or ""),
                            str(pos.get("hedge_exchange") or pos["exchange"]),
                            "SELL",
                            int(pos.get("hedge_qty") or pos["qty"]),
                        ),
                        binding=binding,
                    )
                    if hedge_ok:
                        break
            if not hedge_ok:
                db.event(
                    "error",
                    "hedge_exit_refused",
                    f"{pos['symbol']}: protective leg could not be closed ({hedge_err}); "
                    f"the sold leg was bought back and the hedge is still open",
                    {"position_id": pid},
                )
                # The spread itself is flat, so the row does close — but the
                # note keeps the still-open hedge leg visible on the row (and
                # reconcile keeps verifying the broker book against it).
                db.position_update(
                    pid,
                    note="HEDGE STILL OPEN: protective leg could not be closed "
                    f"({hedge_err or 'refused'}); sell it manually or let reconcile verify",
                )
    else:
        ok, order_id, err = gw.dispatch(
            pos["mode"],
            _order(pos["symbol"], pos["exchange"], "SELL", int(pos["qty"])),
            binding=binding,
        )
    if not ok:
        db.position_release_exit(pid)  # still held: back under management
        db.event("error", "exit_refused", f"{pos['symbol']} ({kind}): {err}", {"position_id": pid})
        return False
    fill: float | None = None
    if order_id:
        # A dispatched MARKET order normally books within a second; retry the
        # status lookup briefly before considering the fill unknown.
        for _ in range(4):
            fill = gw.fill_price(pos["mode"], order_id, binding)
            if fill is not None:
                break
            time.sleep(0.75)
    estimated = fill is None
    if estimated:
        fill = ltp if ltp is not None else float(pos["entry_price"])
        db.event(
            "warn",
            "exit_fill_unknown",
            f"{pos['symbol']} ({kind}): fill price not confirmed after retries; P&L estimated from "
            f"{'the last traded price' if ltp is not None else 'the entry price'}",
            {"position_id": pid, "order_id": order_id or ""},
        )
    fill = float(fill)
    entry_price = float(pos["entry_price"])
    if short:
        # A short spread's P&L is the credit received minus what the spread is
        # worth now, and the spread's exit value is the buy-back of the sold
        # leg MINUS the proceeds of selling the protective leg back. Booking
        # only the buy-back hid the hedge's sale inside the row's P&L.
        hedge_exit: float | None = None
        if hedge_ok and hedge_order_id:
            hedge_exit = gw.fill_price(pos["mode"], hedge_order_id, binding)
        if hedge_ok and hedge_exit is None:
            # The hedge sale went out but its fill is unconfirmed: mark from
            # the hedge's own quote, else from its recorded entry price so
            # the row never flatters the trade.
            hedge_exit = gw.quote(
                str(pos.get("hedge_symbol") or ""),
                str(pos.get("hedge_exchange") or pos["exchange"]),
            ) or float(pos.get("hedge_entry_price") or 0.0)
            db.event(
                "warn",
                "hedge_fill_unknown",
                f"{pos['symbol']} ({kind}): hedge sale fill unconfirmed; "
                f"proceeds estimated at {float(hedge_exit):.2f}",
                {"position_id": pid, "order_id": hedge_order_id or ""},
            )
        # A hedge that could not be closed stays on the broker book (see the
        # note below): its proceeds belong to whoever eventually sells it, so
        # this row books none of it.
        gross_pnl = (entry_price - fill + float(hedge_exit or 0.0)) * int(pos["qty"])
    else:
        gross_pnl = (fill - entry_price) * int(pos["qty"])
    risk_total = float(pos["risk_per_unit"] or 0) * int(pos["qty"])

    # Compute real transaction costs so the equity curve reflects what the
    # trader actually pays, not just the raw price move. The schedule comes
    # from portfolio.costs which is already used by the backtester; the brain
    # reuses it here for consistency.
    exchange_upper = str(pos.get("exchange") or "NFO").upper()
    if exchange_upper.startswith("BSE"):
        cost_key = "india_fno_bse"
    else:
        cost_key = "india_fno_nse"
    qty_int = int(pos["qty"])
    entry_p = entry_price
    if short:
        # Four orders move in a spread's life: sell the leg, buy the hedge,
        # buy the leg back, sell the hedge. The premium turnover on each side
        # is both legs, once at entry and once at exit.
        leg_premium = float(pos.get("hedge_entry_price") or 0.0)
        turnover = max(entry_p, 0.0) + max(leg_premium, 0.0)
        buy_value = turnover * qty_int * 2
        sell_value = turnover * qty_int * 2
        orders = 4
    else:
        buy_value = entry_p * qty_int
        sell_value = fill * qty_int
        orders = 2
    try:
        from portfolio.costs import schedule_for

        cs = schedule_for(cost_key)
        cost_brkdown = cs.breakdown(buy_value, sell_value, orders=orders)
    except Exception:
        # Fallback: keep the flat COST_R estimate that was already in place.
        cost_brkdown = {}

    net_pnl = gross_pnl - cost_brkdown.get("total", 0.0)
    r_multiple = (net_pnl / risk_total) if risk_total > 0 and not estimated else None
    if r_multiple is not None and not math.isfinite(r_multiple):
        # A NaN/inf R poisons every downstream metric it touches — and NaN
        # compares False against every threshold, so live-eligibility gates
        # would fail open. The trade still closes; it just drops out of the
        # metrics like an estimated-fill row does.
        r_multiple = None
    db.position_update(
        pid,
        state="CLOSED",
        exit_reason=reason[:120],
        exit_price=fill,
        exit_order_id=order_id or "",
        exit_ts=now,
        pnl=gross_pnl,
        gross_pnl=gross_pnl,
        brokerage=cost_brkdown.get("brokerage", 0.0),
        stt=cost_brkdown.get("stt", 0.0),
        exchange_txn=cost_brkdown.get("exchange_txn", 0.0),
        sebi_charges=cost_brkdown.get("sebi", 0.0),
        stamp_duty=cost_brkdown.get("stamp_duty", 0.0),
        gst=cost_brkdown.get("tax", 0.0),
        total_cost=cost_brkdown.get("total", 0.0),
        net_pnl=net_pnl if not estimated else None,
        # An estimated fill is for display only: without the real fill price the
        # R-multiple would be a guess. None drops the trade out of the metrics
        # and the champion's realised sample, so the model never learns from a
        # fabricated return.
        r_multiple=r_multiple,
    )
    _last_exit_attempt.pop(pid, None)
    db.event(
        "info",
        "exit",
        f"{pos['mode']} SELL {pos['qty']} {pos['symbol']} @ {fill:.2f} ({kind}) gross_pnl {gross_pnl:+.0f}",
        {"position_id": pid},
    )
    return True


def _spread_ltp(gw: Gateway, pos: dict[str, Any]) -> float | None:
    """What the credit spread is worth right now: sold leg minus hedge leg.

    This is the position's "price" for the risk core. A quote that is missing
    on either leg leaves the value unknown rather than guessing, because a
    half-quoted spread would read as a different trade than it is.
    """
    sell = gw.quote(pos["symbol"], pos["exchange"])
    hedge_symbol = str(pos.get("hedge_symbol") or "")
    if not hedge_symbol:
        return sell
    hedge = gw.quote(hedge_symbol, str(pos.get("hedge_exchange") or pos["exchange"]))
    if sell is None or hedge is None:
        return None
    return spread_value(sell, hedge)


def manage(
    gw: Gateway,
    now: float | None = None,
    flatten_reason: str | None = None,
    limits: RiskLimits | None = None,
    now_min: int | None = None,
) -> list[dict[str, Any]]:
    """One pass over every open position. Returns what was decided, for the UI."""
    now = now or time.time()
    if now_min is None:
        now_min = _ist_now(now).hour * 60 + _ist_now(now).minute
    out: list[dict[str, Any]] = []
    for pos in db.positions_open():
        pid = int(pos["id"])
        if pos["state"] == "PENDING":
            if now - float(pos["entry_ts"]) > PENDING_TIMEOUT_S:
                db.event(
                    "error",
                    "pending_stuck",
                    f"{pos['symbol']}: entry order unresolved after {PENDING_TIMEOUT_S:.0f}s; reconcile will decide",
                    {"position_id": pid},
                )
            continue
        if pos["state"] != "OPEN":
            continue  # CLOSING: owned by an exit in flight
        if pos.get("note") == "premium_pa":
            # Owned and managed by the premium price-action module, which runs
            # its own stop/target/trail/ posterior management per scan.
            continue
        short = str(pos.get("position_type") or "long").lower() == "short"
        if short:
            # A spread is worth what the two legs are worth together.
            ltp = _spread_ltp(gw, pos)
        else:
            ltp = gw.quote(pos["symbol"], pos["exchange"])
        if flatten_reason:
            done = exit_position(gw, pos, "flatten", flatten_reason, ltp, now)
            out.append({"id": pid, "action": "flatten", "closed": done})
            continue
        # Expiry awareness: an open option must never outlive its contract. An
        # expired option cannot be sold at any price, so if the venue refuses
        # the exit the row is ledger-closed without a fabricated mark-out.
        exp_date = _pos_expiry_date(pos)
        if exp_date is not None:
            dte_days = (exp_date - _ist_now(now).date()).days
            if dte_days < 0:
                done = exit_position(gw, pos, "expiry", "contract expired", ltp, now)
                if not done:
                    _force_close_expired(pos, now)
                out.append({"id": pid, "action": "expiry", "closed": True})
                continue
            if dte_days == 0:
                # Expiry-day square-off — human-owned gate; falls back to the
                # module default when limits is not threaded through (shouldn't
                # happen in production, but keep the safe side). The gate is
                # real: before the cut time the position stays under normal
                # management below (stops, trails, holding limits); at/after
                # the cut it is squared off regardless.
                cut = limits.expiry_squareoff_min if limits is not None else EXPIRY_EXIT_MIN_DEFAULT
                if now_min >= cut:
                    done = exit_position(
                        gw,
                        pos,
                        "expiry",
                        f"expiry-day square-off (out by {cut // 60:02d}:{cut % 60:02d} IST)",
                        ltp,
                        now,
                    )
                    out.append({"id": pid, "action": "expiry", "closed": done})
                    continue
        # Per-position holding limits: intraday positions square off at the
        # configured time; swing/positional positions may carry overnight but
        # are closed when their max hold days elapse.
        ptype = str(pos.get("position_type") or "long").lower()
        if limits is not None:
            # Intraday positions store ``long``/``short`` (never "intraday" —
            # that value was written by no code path, which let late-day entries
            # slip past the square-off into the overnight gap). Swing and
            # positional may carry overnight by design.
            if ptype in ("long", "short") and now_min >= limits.squareoff_min:
                done = exit_position(gw, pos, "flatten", "intraday square-off time", ltp, now)
                out.append({"id": pid, "action": "flatten", "closed": done})
                continue
            if ptype == "swing" and limits.swing_max_hold_days > 0:
                held_days = (now - float(pos["entry_ts"])) / 86400.0
                if held_days >= limits.swing_max_hold_days:
                    done = exit_position(
                        gw,
                        pos,
                        "time",
                        f"swing max hold {limits.swing_max_hold_days}d elapsed",
                        ltp,
                        now,
                    )
                    out.append({"id": pid, "action": "time", "closed": done})
                    continue
            if ptype == "positional" and limits.positional_max_hold_days > 0:
                held_days = (now - float(pos["entry_ts"])) / 86400.0
                if held_days >= limits.positional_max_hold_days:
                    done = exit_position(
                        gw,
                        pos,
                        "time",
                        f"positional max hold {limits.positional_max_hold_days}d elapsed",
                        ltp,
                        now,
                    )
                    out.append({"id": pid, "action": "time", "closed": done})
                    continue
        if ltp is None:
            out.append({"id": pid, "action": "no_quote"})
            continue
        d = evaluate_position(_risk(pos, limits), ltp)
        fields: dict[str, Any] = {}
        if d.evaluated:
            fields.update(
                stop_price=d.stop_price, highest_price=d.highest_price, lowest_price=d.lowest_price
            )
            move = ltp - float(pos["entry_price"])
            if short:
                # For a short, a fall in the price is the favourable move.
                move = -move
            fields.update(
                mfe=max(float(pos["mfe"] or 0), move), mae=min(float(pos["mae"] or 0), move)
            )
            db.position_update(pid, **fields)
        if d.breached:
            kind = "stop" if d.reason and d.reason.value == "sl" else "target"
            pos = {**pos, **fields}
            done = exit_position(gw, pos, kind, d.detail or kind, ltp, now)
            out.append({"id": pid, "action": kind, "closed": done})
        elif now >= float(pos["deadline_ts"] or 0) > 0:
            done = exit_position(gw, pos, "time", "time stop: horizon elapsed", ltp, now)
            out.append({"id": pid, "action": "time", "closed": done})
        else:
            out.append(
                {
                    "id": pid,
                    "action": "hold",
                    "ltp": ltp,
                    "stop": d.stop_price,
                    "trail_armed": d.trail_armed,
                }
            )
    return out


def flatten_all(gw: Gateway, reason: str, now: float | None = None) -> int:
    return sum(1 for r in manage(gw, now, flatten_reason=reason) if r.get("closed"))


# --- reconciliation ----------------------------------------------------------
def reconcile(gw: Gateway, platform_mode: str, now: float | None = None) -> dict[str, Any]:
    """Compare what the Brain believes it holds with what the venue says.

    Only positions whose mode matches the book being read are compared: a
    sandbox position says nothing about the live book and vice versa. A live
    position is compared only against the book of the broker it is bound to:
    a book read from another broker's session does not show the position, and
    its absence there does not mean it was closed outside the Brain.
    """
    now = now or time.time()
    summary = {
        "checked": 0,
        "closed_outside": 0,
        "pending_resolved": 0,
        "untracked": [],
        "skipped_other_mode": 0,
        "skipped_broker_mismatch": 0,
        "closing_recovered": 0,
        "bootstrap_skipped": 0,
    }
    global _reconcile_boot_ts
    if _reconcile_boot_ts == 0.0:
        _reconcile_boot_ts = now
    bootstrap_active = now - _reconcile_boot_ts < RECONCILE_BOOTSTRAP_S
    book = gw.positionbook(platform_mode)
    if book is None:
        return {**summary, "error": "position book unavailable"}
    from services.strategy_module.order_dispatch import binding_refusal

    # The session the live book was read from; None for the sandbox book, which
    # no broker holds.
    session_binding = gw.session_binding() if platform_mode != "sandbox" else None
    held = {}
    for b in book:
        try:
            qty = int(float(b.get("quantity") or 0))
        except (TypeError, ValueError):
            qty = 0
        held[(str(b.get("symbol")), str(b.get("exchange")))] = qty
    tracked = set()
    # Phase 1: recycle any stale CLOSING row before touching OPEN positions; a released
    # row must not be immediately re-evaluated against the session's book in the same pass.
    closing_recovered = 0
    recovered_pids: set[int] = set()
    for pos in db.positions_open():
        if pos["state"] != "CLOSING":
            continue
        want = "sandbox" if platform_mode == "sandbox" else "live"
        binding = _binding_of(pos)
        session_binding_local = gw.session_binding() if platform_mode != "sandbox" else None
        mismatch = False
        if (
            binding is not None
            and binding.known
            and session_binding_local is not None
            and session_binding_local.known
            and binding_refusal(
                binding, session_binding_local.broker, session_binding_local.account
            )
        ):
            mismatch = True
        if mismatch:
            summary["skipped_broker_mismatch"] += 1
            continue
        # Only treat as stale if an exit_ts was actually written (i.e. the exit
        # dispatch reached the broker and came back without completing). A
        # CLOSING row whose exit_ts is still None has not yet been dispatched
        # and must be left alone — releasing it would re-open the position
        # mid-flight and risk a double-sell on the next reconcile pass.
        exit_ts = pos.get("exit_ts")
        if exit_ts is not None and now - float(exit_ts) > CLOSING_STALE_S:
            db.position_release_exit(int(pos["id"]))
            db.event(
                "warn",
                "closing_recovered",
                f"{pos['symbol']}: CLOSING row released after {CLOSING_STALE_S:.0f}s; resume management",
                {"position_id": pos["id"]},
            )
            closing_recovered += 1
            recovered_pids.add(int(pos["id"]))
    summary["closing_recovered"] = closing_recovered
    # Phase 2: normal OPEN / PENDING reconciliation, skipping anything just recovered.
    for pos in db.positions_open():
        want = "sandbox" if platform_mode == "sandbox" else "live"
        if pos["mode"] != want:
            summary["skipped_other_mode"] += 1
            continue
        if int(pos["id"]) in recovered_pids:
            # Released from CLOSING in phase 1; give manage() the next tick to pick it up.
            summary["skipped_other_mode"] += 1
            continue
        binding = _binding_of(pos)
        if (
            binding is not None
            and binding.known
            and session_binding is not None
            and session_binding.known
            and binding_refusal(binding, session_binding.broker, session_binding.account)
        ):
            # Bound to another broker (or account) than the one whose book was
            # read: skip rather than close it as "closed outside the Brain".
            summary["skipped_broker_mismatch"] += 1
            continue
        summary["checked"] += 1
        key = (pos["symbol"], pos["exchange"])
        tracked.add(key)
        qty = held.get(key, 0)
        # The broker book is SIGNED: a short position reads negative
        # (agent/tools/account.py:434, risk/models.py:154). The row's ``symbol``
        # is the sold leg of a short spread, so the book's expected qty for it
        # is -qty. Anything else in the past ran long-only arithmetic and
        # force-closed every open short as "closed outside the Brain".
        short_pos = str(pos.get("position_type") or "long").lower() == "short"
        expected = -int(pos["qty"]) if short_pos else int(pos["qty"])
        held_ok = qty != 0 and (qty > 0) == (expected > 0)
        if pos["state"] == "PENDING" and now - float(pos["entry_ts"]) > PENDING_TIMEOUT_S:
            if held_ok:
                db.position_update(int(pos["id"]), state="OPEN")
                db.event(
                    "warn",
                    "pending_adopted",
                    f"{pos['symbol']}: entry had filled, now managed",
                    {"position_id": pos["id"]},
                )
            else:
                db.position_update(
                    int(pos["id"]),
                    state="CLOSED",
                    exit_reason="entry never filled",
                    exit_ts=now,
                    pnl=0.0,
                )
            summary["pending_resolved"] += 1
        elif pos["state"] == "CLOSING":
            # A position stuck in CLOSING means the exit dispatch never completed
            # (crash mid-flight, or broker hung). Release it back to OPEN so manage()
            # picks it up on the next tick instead of leaving it invisible forever.
            # Guard: only act when exit_ts was actually stamped (see above comment).
            exit_ts = pos.get("exit_ts")
            if exit_ts is not None and now - float(exit_ts) > CLOSING_STALE_S:
                db.position_release_exit(int(pos["id"]))
                db.event(
                    "warn",
                    "closing_recovered",
                    f"{pos['symbol']}: CLOSING row released after {CLOSING_STALE_S:.0f}s; resume management",
                    {"position_id": pos["id"]},
                )
                summary["closing_recovered"] = summary.get("closing_recovered", 0) + 1
        elif pos["state"] == "OPEN" and not held_ok:
            if bootstrap_active:
                summary["bootstrap_skipped"] += 1
                db.event(
                    "info",
                    "reconcile_bootstrap_skip",
                    f"{pos['symbol']}: deferred at boot ({int(RECONCILE_BOOTSTRAP_S - (now - _reconcile_boot_ts))}s remaining)",
                    {"position_id": int(pos["id"])},
                )
                continue
            ltp = gw.quote(pos["symbol"], pos["exchange"]) or float(pos["entry_price"])
            # Short marks run (entry - exit): the row was opened on a credit,
            # so a lower exit price is a gain. Sign-aware so a force-close here
            # does not book a long-side mark on a short.
            if short_pos:
                pnl = (float(pos["entry_price"]) - ltp) * int(pos["qty"])
            else:
                pnl = (ltp - float(pos["entry_price"])) * int(pos["qty"])
            _last_exit_attempt.pop(int(pos["id"]), None)  # row closed outside this path
            db.position_update(
                int(pos["id"]),
                state="CLOSED",
                exit_reason="closed outside the Brain",
                exit_price=ltp,
                exit_ts=now,
                pnl=pnl,
            )
            db.event(
                "warn",
                "closed_outside",
                f"{pos['symbol']} no longer in the position book",
                {"position_id": pos["id"]},
            )
            summary["closed_outside"] += 1
        elif pos["state"] == "OPEN" and held_ok and short_pos and pos.get("hedge_symbol") and not bootstrap_active:
            # Short spread whose hedge leg has left the broker book: the account
            # holds a naked short option. Cover the sold leg and close the row,
            # unless the cover is refused, in which case the row stays OPEN with
            # an alarm so reconcile keeps trying on later ticks.
            hedge_key = (pos.get("hedge_symbol"), pos.get("hedge_exchange", pos["exchange"]))
            hedge_qty = held.get(hedge_key, 0)
            tracked.add(hedge_key)  # the hedge leg is accounted for, not "untracked"
            if hedge_qty <= 0:
                ok, order_id, err = gw.dispatch(
                    platform_mode,
                    _order(pos["symbol"], pos["exchange"], "BUY", int(pos["qty"])),
                    binding=binding,
                )
                if ok:
                    ltp = gw.fill_price(platform_mode, order_id, binding) or float(pos["entry_price"])
                    pnl = (
                        float(pos.get("spread_credit") or 0.0)
                        + float(pos.get("hedge_entry_price") or 0.0)
                        - ltp
                    ) * int(pos["qty"])
                    db.position_update(
                        int(pos["id"]),
                        state="CLOSED",
                        exit_kind="naked_cover",
                        exit_reason="naked cover: hedge leg gone from the broker book",
                        exit_price=ltp,
                        exit_ts=now,
                        pnl=pnl,
                    )
                    db.event(
                        "warn",
                        "naked_short",
                        f"{pos['symbol']}: hedge leg no longer in the book; sold leg bought back at {ltp}",
                        {"position_id": pos["id"]},
                    )
                    summary["naked_covered"] = summary.get("naked_covered", 0) + 1
                else:
                    db.position_update(
                        int(pos["id"]),
                        state="OPEN",
                        note="UNRESOLVED NAKED SHORT: hedge leg gone from the book and cover of the sold leg "
                        f"was refused ({err}); flatten manually or let reconcile verify",
                    )
                    db.event(
                        "error",
                        "naked_cover_refused",
                        f"{pos['symbol']}: hedge leg gone and cover of the sold leg refused ({err}); "
                        "account may hold a naked short — flatten it.",
                        {"position_id": pos["id"]},
                    )
                    summary["naked_unresolved"] = summary.get("naked_unresolved", 0) + 1
                continue
        # Stale-deadline detection: the time-stop never fired because manage()
        # has not been able to read an LTP since the broker session dropped.
        # Force-close rather than let the row sit OPEN indefinitely. Must come
        # AFTER the held_ok branch so positions missing from the book are still
        # closed as "closed outside the Brain" first.
        if pos["state"] == "OPEN" and not bootstrap_active:
            deadline = float(pos.get("deadline_ts") or 0)
            if deadline > 0 and now - deadline > STALE_DEADLINE_S:
                ltp = gw.quote(pos["symbol"], pos["exchange"]) or float(pos["entry_price"])
                done = exit_position(
                    gw,
                    pos,
                    "stale_broker_session",
                    "deadline passed with no LTP; feed likely down",
                    ltp,
                    now,
                )
                summary["stale_closed"] = summary.get("stale_closed", 0) + (1 if done else 0)
    summary["untracked"] = [
        f"{s}:{e}" for (s, e), q in held.items() if q != 0 and (s, e) not in tracked
    ][:20]
    return summary
