"""Premium-PA candidate journal: the training data PPA never had.

PPA decides with a hand-weighted vote and learns only from the few trades it
takes. That is too little to fit anything. This module records every decision
point instead: once per completed 5-minute bar, for both the CE and the PE
ATM contract, whether or not PPA traded. Each row keeps the features PPA saw.
Later the row is labelled with what a long-premium trade would have done under
the same stop/target plan (a plain triple-barrier walk over the 1m premium bars).

It changes no trading behaviour: nothing here places, sizes, or vetoes an
order. ``observe`` and ``label_pending`` are called from ``premium_pa.on_scan``
inside a try/except, and every failure is contained.

Honest limits of the labels
---------------------------
* Entry is the open of the first 1m bar after the decision bar closes.
* The walk is the plain barrier game: stop, target or timeout after
  ``horizon_bars``. PPA's trailing stop, minimum hold and posterior early-cut
  are not simulated, so these labels describe the setup, not PPA's exact P&L.
* A bar that touches both stop and target is scored as a stop.
* Cost is the quoted spread only (``label_r_net``). Brokerage and taxes are
  not included.
"""

from __future__ import annotations

import math
import time
from datetime import datetime, timedelta, timezone
from typing import Any

import numpy as np

from utils.logging import get_logger

logger = get_logger(__name__)

BAR_S = 300.0
OBS_MIN_BARS = 25  # same warm-up PPA's vote needs
ENTRY_LAG_MAX_S = 180.0  # the entry bar must open within this of the decision bar's close
EXPIRE_AFTER_S = 3 * 86400.0  # a candidate whose bars never show up is dropped after this
LABEL_MIN_INTERVAL_S = 300.0
FEATURE_VERSION = 1

_last_logged: dict[str, float] = {}
_last_label_run = 0.0


# --- features -----------------------------------------------------------------
def side_features(arr5: np.ndarray) -> dict[str, float] | None:
    """Momentum / range / volume read of one premium's completed 5m bars.

    The same three reads ``premium_pa.premium_vote`` blends (so a fitted model
    can recover and improve on its fixed weights), plus a few extra views.
    Returns None when the window is too short or holds a non-positive close.
    """
    if arr5 is None or len(arr5) < 21:
        return None
    closes = np.asarray(arr5[:, 4], dtype=float)
    highs = np.asarray(arr5[:, 2], dtype=float)
    lows = np.asarray(arr5[:, 3], dtype=float)
    vols = np.where(np.asarray(arr5[:, 5], dtype=float) > 0, arr5[:, 5], 1.0)
    if bool(np.any(closes[-21:] <= 0)):
        return None
    c = float(closes[-1])
    tr = np.diff(np.log(closes[-21:])) + 1e-12
    sigma_m = float(np.std(tr)) + 1e-6
    mom20 = float(closes[-1] / closes[-21] - 1.0)
    mom5 = float(closes[-1] / closes[-6] - 1.0)
    ret1 = float(closes[-1] / closes[-2] - 1.0)
    lo20 = float(np.min(lows[-20:]))
    hi20 = float(np.max(highs[-20:]))
    ran = (c - lo20) / max(hi20 - lo20, 1e-9) - 0.5
    volr = float(np.mean(vols[-3:]) / (np.mean(vols[-20:]) + 1e-9))
    atr = float(np.mean(highs[-10:] - lows[-10:])) / c
    out = {
        "mom20": mom20,
        "mom5": mom5,
        "ret1": ret1,
        "m": float(np.tanh(mom20 / (2.5 * sigma_m + 1e-9))),
        "r": float(ran * 2.0),
        "v": float(np.tanh((volr - 1.0) / 0.8)),
        "atr_pct": atr,
        "sigma_m": sigma_m,
        "log_px": float(math.log(c)),
    }
    return {k: (v if math.isfinite(v) else 0.0) for k, v in out.items()}


def _ist_minute(ts: float) -> float:
    return float(((ts + 19800.0) % 86400.0) / 60.0)


def build_rows(
    underlying: str,
    c5: np.ndarray,
    p5: np.ndarray,
    bars_u: np.ndarray | None,
    chain_row: dict[str, Any] | None,
    u_state: dict[str, Any],
    cfg: dict[str, Any],
    now: float,
    exchange: str = "NFO",
) -> list[dict[str, Any]]:
    """Two candidate rows (CE and PE) for the last completed bar of ``c5``/``p5``.

    ``c5``/``p5`` must already be trimmed to completed bars and end on the same
    bar. Pure: no I/O, so it runs the same in tests.
    """
    from services.brain import premium_pa as ppa

    fc, fp = side_features(c5), side_features(p5)
    if fc is None or fp is None:
        return []
    bar_ts = float(c5[-1, 0])
    vote = ppa.premium_vote(c5, p5, cfg)
    horizon = int(cfg.get("horizon_bars") or 12)

    und_mom3 = und_mom12 = 0.0
    if bars_u is not None and len(bars_u) >= 13:
        cl = np.asarray(bars_u[:, 4], dtype=float)
        if cl[-4] > 0 and cl[-13] > 0:
            und_mom3 = float(cl[-1] / cl[-4] - 1.0)
            und_mom12 = float(cl[-1] / cl[-13] - 1.0)

    rows: list[dict[str, Any]] = []
    for side, own, opp, arr in (("CE", fc, fp, c5), ("PE", fp, fc, p5)):
        sgn = 1.0 if side == "CE" else -1.0
        bid = ask = 0.0
        iv = 0.0
        if chain_row:
            bid = float(chain_row.get(f"{side.lower()}_bid") or 0.0)
            ask = float(chain_row.get(f"{side.lower()}_ask") or 0.0)
            try:
                iv = float(chain_row.get(f"{side.lower()}_iv") or 0.0)
            except (TypeError, ValueError):
                iv = 0.0
        have_q = bid > 0 and ask > 0 and ask >= bid
        mid = (bid + ask) / 2.0 if have_q else 0.0
        spread_abs = (ask - bid) if have_q else 0.0
        spread_pct = (spread_abs / mid) if have_q and mid > 0 else 0.0
        feats: dict[str, float] = {f"own_{k}": v for k, v in own.items()}
        feats.update({f"opp_{k}": v for k, v in opp.items()})
        feats.update(
            {
                "diff_m": own["m"] - opp["m"],
                "diff_r": own["r"] - opp["r"],
                "diff_v": own["v"] - opp["v"],
                "side_score": sgn * float(vote.get("score", 0.0)),
                "vote_conf": float(vote.get("confidence", 0.0)),
                "und_mom3_aligned": sgn * und_mom3,
                "und_mom12_aligned": sgn * und_mom12,
                "spread_pct": spread_pct,
                "spread_missing": 0.0 if have_q else 1.0,
                "dte": float(u_state.get("dte") or 0.0),
                "tod_min": _ist_minute(bar_ts + BAR_S),
                "iv": iv if math.isfinite(iv) else 0.0,
                "is_ce": 1.0 if side == "CE" else 0.0,
                "feature_version": float(FEATURE_VERSION),
            }
        )
        sigma_h = ppa.premium_sigma_h(arr, horizon)
        plan = {
            "k_stop": float(cfg.get("k_stop", 0.8)),
            "rr": float(cfg.get("rr", 1.5)),
            "stop_pct": float(cfg.get("stop_pct", 0.15)),
            "horizon_bars": horizon,
            "sigma_h": float(sigma_h) if sigma_h else None,
            "spread_abs": float(spread_abs),
        }
        rows.append(
            {
                "ts": now,
                "underlying": underlying,
                "side": side,
                "symbol": str(u_state.get("ce_symbol" if side == "CE" else "pe_symbol") or ""),
                "exchange": exchange,
                "bar_ts": bar_ts,
                "features": feats,
                "plan": plan,
                "vote_score": float(vote.get("score", 0.0)),
            }
        )
    return rows


# --- labelling ----------------------------------------------------------------
def label_candidate(
    cand: dict[str, Any], bars1m: np.ndarray | None, now: float
) -> dict[str, Any] | None:
    """Triple-barrier outcome for one candidate.

    Returns a label dict, ``{"expired": True}`` when the outcome can never be
    observed, or None when the bars needed have not arrived yet.
    """
    from services.brain import premium_pa as ppa

    plan = cand.get("plan") or {}
    horizon = int(plan.get("horizon_bars") or 12)
    bar_end = float(cand["bar_ts"]) + BAR_S
    deadline = bar_end + horizon * BAR_S
    too_old = (now - deadline) > EXPIRE_AFTER_S

    if bars1m is None or len(bars1m) == 0 or float(bars1m[-1, 0]) < deadline - 60.0:
        return {"expired": True} if too_old else None
    after = bars1m[bars1m[:, 0] >= bar_end]
    if len(after) == 0 or float(after[0, 0]) - bar_end > ENTRY_LAG_MAX_S:
        return {"expired": True}  # a hole at the entry: the trade could not have been priced
    entry = float(after[0, 1])
    if not math.isfinite(entry) or entry <= 0:
        return {"expired": True}

    cfg_like = {
        "k_stop": float(plan.get("k_stop", 0.8)),
        "rr": float(plan.get("rr", 1.5)),
        "stop_pct": float(plan.get("stop_pct", 0.15)),
    }
    spread_abs = float(plan.get("spread_abs") or 0.0)
    lv = ppa.plan_premium_levels(entry, cfg_like, spread_abs, horizon, sigma_h=plan.get("sigma_h"))
    stop, target, risk = lv["stop"], lv["target"], lv["risk_per_unit"]
    if risk <= 0:
        return {"expired": True}

    window = after[after[:, 0] < deadline]
    outcome, r, bars_used = 0, None, horizon
    for row in window:
        o, h, lo = float(row[1]), float(row[2]), float(row[3])
        elapsed_bars = int((float(row[0]) - bar_end) // BAR_S) + 1
        if lo <= stop:  # stop first when one bar touches both
            fill = min(stop, o)
            outcome, r, bars_used = -1, (fill - entry) / risk, elapsed_bars
            break
        if h >= target:
            outcome, r, bars_used = 1, (target - entry) / risk, elapsed_bars
            break
    if r is None:
        last_close = float(window[-1, 4]) if len(window) else entry
        r = (last_close - entry) / risk
    cost_r = spread_abs / risk
    return {
        "expired": False,
        "label_outcome": int(outcome),
        "label_r": float(r),
        "label_r_net": float(r - cost_r),
        "label_bars": int(min(bars_used, horizon)),
    }


# --- runtime hooks (called from premium_pa.on_scan) ---------------------------
# A candidate is "stale" when its label deadline (bar end + horizon bars) falls
# after today's last observable bar (market close). Its outcome will never
# arrive and it would sit open for three days before ``EXPIRE_AFTER_S`` fires.
# Expire it immediately instead.
_SESSION_CLOSE_MIN = 15 * 60 + 30  # last bar we trust for any expiry decision


def _session_end_today(now: float) -> float:
    """Epoch seconds of the last-trusted bar for the IST calendar day containing ``now``."""
    from services.brain.labeling import IST_OFFSET

    dt = datetime.fromtimestamp(now, tz=timezone(timedelta(hours=5, minutes=30)))
    utc_sec = float(dt.timestamp())
    day_start_utc = utc_sec - ((utc_sec + IST_OFFSET) % 86400.0)
    return day_start_utc + _SESSION_CLOSE_MIN * 60.0 - IST_OFFSET


def _deadline(cand: dict[str, Any]) -> float:
    """When the candidate's label window closes (epoch seconds)."""
    plan = cand.get("plan") or {}
    return float(cand["bar_ts"]) + BAR_S + int(plan.get("horizon_bars") or 12) * BAR_S


def _expire_stale(pending: list[dict[str, Any]], now: float) -> int:
    """Mark open candidates whose horizon can never finish before market close."""
    from database import brain_db as db

    done = 0
    cutoff = _session_end_today(now)
    stale = []
    for c in pending:
        if _deadline(c) > cutoff and now >= cutoff:
            stale.append(int(c["id"]))
    if stale:
        for cid in stale:
            db.ppa_candidate_label(cid, status="expired", label_ts=now)
        done = len(stale)
        pending[:] = [c for c in pending if int(c["id"]) not in set(stale)]
    return done


def observe(
    underlying: str, chain: dict[str, Any] | None, bars: np.ndarray, now: float, api_key: str = ""
) -> int:
    """Journal the last completed 5m bar for this underlying, once. Returns rows added."""
    from database import brain_db as db
    from services.brain import premium_pa as ppa

    cfg = ppa.load_config()
    if not cfg["enable"]:
        return 0
    u_state = ppa._state().get(underlying) or {}
    ce_sym, pe_sym = u_state.get("ce_symbol") or "", u_state.get("pe_symbol") or ""
    if not (ce_sym and pe_sym):
        return 0
    ex = ppa._fo_exchange(underlying)
    key = api_key or ppa._resolve_key()
    ce1 = ppa.premium_bars(ce_sym, key, exchange=ex)
    pe1 = ppa.premium_bars(pe_sym, key, exchange=ex)
    if ce1 is None or pe1 is None or len(ce1) == 0 or len(pe1) == 0:
        return 0
    have = min(float(ce1[-1, 0]), float(pe1[-1, 0]))
    c5, p5 = ppa.aggregate_5m(ce1), ppa.aggregate_5m(pe1)
    # Completed bars only: a bar is complete once data exists at or after its end.
    c5 = c5[c5[:, 0] + BAR_S <= have]
    p5 = p5[p5[:, 0] + BAR_S <= have]
    if len(c5) < OBS_MIN_BARS or len(p5) < OBS_MIN_BARS:
        return 0
    bar_ts = min(float(c5[-1, 0]), float(p5[-1, 0]))
    c5, p5 = c5[c5[:, 0] <= bar_ts], p5[p5[:, 0] <= bar_ts]
    if float(c5[-1, 0]) != bar_ts or float(p5[-1, 0]) != bar_ts:
        return 0  # one side has no bar there (thin contract): skip rather than guess
    if _last_logged.get(underlying) == bar_ts:
        return 0
    _last_logged[underlying] = bar_ts

    bars_u = None
    if bars is not None and len(bars):
        bars_u = bars[bars[:, 0] <= bar_ts]
    row = None
    if chain and chain.get("rows"):
        row = next(
            (r for r in chain["rows"] if str(r.get("strike")) == str(u_state.get("atm"))), None
        )
    rows = build_rows(underlying, c5, p5, bars_u, row, u_state, cfg, now, exchange=ex)
    return db.ppa_candidate_add(rows) if rows else 0


def label_pending(now: float | None = None, force: bool = False) -> int:
    """Label candidates whose horizon has elapsed. Throttled; reads Historify only."""
    global _last_label_run
    from database import brain_db as db
    from services.brain import premium_pa as ppa

    now = now or time.time()
    if not force and now - _last_label_run < LABEL_MIN_INTERVAL_S:
        return 0
    _last_label_run = now
    pending = db.ppa_candidate_pending(before_ts=now - 5 * BAR_S)
    # Expire candidates whose label deadline can never arrive because the
    # session closes before their ``horizon_bars`` window expires. Without
    # this they would sit open until ``EXPIRE_AFTER_S`` (three days) silently,
    # confusing summary counts and delaying model training.
    done = _expire_stale(pending, now)
    cache: dict[tuple[str, str], np.ndarray | None] = {}
    for cand in pending:
        k = (str(cand["symbol"]), str(cand["exchange"]))
        if k not in cache:
            cache[k] = ppa._bars_from_historify(k[0], k[1]) if k[0] else None
        res = label_candidate(cand, cache[k], now)
        if res is None:
            continue
        if res.get("expired"):
            db.ppa_candidate_label(int(cand["id"]), status="expired", label_ts=now)
        else:
            db.ppa_candidate_label(
                int(cand["id"]),
                status="labelled",
                label_outcome=res["label_outcome"],
                label_r=res["label_r"],
                label_r_net=res["label_r_net"],
                label_bars=res["label_bars"],
                label_ts=now,
            )
        done += 1
    return done


# --- reporting ----------------------------------------------------------------
def summary() -> dict[str, Any]:
    """Counts, base rates and effective sample size of the labelled journal."""
    from database import brain_db as db

    counts = db.ppa_candidate_counts()
    rows = db.ppa_candidates_labelled()
    out: dict[str, Any] = {"counts": counts, "sides": {}}
    if not rows:
        return out
    try:
        from services.brain.engines.ml import effective_sample_size
    except Exception:  # pragma: no cover - ml engine unavailable
        effective_sample_size = None  # type: ignore[assignment]
    for side in ("CE", "PE", "ALL"):
        sel = [r for r in rows if side == "ALL" or r["side"] == side]
        if not sel:
            continue
        net = np.array([float(r["label_r_net"]) for r in sel])
        outc = np.array([int(r["label_outcome"]) for r in sel])
        rr = float((sel[0].get("plan") or {}).get("rr") or 1.5)
        item = {
            "n": len(sel),
            "win_rate": round(float((outc == 1).mean()), 4),
            "stop_rate": round(float((outc == -1).mean()), 4),
            "timeout_rate": round(float((outc == 0).mean()), 4),
            "mean_r_net": round(float(net.mean()), 4),
            "break_even_win_rate_no_cost": round(1.0 / (1.0 + rr), 4),
        }
        if effective_sample_size is not None:
            keys = [int(float(r["bar_ts"]) // BAR_S) for r in sel]
            spans = [int(r.get("label_bars") or 12) for r in sel]
            item["n_eff"] = round(float(effective_sample_size(keys, spans)), 1)
        out["sides"][side] = item
    return out


def dataset(limit: int = 20000) -> list[dict[str, Any]]:
    """Flat training rows: features, side, bar time and the labels."""
    from database import brain_db as db

    out = []
    for r in db.ppa_candidates_labelled(limit):
        d = dict(r["features"])
        d.update(
            underlying=r["underlying"],
            side=r["side"],
            bar_ts=r["bar_ts"],
            y=1.0 if r["label_outcome"] == 1 else 0.0,
            label_outcome=r["label_outcome"],
            label_r_net=r["label_r_net"],
            label_bars=r["label_bars"],
        )
        out.append(d)
    return out


def format_summary(s: dict[str, Any], labelled_now: int = 0) -> str:
    """One readable line for the Events tab and the log."""
    c = s.get("counts") or {}
    head = (
        f"PPA candidates: {c.get('total', 0)} logged, {c.get('labelled', 0)} labelled "
        f"(+{labelled_now} today), {c.get('open', 0)} still open, {c.get('expired', 0)} expired"
    )
    a = (s.get("sides") or {}).get("ALL")
    if not a:
        return head + "; nothing labelled yet"
    return (
        f"{head}. Labelled: win {a['win_rate']:.0%} / stop {a['stop_rate']:.0%} / "
        f"timeout {a['timeout_rate']:.0%}, mean net R {a['mean_r_net']:+.3f}, "
        f"effective samples {a.get('n_eff', '?')} "
        f"(win rate needed to break even before costs: {a['break_even_win_rate_no_cost']:.0%})"
    )
