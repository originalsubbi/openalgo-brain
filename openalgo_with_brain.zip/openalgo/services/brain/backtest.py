"""Walk-forward backtest and offline training. Pure.

The engines are expensive and do not depend on the tunable parameters, so the
work is split in two:

``precompute``  runs the engines once per sampled bar and keeps their reports.
``replay``      applies parameters (and optionally a model) to those reports,
                labels each candidate against the bars that followed, and
                returns the signals and the metrics of the trades a one-position
                -at-a-time Brain would have taken.

That split is what lets the tuner try many parameter sets in seconds. A backtest
has no option chain, so the options engine abstains; its weight is simply not
exercised here, and live evaluation is what teaches the model about it.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from services.brain import fusion
from services.brain.config import TunableParams
from services.brain.engines.ml import OnlineLogit, effective_sample_size
from services.brain.labeling import (
    BAR_S,
    Label,
    Metrics,
    in_entry_window,
    label_triple_barrier,
    metrics,
    session_future,
)
from services.brain.types import Candidate, EngineReport, Snapshot

IST_OFFSET = 19800
# The live gate's defaults (config.RiskLimits). Callers that know the operator's real limits pass
# them in; these only keep a bare call faithful to the standard 09:30-14:45 entry window and the
# 15:15 square-off.
DEFAULT_ENTRY_WINDOW = (9 * 60 + 30, 14 * 60 + 45)
DEFAULT_SQUAREOFF_MIN = 15 * 60 + 15
DEFAULT_SPAN = 12  # label window assumed for a row that does not say how far it looked


@dataclass(frozen=True, slots=True)
class BarEval:
    index: int
    entry: float
    minute_of_day: int
    reports: dict[str, EngineReport]


@dataclass(frozen=True, slots=True)
class SignalRow:
    index: int
    candidate: Candidate
    label: Label | None
    y: float  # 1 if target first else 0 (what the model learns)
    r_net: float
    key: int | None = None  # 5-minute bar number the signal was made on (overlap accounting)
    span: int | None = None  # bars the label looked ahead


def precompute(
    bars: np.ndarray,
    bench: np.ndarray | None = None,
    underlying: str = "BT",
    warmup: int = 150,
    step: int = 3,
    horizon: int = 12,
    lot: int = 1,
    entry_window: tuple[int, int] | None = DEFAULT_ENTRY_WINDOW,
    squareoff_min: int = DEFAULT_SQUAREOFF_MIN,
    params: TunableParams | None = None,
    chain_fetcher: Any | None = None,
) -> list[BarEval]:
    """Run the engines on sampled bars.

    Only bars the live Brain could have acted on are sampled: the decision is made when the bar
    closes and the gate refuses entries outside ``entry_window`` (IST minutes, start inclusive,
    cutoff exclusive). Bars are sampled through ``squareoff_min`` so an open position can still be
    squared off at the day-end cut (15:10 IST) even though no new entry is taken after the
    entry cutoff — those post-cutoff rows are squareoff-evaluation only. ``entry_window=None``
    samples every bar, for diagnostics only.

    ``params`` is the tunable set the engines must read. The engines own
    thresholds now (the VWAP band, the PCR lines, the opening-range floor), so
    a search over those thresholds has to re-run the engines rather than
    re-fuse stored votes.

    ``chain_fetcher`` is an optional ``(underlying, bar_ts) -> chain_dict | None`` callable.
    When supplied it gives each engine access to historical option-chain context (OI profile,
    IV rank, greeks) that was available at that bar's timestamp. This turns the study from
    a pure-spot analysis into one that honours the same option-leg selection logic as the
    live scan. Pass ``None`` (default) to keep the existing spot-only behaviour unchanged.
    """
    out: list[BarEval] = []
    for i in range(warmup, len(bars) - 1, step):
        mod = int(((bars[i, 0] + BAR_S + IST_OFFSET) // 60) % 1440)
        if entry_window is not None:
            start, cutoff = entry_window
            # Bars from entry start through squareoff are evaluated. Bars before
            # start can't be traded; bars at/after squareoff are past the close.
            # Bars between cutoff and squareoff are squareoff-evaluation only:
            # simulate() blocks new entries after its own cutoff, so these rows
            # only manage/square-off open positions — this is what makes the
            # 15:10 SQUAREOFF branch reachable instead of holding overnight.
            if mod < start or mod >= squareoff_min:
                continue
        window = bars[: i + 1]
        snap = Snapshot(
            underlying=underlying,
            ts=float(window[-1, 0]),
            bars=window[-400:],
            spot=float(window[-1, 4]),
            lot_size=lot,
            bench_close=None
            if bench is None
            else bench[: i + 1][-400:, 4]
            if bench.ndim == 2
            else bench[: i + 1][-400:],
            minute_of_day=mod,
            params=params,
            chain=chain_fetcher(underlying, float(window[-1, 0]))
            if chain_fetcher is not None
            else None,
        )
        out.append(BarEval(i, float(window[-1, 4]), mod, fusion.run_engines(snap, horizon)))
    return out


def replay(
    pre: list[BarEval],
    bars: np.ndarray,
    params: TunableParams,
    model: OnlineLogit | None = None,
    cost_r: float = fusion.COST_R,
    underlying: str = "BT",
    squareoff_min: int | None = DEFAULT_SQUAREOFF_MIN,
) -> tuple[list[SignalRow], Metrics]:
    """Evaluate every sampled bar, label every candidate, simulate the traded subset.

    A position is flattened at ``squareoff_min`` and never held overnight, so a label's window
    stops there (``None`` turns that off, for diagnostics only).
    """
    rows, traded = replay_traded(pre, bars, params, model, cost_r, underlying, squareoff_min)
    return rows, metrics(traded)


def replay_traded(
    pre: list[BarEval],
    bars: np.ndarray,
    params: TunableParams,
    model: OnlineLogit | None = None,
    cost_r: float = fusion.COST_R,
    underlying: str = "BT",
    squareoff_min: int | None = DEFAULT_SQUAREOFF_MIN,
) -> tuple[list[SignalRow], list[float]]:
    """Like :func:`replay`, but returns the raw R of each traded position.

    The raw list is what a search over several underlyings needs: the results
    of one underlying have to be pooled with another's before the metrics are
    computed, and a metrics object cannot be un-pooled.
    """
    rows, positions = replay_positions(pre, bars, params, model, cost_r, underlying, squareoff_min)
    return rows, [r for _index, r in positions]


def replay_positions(
    pre: list[BarEval],
    bars: np.ndarray,
    params: TunableParams,
    model: OnlineLogit | None = None,
    cost_r: float = fusion.COST_R,
    underlying: str = "BT",
    squareoff_min: int | None = DEFAULT_SQUAREOFF_MIN,
) -> tuple[list[SignalRow], list[tuple[int, float]]]:
    """Like :func:`replay_traded`, but each traded result carries its bar index.

    A study that pools several folds, or several underlyings, has to know when
    each trade happened to put them back in date order before measuring a draw-
    down: an equity curve over a shuffled R list means nothing. The index is the
    position in ``bars`` of the bar the decision was made on.
    """
    rows: list[SignalRow] = []
    positions: list[tuple[int, float]] = []
    busy_until = -1
    h = params.horizon_bars
    for be in pre:
        snap = Snapshot(underlying, 0.0, np.empty((0, 6)), be.entry, minute_of_day=be.minute_of_day)
        cands = fusion.evaluate(snap, be.reports, params, model, cost_r)
        if squareoff_min is None:
            fut, h_eff = bars[be.index + 1 : be.index + 1 + h], h
        else:
            fut, h_eff = session_future(
                bars[be.index + 1 : be.index + 1 + h], bars[be.index, 0], h, squareoff_min
            )
        best_ev = fusion.best(cands)
        for c in cands:
            sign = 1 if c.side == "LONG" else -1
            lab = label_triple_barrier(
                be.entry,
                sign,
                c.sigma_h,
                c.k_stop,
                c.k_target,
                fut[:, 2],
                fut[:, 3],
                fut[:, 4],
                h_eff,
            )
            if lab is None:
                continue
            y = 1.0 if lab.outcome == 1 else 0.0
            r_net = lab.r - cost_r
            rows.append(
                SignalRow(
                    be.index,
                    c,
                    lab,
                    y,
                    r_net,
                    key=int(bars[be.index, 0] // BAR_S),
                    span=int(lab.bars),
                )
            )
            if best_ev is not None and c is best_ev and be.index > busy_until:
                positions.append((be.index, r_net))
                busy_until = be.index + lab.bars
    return rows, positions


def train_model(
    rows: list[SignalRow], names: list[str], holdout: float = 0.25, seed: int = 11
) -> tuple[OnlineLogit, dict[str, float]]:
    """Fit on the older part, calibrate on the newest ``holdout`` share (no leakage)."""
    rows = sorted(rows, key=lambda r: r.index)
    cut = int(len(rows) * (1.0 - holdout))
    fit, cal = rows[:cut], rows[cut:]
    model = OnlineLogit(names)
    model.fit_batch([r.candidate.features for r in fit], [r.y for r in fit], epochs=3, seed=seed)
    model.calibrate([r.candidate.features for r in cal], [r.y for r in cal])
    # How many independent samples the fit really held. Rows without bar numbers are treated as
    # consecutive bars with a full-horizon window, the most overlapped reading.
    keys = [r.key if r.key is not None else r.index for r in fit]
    spans = [r.span if r.span is not None else DEFAULT_SPAN for r in fit]
    model.n_eff = effective_sample_size(keys, spans)
    from services.brain.engines.ml import brier

    ps = [model.predict(r.candidate.features) for r in cal]
    base = float(np.mean([r.y for r in fit])) if fit else 0.5
    stats = {
        "n_fit": len(fit),
        "n_eff": round(float(model.n_eff), 1),
        "n_cal": len(cal),
        "brier": brier(ps, [r.y for r in cal]),
        "brier_base": brier([base] * len(cal), [r.y for r in cal]),
    }
    return model, stats
