"""Walk-forward edge study over the history Historify already holds.

The live Brain can only judge itself on the few months of signals it has
journalled, and that is not enough evidence to answer the question a trader
actually asks: does this rule have an edge. Historify holds years of 5-minute
bars for every index the Brain trades, so the same engines, the same fusion and
the same gate can be replayed over all of it, fold by fold, with nothing from
the future in the fit.

What this measures, and deliberately keeps separate:

``label_*``
    every candidate the fusion scored on a sampled bar, labelled by the triple
    barrier that followed it. This is the barrier configuration's own edge: what
    happens if you take both sides at every opportunity, with no gate.
``trade_*``
    the one-position-at-a-time subset the gate would actually have taken. This
    is the edge of the rule, which is the only number that matters to a trader.

Both are reported per fold, pooled per underlying (``fold="ALL"``) and pooled
across underlyings (``underlying="ALL"``). The pools are what a promotion
decision should read: one quarter rarely holds enough independent trades to say
anything, and a lower confidence bound computed on nine trades is noise.

The model is deliberately absent (``model=None``). No challenger has ever been
promoted, so the live Brain is still trading its prior, and a study that scored
a model trained on the same bars it then evaluated would be measuring its own
memory. What the engines and the barrier can do on their own is the foundation
the model has to beat.

Usage::

    uv run python -m services.brain.edge_report
    uv run python -m services.brain.edge_report --years 3 --fold month --no-save
    uv run python -m services.brain.edge_report --symbols NIFTY,BANKNIFTY --horizons 12
"""

from __future__ import annotations

import argparse
import math
import sys
import time
import uuid
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field, replace
from datetime import date, datetime, timedelta, timezone
from typing import Any

import numpy as np

from database import brain_db as db
from services.brain import backtest as bt
from services.brain import fusion, history
from services.brain.config import PARAM_BOUNDS, RiskLimits, TunableParams
from services.brain.labeling import Metrics, metrics
from utils.logging import get_logger

logger = get_logger(__name__)

IST = timezone(timedelta(hours=5, minutes=30))

#: Label windows to test, in bars. Six is half an hour, twelve an hour, twenty-
#: four two hours — the range a 5-minute index decision can plausibly hold for.
HORIZONS = (6, 12, 24)

#: Stop/target pairs to test, in units of the expected move over the horizon.
#: The default set is first because it is what the live Brain ships with.
BARRIERS = ((0.8, 1.2), (1.0, 1.5), (0.6, 1.2), (1.0, 2.5), (1.5, 2.0))

DEFAULT_STEP = 6  # sample every 6th bar: 12 decisions an hour, a quarter in ~90s
DEFAULT_YEARS = 5
DEFAULT_FOLD = "quarter"

#: The literal label of a pooled row, in ``fold`` and ``underlying`` alike.
POOL = "ALL"


@dataclass(frozen=True, slots=True)
class Cell:
    """One measured cell: a fold (or a pool), an underlying, a barrier set."""

    underlying: str
    fold: str
    horizon_bars: int
    k_stop: float
    k_target: float
    bar_from: float = 0.0
    bar_to: float = 0.0
    label: Metrics = field(default_factory=Metrics)
    trade: Metrics = field(default_factory=Metrics)
    note: str = ""

    @property
    def is_pool(self) -> bool:
        return self.fold == POOL

    def as_row(self) -> dict[str, object]:
        """The shape ``brain_db.edge_report_add`` writes."""
        return {
            "underlying": self.underlying,
            "fold": self.fold,
            "bar_from": float(self.bar_from),
            "bar_to": float(self.bar_to),
            "horizon_bars": int(self.horizon_bars),
            "k_stop": float(self.k_stop),
            "k_target": float(self.k_target),
            "label_n": int(self.label.n),
            "label_win_rate": float(self.label.win_rate),
            "label_expectancy_r": float(self.label.expectancy_r),
            "label_lcb_r": float(self.label.lcb_r),
            "trade_n": int(self.trade.n),
            "trade_win_rate": float(self.trade.win_rate),
            "trade_expectancy_r": float(self.trade.expectancy_r),
            "trade_lcb_r": float(self.trade.lcb_r),
            "trade_stderr_r": float(self.trade.stderr_r),
            "trade_profit_factor": float(self.trade.profit_factor),
            "trade_max_dd_r": float(self.trade.max_dd_r),
            "trade_total_r": float(self.trade.total_r),
            "params_note": self.note[:64],
        }


@dataclass(slots=True)
class _Acc:
    """Raw per-trade results of a pool, kept with their time so a curve can be drawn."""

    label: list[tuple[float, float]] = field(default_factory=list)
    trade: list[tuple[float, float]] = field(default_factory=list)
    bar_from: float = math.inf
    bar_to: float = 0.0

    def add(
        self, label: Sequence[tuple[float, float]], trade: Sequence[tuple[float, float]]
    ) -> None:
        self.label.extend(label)
        self.trade.extend(trade)
        for ts, _r in label:
            self.bar_from = min(self.bar_from, float(ts))
            self.bar_to = max(self.bar_to, float(ts))

    def metrics(self) -> tuple[Metrics, Metrics]:
        return _metrics_of(self.label), _metrics_of(self.trade)


def _metrics_of(items: Sequence[tuple[float, float]]) -> Metrics:
    """Trade metrics over results that may have arrived out of chronological order.

    ``metrics`` measures a drawdown as the deepest fall from a running peak, so
    the order of the list is part of the answer. Pooling two underlyings appends
    one series after the other, which is not their date order, so the list is
    sorted by the time each decision was made before anything is measured.
    """
    if not items:
        return Metrics()
    return metrics([r for _ts, r in sorted(items, key=lambda p: p[0])])


def default_universe() -> dict[str, str]:
    """The Brain's own underlyings and the exchange each one's bars live on."""
    from services.brain.orchestrator import UNDERLYINGS

    return {name: exchange for name, (exchange, _fo) in UNDERLYINGS.items()}


def peers() -> tuple[dict[str, str], str]:
    """The benchmark of each underlying, and the one a stock falls back to.

    Read from the orchestrator rather than restated here: a study that measured
    the engines against a different peer than the live scan does would be
    measuring a different rule.
    """
    from services.brain.orchestrator import BENCHMARKS, DEFAULT_BENCHMARK

    return dict(BENCHMARKS), DEFAULT_BENCHMARK


def session_window() -> tuple[tuple[int, int], int]:
    """The human-owned entry window and square-off, in IST minutes."""
    lim = RiskLimits.from_env()
    return (lim.entry_start_min, lim.entry_cutoff_min), lim.squareoff_min


def check_grid(horizons: Sequence[int], barriers: Sequence[tuple[float, float]]) -> None:
    """Refuse a barrier the tuner is not allowed to set, before hours of replay."""
    if not horizons:
        raise ValueError("at least one horizon is required")
    if not barriers:
        raise ValueError("at least one barrier pair is required")
    lo_h, hi_h = PARAM_BOUNDS["horizon_bars"]
    for h in horizons:
        if not lo_h <= int(h) <= hi_h:
            raise ValueError(f"horizon {h} is outside the allowed {lo_h}..{hi_h} bars")
    for name in ("k_stop", "k_target"):
        lo, hi = PARAM_BOUNDS[name]
        for pair in barriers:
            value = pair[0] if name == "k_stop" else pair[1]
            if not lo <= float(value) <= hi:
                raise ValueError(f"{name}={value} is outside the allowed {lo}..{hi}")


def run_study(
    start: date,
    end: date,
    *,
    underlyings: Mapping[str, str] | None = None,
    fold: str = DEFAULT_FOLD,
    horizons: Sequence[int] = HORIZONS,
    barriers: Sequence[tuple[float, float]] = BARRIERS,
    step: int = DEFAULT_STEP,
    cost_r: float = fusion.COST_R,
    lookback_days: int = history.DEFAULT_LOOKBACK_DAYS,
    pad_days: int = history.DEFAULT_PAD_DAYS,
    fetch: history.BarsFetcher | None = None,
    params: TunableParams | None = None,
    persist: bool = True,
    run_id: str | None = None,
    chain_fetcher: Any | None = None,
) -> dict[str, object]:
    """Replay every fold of ``[start, end)`` and return the measured cells.

    Nothing is trained and nothing is carried between folds: each fold is
    evaluated on bars the previous fold never saw, and a label may not read past
    its own fold except across the pad, where it is closing a trade it opened
    inside the fold. That is the whole point of walking forward rather than
    optimising one period and reporting it.
    """
    if end <= start:
        raise ValueError("the study needs a range that ends after it starts")
    if int(step) < 1:
        raise ValueError("step must be at least one bar")
    check_grid(horizons, barriers)

    folds = history.fold_ranges(start, end, fold)
    if not folds:
        raise ValueError(f"no {fold} folds fall inside the range")

    universe = dict(underlyings or default_universe())
    bench_of, default_bench = peers()
    window, squareoff = session_window()
    base = (params or TunableParams()).clamp()
    lo_ts, hi_ts = history.study_range(start, end, lookback_days, pad_days)
    rid = run_id or _new_run_id()
    created = time.time()

    cells: dict[tuple[str, str, int, float, float], Cell] = {}
    per_underlying: dict[tuple[str, int, float, float], _Acc] = {}
    overall: dict[tuple[int, float, float], _Acc] = {}

    for name, exchange in universe.items():
        bars = history.load_bars(name, exchange, lo_ts, hi_ts, fetch)
        if len(bars) < history.MIN_WARMUP_BARS + 2:
            logger.warning(
                "edge study: %s has %d bars in the window, too few to replay (need %d)",
                name,
                len(bars),
                history.MIN_WARMUP_BARS + 2,
            )
            continue
        bench_name = bench_of.get(name, default_bench)
        bench = None
        if bench_name in universe and bench_name != name:
            bench = history.align_bench(
                bars, history.load_bars(bench_name, universe[bench_name], lo_ts, hi_ts, fetch)
            )
        logger.info(
            "edge study: %s %s..%s, %d bars, benchmark %s",
            name,
            _ymd(float(bars[0, 0])),
            _ymd(float(bars[-1, 0])),
            len(bars),
            bench_name if bench is not None else "none",
        )
        _walk(
            name,
            bars,
            bench,
            folds,
            horizons,
            barriers,
            step,
            cost_r,
            window,
            squareoff,
            base,
            cells,
            per_underlying,
            overall,
            chain_fetcher,
        )

    if not per_underlying:
        raise ValueError(
            "no underlying had enough stored history to replay; "
            "run Historify's downloader for these symbols first"
        )

    # Pools last, so they see every fold of every underlying.
    for (name, h, ks, kt), acc in per_underlying.items():
        label, trade = acc.metrics()
        cells[(name, POOL, h, ks, kt)] = Cell(
            name, POOL, h, ks, kt, acc.bar_from, acc.bar_to, label, trade, _note(h, ks, kt)
        )
    for (h, ks, kt), acc in overall.items():
        label, trade = acc.metrics()
        cells[(POOL, POOL, h, ks, kt)] = Cell(
            POOL, POOL, h, ks, kt, acc.bar_from, acc.bar_to, label, trade, _note(h, ks, kt)
        )

    ordered = _ordered(cells.values(), horizons, barriers)
    rows = [c.as_row() for c in ordered]

    saved = 0
    if persist:
        db.init_db()
        saved = db.edge_report_add(rid, created, rows)
        logger.info("edge study: wrote %d cells to brain_edge_report as run %s", saved, rid)

    return {
        "run_id": rid,
        "created_at": created,
        "start": start.isoformat(),
        "end": end.isoformat(),
        "fold": fold,
        "step": int(step),
        "cost_r": float(cost_r),
        "horizons": list(horizons),
        "barriers": [list(b) for b in barriers],
        "underlyings": list(universe),
        "cells": ordered,
        "rows": rows,
        "saved": saved,
    }


def _walk(
    name: str,
    bars: np.ndarray,
    bench: np.ndarray | None,
    folds: Sequence[history.Fold],
    horizons: Sequence[int],
    barriers: Sequence[tuple[float, float]],
    step: int,
    cost_r: float,
    window: tuple[int, int],
    squareoff: int,
    base: TunableParams,
    cells: dict[tuple[str, str, int, float, float], Cell],
    per_underlying: dict[tuple[str, int, float, float], _Acc],
    overall: dict[tuple[int, float, float], _Acc],
    chain_fetcher: Any | None = None,
) -> None:
    """One underlying: precompute each fold once per horizon, then replay the grid."""
    for h in horizons:
        params_h = replace(base, horizon_bars=int(h))
        for fold in folds:
            i0, i1 = history.window_slice(bars, fold.start_ts, fold.end_ts)
            if i1 <= i0:
                continue
            pre = [
                be
                for be in bt.precompute(
                    bars[:i1],
                    bench=None if bench is None else bench[:i1],
                    underlying=name,
                    warmup=history.MIN_WARMUP_BARS,
                    step=step,
                    horizon=int(h),
                    # ``precompute`` reads ``squareoff_min`` as the last bar it may
                    # sample, so it is given the entry cutoff, not the square-off:
                    # sampling past the cutoff would invent entries the live gate
                    # refuses. The label window is a different thing and is cut at
                    # the real square-off in the replay below.
                    entry_window=window,
                    squareoff_min=window[1],
                    params=params_h,
                    chain_fetcher=chain_fetcher,
                )
                if be.index >= i0
            ]
            if not pre:
                continue
            bar_from = float(bars[pre[0].index, 0])
            bar_to = float(bars[min(len(bars) - 1, pre[-1].index + int(h)), 0])
            for ks, kt in barriers:
                params_b = replace(params_h, k_stop=float(ks), k_target=float(kt))
                rows, positions = bt.replay_positions(
                    pre,
                    bars,
                    params_b,
                    None,
                    cost_r,
                    name,
                    squareoff,
                )
                label = [(float(bars[r.index, 0]), float(r.r_net)) for r in rows]
                trade = [(float(bars[i, 0]), float(r)) for i, r in positions]
                cells[(name, fold.label, int(h), float(ks), float(kt))] = Cell(
                    name,
                    fold.label,
                    int(h),
                    float(ks),
                    float(kt),
                    bar_from,
                    bar_to,
                    _metrics_of(label),
                    _metrics_of(trade),
                    _note(int(h), ks, kt),
                )
                per_underlying.setdefault((name, int(h), float(ks), float(kt)), _Acc()).add(
                    label, trade
                )
                overall.setdefault((int(h), float(ks), float(kt)), _Acc()).add(label, trade)
            logger.info(
                "edge study: %s %s h=%d done (%d sampled bars)", name, fold.label, h, len(pre)
            )


def _note(horizon: int, k_stop: float, k_target: float) -> str:
    return f"prior h={horizon} stop={k_stop:g} target={k_target:g}"


def _ordered(cells, horizons: Sequence[int], barriers: Sequence[tuple[float, float]]) -> list[Cell]:
    """Cells in the order a reader wants them: barrier set, then pool, then names."""
    rank = {
        (int(h), float(ks), float(kt)): i
        for i, (h, ks, kt) in enumerate((h, ks, kt) for h in horizons for ks, kt in barriers)
    }
    return sorted(
        cells,
        key=lambda c: (
            rank.get((c.horizon_bars, c.k_stop, c.k_target), len(rank)),
            0 if c.underlying == POOL else 1,
            0 if c.fold == POOL else 1,
            c.underlying,
            c.fold,
        ),
    )


def _new_run_id() -> str:
    return f"{datetime.now(IST).strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:4]}"


def _ymd(ts: float) -> str:
    return datetime.fromtimestamp(float(ts), IST).strftime("%Y-%m-%d")


# --- reading the result back out -------------------------------------------
def format_report(result: Mapping[str, object], *, pooled_only: bool = False) -> str:
    """A plain-text table an operator can read without a database browser."""
    cells: list[Cell] = list(result["cells"])  # type: ignore[arg-type]
    head = [
        f"run {result['run_id']}  {result['start']}..{result['end']}  "
        f"fold={result['fold']} step={result['step']} cost={result['cost_r']:.2f}R "
        f"cells={len(cells)} saved={result['saved']}",
        "",
    ]
    body: list[str] = []
    current = None
    for c in cells:
        if pooled_only and not c.is_pool:
            continue
        key = (c.horizon_bars, c.k_stop, c.k_target)
        if key != current:
            current = key
            body.append(f"horizon {c.horizon_bars} bars  stop {c.k_stop:g}  target {c.k_target:g}")
            body.append(
                "  underlying   fold      trades  win   expect      lcb    totalR     ddR  "
                "cands  (label expect)"
            )
        body.append(
            f"  {c.underlying:<12} {c.fold:<8} {c.trade.n:>7} "
            f"{100.0 * c.trade.win_rate:>4.0f}% {c.trade.expectancy_r:>+8.3f} "
            f"{c.trade.lcb_r:>+8.3f} {c.trade.total_r:>+9.1f} {c.trade.max_dd_r:>7.1f} "
            f"{c.label.n:>6}  ({c.label.expectancy_r:>+7.3f})"
        )
    return "\n".join(head + body)


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Walk-forward edge study over Historify's stored 5-minute bars.",
    )
    parser.add_argument(
        "--years", type=float, default=DEFAULT_YEARS, help="years of history to study"
    )
    parser.add_argument(
        "--start", type=str, default="", help="first day, YYYY-MM-DD (overrides --years)"
    )
    parser.add_argument("--end", type=str, default="", help="last day, YYYY-MM-DD (default: today)")
    parser.add_argument("--fold", choices=history.FOLDS, default=DEFAULT_FOLD, help="fold length")
    parser.add_argument("--step", type=int, default=DEFAULT_STEP, help="sample one bar in N")
    parser.add_argument(
        "--horizons",
        type=str,
        default=",".join(str(h) for h in HORIZONS),
        help="label windows, in bars",
    )
    parser.add_argument(
        "--barriers",
        type=str,
        default=";".join(f"{a:g}/{b:g}" for a, b in BARRIERS),
        help="stop/target pairs, semicolon separated",
    )
    parser.add_argument("--symbols", type=str, default="", help="comma separated underlyings")
    parser.add_argument("--pooled", action="store_true", help="print pooled rows only")
    parser.add_argument(
        "--no-save", action="store_true", help="measure without writing to the database"
    )
    parser.add_argument(
        "--run-id", type=str, default="", help="reuse a run id instead of minting one"
    )
    args = parser.parse_args(argv)

    try:
        end = _parse_day(args.end) or datetime.now(IST).date()
        start = _parse_day(args.start) or (end - timedelta(days=int(365.25 * args.years)))
        horizons = tuple(int(h) for h in args.horizons.split(",") if h.strip())
        barriers = tuple(
            (float(pair.split("/")[0]), float(pair.split("/")[1]))
            for pair in args.barriers.split(";")
            if pair.strip()
        )
        universe = default_universe()
        if args.symbols.strip():
            wanted = [s.strip().upper() for s in args.symbols.split(",") if s.strip()]
            unknown = [s for s in wanted if s not in universe]
            if unknown:
                parser.error(f"unknown underlying: {', '.join(unknown)}")
            universe = {s: universe[s] for s in wanted}
        result = run_study(
            start,
            end,
            underlyings=universe,
            fold=args.fold,
            horizons=horizons,
            barriers=barriers,
            step=args.step,
            persist=not args.no_save,
            run_id=args.run_id or None,
        )
    except ValueError as exc:
        logger.error("edge study: %s", exc)
        return 2

    print(format_report(result, pooled_only=args.pooled))
    return 0


def _parse_day(text: str) -> date | None:
    text = (text or "").strip()
    if not text:
        return None
    return datetime.strptime(text, "%Y-%m-%d").date()


if __name__ == "__main__":
    sys.exit(main())
