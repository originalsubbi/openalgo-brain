"""Option-chain snapshot logging.

One row per underlying per decided bar, taken at the moment the Brain decides
(so training data matches what the live engine saw, with no look-ahead). The
summary is the options engine's own statistics; the raw part is the thin
ATM +/- N strike table. Mid prices are derivable from bid/ask, so only the raw
quotes are stored. A failure here must never break a scan.
"""

from __future__ import annotations

import math
from typing import Any

from database import brain_db as db
from utils.logging import get_logger

logger = get_logger(__name__)

RAW_KEYS = (
    "strike",
    "ce_ltp",
    "pe_ltp",
    "ce_bid",
    "ce_ask",
    "pe_bid",
    "pe_ask",
    "ce_oi",
    "pe_oi",
    "ce_iv",
    "pe_iv",
    "ce_delta",
    "pe_delta",
    "ce_gamma",
    "pe_gamma",
)
RAW_KEEP_DAYS = 90
STRIKES_EACH_SIDE = 10
PRUNE_EVERY_S = 86400.0


def _f(v: Any) -> float:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return 0.0
    return round(x, 6) if math.isfinite(x) else 0.0


def compact_rows(chain: dict[str, Any], each_side: int = STRIKES_EACH_SIDE) -> dict[str, Any]:
    """Thin raw chain: the ATM strike and ``each_side`` strikes either side."""
    rows = sorted(chain.get("rows") or [], key=lambda r: _f(r.get("strike")))
    if not rows:
        return {"k": list(RAW_KEYS), "r": []}
    spot = _f(chain.get("atm_strike")) or _f(chain.get("spot"))
    centre = min(range(len(rows)), key=lambda i: abs(_f(rows[i].get("strike")) - spot))
    keep = rows[max(centre - each_side, 0) : centre + each_side + 1]
    return {"k": list(RAW_KEYS), "r": [[_f(r.get(k)) for k in RAW_KEYS] for r in keep]}


def log_snapshot(
    underlying: str,
    bar_ts: float,
    now: float,
    chain: dict[str, Any],
    stats: dict[str, float],
) -> bool:
    """Store one snapshot for this bar. True when a row was written."""
    try:
        if not chain.get("rows") or db.chain_snapshot_seen(underlying, bar_ts):
            return False
        db.chain_snapshot_add(
            {
                "ts": now,
                "bar_ts": bar_ts,
                "underlying": underlying,
                "expiry": str(chain.get("expiry") or ""),
                "spot": _f(chain.get("spot")),
                "atm_strike": _f(chain.get("atm_strike")),
                "dte": _f(chain.get("dte")),
                "lot_size": int(chain.get("lot_size") or 1),
                "pcr": _f(stats.get("pcr")),
                "atm_iv": _f(stats.get("atm_iv")),
                "straddle": _f(stats.get("straddle")),
                "skew": _f(stats.get("skew")),
                "net_gex": _f(stats.get("net_gex")),
                "gex_norm": _f(stats.get("gex_norm")),
                "flip": _f(stats.get("flip")),
                "call_wall": _f(stats.get("call_wall")),
                "put_wall": _f(stats.get("put_wall")),
                "max_pain": _f(stats.get("max_pain")),
                "rows": compact_rows(chain),
            }
        )
        return True
    except Exception:  # journaling is best-effort
        logger.exception("brain chain snapshot failed for %s", underlying)
        return False


def maybe_prune(now: float) -> None:
    try:
        last = float(db.state_get("last_chain_prune", 0.0) or 0.0)
        if now - last >= PRUNE_EVERY_S:
            db.chain_prune(RAW_KEEP_DAYS)
            db.state_set("last_chain_prune", now)
    except Exception:
        logger.exception("brain chain prune failed")
