"""Independent Risk Gate. Pure. Fixed rules, human-owned limits, kill switch.

This module is the last word before an order. It knows nothing about engines,
probabilities, models or learning, and it imports only ``RiskLimits`` (frozen,
from the environment). A confident model cannot talk its way past it, and the
learner has no handle on it.

Position-level rules (stop, target, trailing) and the combined loss limit are
evaluated by ``services.risk``; this gate calls that core rather than carrying a
second copy of the arithmetic (CLAUDE.md, "Risk rules live in services/risk/").
What lives here is pre-trade only: may a new position be opened, and how big.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from services.brain.bands import BLAST_DTE_MAX
from services.brain.config import RiskLimits
from services.risk import AggregateRisk, evaluate_aggregate


@dataclass(frozen=True, slots=True)
class GateState:
    now_min: int  # IST minutes since midnight
    weekday: int  # Monday = 0
    capital: float
    funds_available: float
    realized_pnl_today: float
    unrealized_pnl: float
    open_positions: int
    open_exposure: float  # premium outlay currently at risk
    trades_today: int
    consecutive_losses: int
    minutes_since_last_loss: float | None
    equity: float  # the Brain's own cumulative realised P&L curve
    peak_equity: float
    data_age_s: float  # seconds since the market data was last fetched
    kill_switch: bool
    drawdown_halt: bool  # latched in the journal until a human releases it
    bar_lag_s: float = 0.0  # seconds the newest completed bar is behind where it should be
    # Adaptive bar-lag ceiling (p90 of recent lags + buffer), computed in the
    # scan. When > 0 it overrides the fixed limits.max_bar_lag_s so the gate
    # follows real broker publish jitter instead of a static env value. Zero
    # means "use the configured fixed limit".
    bar_lag_thresh: float = 0.0
    open_same_underlying: int = 0  # open positions already held on this underlying
    swing_max_hold_days: int = 5
    positional_max_hold_days: int = 20
    swing_margin_factor: float = 0.30
    positional_margin_factor: float = 0.40


@dataclass(frozen=True, slots=True)
class Proposal:
    premium: float  # option price per unit
    lot_size: int
    spread_pct: float
    risk_per_unit: float  # premium lost per unit if the stop is hit
    band: str = ""  # ITM | ATM | OTM — the moneyness of the proposed leg
    dte: float = 0.0  # days to expiry of the proposed leg
    # Margin the position would tie up, per unit. Zero for a long premium
    # position, where the premium outlay already is the cash commitment. A
    # short option spread blocks far more than its premium is worth, so its
    # margin is carried here and checked against the funds available.
    margin_per_unit: float = 0.0
    # "intraday" | "swing" | "positional" — determines holding period rules
    # and margin factor used at entry.
    trade_type: str = "intraday"
    # Quoted spread of the protective leg of a credit spread, in percent of its
    # mid. 0 = no protective leg (a long option), so the hedge cap is not applied.
    hedge_spread_pct: float = 0.0


@dataclass(frozen=True, slots=True)
class GateVerdict:
    allow: bool
    lots: int = 0
    reasons: tuple[str, ...] = ()
    flatten: bool = False  # the state itself demands closing what is open


def daily_loss_limit(limits: RiskLimits, capital: float) -> float:
    return max(capital, 0.0) * limits.max_daily_loss_pct / 100.0


def drawdown_pct(state: GateState) -> float:
    if state.capital <= 0:
        return 0.0
    return max(state.peak_equity - state.equity, 0.0) / state.capital * 100.0


def daily_loss_breached(limits: RiskLimits, state: GateState) -> bool:
    cap = daily_loss_limit(limits, state.capital)
    if cap <= 0:
        return False
    decision = evaluate_aggregate(
        AggregateRisk(combined_stoploss=cap), state.realized_pnl_today, state.unrealized_pnl
    )
    return bool(decision.breached)


def check_manage(limits: RiskLimits, state: GateState) -> GateVerdict:
    """Should everything open be closed right now, regardless of any signal.

    Only the kill switch and a breached daily loss limit flatten *everything*.
    Square-off at the configured time applies to intraday positions only and is
    enforced per-position in ``executor.manage`` — swing and positional positions
    may carry overnight and are closed instead when their max hold days elapse.
    """
    deny: list[str] = []
    if state.kill_switch:
        deny.append("kill switch engaged")
    if daily_loss_breached(limits, state):
        deny.append("daily loss limit breached")
    return GateVerdict(allow=not deny, reasons=tuple(deny), flatten=bool(deny))


def check_entry(limits: RiskLimits, state: GateState, prop: Proposal) -> GateVerdict:
    deny: list[str] = []
    if state.kill_switch:
        deny.append("kill switch engaged")
    if state.drawdown_halt or drawdown_pct(state) >= limits.max_drawdown_pct:
        deny.append(f"drawdown halt ({drawdown_pct(state):.1f}% >= {limits.max_drawdown_pct:.1f}%)")
    if daily_loss_breached(limits, state):
        deny.append("daily loss limit breached")
    # Swing / positional books carry their own, separate daily-loss ceiling.
    sp_pct = {
        "swing": limits.swing_max_daily_loss_pct,
        "positional": limits.positional_max_daily_loss_pct,
    }.get(prop.trade_type)
    if sp_pct and state.capital > 0:
        day_loss = -(state.realized_pnl_today + state.unrealized_pnl)
        if day_loss >= state.capital * sp_pct / 100.0:
            deny.append(f"{prop.trade_type} daily loss limit breached ({sp_pct:g}% of capital)")
    if state.weekday >= 5:
        deny.append("market closed (weekend)")
    if not (limits.entry_start_min <= state.now_min < limits.entry_cutoff_min):
        deny.append("outside the entry window")
    if state.data_age_s > limits.max_data_age_s:
        deny.append(f"market data is stale ({state.data_age_s:.0f}s since last fetch)")
    bar_lag_limit = state.bar_lag_thresh if state.bar_lag_thresh > 0 else limits.max_bar_lag_s
    if state.bar_lag_s > bar_lag_limit:
        deny.append(f"latest bar is {state.bar_lag_s:.0f}s old: the data feed is behind")
    if state.trades_today >= limits.max_trades_per_day:
        deny.append("max trades per day reached")
    if state.open_positions >= limits.max_open_positions:
        deny.append("max open positions reached")
    if state.open_same_underlying >= limits.max_open_per_underlying:
        deny.append(
            f"already holding {state.open_same_underlying} position(s) on this underlying"
        )
    if state.consecutive_losses >= limits.max_consecutive_losses:
        # Max consecutive losses reached: done for the day unless the cooldown
        # window has lapsed since the last loss. A new win (which resets
        # consecutive_losses) is the normal way to unblock, but the cooldown
        # eventually lets the gate reopen on its own.
        if state.minutes_since_last_loss is not None and state.minutes_since_last_loss >= limits.cooldown_minutes:
            pass  # cooldown expired, allow entry again
        else:
            deny.append("losing streak: cooling off pause")
    elif state.consecutive_losses >= max(2, limits.max_consecutive_losses // 2):
        # Half-way to the limit: start cooling off. Floored at two losses: with the
        # default limit of 3, ``3 // 2`` is 1, which paused entries for the whole
        # cooldown after a single loss.
        if state.minutes_since_last_loss is not None and state.minutes_since_last_loss < limits.cooldown_minutes:
            deny.append(f"cooling off after {state.consecutive_losses} losses")
    if prop.premium < limits.min_premium:
        deny.append(f"premium {prop.premium:.2f} below minimum {limits.min_premium:.2f}")
    if limits.max_premium > 0 and prop.premium > limits.max_premium:
        deny.append(
            f"premium {prop.premium:.2f} above cheap-premium cap {limits.max_premium:.2f}"
        )
    if prop.spread_pct > limits.max_spread_pct:
        deny.append(f"spread {prop.spread_pct:.1f}% above {limits.max_spread_pct:.1f}%")
    if prop.hedge_spread_pct > limits.max_hedge_spread_pct:
        deny.append(
            f"hedge leg spread {prop.hedge_spread_pct:.1f}% above "
            f"{limits.max_hedge_spread_pct:.1f}%"
        )
    if state.capital <= 0:
        deny.append("capital unknown")
    if deny:
        return GateVerdict(False, 0, tuple(deny))

    unit = prop.lot_size
    risk_budget = state.capital * limits.risk_per_trade_pct / 100.0
    per_lot_risk = prop.risk_per_unit * unit
    per_lot_cost = prop.premium * unit
    if per_lot_risk <= 0 or per_lot_cost <= 0:
        return GateVerdict(False, 0, ("cannot size: risk per lot is not positive",))
    by_risk = math.floor(risk_budget / per_lot_risk)
    by_funds = math.floor(state.funds_available / per_lot_cost)
    room = state.capital * limits.max_exposure_pct / 100.0 - state.open_exposure
    by_exposure = math.floor(max(room, 0.0) / per_lot_cost)
    lots = min(by_risk, by_funds, by_exposure, limits.max_lots)
    # Margin block: a short option spread ties up far more than the premium it
    # collects, and the premium outlay alone would let it through. The block is
    # a share of the funds available, never more. Swing/positional use a
    # different margin factor than intraday (they carry overnight risk).
    margin_factor = limits.margin_factor
    if prop.trade_type == "swing":
        margin_factor = limits.swing_margin_factor
    elif prop.trade_type == "positional":
        margin_factor = limits.positional_margin_factor

    if prop.margin_per_unit > 0:
        per_lot_margin = prop.margin_per_unit * unit
        margin_room = state.funds_available * limits.max_margin_pct / 100.0
        by_margin = math.floor(margin_room / per_lot_margin)
        if by_margin < lots:
            lots = max(0, by_margin)
    # Gamma-blast trades (OTM inside the last days of an expiry) are the
    # highest-variance position the Brain can open: cap them at one lot
    # regardless of what the risk budget would otherwise allow.
    if lots > 1 and prop.band == "OTM" and prop.dte <= BLAST_DTE_MAX:
        lots = 1
        return GateVerdict(
            True,
            1,
            ("gamma-blast zone: capped at 1 lot",),
        )
    if lots < 1:
        binding = min(
            (by_risk, "risk budget"),
            (by_funds, "available funds"),
            (by_exposure, "exposure cap"),
            key=lambda t: t[0],
        )[1]
        return GateVerdict(False, 0, (f"{binding} is below one lot",))
    return GateVerdict(
        True,
        int(lots),
        (
            f"sized {lots} lot(s): risk {by_risk}, funds {by_funds}, exposure {by_exposure}, cap {limits.max_lots}",
        ),
    )


def live_eligible(
    limits: RiskLimits,
    n: int,
    expectancy_r: float,
    profit_factor: float,
    max_dd_r: float,
    stderr_r: float | None = None,
) -> tuple[bool, tuple[str, ...]]:
    """May the Brain trade real money, judged on its paper record only.

    The record must clear a *lower confidence bound*, ``expectancy - sigmas x standard error``,
    not just a point estimate. ``stderr_r`` is required: without it the bound cannot be formed
    and the answer is no.
    """
    why: list[str] = []
    if not limits.live_enabled:
        why.append("BRAIN_LIVE_ENABLED is false")
    if n < limits.live_min_trades:
        why.append(f"{n}/{limits.live_min_trades} paper trades")
    if expectancy_r < limits.live_min_expectancy_r:
        why.append(f"paper expectancy {expectancy_r:+.2f}R < {limits.live_min_expectancy_r:+.2f}R")
    if stderr_r is None:
        why.append("no standard error supplied: the expectancy cannot be bounded")
    else:
        # Student-t correction: with a finite sample the 95% quantile of
        # t(df = n-1) sits above the normal quantile the configured sigmas
        # come from. Fisher–Cornish expansion (no scipy — scipy is an
        # analysis-only dependency): t ≈ z + (z³ + z) / (4·df). Small n pays
        # the full penalty; large n converges to the normal bound.
        z = limits.live_lcb_sigmas
        df = max(n - 1, 1)
        t_crit = z + (z**3 + z) / (4.0 * df)
        lcb = expectancy_r - t_crit * stderr_r
        if lcb < limits.live_min_lcb_r:
            why.append(
                f"expectancy lower bound {lcb:+.2f}R < {limits.live_min_lcb_r:+.2f}R "
                f"({t_crit:.3f} t-corrected std errors of {stderr_r:.2f}R over {n} trades)"
            )
    if profit_factor < limits.live_min_profit_factor:
        why.append(f"profit factor {profit_factor:.2f} < {limits.live_min_profit_factor:.2f}")
    if max_dd_r > limits.live_max_drawdown_r:
        why.append(f"paper drawdown {max_dd_r:.1f}R > {limits.live_max_drawdown_r:.1f}R")
    return (not why), tuple(why)
