"""Moneyness bands: which option to buy, learned from each band's own results.

The Brain's engines vote on the *underlying*; the option leg is a translation
layer on top. Which translation pays — ITM (high delta, expensive, moves like
the index), ATM (balanced), OTM (cheap, gamma-heavy, bleeds theta) — is an
empirical question, so the Brain journals one signal per band, labels each
band's own premium path, and lets a shrunk expectancy rating decide which band
actually gets traded. Near expiry the OTM band's gamma dominates (measured on
stored chains: a 1% index move is worth ~2.5x an OTM premium at 0 DTE vs ~0.1x
at 12+ DTE), which is the gamma-blast zone.

Nothing here trades by itself: the rating only re-orders bands the fusion
already passed. If OTM never earns, its rating sinks and ATM keeps trading.
"""

from __future__ import annotations

from typing import Any

from database import brain_db as db

#: (low |delta|, high |delta|, target |delta|) per band. The picker scores
#: candidate rows by distance from the target plus a spread penalty, so a band
#: picks its most liquid row near its delta centre.
BANDS: dict[str, tuple[float, float, float]] = {
    "ITM": (0.62, 0.85, 0.72),
    "ATM": (0.45, 0.55, 0.50),
    "OTM": (0.20, 0.42, 0.30),
}

#: The gamma-blast window: DTE at which the OTM band's gamma is explosive.
#: Measured on stored chain snapshots — a 1% index move is worth ~28% of an
#: OTM (delta 0.3) premium at 3 DTE and ~50% at 1 DTE, against ~6% at 12 DTE.
GAMMA_DTE_MAX = 3.0
#: Peak zone: theta drag is survivable only if the move comes fast.
BLAST_DTE_MAX = 1.0

#: Shrinkage for the band rating: a band's expectancy is blended toward the
#: all-band mean until it has this many labelled results of its own.
RATING_N_SATURATION = 40.0

#: Minimum labelled results before a band's rating is allowed to override the
#: default ATM preference for the traded leg.
MIN_LABELLED_TO_PREFER = 20


def band_of(delta: float) -> str:
    """Which band an absolute delta falls into ("" when in none)."""
    d = abs(delta)
    for name, (lo, hi, _target) in BANDS.items():
        if lo <= d <= hi:
            return name
    return ""


def in_gamma_zone(dte: float) -> bool:
    """True when the expiry is close enough for the OTM gamma to dominate."""
    return 0 <= dte <= GAMMA_DTE_MAX


def is_blast(dte: float) -> bool:
    """True inside the peak blast window (theta makes these hour-scale trades)."""
    return 0 <= dte <= BLAST_DTE_MAX


def band_stats(underlying: str = "", regime: str = "") -> dict[str, dict[str, float]]:
    """Labelled result stats per band, optionally scoped to an underlying/regime.

    Returns ``{band: {n, mean_r}}`` from brain_signal rows that carry a band and
    a finished *leg* label — the option's own premium-path barrier, not the
    underlying's. These are the training results of the band's leg, so a band
    that bleeds theta shows a negative mean no matter how pretty its
    gamma looks.
    """
    with db.session_scope() as s:
        q = s.query(
            db.BrainSignal.band,
            db.BrainSignal.leg_label_r,
        ).filter(
            db.BrainSignal.band.isnot(None),
            db.BrainSignal.band != "",
            db.BrainSignal.leg_label_r.isnot(None),
        )
        if underlying:
            q = q.filter(db.BrainSignal.underlying == underlying)
        if regime:
            q = q.filter(db.BrainSignal.regime == regime)
        rows = q.all()

    out: dict[str, dict[str, float]] = {}
    for band, leg_label_r in rows:
        acc = out.setdefault(band, {"n": 0, "mean_r": 0.0, "sum_r": 0.0})
        acc["n"] += 1
        acc["sum_r"] += float(leg_label_r)
    for acc in out.values():
        acc["mean_r"] = acc["sum_r"] / acc["n"] if acc["n"] else 0.0
    return out


def band_offsets(underlying: str, regime: str) -> dict[str, float]:
    """Per-band EV adjustment in R: how much better (worse) than average a band's
    labelled results have been, shrunk toward zero until it has enough samples.

    A band with no history gets 0.0 — the fusion EV alone decides. A band with
    enough labelled results gets its shrunk edge, which is what lets the Brain
    drift toward ITM in grindy regimes or OTM in the blast zone when the data
    says so.
    """
    scoped = band_stats(underlying, regime)
    all_stats = band_stats()
    if not all_stats:
        return {}
    global_mean = sum(a["mean_r"] * a["n"] for a in all_stats.values()) / max(
        sum(a["n"] for a in all_stats.values()), 1
    )
    offsets: dict[str, float] = {}
    for band in BANDS:
        acc = scoped.get(band)
        if not acc or not acc["n"]:
            offsets[band] = 0.0
            continue
        n = acc["n"]
        shrink = min(n / RATING_N_SATURATION, 1.0)
        offsets[band] = (acc["mean_r"] - global_mean) * shrink
    return offsets


def pick_band(
    legs: dict[str, dict[str, Any]],
    ev_r: float,
    offsets: dict[str, float],
    dte: float,
) -> str | None:
    """Which band to trade: the best spread-adjusted EV plus its learned offset.

    OTM only trades inside the gamma zone — outside it its theta bleed is not
    compensated by any gamma, and the labelled results of blast-zone OTM legs
    are the only evidence that says otherwise.
    """
    best, best_ev = None, -1e9
    for band, leg in legs.items():
        if band == "OTM" and not in_gamma_zone(dte):
            continue
        ev = ev_r + offsets.get(band, 0.0)
        if ev > best_ev:
            best, best_ev = band, ev
    return best
