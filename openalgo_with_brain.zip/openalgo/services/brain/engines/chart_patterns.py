"""Chart pattern engine: multi-bar chart pattern detection.

Detects classical chart patterns across reversal and continuation families.
All patterns are detected on 5-minute bar data using swing-based geometry
with strict rarity filters to avoid false positives.

Pattern families:
  Reversal:   head-and-shoulders, inverse H&S, double top/bottom,
              triple top/bottom, rising/falling wedge, cup-and-handle
  Continuation: ascending/descending/symmetrical triangle,
                bull/bear flag, bull/bear pennant, rectangle

Design rules:
* Pure numpy, no external dependencies.
* Swing-based: local highs/lows detected with a window, then pattern
  geometry is matched against swing sequences.
* Strict rarity filters: ATR-normalised thresholds, volume confirmation,
  max formation length, and proximity-to-breakout gates.
* Volume confirmation is MANDATORY: no pattern scores without it.
* Trend alignment is MANDATORY: patterns must align with the higher-timeframe trend.
* One pass over the last ``window`` bars; output is deterministic.
* Each signed feature sits in approximately [-1, 1] and flips sign between
  bullish and bearish variants of the same pattern family.
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np

from services.brain.types import EngineReport, Snapshot

EPS = 1e-12


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _atr(high: np.ndarray, low: np.ndarray, close: np.ndarray, n: int = 14) -> float:
    """Average true range as fraction of current close."""
    prev = close[:-1]
    tr = np.maximum.reduce(
        [high[1:] - low[1:], np.abs(high[1:] - prev), np.abs(low[1:] - prev)]
    )
    if len(tr) < n:
        return float(np.mean(tr)) / max(float(close[-1]), EPS) if len(tr) else 0.0
    val = float(np.mean(tr[:n]))
    for x in tr[n:]:
        val = (val * (n - 1) + x) / n
    return val / max(float(close[-1]), EPS)


def _find_swings(
    high: np.ndarray,
    low: np.ndarray,
    window: int = 5,
) -> tuple[np.ndarray, np.ndarray]:
    """Detect local swing highs/lows.

    A swing high at index i means high[i] is the maximum in
    [i-window, i+window]; a swing low similarly for minimum.
    Returns boolean arrays same length as input.
    """
    n = len(high)
    swings_high = np.zeros(n, dtype=bool)
    swings_low = np.zeros(n, dtype=bool)
    for i in range(window, n - window):
        win_h = high[i - window : i + window + 1]
        win_l = low[i - window : i + window + 1]
        if high[i] == float(win_h.max()):
            swings_high[i] = True
        if low[i] == float(win_l.min()):
            swings_low[i] = True
    return swings_high, swings_low


def _swing_points(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
    swings_high: np.ndarray,
    swings_low: np.ndarray,
) -> tuple[list[float], list[float], list[int], list[int]]:
    """Extract swing price levels and their bar indices."""
    sh_idx = [i for i, v in enumerate(swings_high) if v]
    sl_idx = [i for i, v in enumerate(swings_low) if v]
    sh_px = [float(high[i]) for i in sh_idx]
    sl_px = [float(low[i]) for i in sl_idx]
    return sh_px, sl_px, sh_idx, sl_idx


def _linreg(x: np.ndarray, y: np.ndarray) -> tuple[float, float, float]:
    """Linear regression: returns (slope, intercept, r_squared)."""
    n = len(x)
    if n < 2:
        return 0.0, float(y[0]) if n else 0.0, 0.0
    x_mean = float(x.mean())
    y_mean = float(y.mean())
    sxy = float(((x - x_mean) * (y - y_mean)).sum())
    sxx = float(((x - x_mean) ** 2).sum())
    if abs(sxx) < EPS:
        return 0.0, y_mean, 0.0
    slope = sxy / sxx
    intercept = y_mean - slope * x_mean
    y_pred = slope * x + intercept
    ss_res = float(((y - y_pred) ** 2).sum())
    ss_tot = float(((y - y_mean) ** 2).sum())
    r2 = 1.0 - ss_res / (ss_tot + EPS)
    return slope, intercept, max(0.0, min(1.0, r2))


def _trendline_strength(
    x: np.ndarray,
    y: np.ndarray,
    min_r2: float = 0.7,
) -> tuple[float, float, bool]:
    """Fit a trendline; return (slope, r2, is_valid)."""
    if len(x) < 3:
        return 0.0, 0.0, False
    slope, intercept, r2 = _linreg(x, y)
    return slope, r2, r2 >= min_r2


def _clamp(x: float, lim: float = 1.0) -> float:
    return float(max(-lim, min(lim, x)))


def _is_trending(close: np.ndarray, atr_frac: float, lookback: int = 20) -> int:
    """Return +1 for uptrend, -1 for downtrend, 0 for sideways."""
    if len(close) < lookback + 1:
        return 0
    returns = np.diff(close[-(lookback + 1) :])
    trend = np.sum(returns) / (atr_frac * close[-1] + EPS)
    if trend > 0.8:
        return 1
    elif trend < -0.8:
        return -1
    return 0


# ---------------------------------------------------------------------------
# Pattern detectors
# ---------------------------------------------------------------------------


def _detect_head_and_shoulders(
    sh_px: list[float],
    sl_px: list[float],
    sh_idx: list[int],
    sl_idx: list[int],
    close: np.ndarray,
    atr_abs: float,
    vol_confirm: bool,
    trend: int,
) -> tuple[float, float]:
    """Head & Shoulders (bearish) and Inverse H&S (bullish).

    Returns (bearish_score, bullish_score) each in [0, 1].
    Strict thresholds: shoulders within 1%, head promoted > 2 ATR,
    neckline flat or sloping with trend, breakout confirmed, volume confirm.
    """
    bearish = 0.0
    bullish = 0.0

    if not vol_confirm:
        return bearish, bullish

    if len(sh_px) >= 3 and len(sl_px) >= 2 and trend <= 0:
        hs = sh_px[-3:]
        hi = sh_idx[-3:]
        ls, h, rs = hs
        if h > ls and h > rs:
            shoulder_sym = 1.0 - abs(ls - rs) / (max(ls, rs) + EPS)
            head_prom = (h - max(ls, rs)) / (atr_abs + EPS)
            li_sh_h = [i for i in sl_idx if sh_idx[0] < i < sh_idx[1]]
            li_h_rs = [i for i in sl_idx if sh_idx[1] < i < sh_idx[2]]
            if li_sh_h and li_h_rs:
                t1 = min(float(sl_px[sl_idx.index(i)]) for i in li_sh_h)
                t2 = min(float(sl_px[sl_idx.index(i)]) for i in li_h_rs)
                neck_slope = (t2 - t1) / max(sh_idx[2] - sh_idx[0], 1)
                neck_flat = abs(neck_slope) < atr_abs * 0.15
                if shoulder_sym > 0.85 and head_prom > 2.0 and neck_flat:
                    neck_at_close = t1 + neck_slope * (len(close) - 1 - sh_idx[0])
                    breakout = max(0.0, (neck_at_close - close[-1]) / (atr_abs + EPS))
                    bearish = _clamp(
                        shoulder_sym * 0.35
                        + min(head_prom, 3.0) / 3.0 * 0.35
                        + breakout * 0.3
                    )

    if len(sl_px) >= 3 and len(sh_px) >= 2 and trend >= 0:
        ls_px = sl_px[-3:]
        l_s, h_l, r_s = ls_px
        if h_l < l_s and h_l < r_s:
            shoulder_sym = 1.0 - abs(l_s - r_s) / (max(l_s, r_s) + EPS)
            head_prom = (min(l_s, r_s) - h_l) / (atr_abs + EPS)
            hi_sh_l = [i for i in sh_idx if sl_idx[0] < i < sl_idx[1]]
            li_h_rl = [i for i in sh_idx if sl_idx[1] < i < sl_idx[2]]
            if hi_sh_l and li_h_rl:
                t1 = max(float(sh_px[sh_idx.index(i)]) for i in hi_sh_l)
                t2 = max(float(sh_px[sh_idx.index(i)]) for i in li_h_rl)
                neck_slope = (t2 - t1) / max(sl_idx[2] - sl_idx[0], 1)
                neck_flat = abs(neck_slope) < atr_abs * 0.15
                if shoulder_sym > 0.85 and head_prom > 2.0 and neck_flat:
                    neck_at_close = t1 + neck_slope * (len(close) - 1 - sl_idx[0])
                    breakout = max(0.0, (close[-1] - neck_at_close) / (atr_abs + EPS))
                    bullish = _clamp(
                        shoulder_sym * 0.35
                        + min(head_prom, 3.0) / 3.0 * 0.35
                        + breakout * 0.3
                    )

    return bearish, bullish


def _detect_double_top_bottom(
    sh_px: list[float],
    sl_px: list[float],
    sh_idx: list[int],
    sl_idx: list[int],
    close: np.ndarray,
    atr_abs: float,
    vol_confirm: bool,
    trend: int,
) -> tuple[float, float]:
    """Double top (bearish) and double bottom (bullish).

    Returns (bearish_score, bullish_score) each in [0, 1].
    Strict: tops within 1%, trough depth > 2 ATR, breakout confirmed, volume.
    """
    bearish = 0.0
    bullish = 0.0

    if not vol_confirm:
        return bearish, bullish

    if len(sh_px) >= 2 and len(sl_px) >= 1 and trend <= 0:
        h1, h2 = sh_px[-2], sh_px[-1]
        i1, i2 = sh_idx[-2], sh_idx[-1]
        between_lows = [
            float(sl_px[sl_idx.index(i)]) for i in sl_idx if i1 < i < i2
        ]
        if between_lows:
            trough = min(between_lows)
            top_sym = 1.0 - abs(h1 - h2) / (max(h1, h2) + EPS)
            depth = (min(h1, h2) - trough) / (atr_abs + EPS)
            if top_sym > 0.97 and depth > 2.5:
                breakout = max(0.0, (trough - close[-1]) / (atr_abs + EPS))
                bearish = _clamp(
                    top_sym * 0.4 + min(depth, 3.0) / 3.0 * 0.3 + breakout * 0.3
                )

    if len(sl_px) >= 2 and len(sh_px) >= 1 and trend >= 0:
        l1, l2 = sl_px[-2], sl_px[-1]
        i1, i2 = sl_idx[-2], sl_idx[-1]
        between_highs = [
            float(sh_px[sh_idx.index(i)]) for i in sh_idx if i1 < i < i2
        ]
        if between_highs:
            peak = max(between_highs)
            bottom_sym = 1.0 - abs(l1 - l2) / (max(l1, l2) + EPS)
            depth = (peak - max(l1, l2)) / (atr_abs + EPS)
            if bottom_sym > 0.97 and depth > 2.5:
                breakout = max(0.0, (close[-1] - peak) / (atr_abs + EPS))
                bullish = _clamp(
                    bottom_sym * 0.4 + min(depth, 3.0) / 3.0 * 0.3 + breakout * 0.3
                )

    return bearish, bullish


def _detect_triple_top_bottom(
    sh_px: list[float],
    sl_px: list[float],
    sh_idx: list[int],
    sl_idx: list[int],
    close: np.ndarray,
    atr_abs: float,
    vol_confirm: bool,
    trend: int,
) -> tuple[float, float]:
    """Triple top (bearish) and triple bottom (bullish).

    Returns (bearish_score, bullish_score) each in [0, 1].
    Strict: all three within 0.75%, depth > 2.5 ATR.
    """
    bearish = 0.0
    bullish = 0.0

    if not vol_confirm:
        return bearish, bullish

    if len(sh_px) >= 3 and len(sl_px) >= 2 and trend <= 0:
        h1, h2, h3 = sh_px[-3:]
        top_range = max(h1, h2, h3) - min(h1, h2, h3)
        top_sym = 1.0 - top_range / (max(h1, h2, h3) + EPS)
        between = []
        for a, b in zip(sh_idx[-3:-1], sh_idx[-2:]):
            bl = [float(sl_px[sl_idx.index(i)]) for i in sl_idx if a < i < b]
            if bl:
                between.append(min(bl))
        if len(between) >= 2:
            avg_trough = sum(between) / len(between)
            depth = (min(h1, h2, h3) - avg_trough) / (atr_abs + EPS)
            if top_sym > 0.97 and depth > 2.5:
                breakout = max(0.0, (avg_trough - close[-1]) / (atr_abs + EPS))
                bearish = _clamp(
                    top_sym * 0.4 + min(depth, 3.0) / 3.0 * 0.3 + breakout * 0.3
                )

    if len(sl_px) >= 3 and len(sh_px) >= 2 and trend >= 0:
        l1, l2, l3 = sl_px[-3:]
        bottom_range = max(l1, l2, l3) - min(l1, l2, l3)
        bottom_sym = 1.0 - bottom_range / (max(l1, l2, l3) + EPS)
        between = []
        for a, b in zip(sl_idx[-3:-1], sl_idx[-2:]):
            bh = [float(sh_px[sh_idx.index(i)]) for i in sh_idx if a < i < b]
            if bh:
                between.append(max(bh))
        if len(between) >= 2:
            avg_peak = sum(between) / len(between)
            depth = (avg_peak - max(l1, l2, l3)) / (atr_abs + EPS)
            if bottom_sym > 0.97 and depth > 2.5:
                breakout = max(0.0, (close[-1] - avg_peak) / (atr_abs + EPS))
                bullish = _clamp(
                    bottom_sym * 0.4 + min(depth, 3.0) / 3.0 * 0.3 + breakout * 0.3
                )

    return bearish, bullish


def _detect_triangles(
    sh_px: list[float],
    sl_px: list[float],
    sh_idx: list[int],
    sl_idx: list[int],
    close: np.ndarray,
    atr_abs: float,
    vol_confirm: bool,
    trend: int,
) -> tuple[float, float, float]:
    """Ascending, descending, symmetrical triangles.

    Returns (ascending_bullish, descending_bearish, symmetrical_dir).
    symmetrical_dir: +1 bullish breakout, -1 bearish breakout, 0 none.
    """
    asc_bull = 0.0
    desc_bear = 0.0
    sym_dir = 0.0

    if not vol_confirm:
        return asc_bull, desc_bear, sym_dir

    if len(sh_px) >= 3 and len(sl_px) >= 3:
        recent_highs = sh_px[-4:]
        recent_lows = sl_px[-4:]
        hi_idx = sh_idx[-4:]
        lo_idx = sl_idx[-4:]

        high_range = max(recent_highs) - min(recent_highs)
        top_flat = high_range / (atr_abs + EPS) < 0.3
        if top_flat and len(lo_idx) >= 2:
            lo_x = np.array(lo_idx[-3:], dtype=float)
            lo_y = np.array(recent_lows[-3:], dtype=float)
            slope, r2, valid = _trendline_strength(lo_x, lo_y, min_r2=0.7)
            if valid and slope > atr_abs * 0.3 and trend >= 0:
                resistance = max(recent_highs)
                breakout = max(0.0, (close[-1] - resistance) / (atr_abs + EPS))
                asc_bull = _clamp(
                    r2 * 0.4 + min(slope / (atr_abs + EPS), 1.0) * 0.3
                    + breakout * 0.3
                )

        low_range = max(recent_lows) - min(recent_lows)
        bottom_flat = low_range / (atr_abs + EPS) < 0.3
        if bottom_flat and len(hi_idx) >= 2:
            hi_x = np.array(hi_idx[-3:], dtype=float)
            hi_y = np.array(recent_highs[-3:], dtype=float)
            slope, r2, valid = _trendline_strength(hi_x, hi_y, min_r2=0.7)
            if valid and slope < -atr_abs * 0.3 and trend <= 0:
                support = min(recent_lows)
                breakout = max(0.0, (support - close[-1]) / (atr_abs + EPS))
                desc_bear = _clamp(
                    r2 * 0.4
                    + min(abs(slope) / (atr_abs + EPS), 1.0) * 0.3
                    + breakout * 0.3
                )

        if len(hi_idx) >= 3 and len(lo_idx) >= 3:
            hi_x = np.array(hi_idx[-3:], dtype=float)
            hi_y = np.array(recent_highs[-3:], dtype=float)
            lo_x = np.array(lo_idx[-3:], dtype=float)
            lo_y = np.array(recent_lows[-3:], dtype=float)
            hi_slope, hi_r2, hi_valid = _trendline_strength(
                hi_x, hi_y, min_r2=0.6
            )
            lo_slope, lo_r2, lo_valid = _trendline_strength(
                lo_x, lo_y, min_r2=0.6
            )
            if (
                hi_valid
                and lo_valid
                and hi_slope < -atr_abs * 0.15
                and lo_slope > atr_abs * 0.15
            ):
                if abs(hi_slope - lo_slope) > EPS:
                    x_conv = (
                        lo_y[-1]
                        - hi_y[-1]
                        + hi_slope * hi_x[-1]
                        - lo_slope * lo_x[-1]
                    ) / (hi_slope - lo_slope)
                    top_line = hi_slope * (len(close) - 1) + (
                        hi_y[-1] - hi_slope * hi_x[-1]
                    )
                    bot_line = lo_slope * (len(close) - 1) + (
                        lo_y[-1] - lo_slope * lo_x[-1]
                    )
                    if close[-1] > top_line:
                        sym_dir = 1.0
                    elif close[-1] < bot_line:
                        sym_dir = -1.0
                    sym_dir = _clamp(sym_dir * min(hi_r2, lo_r2))

    return asc_bull, desc_bear, sym_dir


def _detect_flags_pennants(
    sh_px: list[float],
    sl_px: list[float],
    sh_idx: list[int],
    sl_idx: list[int],
    close: np.ndarray,
    atr_abs: float,
    atr_frac: float,
    vol_confirm: bool,
    trend: int,
) -> tuple[float, float, float, float]:
    """Bull/bear flag and pennant.

    Returns (bull_flag, bear_flag, bull_pennant, bear_pennant) each in [0, 1].
    Strict: strong pole move (> 3 ATR), tight channel (< 1 ATR), volume confirm.
    """
    bull_flag = bear_flag = 0.0
    bull_pennant = bear_pennant = 0.0

    if not vol_confirm:
        return bull_flag, bear_flag, bull_pennant, bear_pennant

    if len(close) < 30:
        return bull_flag, bear_flag, bull_pennant, bear_pennant

    recent = close[-20:]
    prior = close[-40:-20]

    pole_move = float(recent[0] - prior[0]) / (atr_abs + EPS)
    if abs(pole_move) < 3.0:
        return bull_flag, bear_flag, bull_pennant, bear_pennant

    recent_high = float(recent.max())
    recent_low = float(recent.min())
    flag_range = recent_high - recent_low
    flag_range_atr = flag_range / (atr_abs + EPS)

    if flag_range_atr < 0.8:
        if pole_move > 3.0 and trend >= 0:
            x = np.arange(20, dtype=float)
            slope, r2, valid = _linreg(x, recent)
            if valid and r2 > 0.5 and slope < atr_abs * 0.03:
                breakout = max(0.0, (close[-1] - recent_high) / (atr_abs + EPS))
                bull_flag = _clamp(
                    r2 * 0.4 + min(pole_move, 4.0) / 4.0 * 0.3 + breakout * 0.3
                )
        elif pole_move < -3.0 and trend <= 0:
            x = np.arange(20, dtype=float)
            slope, r2, valid = _linreg(x, recent)
            if valid and r2 > 0.5 and slope > -atr_abs * 0.03:
                breakout = max(0.0, (recent_low - close[-1]) / (atr_abs + EPS))
                bear_flag = _clamp(
                    r2 * 0.4 + min(abs(pole_move), 4.0) / 4.0 * 0.3 + breakout * 0.3
                )

    if abs(pole_move) > 3.0 and len(sh_idx) >= 2 and len(sl_idx) >= 2:
        recent_sh = sh_px[-3:] if len(sh_px) >= 3 else []
        recent_sl = sl_px[-3:] if len(sl_px) >= 3 else []
        if len(recent_sh) >= 2 and len(recent_sl) >= 2:
            hi_conv = abs(recent_sh[-1] - recent_sh[-2]) / (atr_abs + EPS) < 0.15
            lo_conv = abs(recent_sl[-1] - recent_sl[-2]) / (atr_abs + EPS) < 0.15
            if hi_conv and lo_conv:
                if pole_move > 3.0 and trend >= 0:
                    breakout = max(
                        0.0, (close[-1] - max(recent_sh)) / (atr_abs + EPS)
                    )
                    bull_pennant = _clamp(
                        min(hi_conv, lo_conv) * 0.5
                        + min(pole_move, 4.0) / 4.0 * 0.3
                        + breakout * 0.2
                    )
                elif pole_move < -3.0 and trend <= 0:
                    breakout = max(
                        0.0, (min(recent_sl) - close[-1]) / (atr_abs + EPS)
                    )
                    bear_pennant = _clamp(
                        min(hi_conv, lo_conv) * 0.5
                        + min(abs(pole_move), 4.0) / 4.0 * 0.3
                        + breakout * 0.2
                    )

    return bull_flag, bear_flag, bull_pennant, bear_pennant


def _detect_wedges(
    sh_px: list[float],
    sl_px: list[float],
    sh_idx: list[int],
    sl_idx: list[int],
    close: np.ndarray,
    atr_abs: float,
    vol_confirm: bool,
    trend: int,
) -> tuple[float, float]:
    """Rising wedge (bearish) and falling wedge (bullish).

    Returns (rising_wedge_bearish, falling_wedge_bullish).
    Strict: both trendlines significant (R² > 0.7), converging.
    """
    rising = 0.0
    falling = 0.0

    if not vol_confirm:
        return rising, falling

    if len(sh_px) >= 4 and len(sl_px) >= 4:
        hi_x = np.array(sh_idx[-4:], dtype=float)
        hi_y = np.array(sh_px[-4:], dtype=float)
        lo_x = np.array(sl_idx[-4:], dtype=float)
        lo_y = np.array(sl_px[-4:], dtype=float)
        hi_slope, hi_r2, hi_valid = _trendline_strength(hi_x, hi_y, min_r2=0.7)
        lo_slope, lo_r2, lo_valid = _trendline_strength(lo_x, lo_y, min_r2=0.7)

        if hi_valid and lo_valid:
            if (
                hi_slope > atr_abs * 0.15
                and lo_slope > atr_abs * 0.15
                and hi_slope >= lo_slope * 0.5
                and trend <= 0
            ):
                if abs(hi_slope - lo_slope) < max(hi_slope, lo_slope) * 0.4:
                    breakout = max(0.0, (min(sl_px[-2:]) - close[-1]) / (atr_abs + EPS))
                    rising = _clamp(
                        min(hi_r2, lo_r2) * 0.5
                        + min(hi_slope / (atr_abs + EPS), 1.0) * 0.3
                        + breakout * 0.2
                    )
            if hi_slope < -atr_abs * 0.15 and lo_slope < -atr_abs * 0.15:
                if abs(hi_slope - lo_slope) < max(
                    abs(hi_slope), abs(lo_slope)
                ) * 0.5 and trend >= 0:
                    breakout = max(0.0, (close[-1] - max(sh_px[-2:])) / (atr_abs + EPS))
                    falling = _clamp(
                        min(hi_r2, lo_r2) * 0.5
                        + min(abs(hi_slope) / (atr_abs + EPS), 1.0) * 0.3
                        + breakout * 0.2
                    )

    return rising, falling


def _detect_cup_and_handle(
    close: np.ndarray,
    high: np.ndarray,
    low: np.ndarray,
    atr_abs: float,
    vol_confirm: bool,
    trend: int,
) -> float:
    """Cup and handle (bullish continuation).

    Returns score in [0, 1].
    Strict: deep cup (> 2 ATR), shallow handle (< 1.5 ATR), breakout above rim.
    """
    if not vol_confirm or trend < 0:
        return 0.0

    if len(close) < 50:
        return 0.0

    cup_len = min(50, len(close) - 10)
    cup_section = close[-cup_len:-10]
    handle_section = close[-10:]

    if len(cup_section) < 25:
        return 0.0

    cup_low_idx = int(np.argmin(cup_section))
    cup_low = float(cup_section[cup_low_idx])
    cup_start = float(cup_section[0])
    cup_end = float(cup_section[-1])

    cup_depth = (cup_start - cup_low) / (atr_abs + EPS)
    cup_recovery = (cup_end - cup_low) / (atr_abs + EPS)
    cup_sym = 1.0 - abs(cup_start - cup_end) / (max(cup_start, cup_end) + EPS)

    handle_low = float(handle_section.min())
    handle_depth = (cup_end - handle_low) / (atr_abs + EPS)

    if (
        cup_depth > 2.0
        and cup_recovery > 0.8
        and cup_sym > 0.8
        and 0.3 < handle_depth < 1.5
    ):
        breakout = max(0.0, (close[-1] - cup_end) / (atr_abs + EPS))
        return _clamp(
            cup_sym * 0.4 + min(cup_depth, 4.0) / 4.0 * 0.3 + breakout * 0.3
        )

    return 0.0


def _detect_rectangle(
    sh_px: list[float],
    sl_px: list[float],
    close: np.ndarray,
    atr_abs: float,
    vol_confirm: bool,
) -> float:
    """Rectangle / trading range (neutral, breakout direction).

    Returns direction: +1 bullish breakout, -1 bearish breakout, 0 none.
    Strict: highs and lows flat within 0.3 ATR.
    """
    if not vol_confirm:
        return 0.0

    if len(sh_px) < 3 or len(sl_px) < 3:
        return 0.0

    recent_highs = sh_px[-4:]
    recent_lows = sl_px[-4:]

    high_range = max(recent_highs) - min(recent_highs)
    low_range = max(recent_lows) - min(recent_lows)
    range_height = max(recent_highs) - min(recent_lows)

    if (
        high_range / (atr_abs + EPS) < 0.3
        and low_range / (atr_abs + EPS) < 0.3
        and range_height > atr_abs * 1.0
    ):
        position = (close[-1] - min(recent_lows)) / (range_height + EPS)
        if position > 0.85:
            return 1.0
        elif position < 0.15:
            return -1.0
    return 0.0


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------


def analyze(snap: Snapshot, window: int = 200) -> EngineReport:
    """Chart pattern detection engine.

    Detects reversal and continuation chart patterns from swing geometry.
    All features are ATR-normalised and rarity-filtered.
    """
    o, h, l, c, v = snap.bars[:, 1], snap.bars[:, 2], snap.bars[:, 3], snap.bars[:, 4], snap.bars[:, 5]
    if len(c) < window:
        return EngineReport("chart_patterns", 0.0, 0.0)

    O = o[-window:].astype(float)
    H = h[-window:].astype(float)
    L = l[-window:].astype(float)
    C = c[-window:].astype(float)
    V = v[-window:].astype(float)

    atr_frac = _atr(H, L, C) + EPS
    atr_abs = atr_frac * C[-1]

    # Swing detection
    swings_high, swings_low = _find_swings(H, L, window=5)
    sh_px, sl_px, sh_idx, sl_idx = _swing_points(H, L, C, swings_high, swings_low)

    # --- Volume confirmation (global gate) ---
    vol_ma20 = float(np.mean(V[-20:])) if len(V) >= 20 else float(V[-1])
    vol_ratio = float(V[-1] / max(vol_ma20, EPS))
    vol_confirm = vol_ratio > 1.5

    # --- Trend alignment ---
    trend = _is_trending(C, atr_frac, 20)

    # --- Pattern detection ---
    hs_bear, hs_bull = _detect_head_and_shoulders(
        sh_px, sl_px, sh_idx, sl_idx, C, atr_abs, vol_confirm, trend
    )
    dt_bear, db_bull = _detect_double_top_bottom(
        sh_px, sl_px, sh_idx, sl_idx, C, atr_abs, vol_confirm, trend
    )
    tt_bear, tb_bull = _detect_triple_top_bottom(
        sh_px, sl_px, sh_idx, sl_idx, C, atr_abs, vol_confirm, trend
    )
    asc_bull, desc_bear, sym_dir = _detect_triangles(
        sh_px, sl_px, sh_idx, sl_idx, C, atr_abs, vol_confirm, trend
    )
    bf_flag, bf_bear, bp_bull, bp_bear = _detect_flags_pennants(
        sh_px, sl_px, sh_idx, sl_idx, C, atr_abs, atr_frac, vol_confirm, trend
    )
    rw_bear, fw_bull = _detect_wedges(
        sh_px, sl_px, sh_idx, sl_idx, C, atr_abs, vol_confirm, trend
    )
    ch_bull = _detect_cup_and_handle(C, H, L, atr_abs, vol_confirm, trend)
    rect_dir = _detect_rectangle(sh_px, sl_px, C, atr_abs, vol_confirm)

    # --- Assemble signed features ---
    signed = {
        "h_and_s_bear": -hs_bear,
        "h_and_s_bull": hs_bull,
        "double_top": -dt_bear,
        "double_bottom": db_bull,
        "triple_top": -tt_bear,
        "triple_bottom": tb_bull,
        "rising_wedge": -rw_bear,
        "falling_wedge": fw_bull,
        "asc_triangle": asc_bull,
        "desc_triangle": -desc_bear,
        "sym_triangle": sym_dir,
        "bull_flag": bf_flag if trend >= 0 else 0.0,
        "bear_flag": -bf_bear if trend <= 0 else 0.0,
        "bull_pennant": bp_bull if trend >= 0 else 0.0,
        "bear_pennant": -bp_bear if trend <= 0 else 0.0,
        "cup_handle": ch_bull if trend >= 0 else 0.0,
        "rectangle": rect_dir,
    }

    # --- Neutral features ---
    pattern_scores = [
        hs_bear, hs_bull, dt_bear, db_bull, tt_bear, tb_bull,
        asc_bull, desc_bear, abs(sym_dir),
        bf_flag, bf_bear, bp_bull, bp_bear,
        rw_bear, fw_bull, ch_bull, abs(rect_dir),
    ]
    max_pattern = max(pattern_scores) if pattern_scores else 0.0
    active_patterns = sum(1 for s in pattern_scores if s > 0.4)

    neutral = {
        "cp_strength": min(max_pattern, 1.0),
        "cp_active": min(active_patterns / 5.0, 1.0),
        "cp_vol_confirm": 1.0 if vol_confirm else 0.0,
        "cp_trend_align": 1.0 if trend != 0 else 0.0,
        "cp_swing_count": min((len(sh_px) + len(sl_px)) / 20.0, 1.0),
        "cp_atr_ratio": min(atr_frac * 10.0, 1.0),
    }

    # --- Vote: net bullish - bearish ---
    bullish = hs_bull + db_bull + tb_bull + asc_bull
    if sym_dir > 0:
        bullish += sym_dir
    bullish += bf_flag + bp_bull + fw_bull + ch_bull
    if rect_dir > 0:
        bullish += rect_dir

    bearish = hs_bear + dt_bear + tt_bear + desc_bear
    if sym_dir < 0:
        bearish += abs(sym_dir)
    bearish += bf_bear + bp_bear + rw_bear
    if rect_dir < 0:
        bearish += abs(rect_dir)

    vote = _clamp(bullish - bearish, 1.0)

    # Confidence
    conf = min(
        1.0,
        max_pattern * 0.5
        + (0.2 if vol_confirm else 0.0)
        + (0.2 if trend != 0 else 0.0)
        + (0.1 if active_patterns > 1 else 0.0),
    )

    notes = []
    if hs_bear > 0.5: notes.append("h&s_bearish")
    if hs_bull > 0.5: notes.append("h&s_bullish")
    if dt_bear > 0.5: notes.append("double_top")
    if db_bull > 0.5: notes.append("double_bottom")
    if asc_bull > 0.5: notes.append("asc_triangle")
    if desc_bear > 0.5: notes.append("desc_triangle")
    if abs(sym_dir) > 0.5: notes.append(f"sym_triangle {'bull' if sym_dir > 0 else 'bear'}")
    if bf_flag > 0.5: notes.append("bull_flag")
    if bf_bear > 0.5: notes.append("bear_flag")
    if ch_bull > 0.5: notes.append("cup_handle")
    if rw_bear > 0.5: notes.append("rising_wedge")
    if fw_bull > 0.5: notes.append("falling_wedge")
    if abs(rect_dir) > 0.5: notes.append(f"rectangle {'bull' if rect_dir > 0 else 'bear'}")

    return EngineReport(
        "chart_patterns",
        vote=float(vote),
        confidence=float(conf),
        signed=signed,
        neutral=neutral,
        notes=tuple(notes) if notes else (),
    )
