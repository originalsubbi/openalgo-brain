"""Opening Range Breakout (ORB) engine.

The opening range is the first 3 bars (15 minutes at 5-minute resolution)
of the current session (09:15 IST). The engine detects:

* **OR breakout** — price breaks above OR high = bullish; below OR low = bearish.
* **OR failure** — price breaks out then reverses back inside the range = trap.
* **OR range size** — wide range = high volatility day (expect movement);
  narrow range = low volatility (mean reversion more likely).
* **Time decay** — OR signals decay over ``orb_decay_min`` minutes as the range
  loses relevance, and a range narrower than ``orb_range_atr_min`` ATR is not
  treated as a tradable breakout at all.

Both thresholds are tunable and read from the live parameters. The opening
range itself is taken from the current session's bars only — the oldest bars of
the fetch window belong to a previous session and would measure a range from
days ago.
"""

from __future__ import annotations

from typing import Any

import numpy as np

from services.brain.types import EngineReport, Snapshot, param, session_slice

EPS = 1e-12

OPEN_MINUTE = 555  # 09:15 IST in minutes
OR_BARS = 3  # 09:15-09:30 IST


def _math_tanh(x: float) -> float:
    import math

    return math.tanh(x)


def analyze(snap) -> EngineReport:
    """Opening Range Breakout engine."""
    b = snap.bars
    if len(b) < 8:  # need at least opening range + follow-through
        return EngineReport("orb", 0.0, 0.0, neutral={"orb_available": 0.0})

    range_min_atr = param(snap, "orb_range_atr_min", 0.5)
    decay_min = param(snap, "orb_decay_min", 120)

    # The opening range belongs to THIS session. Reading the oldest bars of the
    # fetch window instead would measure a range from days ago.
    sess = session_slice(b)
    if len(sess) < OR_BARS + 1:
        return EngineReport("orb", 0.0, 0.0, neutral={"orb_available": 0.0})

    o, h, lo, c, v = sess[:, 1], sess[:, 2], sess[:, 3], sess[:, 4], sess[:, 5]
    spot = float(c[-1])
    minute = snap.minute_of_day

    # Opening range = the first 3 bars of the session (09:15-09:30 IST).
    orb_bars = sess[:OR_BARS]
    if len(orb_bars) < OR_BARS:
        return EngineReport("orb", 0.0, 0.0, neutral={"orb_available": 0.0})

    orb_high = float(np.max(orb_bars[:, 2]))
    orb_low = float(np.min(orb_bars[:, 3]))
    orb_range = orb_high - orb_low

    # ATR for normalization
    prev_close = np.concatenate([[o[0]], c[:-1]])
    tr = np.maximum.reduce(
        [h[1:] - lo[1:], np.abs(h[1:] - prev_close[1:]), np.abs(lo[1:] - prev_close[1:])]
    )
    atr_abs = (
        float(np.mean(tr[-14:]))
        if len(tr) >= 14
        else float(np.mean(tr))
        if len(tr)
        else orb_range
    )
    orb_range_atr = orb_range / atr_abs if atr_abs > 0 else 0.0

    # ---- breakout detection ---------------------------------------------------
    vote = 0.0
    notes = []

    broke_high = spot > orb_high
    broke_low = spot < orb_low

    # Time decay: the OR signal fades over ``decay_min`` minutes from the open.
    minutes_since_open = max(minute - OPEN_MINUTE, 0)
    time_decay = (
        _math_tanh((decay_min - minutes_since_open) / 60.0)
        if minutes_since_open < decay_min
        else 0.0
    )

    # A range narrower than the tunable floor is not a tradable breakout.
    range_ok = orb_range_atr >= range_min_atr

    if broke_high and minutes_since_open < decay_min and range_ok:
        # Breakout above OR high = bullish
        strength = _math_tanh((spot - orb_high) / orb_range * 5.0) if orb_range > 0 else 0.5
        vote += 0.35 * strength * time_decay
        notes.append(f"orb_breakout_high={orb_range_atr:.1f}ATR")
    elif broke_low and minutes_since_open < decay_min and range_ok:
        # Breakout below OR low = bearish
        strength = _math_tanh((orb_low - spot) / orb_range * 5.0) if orb_range > 0 else 0.5
        vote -= 0.35 * strength * time_decay
        notes.append(f"orb_breakout_low={orb_range_atr:.1f}ATR")
    elif (broke_high or broke_low) and not range_ok:
        notes.append(f"orb_range_too_tight={orb_range_atr:.1f}ATR")

    # ---- OR failure (trap) detection -----------------------------------------
    # If price broke out but is now back inside the range = trap
    # We check if previous close was outside but current close is inside
    if len(c) >= 2:
        prev_close = float(c[-2])
        prev_broke_high = prev_close > orb_high
        prev_broke_low = prev_close < orb_low
        back_inside = orb_low <= spot <= orb_high

        if prev_broke_high and back_inside:
            # Bull trap: broke high, now back inside = bearish
            vote -= 0.25
            notes.append("orb_bull_trap")
        elif prev_broke_low and back_inside:
            # Bear trap: broke low, now back inside = bullish
            vote += 0.25
            notes.append("orb_bear_trap")

    # ---- Range width context -------------------------------------------------
    # Wide OR range = expect movement; narrow = mean reversion more likely
    if orb_range_atr > 1.5:
        # Wide range = trend day likely; breakout more meaningful
        vote *= 1.1
    elif orb_range_atr < 0.5:
        # Narrow range = choppy; fade breakouts
        vote *= 0.7

    vote = _math_tanh(vote)

    # confidence: higher when range is well-defined and we're within decision window
    conf = min(1.0, 0.4 + 0.3 * min(1.0, orb_range_atr) + 0.3 * time_decay)

    signed = {
        "orb_dev_from_high": (spot - orb_high) / orb_range if orb_range > 0 else 0.0,
        "orb_dev_from_low": (orb_low - spot) / orb_range if orb_range > 0 else 0.0,
        "orb_range_atr": orb_range_atr,
    }
    neutral = {
        "orb_available": 1.0,
        "orb_high": orb_high,
        "orb_low": orb_low,
        "orb_range_atr": orb_range_atr,
        "orb_minutes_since": float(minutes_since_open),
        "orb_time_decay": time_decay,
    }

    return EngineReport(
        "orb",
        vote=float(vote),
        confidence=float(conf),
        signed=signed,
        neutral=neutral,
        notes=tuple(notes),
    )


__all__ = ["analyze", "_math_tanh"]
