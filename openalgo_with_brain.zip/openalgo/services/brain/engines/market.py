"""Market engine: trend, order flow, liquidity, correlation.

Index feeds carry no volume, so flow falls back to where each bar closed inside
its range (close location) when volume is absent. Liquidity prefers the option
spread passed in by the orchestrator over anything inferred from bars.
"""

from __future__ import annotations

import math

import numpy as np

from services.brain.types import EngineReport, Snapshot

EPS = 1e-12


def ema(x: np.ndarray, span: int) -> np.ndarray:
    alpha = 2.0 / (span + 1.0)
    out = np.empty_like(x, dtype=float)
    out[0] = x[0]
    for i in range(1, len(x)):
        out[i] = alpha * x[i] + (1 - alpha) * out[i - 1]
    return out


def atr(high: np.ndarray, low: np.ndarray, close: np.ndarray, n: int = 14) -> float:
    prev = close[:-1]
    tr = np.maximum.reduce([high[1:] - low[1:], np.abs(high[1:] - prev), np.abs(low[1:] - prev)])
    if len(tr) < n:
        return float(np.mean(tr)) if len(tr) else 0.0
    val = float(np.mean(tr[:n]))
    for x in tr[n:]:
        val = (val * (n - 1) + x) / n
    return val


def adx(high: np.ndarray, low: np.ndarray, close: np.ndarray, n: int = 14) -> tuple[float, float]:
    """Wilder ADX and the signed DI spread in [-1, 1]."""
    up = high[1:] - high[:-1]
    dn = low[:-1] - low[1:]
    plus = np.where((up > dn) & (up > 0), up, 0.0)
    minus = np.where((dn > up) & (dn > 0), dn, 0.0)
    prev = close[:-1]
    tr = np.maximum.reduce([high[1:] - low[1:], np.abs(high[1:] - prev), np.abs(low[1:] - prev)])
    if len(tr) < 2 * n:
        return 15.0, 0.0

    def wilder(v: np.ndarray) -> np.ndarray:
        out = np.empty(len(v) - n + 1)
        out[0] = v[:n].sum()
        for i in range(n, len(v)):
            out[i - n + 1] = out[i - n] - out[i - n] / n + v[i]
        return out

    tr_s, p_s, m_s = wilder(tr), wilder(plus), wilder(minus)
    pdi = 100 * p_s / (tr_s + EPS)
    mdi = 100 * m_s / (tr_s + EPS)
    dx = 100 * np.abs(pdi - mdi) / (pdi + mdi + EPS)
    if len(dx) < n:
        return float(dx[-1]), 0.0
    adx_val = float(np.mean(dx[:n]))
    for x in dx[n:]:
        adx_val = (adx_val * (n - 1) + x) / n
    spread = float((pdi[-1] - mdi[-1]) / (pdi[-1] + mdi[-1] + EPS))
    return adx_val, spread


def analyze(snap: Snapshot, spread_pct: float | None = None) -> EngineReport:
    b = snap.bars
    if len(b) < 70:
        return EngineReport("market", 0.0, 0.0)
    o, h, lo, c, v = (b[:, i] for i in range(1, 6))
    a = atr(h, lo, c) + EPS

    e9, e21, e50 = ema(c, 9)[-1], ema(c, 21)[-1], ema(c, 50)[-1]
    stack = (1.0 if e9 > e21 else -1.0) * 0.5 + (1.0 if e21 > e50 else -1.0) * 0.5
    dist = float(np.clip((e9 - e50) / a, -6.0, 6.0))
    adx_val, di_spread = adx(h, lo, c)
    strength = min(adx_val / 30.0, 1.5)
    trend = math.tanh(0.6 * stack * strength + 0.25 * di_spread + 0.15 * dist / 3.0)

    # flow: money-flow volume z-score over rolling 10-bar sums
    rng = np.maximum(h - lo, EPS)
    clv = ((c - lo) - (h - c)) / rng
    has_vol = float(v[-100:].sum()) > 0
    mfv = clv * v if has_vol else clv
    roll = np.convolve(mfv[-110:], np.ones(10), mode="valid")
    flow_z = float((roll[-1] - roll.mean()) / (roll.std() + EPS)) if len(roll) > 20 else 0.0
    flow_z = max(-4.0, min(4.0, flow_z))

    rel_vol = float(v[-5:].mean() / (v[-55:-5].mean() + EPS)) if has_vol else 1.0

    corr, rel_strength = 0.0, 0.0
    bench = snap.bench_close
    if bench is not None and len(bench) >= 60:
        n = min(len(bench), len(c), 60)
        r1, r2 = np.diff(np.log(c[-n:])), np.diff(np.log(bench[-n:]))
        if r1.std() > 0 and r2.std() > 0:
            corr = float(np.corrcoef(r1, r2)[0, 1])
            beta = float(np.cov(r1, r2)[0, 1] / r2.var())
            idio = float(r1[-20:].sum() - beta * r2[-20:].sum())
            rel_strength = max(-4.0, min(4.0, idio / (r1.std() * math.sqrt(20) + EPS)))

    vote = math.tanh(1.2 * trend + 0.35 * flow_z / 2.0)
    conf = float(np.clip(adx_val / 40.0, 0.0, 1.0) * 0.7 + min(abs(flow_z) / 4.0, 1.0) * 0.3)
    atr_pct = a / float(c[-1]) * 100.0
    return EngineReport(
        "market",
        vote=float(vote),
        confidence=conf,
        signed={
            "trend": float(trend),
            "ema_dist": dist / 3.0,
            "flow_z": flow_z / 2.0,
            "rel_strength": rel_strength / 2.0,
        },
        neutral={
            "adx": adx_val / 50.0,
            "rel_volume": min(rel_vol, 4.0) / 2.0,
            "atr_pct": atr_pct,
            "corr_bench": corr,
            "spread_pct": (spread_pct if spread_pct is not None else 0.0) / 5.0,
        },
        notes=(f"adx={adx_val:.0f}", f"stack={stack:+.1f}"),
    )
