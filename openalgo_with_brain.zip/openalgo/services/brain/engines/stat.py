"""Statistical engine: Bayesian inference, GARCH volatility, barrier probabilities.

* GARCH(1,1) by variance-targeted quasi-maximum-likelihood over a coarse grid,
  which is robust on short intraday samples where a free optimiser overfits.
* Bayesian updates: a Beta posterior for the share of up-bars and a Normal-Normal
  posterior for drift, both shrunk toward "no edge".
* ``barrier_probabilities`` answers the question trading actually asks: starting
  now, with this drift and volatility, how likely is the target to be touched
  before the stop within the horizon. A seeded Monte Carlo keeps it reproducible.
"""

from __future__ import annotations

import math

import numpy as np

from services.brain.types import EngineReport, Snapshot

EPS = 1e-12
IST_OFFSET = 19800
SLOTS = 288  # 5-minute slots in a day
SEASON_PSEUDO_OBS = 3.0  # pseudo-observations pulling each slot's variance toward the average
_GRID_A = (0.03, 0.06, 0.09, 0.12, 0.16)
_GRID_B = (0.75, 0.80, 0.85, 0.90, 0.94)


def _phi(z: float) -> float:
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


def slot_of(ts) -> np.ndarray:
    """5-minute slot of the IST day for bar open timestamps."""
    return (((np.asarray(ts, dtype=float) + IST_OFFSET) // 300) % SLOTS).astype(np.int64)


def seasonal_profile(slots: np.ndarray, r: np.ndarray) -> np.ndarray:
    """Relative volatility of each 5-minute slot of the day, estimated from the returns at hand.

    The open is several times as volatile as the middle of the day. A GARCH fitted on the raw
    returns reads that rhythm as news: it forecasts high volatility just after every open
    and the horizon sigma, the Monte Carlo and the regime label are all wrong in the same
    direction. This estimates each slot's variance from the history in the snapshot, shrinks
    it toward the overall variance (a few days give only a handful of observations per slot),
    and smooths over neighbouring slots. Returns ``s`` with ``return / s`` roughly
    homoscedastic; slots never seen get 1.
    """
    r2 = np.asarray(r, dtype=float) ** 2
    if r2.size == 0:
        return np.ones(SLOTS)
    v_all = float(r2.mean()) + EPS
    n_k = np.bincount(slots, minlength=SLOTS).astype(float)
    s_k = np.bincount(slots, weights=r2, minlength=SLOTS)
    v = (s_k + SEASON_PSEUDO_OBS * v_all) / (n_k + SEASON_PSEUDO_OBS)
    v = np.convolve(np.concatenate([v[-2:], v, v[:2]]), [0.2, 0.2, 0.2, 0.2, 0.2], mode="valid")
    # Standardise so the typical standardised return keeps the overall variance.
    prof = np.sqrt(v / v_all)
    seen = n_k > 0
    prof /= float(np.sqrt(np.average(prof[seen] ** 2, weights=n_k[seen])))
    return np.clip(prof, 0.35, 3.0)


def garch11(r: np.ndarray) -> dict[str, float]:
    """Fit GARCH(1,1) with variance targeting; return forecasts per bar."""
    r = np.asarray(r, dtype=float) - float(np.mean(r))
    var = float(np.var(r)) + EPS
    best = (-np.inf, 0.06, 0.90)
    for a in _GRID_A:
        for b in _GRID_B:
            if a + b >= 0.995:
                continue
            omega = var * (1.0 - a - b)
            h = var
            ll = 0.0
            for x in r:
                ll += -0.5 * (math.log(h) + x * x / h)
                h = omega + a * x * x + b * h
            if ll > best[0]:
                best = (ll, a, b)
    _, a, b = best
    omega = var * (1.0 - a - b)
    h = var
    for x in r:
        h = omega + a * x * x + b * h
    persist = a + b
    return {
        "alpha": a,
        "beta": b,
        "persistence": persist,
        "var_long": var,
        "var_next": float(h),
        "vol_ratio": math.sqrt(float(h) / var),
    }


def garch_var_path(g: dict[str, float], horizon: int) -> np.ndarray:
    """Per-bar forecast variances under the fitted GARCH, mean-reverting to the long-run level."""
    p, v_long, h1 = g["persistence"], g["var_long"], g["var_next"]
    k = np.arange(horizon, dtype=float)
    return v_long + (p**k) * (h1 - v_long)


def horizon_sigma(g: dict[str, float], horizon: int) -> float:
    """sd of the cumulative log return over ``horizon`` bars under the fitted GARCH."""
    return math.sqrt(max(float(garch_var_path(g, horizon).sum()), EPS))


def bayes_up_share(r: np.ndarray, n: int = 40, prior: float = 6.0) -> tuple[float, float]:
    """Beta(prior, prior) posterior for P(up bar). Returns (mean, P(share > 0.5))."""
    tail = r[-n:]
    ups = float((tail > 0).sum())
    a, b = prior + ups, prior + (len(tail) - ups)
    mean = a / (a + b)
    sd = math.sqrt(a * b / ((a + b) ** 2 * (a + b + 1)))
    return mean, _phi((mean - 0.5) / (sd + EPS))


def bayes_drift(r: np.ndarray, n: int = 40, tau_mult: float = 0.1) -> tuple[float, float]:
    """Normal-Normal posterior for per-bar drift. Returns (posterior mean, z = mean/sd)."""
    tail = r[-n:]
    sigma = float(np.std(r)) + EPS
    se2 = sigma**2 / len(tail)
    tau2 = (tau_mult * sigma) ** 2
    post_var = 1.0 / (1.0 / tau2 + 1.0 / se2)
    post_mean = post_var * (float(np.mean(tail)) / se2)
    return post_mean, post_mean / math.sqrt(post_var)


def barrier_probabilities(
    mu_bar: float | np.ndarray,
    sigma_bar: float | np.ndarray,
    stop_dist: float,
    target_dist: float,
    horizon: int,
    paths: int = 600,
    seed: int = 20240607,
) -> dict[str, float]:
    """P(target first), P(stop first), P(timeout) and mean R for a LONG exposure.

    Distances are log-return units. For a SHORT call it with ``mu_bar`` negated. ``mu_bar`` and
    ``sigma_bar`` are a scalar (constant over the horizon) or one value per bar, which is how
    the volatility path and the time-of-day pattern enter.
    Ties inside one bar count as stop first, the same adverse assumption the
    risk core makes (services/risk/position.py, note 9).
    """
    rng = np.random.default_rng(seed)
    sigma = np.broadcast_to(np.asarray(sigma_bar, dtype=float), (horizon,))
    mu = np.broadcast_to(np.asarray(mu_bar, dtype=float), (horizon,))
    steps = rng.standard_normal((paths, horizon)) * sigma + mu
    # Brownian bridge-free discretisation: check the path at bar closes plus a
    # conservative intrabar excursion allowance of half a sigma on each side.
    path = np.cumsum(steps, axis=1)
    hi = path + 0.5 * sigma
    lo = path - 0.5 * sigma
    hit_t = hi >= target_dist
    hit_s = lo <= -stop_dist
    first_t = np.where(hit_t.any(axis=1), hit_t.argmax(axis=1), horizon + 1)
    first_s = np.where(hit_s.any(axis=1), hit_s.argmax(axis=1), horizon + 1)
    t_win = first_t < first_s
    s_win = first_s <= first_t
    s_win &= first_s <= horizon
    timeout = ~(t_win | s_win)
    final = path[:, -1]
    r_t = target_dist / stop_dist
    mean_r = (
        t_win.sum() * r_t
        - s_win.sum() * 1.0
        + float((np.clip(final[timeout], -stop_dist, target_dist) / stop_dist).sum())
    ) / paths
    return {
        "p_target": float(t_win.mean()),
        "p_stop": float(s_win.mean()),
        "p_timeout": float(timeout.mean()),
        "mean_r": float(mean_r),
    }


def analyze(snap: Snapshot, horizon: int = 12) -> EngineReport:
    close = snap.bars[:, 4]
    if len(close) < 80:
        return EngineReport("stat", 0.0, 0.0)
    r_all = np.diff(np.log(close))
    slots = slot_of(snap.bars[1:, 0])
    prof = seasonal_profile(slots, r_all)
    r = (r_all / prof[slots])[-200:]  # returns with the time-of-day rhythm taken out
    g = garch11(r[-120:])
    # Forecast the next ``horizon`` bars: the GARCH path, scaled back up by the rhythm of the
    # slots those bars will fall in (past the session end the last slot's level is kept).
    next_slot = int(slot_of([snap.bars[-1, 0] + 300.0])[0])
    ahead = prof[np.minimum(next_slot + np.arange(horizon), SLOTS - 1)]
    var_path = garch_var_path(g, horizon) * ahead**2
    sig_h = math.sqrt(max(float(var_path.sum()), EPS))
    up_mean, p_up_gt = bayes_up_share(r)
    drift, drift_z = bayes_drift(r)
    mu_path = drift * ahead

    vote = math.tanh(0.8 * drift_z + 2.0 * (up_mean - 0.5))
    conf = float(np.clip(abs(drift_z) / 2.5, 0.0, 1.0))
    return EngineReport(
        "stat",
        vote=float(vote),
        confidence=conf,
        signed={
            "drift_z": max(-4.0, min(4.0, drift_z)) / 2.0,
            "bayes_up_tilt": (up_mean - 0.5) * 4.0,
        },
        neutral={
            "vol_ratio": min(g["vol_ratio"], 4.0) / 2.0,
            "garch_persist": g["persistence"],
            "sigma_h_pct": sig_h * 100.0,
            "p_up_gt_half": p_up_gt,
        },
        notes=(f"vol_ratio={g['vol_ratio']:.2f}", f"drift_z={drift_z:+.2f}"),
        extras={
            "garch": g,
            "mu_bar": float(mu_path.mean()),
            "sigma_bar": float(np.sqrt(var_path[0])),
            "sigma_h": sig_h,
            # per-bar forecasts for the barrier simulation
            "sigma_path": [float(x) for x in np.sqrt(var_path)],
            "mu_path": [float(x) for x in mu_path],
        },
    )
