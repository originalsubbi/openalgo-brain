"""Options engine: Greeks, IV, gamma exposure (GEX), open-interest walls, max pain.

Input is a normalised chain dict, built from OpenAlgo's option chain service
(``services.option_chain_service.get_option_chain(..., with_greeks=True)``) by
``orchestrator.build_chain``:

    {"spot": float, "atm_strike": float, "lot_size": int, "dte": float,
     "rows": [{"strike", "ce_ltp", "pe_ltp", "ce_oi", "pe_oi", "ce_iv", "pe_iv",
               "ce_gamma", "pe_gamma", "ce_delta", "pe_delta",
               "ce_bid", "ce_ask", "pe_bid", "pe_ask"}, ...]}

With no chain (a backtest, or the feed is down) the engine abstains: vote 0,
confidence 0, ``opt_available`` 0, so the fusion layer simply ignores it.
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np

from services.brain.types import EngineReport, Snapshot

EPS = 1e-12


def _num(row: dict[str, Any], key: str) -> float:
    v = row.get(key)
    try:
        f = float(v)
    except (TypeError, ValueError):
        return 0.0
    return f if math.isfinite(f) else 0.0


def _iv(v: float) -> float:
    """IV may arrive as a percent (14.2) or a fraction (0.142)."""
    return v / 100.0 if v > 3.0 else v


def max_pain(rows: list[dict[str, Any]]) -> float:
    strikes = np.array([_num(r, "strike") for r in rows])
    ce = np.array([_num(r, "ce_oi") for r in rows])
    pe = np.array([_num(r, "pe_oi") for r in rows])
    if not len(strikes):
        return 0.0
    pain = [
        float((ce * np.maximum(k - strikes, 0.0)).sum() + (pe * np.maximum(strikes - k, 0.0)).sum())
        for k in strikes
    ]
    return float(strikes[int(np.argmin(pain))])


def gex_profile(rows: list[dict[str, Any]], spot: float, lot: int) -> dict[str, float]:
    """Net dealer-style gamma exposure per 1% move, the gamma flip strike, OI walls."""
    rows = sorted(rows, key=lambda r: _num(r, "strike"))
    strikes = np.array([_num(r, "strike") for r in rows])
    ce_oi = np.array([_num(r, "ce_oi") for r in rows])
    pe_oi = np.array([_num(r, "pe_oi") for r in rows])
    ce_g = np.array([_num(r, "ce_gamma") for r in rows])
    pe_g = np.array([_num(r, "pe_gamma") for r in rows])
    scale = lot * spot * spot * 0.01
    net = (ce_g * ce_oi - pe_g * pe_oi) * scale  # calls positive, puts negative
    gross = float(np.abs(net).sum()) + EPS
    flip = spot
    cum = np.cumsum(net)
    for i in range(1, len(cum)):
        if cum[i - 1] * cum[i] < 0:
            f = abs(cum[i - 1]) / (abs(cum[i - 1]) + abs(cum[i]) + EPS)
            flip = float(strikes[i - 1] + f * (strikes[i] - strikes[i - 1]))
            break
    above = strikes >= spot
    call_wall = (
        float(strikes[above][np.argmax(ce_oi[above])])
        if above.any() and ce_oi[above].max() > 0
        else spot
    )
    below = ~above
    put_wall = (
        float(strikes[below][np.argmax(pe_oi[below])])
        if below.any() and pe_oi[below].max() > 0
        else spot
    )
    return {
        "net_gex": float(net.sum()),
        "gex_norm": float(net.sum() / gross),
        "flip": flip,
        "call_wall": call_wall,
        "put_wall": put_wall,
    }


def summarize(chain: dict[str, Any]) -> dict[str, float]:
    """All derived option statistics in one dict (also stored with each signal)."""
    spot = float(chain["spot"])
    lot = int(chain.get("lot_size") or 1)
    rows = chain.get("rows") or []
    atm = float(chain.get("atm_strike") or spot)
    total_ce = sum(_num(r, "ce_oi") for r in rows)
    total_pe = sum(_num(r, "pe_oi") for r in rows)
    pcr = total_pe / total_ce if total_ce > 0 else 1.0

    by_strike = {float(_num(r, "strike")): r for r in rows}
    strikes = sorted(by_strike)
    atm_row = by_strike.get(atm) or (
        by_strike[min(strikes, key=lambda k: abs(k - spot))] if strikes else {}
    )
    ce_iv, pe_iv = _iv(_num(atm_row, "ce_iv")), _iv(_num(atm_row, "pe_iv"))
    ivs = [x for x in (ce_iv, pe_iv) if x > 0]
    atm_iv = float(np.mean(ivs)) if ivs else 0.0
    straddle = _num(atm_row, "ce_ltp") + _num(atm_row, "pe_ltp")

    skew = 0.0
    if strikes and atm_iv > 0:
        i = strikes.index(min(strikes, key=lambda k: abs(k - atm)))
        lo, hi = max(i - 2, 0), min(i + 2, len(strikes) - 1)
        put_iv = _iv(_num(by_strike[strikes[lo]], "pe_iv"))
        call_iv = _iv(_num(by_strike[strikes[hi]], "ce_iv"))
        if put_iv > 0 and call_iv > 0:
            skew = (put_iv - call_iv) / atm_iv

    gex = (
        gex_profile(rows, spot, lot)
        if rows
        else {
            "net_gex": 0.0,
            "gex_norm": 0.0,
            "flip": spot,
            "call_wall": spot,
            "put_wall": spot,
        }
    )
    pain = max_pain(rows) if rows else spot
    return {
        "pcr": float(pcr),
        "atm_iv": atm_iv,
        "straddle": straddle,
        "expected_move_pct": straddle / spot if spot > 0 else 0.0,
        "skew": float(skew),
        "max_pain": pain,
        "dte": float(chain.get("dte") or 0.0),
        **gex,
    }


def analyze(snap: Snapshot) -> EngineReport:
    chain = snap.chain
    if not chain or not chain.get("rows"):
        return EngineReport("options", 0.0, 0.0, neutral={"opt_available": 0.0})
    s = summarize(chain)
    spot = snap.spot
    pcr_tilt = math.tanh((s["pcr"] - 1.0) * 1.5)
    skew_tilt = -math.tanh(s["skew"] * 3.0)  # richer puts read as fear
    d_call = max(s["call_wall"] - spot, 0.0)
    d_put = max(spot - s["put_wall"], 0.0)
    wall_tilt = (d_call - d_put) / (d_call + d_put + EPS) if (d_call + d_put) > 0 else 0.0
    pain_w = math.exp(-max(s["dte"], 0.0) / 2.0)
    pain_tilt = math.tanh((s["max_pain"] - spot) / spot * 100.0) if spot > 0 else 0.0
    vote = math.tanh(
        0.35 * pcr_tilt + 0.30 * skew_tilt + 0.35 * wall_tilt + 0.25 * pain_w * pain_tilt
    )
    covered = sum(1 for r in chain["rows"] if _num(r, "ce_oi") > 0 and _num(r, "pe_oi") > 0)
    conf = 0.8 * min(1.0, covered / 10.0)

    rv_ann = None
    if len(snap.bars) > 60:
        rets = np.diff(np.log(snap.bars[-120:, 4]))
        rv_ann = float(np.std(rets) * math.sqrt(75 * 252))  # ~75 five-minute bars a session
    vrp = (s["atm_iv"] - rv_ann) if (rv_ann is not None and s["atm_iv"] > 0) else 0.0
    return EngineReport(
        "options",
        vote=float(vote),
        confidence=float(conf),
        signed={
            "pcr_tilt": pcr_tilt,
            "skew_tilt": skew_tilt,
            "wall_tilt": float(wall_tilt),
            "pain_tilt": pain_tilt * pain_w,
        },
        neutral={
            "opt_available": 1.0,
            "gex_sign": 1.0 if s["net_gex"] >= 0 else -1.0,
            "gex_norm": s["gex_norm"],
            "dist_flip": max(-0.05, min(0.05, (spot - s["flip"]) / spot)) * 20.0
            if spot > 0
            else 0.0,
            "atm_iv": s["atm_iv"],
            "iv_rank": float(snap.iv_rank) if snap.iv_rank is not None else 0.5,
            "vrp": float(vrp),
            "expected_move_pct": s["expected_move_pct"] * 100.0,
        },
        notes=(
            f"pcr={s['pcr']:.2f}",
            f"gex={'+' if s['net_gex'] >= 0 else '-'}",
            f"walls {s['put_wall']:.0f}/{s['call_wall']:.0f}",
        ),
    )
