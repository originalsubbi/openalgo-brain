"""Volatility breakout engine for the AI Brain.

Detects intraday volatility expansion with a directional close — the classic
"volatility breakout" edge for index options. When true range spikes well above
the trailing average and price closes near the bar's extreme, the next bar tends
to continue in the breakout direction.

Features:
- ATR expansion: current TR >= atr_multiplier x trailing ATR(20)
- Directional close: close in the outer quartile of the bar's range
- Volume confirmation: volume >= vol_multiplier x trailing average volume
- Time filter: avoids first 30 min and last 30 min of the session
- Vote bounded to [-1, 1], scaled by expansion strength

Outputs:
  vote:    signed strength in [-1, 1]
  confidence: 0..1
  signed keys: vol_breakout (signed), vol_atr_ratio, vol_volume_ratio
  neutral keys: vol_atr_pct, vol_expansion, vol_quiet
"""

from __future__ import annotations

import numpy as np

from services.brain.engines.orb import OPEN_MINUTE  # shared session-anchor constant
from services.brain.types import EngineReport, Snapshot, param, session_slice

EPS = 1e-12

#: Skip the first 30 minutes (09:15–09:45) and stop taking new entries at 15:00.
#: Written relative to ORB's shared OPEN_MINUTE so the units can't drift again —
#: the old ``30 <= mod <= 660`` compared minutes-since-midnight against
#: 00:30–11:00, which both admitted the opening 30 minutes the filter exists to
#: avoid and silenced the engine after 11:00.
ENTRY_START_MIN = OPEN_MINUTE + 30  # 09:45 IST
ENTRY_END_MIN = 15 * 60             # 15:00 IST


def _atr(high: np.ndarray, low: np.ndarray, close: np.ndarray, n: int = 20) -> float:
    """Average True Range as absolute value (Wilder-style mean of last n TRs)."""
    prev = close[:-1]
    tr = np.maximum.reduce([high[1:] - low[1:], np.abs(high[1:] - prev), np.abs(low[1:] - prev)])
    if len(tr) < n:
        return float(np.mean(tr)) if len(tr) else 0.0
    return float(np.mean(tr[-n:]))


def _clamp(x: float, lim: float = 1.0) -> float:
    return float(max(-lim, min(lim, x)))


def analyze(snap: Snapshot) -> EngineReport:
    """Volatility breakout detection on 5-minute bars."""
    o, h, l, c, v = snap.bars[:, 1], snap.bars[:, 2], snap.bars[:, 3], snap.bars[:, 4], snap.bars[:, 5]
    if len(c) < 40:
        return EngineReport("vol_breakout", 0.0, 0.0)

    # Only consider bars of the current IST session for baseline computation;
    # otherwise the trailing mean swamps today's move with yesterday's noise.
    sess = session_slice(snap.bars)
    if len(sess) < 40:
        return EngineReport("vol_breakout", 0.0, 0.0, neutral={"vol_available": 0.0})
    o, h, l, c, v = sess[:, 1], sess[:, 2], sess[:, 3], sess[:, 4], sess[:, 5]

    O = o[-40:].astype(float)
    H = h[-40:].astype(float)
    L = l[-40:].astype(float)
    C = c[-40:].astype(float)
    V = v[-40:].astype(float)

    atr_abs = _atr(H, L, C, 20)
    atr_pct = atr_abs / C[-1] if C[-1] > 0 else 0.0

    # Last completed bar
    i = -1
    o_i, h_i, l_i, c_i = O[i], H[i], L[i], C[i]
    v_i = V[i]

    # True range for last bar: max(high-low, |high-prev_close|, |low-prev_close|)
    prev_close = C[i - 1] if len(C) > 1 else o_i
    tr_i = max(h_i - l_i, abs(h_i - prev_close), abs(l_i - prev_close))

    atr_ratio = tr_i / max(atr_abs, EPS)  # current TR / trailing ATR

    # Directional close: close near high (bullish) or near low (bearish)
    bar_range = max(h_i - l_i, EPS)
    close_pos = (c_i - l_i) / bar_range  # 0 = close at low, 1 = close at high

    # Volume confirmation
    avg_vol = float(np.mean(V[:-1])) if len(V) > 1 else float(v_i)
    vol_ratio = v_i / max(avg_vol, EPS)

    # Time filter: avoid first 30 min (9:15-9:45) and last 30 min (15:00-15:30)
    mod = snap.minute_of_day
    in_entry_window = ENTRY_START_MIN <= mod <= ENTRY_END_MIN  # 9:45 to 15:00 IST

    vote = 0.0
    confidence = 0.0
    notes = []

    # Volatility expansion threshold: TR must be at least the tunable multiple
    # of trailing ATR, with the tunable volume confirmation.
    atr_multiplier = param(snap, "vol_breakout_atr_mult", 1.5)
    vol_multiplier = param(snap, "vol_breakout_vol_mult", 1.2)

    if in_entry_window and atr_ratio >= atr_multiplier and vol_ratio >= vol_multiplier:
        # Bullish breakout: close in upper quartile
        if close_pos >= 0.75:
            strength = min((atr_ratio - atr_multiplier) / atr_multiplier, 1.0)
            vol_strength = min((vol_ratio - vol_multiplier) / vol_multiplier, 1.0)
            vote = 0.5 + 0.3 * strength + 0.2 * vol_strength
            confidence = min(0.9, 0.5 + 0.25 * strength + 0.15 * vol_strength)
            notes.append(f"vol_breakout_bullish atr_ratio={atr_ratio:.2f} vol_ratio={vol_ratio:.2f}")
        # Bearish breakout: close in lower quartile
        elif close_pos <= 0.25:
            strength = min((atr_ratio - atr_multiplier) / atr_multiplier, 1.0)
            vol_strength = min((vol_ratio - vol_multiplier) / vol_multiplier, 1.0)
            vote = -(0.5 + 0.3 * strength + 0.2 * vol_strength)
            confidence = min(0.9, 0.5 + 0.25 * strength + 0.15 * vol_strength)
            notes.append(f"vol_breakout_bearish atr_ratio={atr_ratio:.2f} vol_ratio={vol_ratio:.2f}")

    # Quiet market detection (low volatility = avoid trading)
    is_quiet = atr_ratio < 0.7
    neutral = {
        "vol_atr_pct": min(atr_pct * 100, 1.0),
        "vol_atr_ratio": min(atr_ratio, 3.0),
        "vol_volume_ratio": min(vol_ratio, 3.0),
        "vol_expansion": min(max(atr_ratio - 1.0, 0.0), 1.0),
        "vol_quiet": 1.0 if is_quiet else 0.0,
    }

    signed = {
        "vol_breakout": _clamp(vote, 1.0),
        "vol_atr_ratio": min(atr_ratio, 3.0) if vote > 0 else -min(atr_ratio, 3.0),
        "vol_volume_ratio": min(vol_ratio, 3.0),
    }

    return EngineReport(
        "vol_breakout",
        vote=_clamp(vote, 1.0),
        confidence=float(confidence),
        signed=signed,
        neutral=neutral,
        notes=tuple(notes) if notes else (),
    )


__all__ = ["analyze", "EPS"]
