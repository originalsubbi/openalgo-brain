"""OI/PCR engine: open-interest buildup, put-call ratio extremes, max pain gravity.

Reads the option chain (same dict as ``engines.options``) and adds trading-knowledge
signals that the raw options engine does not emit:

* **PCR extremes (contrarian)** — PCR > 1.35 = put panic (oversold, bullish contrarian);
  PCR < 0.70 = call euphoria (overbought, bearish contrarian). Returns to 1.0 as IV
  mean-reverts, so extreme PCR is a mean-reversion signal, not a trend signal.
* **OI buildup** — when OI rises *with* price it confirms the trend (new money entering);
  when OI falls *with* price it signals unwinding (trend exhaustion).
* **Max pain gravity** — index tends to gravitate toward max pain at expiry; distance
  from max pain is a mean-reversion signal (far above = bearish, far below = bullish).
* **Option chain liquidity** — total OI across strikes; thin chains are skipped.

With no chain the engine abstains (vote 0, confidence 0).
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np

from services.brain.types import EngineReport, Snapshot, param

EPS = 1e-12


def _math_tanh(x: float) -> float:
    return math.tanh(x)


def _num(row: dict[str, Any], key: str) -> float:
    v = row.get(key)
    try:
        f = float(v)
    except (TypeError, ValueError):
        return 0.0
    return f if np.isfinite(f) else 0.0


def _iv(v: float) -> float:
    return v / 100.0 if v > 3.0 else v


def analyze(snap) -> EngineReport:
    """OI/PCR + max pain + OI buildup engine."""
    chain = snap.chain
    if not chain or not chain.get("rows"):
        return EngineReport("oi_pcr", 0.0, 0.0, neutral={"oi_available": 0.0})

    spot = float(chain.get("spot") or snap.spot)
    rows = chain.get("rows") or []
    if not rows:
        return EngineReport("oi_pcr", 0.0, 0.0, neutral={"oi_available": 0.0})

    lot = int(chain.get("lot_size") or 1)
    dte = float(chain.get("dte") or 0.0)

    # ---- aggregate OI across all strikes -------------------------------------
    total_ce = sum(_num(r, "ce_oi") for r in rows)
    total_pe = sum(_num(r, "pe_oi") for r in rows)
    total_oi = total_ce + total_pe
    pcr = total_pe / total_ce if total_ce > 0 else 1.0

    # ---- liquidity gate -------------------------------------------------------
    # need at least some OI across the chain; otherwise skip
    liq_ok = total_oi > 0
    if not liq_ok:
        return EngineReport("oi_pcr", 0.0, 0.0, neutral={"oi_available": 0.0})

    # ---- PCR contrarian signal -----------------------------------------------
    # PCR above the panic line = put panic (oversold -> bullish contrarian)
    # PCR below the euphoria line = call euphoria (overbought -> bearish contrarian)
    panic_line = param(snap, "oi_pcr_panic", 1.35)
    euphoria_line = param(snap, "oi_pcr_euphoria", 0.70)
    pcr_tilt = 0.0
    if pcr >= panic_line:
        pcr_tilt = min(1.0, (pcr - panic_line) / 0.65)  # ramp to 1.0 at panic+0.65
    elif pcr <= euphoria_line:
        pcr_tilt = -min(1.0, (euphoria_line - pcr) / 0.40)  # ramp to -1.0 at 0.30

    # ---- max pain gravity ----------------------------------------------------
    # Only consider strikes that actually have open interest — zero-OI strikes
    # are ghost entries left over from the data source and would pull max pain
    # toward illiquid wings.
    strikes = np.array([_num(r, "strike") for r in rows])
    ce = np.array([_num(r, "ce_oi") for r in rows])
    pe = np.array([_num(r, "pe_oi") for r in rows])
    valid = ce + pe > 0
    strikes_valid = strikes[valid]
    ce_valid = ce[valid]
    pe_valid = pe[valid]
    pain = [
        float((ce_valid * np.maximum(k - strikes_valid, 0.0)).sum() +
              (pe_valid * np.maximum(strikes_valid - k, 0.0)).sum())
        for k in strikes_valid
    ]
    max_pain = float(strikes_valid[int(np.argmin(pain))]) if len(strikes_valid) else spot
    pain_dist = (max_pain - spot) / spot if spot > 0 else 0.0  # + = spot below pain (bullish grav)
    # A graded ramp, not a saturating one: 1% of distance from max pain is a
    # mild pull, 3% is a strong one. A tanh scaled to saturate at 1% turned
    # this into a binary flag that was fully "on" for any real deviation.
    pain_tilt = _math_tanh(pain_dist * 20.0)  # +1 = far below pain (bullish), -1 = far above (bearish)
    pain_w = math.exp(-max(dte, 0.0) / 3.0)  # weight decays with DTE
    pain_weight = param(snap, "oi_pain_weight", 0.25)

    # ---- OI buildup (need history: compare current OI to 20 bars ago) ---------
    # We don't have history in the snapshot, so use a proxy: the OI-weighted
    # strike centroid is where the money sits.
    if len(strikes) > 0 and total_oi > 0:
        oi_weighted = float((ce + pe) @ strikes) / total_oi
        centroid_tilt = _math_tanh((oi_weighted - spot) / spot * 20.0)
    else:
        oi_weighted = spot
        centroid_tilt = 0.0

    # ---- ATM skew for skew-aware directional bias -----------------------------
    # Same strike on both sides: a put's IV at one strike compared with a call's
    # IV at a different strike is not a skew, it is two unrelated quotes.
    by_strike = {float(_num(r, "strike")): r for r in rows}
    strike_list = sorted(by_strike)
    atm_idx = min(range(len(strike_list)), key=lambda i: abs(strike_list[i] - spot))
    atm_row = by_strike[strike_list[atm_idx]]
    put_iv = _iv(_num(atm_row, "pe_iv"))
    call_iv = _iv(_num(atm_row, "ce_iv"))
    atm_iv_ref = _iv(_num(atm_row, "ce_iv"))
    skew = (put_iv - call_iv) / atm_iv_ref if put_iv > 0 and call_iv > 0 and atm_iv_ref > 0 else 0.0
    # Richer puts are fear, and this engine reads fear the way it reads the PCR:
    # as an oversold condition that mean-reverts. Reading the same market as
    # bullish here and bearish in the PCR line above would have the engine
    # arguing with itself.
    skew_tilt = _math_tanh(skew * 3.0)  # richer puts = fear = oversold = bullish tilt

    # ---- fuse into vote -------------------------------------------------------
    # PCR contrarian (mean reversion), pain gravity (mean reversion toward pain),
    # centroid tilt (trend confirmation), skew (fear/greed)
    vote = _math_tanh(
        0.35 * pcr_tilt +
        pain_weight * pain_w * pain_tilt +
        0.25 * centroid_tilt +
        0.15 * skew_tilt,
    )

    conf = 0.0
    if liq_ok:
        conf = min(1.0, 0.3 + 0.4 * min(1.0, total_oi / 1e6) + 0.3 * abs(pcr_tilt))

    signed = {
        "oi_pcr_tilt": pcr_tilt,
        "oi_pain_tilt": pain_tilt * pain_w,
        "oi_centroid_tilt": centroid_tilt,
        "oi_skew_tilt": skew_tilt,
    }
    neutral = {
        "oi_available": 1.0 if liq_ok else 0.0,
        "oi_pcr": pcr,
        "oi_total_oi": min(1.0, total_oi / 5e6),
        "oi_max_pain_dist": pain_dist,
        "oi_dte": min(1.0, dte / 7.0),
    }
    notes = []
    if pcr >= 1.35:
        notes.append(f"oi_pcr_put_panic={pcr:.2f}")
    elif pcr <= 0.70:
        notes.append(f"oi_pcr_call_euphoria={pcr:.2f}")
    if abs(pain_dist) > 0.01:
        notes.append(f"oi_pain_dist={pain_dist:+.2%}")

    return EngineReport(
        "oi_pcr",
        vote=float(vote),
        confidence=float(conf),
        signed=signed,
        neutral=neutral,
        notes=tuple(notes),
    )


def math_tanh(x: float) -> float:
    import math
    return math.tanh(x)


__all__ = ["analyze"]
