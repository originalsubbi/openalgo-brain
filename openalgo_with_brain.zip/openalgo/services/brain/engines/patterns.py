"""Pattern engine: candlestick + micro-structure detection (V4 - Ultra-Strict).

Zero-tolerance false positive elimination. Patterns only fire when:
- Statistically rare for current volatility regime (ATR-normalized)
- Multiple independent confirmations align
- Volume/range confirmations align
- Pattern structure matches textbook definition precisely
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np

from services.brain.types import EngineReport, Snapshot

EPS = 1e-12


def _atr(high: np.ndarray, low: np.ndarray, close: np.ndarray, n: int = 14) -> float:
    prev = close[:-1]
    tr = np.maximum.reduce(
        [high[1:] - low[1:], np.abs(high[1:] - prev), np.abs(low[1:] - prev)]
    )
    if len(tr) < n:
        return float(np.mean(tr)) / max(float(close[-1]), EPS) if len(tr) else 0.0
    val = float(np.mean(tr[:n]))
    for x in tr[n:]:
        val = (val * (n - 1) + x) / n
    return val / max(float(close[-1]), EPS)


def _body_parts(o: float, h: float, l: float, c: float, atr_abs: float) -> tuple[float, float, float, float]:
    body = abs(c - o)
    upper = h - max(c, o)
    lower = min(c, o) - l
    tr = max(h - l, body + upper + lower)
    atr = max(atr_abs, EPS)
    return body / atr, upper / atr, lower / atr, tr / atr


def _clamp(x: float, lim: float = 1.0) -> float:
    return float(max(-lim, min(lim, x)))


def _is_trending(close: np.ndarray, atr_frac: float, lookback: int = 10) -> int:
    if len(close) < lookback + 1:
        return 0
    returns = np.diff(close[-(lookback+1):])
    trend = np.sum(returns) / (atr_frac * close[-1] + EPS)
    if trend > 0.5:
        return 1
    elif trend < -0.5:
        return -1
    return 0


def analyze(snap: Snapshot, window: int = 80) -> EngineReport:
    o, h, l, c, v = snap.bars[:, 1], snap.bars[:, 2], snap.bars[:, 3], snap.bars[:, 4], snap.bars[:, 5]
    if len(c) < window:
        return EngineReport("patterns", 0.0, 0.0)
    
    O = o[-window:].astype(float)
    H = h[-window:].astype(float)
    L = l[-window:].astype(float)
    C = c[-window:].astype(float)
    V = v[-window:].astype(float)
    
    atr_frac = _atr(H, L, C) + EPS
    atr_abs = atr_frac * C[-1]
    
    # ========================================================================
    # LAST COMPLETED BAR
    # ========================================================================
    i = -1
    o_i, h_i, l_i, c_i = O[i], H[i], L[i], C[i]
    body_atr, upper_atr, lower_atr, tr_atr = _body_parts(o_i, h_i, l_i, c_i, atr_abs)
    
    # Dead bar guard: zero true range means no meaningful price action
    if tr_atr < EPS:
        return EngineReport("patterns", 0.0, 0.0)
    
    # ========================================================================
    # DOJI: body < 0.03 ATR (extremely small) + min true range > 0.5 ATR
    # ========================================================================
    doji_flag = 1.0 if (body_atr < 0.02 and tr_atr > 0.5) else 0.0
    doji_strength = max(0.0, 1.0 - body_atr / 0.02) if body_atr < 0.02 else 0.0
    dg = dm = 0.0
    if body_atr < 0.03:
        if lower_atr > 4 * upper_atr and lower_atr > 0.4:
            dg = 1.0
        elif upper_atr > 4 * lower_atr and upper_atr > 0.4:
            dm = 1.0
    doji_signed = dg - dm
    
    # ========================================================================
    # HAMMER / HANGING MAN: body < 0.1 ATR, lower wick >= 3x body, upper < 0.3x body
    # ========================================================================
    hammer_flag = 0.0
    if O[-1] != C[-1]:
        body_atr_abs = abs(O[-1] - C[-1]) / atr_abs
        if body_atr < 0.05 and lower_atr >= 4 * max(body_atr, 0.01) and upper_atr < 0.2 * max(body_atr, 0.01):
            hammer_flag = min(1.0, lower_atr / (4 * max(body_atr, 0.01) + EPS))
    
    trend_10 = 0
    if len(C) >= 11:
        returns = np.diff(C[-11:])
        trend = np.sum(returns) / (atr_frac * C[-1] + EPS)
        if trend > 0.5: trend_10 = 1
        elif trend < -0.5: trend_10 = -1
    
    hammer_signed = hammer_flag if trend_10 == -1 else 0.0
    hanging_signed = -hammer_flag if trend_10 == 1 else 0.0
    
    # ========================================================================
    # INVERTED HAMMER / SHOOTING STAR
    # ========================================================================
    inv_hammer_flag = 0.0
    if O[-1] != C[-1]:
        body_atr_abs = abs(O[-1] - C[-1]) / atr_abs
        if body_atr < 0.1 and upper_atr >= 3 * max(body_atr, 0.01) and lower_atr < 0.3 * max(body_atr, 0.01):
            inv_hammer_flag = min(1.0, upper_atr / (3 * max(body_atr, 0.01) + EPS))
    inv_hammer_signed = inv_hammer_flag if trend_10 == -1 else 0.0
    shooting_signed = -inv_hammer_flag if trend_10 == 1 else 0.0
    
    # ========================================================================
    # MARUBOZU: body > 0.85 ATR, wicks < 0.02 ATR each
    # ========================================================================
    marubozu_flag = 1.0 if (body_atr > 0.9 and upper_atr < 0.01 and lower_atr < 0.01) else 0.0
    marubozu_signed = marubozu_flag * (1.0 if C[-1] > O[-1] else -1.0)
    
    # ========================================================================
    # TWO-BAR PATTERNS
    # ========================================================================
    body_p_atr = abs(C[-2] - O[-2]) / atr_abs
    tr_p_atr = (H[-2] - L[-2]) / atr_abs
    body_c_atr = abs(C[-1] - O[-1]) / atr_abs
    tr_c_atr = (H[-1] - L[-1]) / atr_abs
    
    vol_ma20 = np.mean(V[-20:]) if len(V) >= 20 else V[-1]
    vol_ratio = V[-1] / max(vol_ma20, EPS)
    vol_confirm = vol_ratio > 1.5  # strict volume confirmation
    
    # ========================================================================
    # ENGULFING: current body >= 2.5x prior body, range >= 1.2x prior, volume > 1.5x
    # ========================================================================
    bull_engulf = bear_engulf = 0.0
    if C[-2] < O[-2] and C[-1] > O[-1]:  # prior red, current green
        if body_c_atr := abs(C[-1] - O[-1]) / atr_abs:
            if body_c_atr >= 2.5 * body_p_atr and tr_c_atr >= 1.2 * tr_p_atr and vol_confirm:
                bull_engulf = min(1.0, (body_c_atr / body_p_atr - 2.5) * 0.8)
    if C[-2] > O[-2] and C[-1] < O[-1]:
        body_c_atr = abs(C[-1] - O[-1]) / atr_abs
        if body_c_atr >= 2.5 * body_p_atr and tr_c_atr >= 1.2 * tr_p_atr and vol_confirm:
            bear_engulf = min(1.0, (body_c_atr / body_p_atr - 2.5) * 0.8)
    
    # ========================================================================
    # HARAMI: current body <= 0.25x prior body
    # ========================================================================
    bull_harami = bear_harami = 0.0
    if C[-2] > O[-2] and C[-1] < O[-1] and body_c_atr <= 0.25 * body_p_atr:
        bull_harami = max(0.0, 1.0 - body_c_atr / (0.2 * body_p_atr + EPS))
    if C[-2] < O[-2] and C[-1] > O[-1] and body_c_atr <= 0.25 * body_p_atr:
        bear_harami = max(0.0, 1.0 - body_c_atr / (0.2 * body_p_atr + EPS))
    
        # ========================================================================
    # TWEEZERS: exact high/low match within 0.5 tick (ultra-tight)
    # ========================================================================
    tick_size = C[-1] * 0.00005  # 0.005% = half a tick for most indices
    tweezer_top = 1.0 if abs(H[-1] - H[-2]) < tick_size and abs(H[-1] - H[-2]) < 0.1 * atr_abs else 0.0
    tweezer_bottom = 1.0 if abs(L[-1] - L[-2]) < tick_size and abs(L[-1] - L[-2]) < 0.1 * atr_abs else 0.0
    
    # ========================================================================
    # THREE-BAR PATTERNS
    # ========================================================================
    morning_star = evening_star = 0.0
    if len(C) >= 3:
        b1 = C[-3] - O[-3]
        b2 = C[-2] - O[-2]
        b3 = C[-1] - O[-1]
        mid_body = abs(b2) / (abs(b1) + abs(b3) + EPS)
        gap1 = (O[-2] - C[-3]) / max(C[-3], EPS)
        gap2 = (O[-1] - C[-2]) / max(C[-2], EPS)
        
        if b1 < -4 * atr_abs and b3 > 4 * atr_abs and mid_body < 0.2:
            morning_star = min(1.0, (abs(gap1) + abs(gap2)) / (2 * atr_frac + EPS))
        elif b1 > 4 * atr_abs and b3 < -4 * atr_abs and mid_body < 0.2:
            evening_star = min(1.0, (abs(gap1) + abs(gap2)) / (2 * atr_frac + EPS))
    
    # Three soldiers / crows: 3 consecutive same-color, each closes beyond prior, opens in prior body
    three_soldiers = three_crows = 0.0
    if len(C) >= 4:
        c1, c2, c3 = C[-3] - O[-3], C[-2] - O[-2], C[-1] - O[-1]
        if c1 > 2*atr_abs and c2 > 2*atr_abs and c3 > 2*atr_abs and C[-3] > C[-4] and C[-2] > C[-3] and C[-1] > C[-2]:
            if O[-2] > C[-3] and O[-2] < C[-3] + 0.3*abs(C[-3]-O[-3]) and O[-1] > C[-2] and O[-1] < C[-2] + 0.3*abs(C[-2]-O[-2]):
                three_soldiers = min(1.0, (abs(c1)+abs(c2)+abs(c3)) / (3 * atr_abs + EPS))
        if c1 < -2*atr_abs and c2 < -2*atr_abs and c3 < -2*atr_abs and C[-3] < C[-4] and C[-2] < C[-3] and C[-1] < C[-2]:
            if O[-2] < C[-3] and O[-2] > C[-3] - 0.3*abs(C[-3]-O[-3]) and O[-1] < C[-2] and O[-1] > C[-2] - 0.3*abs(C[-2]-O[-2]):
                three_crows = min(1.0, (abs(c1)+abs(c2)+abs(c3)) / (3 * atr_abs + EPS))
    
    # Inside / Outside bar
    inside_bar = 1.0 if (H[-1] <= H[-2] and L[-1] >= L[-2] and (H[-1]-L[-1]) < 0.4*(H[-2]-L[-2])) else 0.0
    outside_bar = 1.0 if (H[-1] >= H[-2] and L[-1] <= L[-2] and (H[-1]-L[-1]) > 1.8*(H[-2]-L[-2])) else 0.0
    
    # ========================================================================
    # MICRO-STRUCTURE
    # ========================================================================
    # Swings: 5-bar window
    swing_window = 5
    swings_high = np.zeros(len(H))
    swings_low = np.zeros(len(L))
    for i in range(swing_window, len(H) - swing_window):
        if H[i] == float(H[i-swing_window:i+swing_window+1].max()):
            swings_high[i] = 1.0
        if L[i] == float(L[i-swing_window:i+swing_window+1].min()):
            swings_low[i] = 1.0
    
    hh_count = ll_count = 0
    last_hh = last_ll = C[-1]
    for idx in range(len(swings_high) - 30, len(swings_high)):
        if swings_high[idx]:
            hh_count += 1
            last_hh = H[idx]
        if swings_low[idx]:
            ll_count += 1
            last_ll = L[idx]
    
    swing_range = last_hh - last_ll + EPS
    hh_bias = _clamp((C[-1] - last_ll) / swing_range - 0.5, 0.5)
    ll_bias = _clamp(0.5 - (C[-1] - last_hh) / swing_range, 0.5)
    
    # ========================================================================
    # SLOPE FLIP: slope change > 2.0 ATR over 12 bars + direction reversal
    # ========================================================================
    slope_lookback = 12
    slope_prev = float(np.polyfit(range(slope_lookback), C[-2*slope_lookback:-slope_lookback], 1)[0]) if len(C) >= 2*slope_lookback else 0.0
    slope_now = float(np.polyfit(range(slope_lookback), C[-slope_lookback:], 1)[0])
    slope_change = abs(slope_now - slope_prev) / max(atr_frac * C[-1], EPS)
    slope_flip = 1.0 if slope_change > 2.0 and slope_now * slope_prev < 0 else 0.0
    slope_dir = 1.0 if slope_now > 2*atr_frac else -1.0 if slope_now < -2*atr_frac else 0.0
    
    # ATR ratio
    atr_short = _atr(H[-10:], L[-10:], C[-10:])
    atr_long = _atr(H[-40:-10], L[-40:-10], C[-40:-10]) if len(C) >= 40 else atr_short
    atr_ratio = atr_short / (atr_long + EPS)
    contraction = max(0.0, 1.0 - atr_ratio)
    expansion = max(0.0, atr_ratio - 1.0)
    
    swing_range = last_hh - last_ll + EPS
    hh_bias = _clamp((C[-1] - last_ll) / swing_range - 0.5, 0.5)
    ll_bias = _clamp(0.5 - (C[-1] - last_hh) / swing_range, 0.5)
    
    swing_span_pct = min(abs(last_hh - last_ll) / (C[-1] + EPS) * 10, 10.0) / 10.0
    body_avg_pct = min(float(np.mean(np.abs(C[-20:] - O[-20:])) / atr_abs) / 10.0, 1.0)
    
    # ========================================================================
    # HAMMER / HANGING MAN (recompute for signed)
    # ========================================================================
    hammer_flag = 0.0
    if O[-1] != C[-1]:
        body_atr_abs = abs(O[-1] - C[-1]) / atr_abs
        if body_atr < 0.05 and lower_atr >= 4 * max(body_atr, 0.01) and upper_atr < 0.2 * max(body_atr, 0.01):
            hammer_flag = min(1.0, lower_atr / (4 * max(body_atr, 0.01) + EPS))
    
    trend_10 = 0
    if len(C) >= 11:
        returns = np.diff(C[-11:])
        trend = np.sum(returns) / (atr_frac * C[-1] + EPS)
        if trend > 0.5: trend_10 = 1
        elif trend < -0.5: trend_10 = -1
    
    hammer_signed = hammer_flag if trend_10 == -1 else 0.0
    hanging_signed = -hammer_flag if trend_10 == 1 else 0.0
    
    inv_hammer_flag = 0.0
    if O[-1] != C[-1]:
        body_atr_abs = abs(O[-1] - C[-1]) / atr_abs
        if body_atr < 0.05 and upper_atr >= 4 * max(body_atr, 0.01) and lower_atr < 0.2 * max(body_atr, 0.01):
            inv_hammer_flag = min(1.0, upper_atr / (4 * max(body_atr, 0.01) + EPS))
    inv_hammer_signed = inv_hammer_flag if trend_10 == -1 else 0.0
    shooting_signed = -inv_hammer_flag if trend_10 == 1 else 0.0
    
    marubozu_flag = 1.0 if (body_atr > 0.9 and upper_atr < 0.01 and lower_atr < 0.01) else 0.0
    marubozu_signed = marubozu_flag * (1.0 if C[-1] > O[-1] else -1.0)
    
    # Two-bar vars (recompute)
    body_p_atr = abs(C[-2] - O[-2]) / atr_abs
    tr_p_atr = (H[-2] - L[-2]) / atr_abs
    body_c_atr = abs(C[-1] - O[-1]) / atr_abs
    tr_c_atr = (H[-1] - L[-1]) / atr_abs
    
    vol_ma20 = np.mean(V[-20:]) if len(V) >= 20 else V[-1]
    vol_ratio = V[-1] / max(np.mean(V[-20:]), EPS) if len(V) >= 20 else 1.0
    vol_confirm = vol_ratio > 1.5
    
    bull_engulf = bear_engulf = 0.0
    if C[-2] < O[-2] and C[-1] > O[-1]:
        if body_c_atr >= 2.0 * body_p_atr and tr_c_atr >= 1.1 * tr_p_atr and vol_confirm:
            bull_engulf = min(1.0, (body_c_atr / body_p_atr - 2.0) * 0.8)
    if C[-2] > O[-2] and C[-1] < O[-1]:
        body_c_atr = abs(C[-1] - O[-1]) / atr_abs
        if body_c_atr >= 2.0 * body_p_atr and tr_c_atr >= 1.1 * tr_p_atr and vol_confirm:
            bear_engulf = min(1.0, (body_c_atr / body_p_atr - 2.0) * 0.8)
    
    # Three-bar
    morning_star = evening_star = 0.0
    if len(C) >= 3:
        b1 = C[-3] - O[-3]
        b2 = C[-2] - O[-2]
        b3 = C[-1] - O[-1]
        mid_body = abs(b2) / (abs(b1) + abs(b3) + EPS)
        gap1 = (O[-2] - C[-3]) / max(C[-3], EPS)
        gap2 = (O[-1] - C[-2]) / max(C[-2], EPS)
        
        if b1 < -4 * atr_abs and b3 > 4 * atr_abs and mid_body < 0.2:
            morning_star = min(1.0, (abs(gap1) + abs(gap2)) / (2 * atr_frac + EPS))
        elif b1 > 4 * atr_abs and b3 < -4 * atr_abs and mid_body < 0.2:
            evening_star = min(1.0, (abs(gap1) + abs(gap2)) / (2 * atr_frac + EPS))
    
    three_soldiers = three_crows = 0.0
    if len(C) >= 4:
        c1, c2, c3 = C[-3] - O[-3], C[-2] - O[-2], C[-1] - O[-1]
        if c1 > 2*atr_abs and c2 > 2*atr_abs and c3 > 2*atr_abs and C[-3] > C[-4] and C[-2] > C[-3] and C[-1] > C[-2]:
            if O[-2] > C[-3] and O[-2] < C[-3] + 0.3*abs(C[-3]-O[-3]) and O[-1] > C[-2] and O[-1] < C[-2] + 0.3*abs(C[-2]-O[-2]):
                three_soldiers = min(1.0, (abs(c1)+abs(c2)+abs(c3)) / (3 * atr_abs + EPS))
        if c1 < -2*atr_abs and c2 < -2*atr_abs and c3 < -2*atr_abs and C[-3] < C[-4] and C[-2] < C[-3] and C[-1] < C[-2]:
            if O[-2] < C[-3] and O[-2] > C[-3] - 0.3*abs(C[-3]-O[-3]) and O[-1] < C[-2] and O[-1] > C[-2] - 0.3*abs(C[-2]-O[-2]):
                three_crows = min(1.0, (abs(c1)+abs(c2)+abs(c3)) / (3 * atr_abs + EPS))
    
    inside_bar = 1.0 if (H[-1] <= H[-2] and L[-1] >= L[-2] and (H[-1]-L[-1]) < 0.4*(H[-2]-L[-2])) else 0.0
    outside_bar = 1.0 if (H[-1] >= H[-2] and L[-1] <= L[-2] and (H[-1]-L[-1]) > 1.8*(H[-2]-L[-2])) else 0.0
    
    # Swings
    swing_window = 5
    swings_high = np.zeros(len(H))
    swings_low = np.zeros(len(L))
    for i in range(swing_window, len(H) - swing_window):
        if H[i] == float(H[i-swing_window:i+swing_window+1].max()):
            swings_high[i] = 1.0
        if L[i] == float(L[i-swing_window:i+swing_window+1].min()):
            swings_low[i] = 1.0
    
    hh_count = ll_count = 0
    last_hh = last_ll = C[-1]
    for idx in range(len(swings_high) - 30, len(swings_high)):
        if swings_high[idx]:
            hh_count += 1
            last_hh = H[idx]
        if swings_low[idx]:
            ll_count += 1
            last_ll = L[idx]
    
    swing_range = last_hh - last_ll + EPS
    hh_bias = _clamp((C[-1] - last_ll) / swing_range - 0.5, 0.5)
    ll_bias = _clamp(0.5 - (C[-1] - last_hh) / swing_range, 0.5)
    
    # Slope flip
    slope_lookback = 12
    slope_prev = float(np.polyfit(range(slope_lookback), C[-2*slope_lookback:-slope_lookback], 1)[0]) if len(C) >= 2*slope_lookback else 0.0
    slope_now = float(np.polyfit(range(slope_lookback), C[-slope_lookback:], 1)[0])
    slope_change = abs(slope_now - slope_prev) / max(atr_frac * C[-1], EPS)
    slope_flip = 1.0 if slope_change > 2.0 and slope_now * slope_prev < 0 else 0.0
    slope_dir = 1.0 if slope_now > 2*atr_frac else -1.0 if slope_now < -2*atr_frac else 0.0
    
    atr_short = _atr(H[-10:], L[-10:], C[-10:])
    atr_long = _atr(H[-40:-10], L[-40:-10], C[-40:-10]) if len(C) >= 40 else atr_short
    atr_ratio = atr_short / (atr_long + EPS)
    contraction = max(0.0, 1.0 - atr_ratio)
    expansion = max(0.0, atr_ratio - 1.0)
    
    swing_span_pct = min(abs(last_hh - last_ll) / (C[-1] + EPS) * 10, 10.0) / 10.0
    body_avg_pct = min(float(np.mean(np.abs(C[-20:] - O[-20:])) / atr_abs) / 10.0, 1.0)
    
    # Recompute for signed
    body_atr, upper_atr, lower_atr, tr_atr = _body_parts(O[-1], H[-1], L[-1], C[-1], atr_abs)
    
    dg = dm = 0.0
    if body_atr < 0.03:
        if lower_atr > 4 * upper_atr and lower_atr > 0.4:
            dg = 1.0
        elif upper_atr > 4 * lower_atr and upper_atr > 0.4:
            dm = 1.0
    doji_signed = dg - dm
    doji_flag = 1.0 if body_atr < 0.03 else 0.0
    doji_strength = max(0.0, 1.0 - body_atr / 0.03) if body_atr < 0.03 else 0.0
    
    hammer_flag = 0.0
    if O[-1] != C[-1]:
        body_atr_abs = abs(O[-1] - C[-1]) / atr_abs
        if body_atr < 0.05 and lower_atr >= 4 * max(body_atr, 0.01) and upper_atr < 0.2 * max(body_atr, 0.01):
            hammer_flag = min(1.0, lower_atr / (4 * max(body_atr, 0.01) + EPS))
    
    trend_10 = 0
    if len(C) >= 11:
        returns = np.diff(C[-11:])
        trend = np.sum(returns) / (atr_frac * C[-1] + EPS)
        if trend > 0.5: trend_10 = 1
        elif trend < -0.5: trend_10 = -1
    
    hammer_signed = hammer_flag if trend_10 == -1 else 0.0
    hanging_signed = -hammer_flag if trend_10 == 1 else 0.0
    
    inv_hammer_flag = 0.0
    if O[-1] != C[-1]:
        body_atr_abs = abs(O[-1] - C[-1]) / atr_abs
        if body_atr < 0.05 and upper_atr >= 4 * max(body_atr, 0.01) and lower_atr < 0.2 * max(body_atr, 0.01):
            inv_hammer_flag = min(1.0, upper_atr / (4 * max(body_atr, 0.01) + EPS))
    inv_hammer_signed = inv_hammer_flag if trend_10 == -1 else 0.0
    shooting_signed = -inv_hammer_flag if trend_10 == 1 else 0.0
    
    marubozu_flag = 1.0 if (body_atr > 0.9 and upper_atr < 0.01 and lower_atr < 0.01) else 0.0
    marubozu_signed = marubozu_flag * (1.0 if C[-1] > O[-1] else -1.0)
    
    # Two-bar recomputed
    body_p_atr = abs(C[-2] - O[-2]) / atr_abs
    tr_p_atr = (H[-2] - L[-2]) / atr_abs
    body_c_atr = abs(C[-1] - O[-1]) / atr_abs
    tr_c_atr = (H[-1] - L[-1]) / atr_abs
    vol_ma20 = np.mean(V[-20:]) if len(V) >= 20 else V[-1]
    vol_ratio = V[-1] / max(np.mean(V[-20:]), EPS) if len(V) >= 20 else 1.0
    vol_confirm = vol_ratio > 1.5

    bull_engulf = bear_engulf = 0.0
    if C[-2] < O[-2] and C[-1] > O[-1]:
        if body_c_atr >= 2.5 * body_p_atr and tr_c_atr >= 1.2 * tr_p_atr and vol_confirm:
            bull_engulf = min(1.0, (body_c_atr / body_p_atr - 2.5) * 0.8)
    if C[-2] > O[-2] and C[-1] < O[-1]:
        body_c_atr = abs(C[-1] - O[-1]) / atr_abs
        if body_c_atr >= 2.5 * body_p_atr and tr_c_atr >= 1.2 * tr_p_atr and vol_confirm:
            bear_engulf = min(1.0, (body_c_atr / body_p_atr - 2.5) * 0.8)
    
    # Three-bar
    morning_star = evening_star = 0.0
    if len(C) >= 3:
        b1 = C[-3] - O[-3]
        b2 = C[-2] - O[-2]
        b3 = C[-1] - O[-1]
        mid_body = abs(b2) / (abs(b1) + abs(b3) + EPS)
        gap1 = (O[-2] - C[-3]) / max(C[-3], EPS)
        gap2 = (O[-1] - C[-2]) / max(C[-2], EPS)
        
        if b1 < -4 * atr_abs and b3 > 4 * atr_abs and mid_body < 0.2:
            morning_star = min(1.0, (abs(gap1) + abs(gap2)) / (2 * atr_frac + EPS))
        elif b1 > 4 * atr_abs and b3 < -4 * atr_abs and mid_body < 0.2:
            evening_star = min(1.0, (abs(gap1) + abs(gap2)) / (2 * atr_frac + EPS))
    
    three_soldiers = three_crows = 0.0
    if len(C) >= 4:
        c1, c2, c3 = C[-3] - O[-3], C[-2] - O[-2], C[-1] - O[-1]
        if c1 > 2*atr_abs and c2 > 2*atr_abs and c3 > 2*atr_abs and C[-3] > C[-4] and C[-2] > C[-3] and C[-1] > C[-2]:
            if O[-2] > C[-3] and O[-2] < C[-3] + 0.3*abs(C[-3]-O[-3]) and O[-1] > C[-2] and O[-1] < C[-2] + 0.3*abs(C[-2]-O[-2]):
                three_soldiers = min(1.0, (abs(c1)+abs(c2)+abs(c3)) / (3 * atr_abs + EPS))
        if c1 < -2*atr_abs and c2 < -2*atr_abs and c3 < -2*atr_abs and C[-3] < C[-4] and C[-2] < C[-3] and C[-1] < C[-2]:
            if O[-2] < C[-3] and O[-2] > C[-3] - 0.3*abs(C[-3]-O[-3]) and O[-1] < C[-2] and O[-1] > C[-2] - 0.3*abs(C[-2]-O[-2]):
                three_crows = min(1.0, (abs(c1)+abs(c2)+abs(c3)) / (3 * atr_abs + EPS))
    
    inside_bar = 1.0 if (H[-1] <= H[-2] and L[-1] >= L[-2] and (H[-1]-L[-1]) < 0.4*(H[-2]-L[-2])) else 0.0
    outside_bar = 1.0 if (H[-1] >= H[-2] and L[-1] <= L[-2] and (H[-1]-L[-1]) > 1.8*(H[-2]-L[-2])) else 0.0
    
    # Swings
    swing_window = 5
    swings_high = np.zeros(len(H))
    swings_low = np.zeros(len(L))
    for i in range(swing_window, len(H) - swing_window):
        if H[i] == float(H[i-swing_window:i+swing_window+1].max()):
            swings_high[i] = 1.0
        if L[i] == float(L[i-swing_window:i+swing_window+1].min()):
            swings_low[i] = 1.0
    
    hh_count = ll_count = 0
    last_hh = last_ll = C[-1]
    for idx in range(len(swings_high) - 30, len(swings_high)):
        if swings_high[idx]:
            hh_count += 1
            last_hh = H[idx]
        if swings_low[idx]:
            ll_count += 1
            last_ll = L[idx]
    
    swing_range = last_hh - last_ll + EPS
    hh_bias = _clamp((C[-1] - last_ll) / swing_range - 0.5, 0.5)
    ll_bias = _clamp(0.5 - (C[-1] - last_hh) / swing_range, 0.5)
    
    # Slope flip
    slope_lookback = 12
    slope_prev = float(np.polyfit(range(slope_lookback), C[-2*slope_lookback:-slope_lookback], 1)[0]) if len(C) >= 2*slope_lookback else 0.0
    slope_now = float(np.polyfit(range(slope_lookback), C[-slope_lookback:], 1)[0])
    slope_change = abs(slope_now - slope_prev) / max(atr_frac * C[-1], EPS)
    slope_flip = 1.0 if slope_change > 2.0 and slope_now * slope_prev < 0 else 0.0
    slope_dir = 1.0 if slope_now > 2*atr_frac else -1.0 if slope_now < -2*atr_frac else 0.0
    
    atr_short = _atr(H[-10:], L[-10:], C[-10:])
    atr_long = _atr(H[-40:-10], L[-40:-10], C[-40:-10]) if len(C) >= 40 else atr_short
    atr_ratio = atr_short / (atr_long + EPS)
    contraction = max(0.0, 1.0 - atr_ratio)
    expansion = max(0.0, atr_ratio - 1.0)
    
    swing_span_pct = min(abs(last_hh - last_ll) / (C[-1] + EPS) * 10, 10.0) / 10.0
    body_avg_pct = min(float(np.mean(np.abs(C[-20:] - O[-20:])) / atr_abs) / 10.0, 1.0)
    
    # Recompute for signed
    body_atr, upper_atr, lower_atr, tr_atr = _body_parts(O[-1], H[-1], L[-1], C[-1], atr_abs)
    
    dg = dm = 0.0
    if body_atr < 0.03:
        if lower_atr > 4 * upper_atr and lower_atr > 0.4:
            dg = 1.0
        elif upper_atr > 4 * lower_atr and upper_atr > 0.4:
            dm = 1.0
    doji_signed = dg - dm
    doji_flag = 1.0 if body_atr < 0.03 else 0.0
    doji_strength = max(0.0, 1.0 - body_atr / 0.03) if body_atr < 0.03 else 0.0
    
    hammer_flag = 0.0
    if O[-1] != C[-1]:
        body_atr_abs = abs(O[-1] - C[-1]) / atr_abs
        if body_atr < 0.05 and lower_atr >= 4 * max(body_atr, 0.01) and upper_atr < 0.2 * max(body_atr, 0.01):
            hammer_flag = min(1.0, lower_atr / (4 * max(body_atr, 0.01) + EPS))
    
    trend_10 = 0
    if len(C) >= 11:
        returns = np.diff(C[-11:])
        trend = np.sum(returns) / (atr_frac * C[-1] + EPS)
        if trend > 0.5: trend_10 = 1
        elif trend < -0.5: trend_10 = -1
    
    hammer_signed = hammer_flag if trend_10 == -1 else 0.0
    hanging_signed = -hammer_flag if trend_10 == 1 else 0.0
    
    inv_hammer_flag = 0.0
    if O[-1] != C[-1]:
        body_atr_abs = abs(O[-1] - C[-1]) / atr_abs
        if body_atr < 0.05 and upper_atr >= 4 * max(body_atr, 0.01) and lower_atr < 0.2 * max(body_atr, 0.01):
            inv_hammer_flag = min(1.0, upper_atr / (4 * max(body_atr, 0.01) + EPS))
    inv_hammer_signed = inv_hammer_flag if trend_10 == -1 else 0.0
    shooting_signed = -inv_hammer_flag if trend_10 == 1 else 0.0
    
    marubozu_flag = 1.0 if (body_atr > 0.9 and upper_atr < 0.01 and lower_atr < 0.01) else 0.0
    marubozu_signed = marubozu_flag * (1.0 if C[-1] > O[-1] else -1.0)
    
    trend_10 = _is_trending(C, atr_frac, 10)
    vol_ma20 = np.mean(V[-20:]) if len(V) >= 20 else V[-1]
    vol_ratio = V[-1] / max(np.mean(V[-20:]), EPS) if len(V) >= 20 else 1.0
    vol_confirm = vol_ratio > 1.5
    
    atr_short = _atr(H[-10:], L[-10:], C[-10:])
    atr_long = _atr(H[-40:-10], L[-40:-10], C[-40:-10]) if len(C) >= 40 else atr_short
    atr_ratio = atr_short / (atr_long + EPS)
    contraction = max(0.0, 1.0 - atr_ratio)
    expansion = max(0.0, atr_ratio - 1.0)
    swing_span_pct = min(abs(last_hh - last_ll) / (C[-1] + EPS) * 10, 10.0) / 10.0
    body_avg_pct = min(float(np.mean(np.abs(C[-20:] - O[-20:])) / atr_abs) / 10.0, 1.0)
    
    # Recompute dg/dm for signed
    dg = dm = 0.0
    if body_atr < 0.03:
        if lower_atr > 4 * upper_atr and lower_atr > 0.4:
            dg = 1.0
        elif upper_atr > 4 * lower_atr and upper_atr > 0.4:
            dm = 1.0
    doji_signed = dg - dm
    
    vote = (
        0.25 * doji_signed
        + 0.30 * (bull_engulf - bear_engulf)
        + 0.15 * (hammer_signed + hanging_signed + inv_hammer_signed + shooting_signed)
        + 0.10 * (morning_star - evening_star)
        + 0.08 * (three_soldiers - three_crows)
        + 0.05 * (inside_bar - outside_bar)
        + 0.05 * marubozu_signed
        + 0.05 * slope_flip * slope_dir
    )
    
    conf = min(1.0,
        0.20 * doji_flag +
        0.30 * (bull_engulf + bear_engulf) * 0.5 +
        0.15 * (hammer_flag + inv_hammer_flag) +
        0.10 * (morning_star + evening_star) +
        0.08 * (three_soldiers + three_crows) +
        0.05 * (inside_bar + outside_bar) * 0.5 +
        0.05 * marubozu_flag +
        0.05 * slope_flip
    )
    
    signed = {
        "doji": _clamp(doji_signed, 1.0),
        "engulf_bull": min(bull_engulf, 1.0),
        "engulf_bear": min(bear_engulf, 1.0),
        "harami_bull": min(bull_harami := max(0.0, 1.0 - body_c_atr / (0.2 * body_p_atr + EPS)) if (C[-2] > O[-2] and C[-1] < O[-1] and body_c_atr <= 0.25 * body_p_atr) else 0.0, 1.0),
        "harami_bear": min(bear_harami := max(0.0, 1.0 - body_c_atr / (0.2 * body_p_atr + EPS)) if (C[-2] < O[-2] and C[-1] > O[-1] and body_c_atr <= 0.25 * body_p_atr) else 0.0, 1.0),
        "hammer": min(hammer_signed, 1.0),
        "hanging_man": max(hanging_signed, -1.0),
        "inv_hammer": min(inv_hammer_signed, 1.0),
        "shooting_star": max(shooting_signed, -1.0),
        "morning_star": min(morning_star, 1.0),
        "evening_star": max(-evening_star, -1.0),
        "soldiers": min(three_soldiers, 1.0),
        "crows": max(-three_crows, -1.0),
        "tweezer_top": -tweezer_top,
        "tweezer_bottom": tweezer_bottom,
        "inside_bar": inside_bar * 0.5,
        "outside_bar": outside_bar * 0.5,
        "marubozu": _clamp(marubozu_signed, 1.0),
        "slope_flip": slope_flip * slope_dir,
        "hh_bias": hh_bias,
        "ll_bias": ll_bias,
    }
    
    neutral = {
        "doji_strength": min(doji_flag, 1.0),
        "atr_ratio": min(atr_ratio, 2.0),
        "contraction": min(contraction, 1.0),
        "expansion": min(expansion, 1.0),
        "swing_span_pct": swing_span_pct,
        "swing_count": min((hh_count + ll_count) / 10.0, 1.0),
        "body_avg_pct": body_avg_pct,
    }
    
    notes = []
    if doji_flag: notes.append(f"doji {doji_strength:.2f}")
    if bull_engulf > 0.5: notes.append(f"bull_engulf {bull_engulf:.2f}")
    if bear_engulf > 0.5: notes.append(f"bear_engulf {bear_engulf:.2f}")
    if hammer_flag > 0.3: notes.append(f"hammer {hammer_flag:.2f}")
    if morning_star > 0.3: notes.append(f"morning_star {morning_star:.2f}")
    if evening_star > 0.3: notes.append(f"evening_star {evening_star:.2f}")
    if marubozu_flag: notes.append("marubozu")
    if slope_flip: notes.append(f"slope_flip {'up' if slope_dir > 0 else 'down'}")
    if atr_ratio > 1.5: notes.append(f"expansion {atr_ratio:.2f}")
    elif atr_ratio < 0.6: notes.append(f"contraction {atr_ratio:.2f}")
    
    return EngineReport(
        "patterns",
        vote=float(vote),
        confidence=float(conf),
        signed=signed,
        neutral=neutral,
        notes=tuple(notes) if notes else (),
    )