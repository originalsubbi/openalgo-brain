"""Mathematical engine: calculus, linear algebra, trigonometry.

* Calculus  - a local quadratic fit gives price velocity (first derivative) and
              acceleration (second derivative) at the latest bar.
* Linear algebra - an OLS trend by least squares (with its t-statistic) and the
              principal-component share of the underlying against its benchmark.
* Trigonometry - the trend angle, and the slope of the best-fitting sine/cosine
              cycle, which says whether the next bars sit on a rising or falling
              part of the dominant swing.
"""

from __future__ import annotations

import math
from functools import lru_cache

import numpy as np

from services.brain.types import EngineReport, Snapshot

EPS = 1e-12


def _clip(x: float, lim: float) -> float:
    return float(max(-lim, min(lim, x)))


@lru_cache(maxsize=16)
def _rw_weights(window: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return (quadratic slope, quadratic curvature, linear slope) as sd-units.

    Each estimator is linear in the log prices, so under a random walk (where
    price is the running sum of returns) its standard deviation is exactly
    ``sigma * sqrt(sum(g**2))`` for the weight vector ``g`` on the returns. Dividing
    by that makes the statistic ~N(0, 1) on pure noise, which is the property a
    t-statistic on price *levels* lacks (it is wildly inflated for a random walk).
    Returns the three pseudo-inverse rows and their normalisers packed together.
    """
    x = np.arange(window, dtype=float) - (window - 1)
    quad = np.linalg.pinv(np.column_stack([x**2, x, np.ones(window)]))
    lin = np.linalg.pinv(np.column_stack([x, np.ones(window)]))
    rows = (quad[1], 2.0 * quad[0], lin[0])
    out = []
    for c in rows:
        g = np.cumsum(c[::-1])[::-1]  # weight each return carries in the estimator
        out.append(c / math.sqrt(float((g[1:] ** 2).sum())))
    return out[0], out[1], out[2]


def analyze(snap: Snapshot, window: int = 24) -> EngineReport:
    close = snap.bars[:, 4]
    if len(close) < window + 10:
        return EngineReport("math", 0.0, 0.0)
    logc = np.log(close)
    sigma = float(np.std(np.diff(logc[-120:]))) + EPS

    y = logc[-window:]
    x = np.arange(window, dtype=float) - (window - 1)
    c_slope, c_curv, c_lin = _rw_weights(window)
    # --- calculus: derivatives of a local quadratic at the last bar, in noise units
    slope_z = _clip(float(c_slope @ y) / sigma, 6.0)
    curv_z = _clip(float(c_curv @ y) / sigma, 6.0)
    # --- linear algebra: least-squares trend, also normalised against a random walk
    tstat = _clip(float(c_lin @ y) / sigma, 8.0)
    design = np.column_stack([np.ones(window), x])
    coef, *_ = np.linalg.lstsq(design, y, rcond=None)
    resid = y - design @ coef

    pc1_share = 0.5
    rel_beta = 1.0
    bench = snap.bench_close
    if bench is not None and len(bench) >= window + 10:
        n = min(len(bench), len(close), 120)
        r1 = np.diff(np.log(close[-n:]))
        r2 = np.diff(np.log(bench[-n:]))
        m = np.column_stack([r1 - r1.mean(), r2 - r2.mean()])
        cov = (m.T @ m) / max(len(m) - 1, 1)
        # A degenerate/NaN covariance (flat bench, gap in the data) makes
        # eigvalsh raise — the whole engine used to die with it. The benchmark
        # context is an extra; without it the engine falls back to the
        # no-bench defaults.
        try:
            eig = np.linalg.eigvalsh(cov)
            pc1_share = float(eig[-1] / (eig.sum() + EPS))
            rel_beta = float(cov[0, 1] / (cov[1, 1] + EPS))
        except (np.linalg.LinAlgError, ValueError, FloatingPointError):
            pass

    # --- trigonometry: trend angle and the dominant cycle's slope
    angle = math.atan(slope_z) / (math.pi / 2)
    detrended = resid
    best_r2, best_slope = 0.0, 0.0
    var_total = float(detrended @ detrended) + EPS
    for period in range(6, 41, 2):
        w = 2.0 * math.pi / period
        basis = np.column_stack([np.sin(w * x), np.cos(w * x)])
        c, *_ = np.linalg.lstsq(basis, detrended, rcond=None)
        fit = basis @ c
        r2 = 1.0 - float((detrended - fit) @ (detrended - fit)) / var_total
        if r2 > best_r2:
            best_r2, best_slope = r2, float(c[0]) * w  # d/dx of a sin(wx) at 0
    cycle_mom = math.tanh(best_slope / sigma)

    vote = math.tanh(0.55 * slope_z + 0.2 * curv_z)
    agree_curv = 1.0 if slope_z * curv_z >= 0 else 0.7
    conf = min(1.0, abs(tstat) / 3.0) * agree_curv
    return EngineReport(
        "math",
        vote=float(vote),
        confidence=float(conf),
        signed={
            "slope_z": slope_z / 3.0,
            "curv_z": curv_z / 3.0,
            "trend_angle": float(angle),
            "trend_tstat": tstat / 3.0,
            "cycle_mom": float(cycle_mom),
        },
        neutral={
            "cycle_r2": float(best_r2),
            "pc1_share": pc1_share,
            "rel_beta": _clip(rel_beta, 3.0),
        },
        notes=(f"t={tstat:.1f}", f"angle={angle:+.2f}"),
    )
