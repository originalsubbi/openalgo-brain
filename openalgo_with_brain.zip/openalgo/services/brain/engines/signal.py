"""Signal engine: Fourier, wavelets, Kalman filter, entropy.

Answers two questions the price alone cannot: *is there a signal here at all*
(entropy, spectral flatness, how much energy sits in the slow wavelet scales)
and *what is its direction once noise is filtered out* (Kalman velocity,
wavelet-denoised slope).
"""

from __future__ import annotations

import math
from functools import lru_cache

import numpy as np

from services.brain.types import EngineReport, Snapshot

EPS = 1e-12
_PERMS = {
    p: i for i, p in enumerate([(0, 1, 2), (0, 2, 1), (1, 0, 2), (1, 2, 0), (2, 0, 1), (2, 1, 0)])
}


def _clip(x: float, lim: float) -> float:
    return float(max(-lim, min(lim, x)))


def spectrum(logc: np.ndarray) -> tuple[float, float, float]:
    """Dominant period (bars), spectral flatness (1 = white noise), low-frequency share."""
    n = len(logc)
    t = np.arange(n, dtype=float)
    slope, icpt = np.polyfit(t, logc, 1)
    resid = (logc - (slope * t + icpt)) * np.hanning(n)
    power = np.abs(np.fft.rfft(resid)) ** 2
    power = power[1:] + EPS
    period = n / (int(np.argmax(power)) + 1)
    flat = float(np.exp(np.mean(np.log(power))) / np.mean(power))
    low = float(power[:3].sum() / power.sum())
    return float(period), flat, low


def haar_denoise(x: np.ndarray, levels: int = 3) -> tuple[np.ndarray, float]:
    """Haar wavelet decomposition; returns the approximation-only signal and the
    share of detail energy sitting in the finest (noisiest) scale."""
    n = 1 << int(math.floor(math.log2(len(x))))
    seg = np.asarray(x[-n:], dtype=float)
    mean = seg.mean()
    a = seg - mean
    details = []
    for _ in range(levels):
        if len(a) < 2:
            break
        d = (a[0::2] - a[1::2]) / math.sqrt(2.0)
        a = (a[0::2] + a[1::2]) / math.sqrt(2.0)
        details.append(d)
    energy = [float(d @ d) for d in details]
    fine_share = energy[0] / (sum(energy) + EPS) if energy else 1.0
    for _ in details:  # inverse transform with every detail zeroed
        up = np.empty(len(a) * 2)
        up[0::2] = a / math.sqrt(2.0)
        up[1::2] = a / math.sqrt(2.0)
        a = up
    return a + mean, float(fine_share)


def kalman_trend(logc: np.ndarray) -> tuple[float, float, float]:
    """Local linear trend filter. Returns (velocity per bar, velocity std, last innovation z)."""
    r = np.diff(logc)
    s2 = float(np.var(r)) + EPS
    F = np.array([[1.0, 1.0], [0.0, 1.0]])
    H = np.array([1.0, 0.0])
    Q = np.array([[0.05 * s2, 0.0], [0.0, 0.002 * s2]])
    R = 0.5 * s2
    x = np.array([logc[0], 0.0])
    P = np.eye(2) * s2 * 10.0
    innov_z = 0.0
    for z in logc[1:]:
        x = F @ x
        P = F @ P @ F.T + Q
        S = float(H @ P @ H) + R
        K = (P @ H) / S
        innov = float(z - H @ x)
        innov_z = innov / math.sqrt(S)
        x = x + K * innov
        P = (np.eye(2) - np.outer(K, H)) @ P
    return float(x[1]), math.sqrt(max(float(P[1, 1]), EPS)), float(innov_z)


def permutation_entropy(r: np.ndarray) -> float:
    """Normalised order-3 permutation entropy: ~1 for noise, lower when ordered."""
    if len(r) < 20:
        return 1.0
    counts = np.zeros(6)
    for i in range(len(r) - 2):
        counts[_PERMS[tuple(int(k) for k in np.argsort(r[i : i + 3], kind="stable"))]] += 1
    p = counts / counts.sum()
    p = p[p > 0]
    return float(-(p * np.log(p)).sum() / math.log(6))


def shannon_entropy(r: np.ndarray, bins: int = 10) -> float:
    hist, _ = np.histogram(r, bins=bins)
    p = hist[hist > 0] / hist.sum()
    return float(-(p * np.log(p)).sum() / math.log(bins))


@lru_cache(maxsize=4)
def _null_scale(n_kal: int = 96, n_wav: int = 64) -> tuple[float, float]:
    """sd of the Kalman velocity and wavelet slope statistics on pure random walks.

    Both filters smooth, so their raw outputs are not unit-variance on noise.
    Measuring that once, with a fixed seed, lets the engine report each as a
    z-score that is ~0 for a market with no trend. Cached for the process.
    """
    rng = np.random.default_rng(424242)
    kal, wav = [], []
    for _ in range(120):
        r = rng.standard_normal(max(n_kal, n_wav)) * 0.001
        lc = np.cumsum(r)
        sd = float(np.std(np.diff(lc))) + EPS
        kal.append(kalman_trend(lc[-n_kal:])[0] / sd)
        d, _ = haar_denoise(lc[-n_wav:])
        wav.append((d[-1] - d[-9]) / (8 * sd))
    return float(np.std(kal)) + EPS, float(np.std(wav)) + EPS


def analyze(snap: Snapshot) -> EngineReport:
    close = snap.bars[:, 4]
    if len(close) < 70:
        return EngineReport("signal", 0.0, 0.0)
    logc = np.log(close)
    r = np.diff(logc[-128:])
    sigma = float(np.std(r)) + EPS

    period, flat, low_share = spectrum(logc[-64:])
    denoised, fine_share = haar_denoise(logc[-64:])
    null_kal, null_wav = _null_scale()
    wave_slope_z = _clip((denoised[-1] - denoised[-9]) / (8 * sigma) / null_wav, 6.0)
    vel, _vel_sd, innov_z = kalman_trend(logc[-96:])
    kal_z = _clip(vel / sigma / null_kal, 8.0)
    pe = permutation_entropy(r[-80:])
    se = shannon_entropy(r[-80:])

    predictability = float(np.clip((0.98 - pe) / 0.2, 0.0, 1.0))
    vote = math.tanh(0.3 * kal_z + 0.3 * wave_slope_z)
    conf = float(np.clip(0.6 * predictability + 0.4 * (1.0 - fine_share), 0.0, 1.0))
    return EngineReport(
        "signal",
        vote=float(vote),
        confidence=conf,
        signed={
            "kalman_vel_z": kal_z / 4.0,
            "wavelet_slope_z": wave_slope_z / 3.0,
            "kalman_innov": _clip(innov_z, 4.0) / 2.0,
        },
        neutral={
            "perm_entropy": pe,
            "shannon_entropy": se,
            "spec_flatness": flat,
            "lowfreq_share": low_share,
            "wavelet_noise_share": fine_share,
            "dom_period": min(period, 64.0) / 64.0,
        },
        notes=(f"perm_entropy={pe:.2f}", f"period={period:.0f} bars"),
    )
