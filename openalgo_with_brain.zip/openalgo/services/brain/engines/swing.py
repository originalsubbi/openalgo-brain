"""Swing trading engine for the AI Brain.

Trades on daily timeframe with 1-10 day hold periods.
Uses trend following with pullback entries.

Aggregates 1m bars to daily bars internally, then applies swing logic.

Features:
- Trend detection: EMA(20) > EMA(50) > EMA(200) for uptrend, reverse for downtrend
- Entry: Pullback to EMA(20) in trending market, or breakout above/below swing highs/lows
- Exit: Trail stop below swing low (long) / above swing high (short), or target at next level
- Position sizing: Smaller than intraday (wider stops = smaller size)
"""

from __future__ import annotations

import numpy as np
from datetime import datetime, timezone, timedelta

from services.brain.types import EngineReport, Snapshot, param

IST = timezone(timedelta(hours=5, minutes=30))


def _is_daily_bar_complete(daily_bars: np.ndarray, snap_ts: float) -> bool:
    """Return True if the last aggregated daily bar is almost certainly complete.

    A daily bar built from today's intraday bars is still forming while the
    market is open; basing a signal on it would mean reacting to noise that
    can still reverse before the session ends. We treat the bar as complete
    when its date (IST) differs from the snapshot's current date.
    """
    if len(daily_bars) == 0:
        return False
    last_bar_ts = float(daily_bars[-1, 0])
    return int((last_bar_ts + 19800) // 86400) != int((snap_ts + 19800) // 86400)

IST_OFFSET = 19800  # seconds, UTC+05:30
EPS = 1e-12


def _ema(values: np.ndarray, period: int) -> np.ndarray:
    """Exponential moving average."""
    if len(values) < 2:
        return np.full_like(values, np.nan, dtype=float)
    alpha = 2.0 / (period + 1.0)
    out = np.empty_like(values, dtype=float)
    out[0] = values[0]
    for i in range(1, len(values)):
        out[i] = alpha * values[i] + (1.0 - alpha) * out[i - 1]
    return out


def _atr(high: np.ndarray, low: np.ndarray, close: np.ndarray, n: int = 14) -> float:
    """Average True Range as absolute value."""
    prev = close[:-1]
    tr = np.maximum.reduce([high[1:] - low[1:], np.abs(high[1:] - prev), np.abs(low[1:] - prev)])
    if len(tr) < n:
        return float(np.mean(tr)) if len(tr) else 0.0
    return float(np.mean(tr[-n:]))


def _find_swing_lows(lows: np.ndarray, window: int = 5) -> list[float]:
    """Find swing lows (local minima)."""
    swings = []
    for i in range(window, len(lows) - window):
        if lows[i] <= lows[i - window : i + window + 1].min():
            swings.append(float(lows[i]))
    return swings


def _find_swing_highs(highs: np.ndarray, window: int = 5) -> list[float]:
    """Find swing highs (local maxima)."""
    swings = []
    for i in range(window, len(highs) - window):
        if highs[i] >= highs[i - window : i + window + 1].max():
            swings.append(float(highs[i]))
    return swings


def _clamp(x: float, lim: float = 1.0) -> float:
    return float(max(-lim, min(lim, x)))


def _aggregate_1m_to_daily(bars: np.ndarray) -> np.ndarray:
    """Aggregate intraday bars to daily OHLCV bars.

    Input: (n, 6) array of [ts, open, high, low, close, volume]
    Output: (m, 6) array of daily OHLCV bars

    Days are IST days. A UTC day boundary would cut the Indian session (09:15
    to 15:30 IST is 03:45 to 10:00 UTC, so it happens to sit inside one UTC
    day) differently from anything the market recognises, and would split a
    session that runs past 19:00 UTC.
    """
    if len(bars) == 0:
        return bars

    ts = bars[:, 0]
    # Group by IST day
    dates = ((ts + IST_OFFSET) // 86400).astype(int)

    daily_rows = []
    for day in np.unique(dates):
        mask = dates == day
        day_bars = bars[mask]
        if len(day_bars) == 0:
            continue
        daily_rows.append([
            day_bars[0, 0],      # timestamp of first bar of day
            day_bars[0, 1],      # open = first open
            day_bars[:, 2].max(),  # high = max high
            day_bars[:, 3].min(),  # low = min low
            day_bars[-1, 4],     # close = last close
            day_bars[:, 5].sum(), # volume = sum volume
        ])

    if len(daily_rows) == 0:
        return np.empty((0, 6))

    return np.array(daily_rows)


def analyze(snap: Snapshot) -> EngineReport:
    """Swing trading engine using daily bars aggregated from 1m data.

    Detects trend direction and enters on pullbacks to EMA(20).
    """
    # Aggregate 1m bars to daily bars
    daily_bars = _aggregate_1m_to_daily(snap.bars)

    if len(daily_bars) < 60:
        return EngineReport("swing", 0.0, 0.0)

    o, h, l, c, v = daily_bars[:, 1], daily_bars[:, 2], daily_bars[:, 3], daily_bars[:, 4], daily_bars[:, 5]

    # Calculate EMAs
    ema_20 = _ema(c, 20)
    ema_50 = _ema(c, 50)
    ema_200 = _ema(c, 200)

    # Today's daily bar may still be forming; exclude it from signal conditions
    # so the engine never reacts to intraday noise that can reverse before
    # the session ends. Use the last *completed* day's values for decisions.
    _complete = _is_daily_bar_complete(daily_bars, snap.ts)
    sig_c = c[:-1] if not _complete else c
    sig_o = o[:-1] if not _complete else o
    sig_h = h[:-1] if not _complete else h
    sig_l = l[:-1] if not _complete else l
    sig_ema20 = ema_20[:-1] if not _complete else ema_20
    sig_ema50 = ema_50[:-1] if not _complete else ema_50
    sig_ema200 = ema_200[:-1] if not _complete else ema_200

    if len(sig_c) == 0:
        return EngineReport("swing", 0.0, 0.0, neutral={"swing_available": 0.0})

    curr_close = float(sig_c[-1])
    curr_open = float(sig_o[-1])
    curr_high = float(sig_h[-1])
    curr_low = float(sig_l[-1])
    curr_ema_20 = float(sig_ema20[-1])
    curr_ema_50 = float(sig_ema50[-1])
    curr_ema_200 = float(sig_ema200[-1])

    atr = _atr(sig_h, sig_l, sig_c, 14)
    atr_pct = atr / curr_close if curr_close > 0 else 0.0

    # Trend determination
    uptrend = bool(curr_close > curr_ema_20 > curr_ema_50 > curr_ema_200)
    downtrend = bool(curr_close < curr_ema_20 < curr_ema_50 < curr_ema_200)

    # Pullback detection
    bullish_pullback = bool(
        uptrend
        and curr_low <= curr_ema_20 * 1.005
        and curr_close > curr_ema_20
        and curr_close > curr_open
    )

    bearish_pullback = bool(
        downtrend
        and curr_high >= curr_ema_20 * 0.995
        and curr_close < curr_ema_20
        and curr_close < curr_open
    )

    # Swing points for stop placement (use only completed bars)
    swing_lows = _find_swing_lows(sig_l, 5)
    swing_highs = _find_swing_highs(sig_h, 5)

    vote = 0.0
    confidence = 0.0

    if bullish_pullback:
        dist_to_ema = abs(curr_close - curr_ema_20) / curr_ema_20 if curr_ema_20 > 0 else 0.0
        trend_strength = min((curr_ema_20 - curr_ema_50) / curr_ema_50 * 100, 1.0) if curr_ema_50 > 0 else 0.0
        vote = 0.55 + trend_strength * 0.35
        confidence = min(0.85, 0.5 + trend_strength * 0.25)

    elif bearish_pullback:
        dist_to_ema = abs(curr_close - curr_ema_20) / curr_ema_20 if curr_ema_20 > 0 else 0.0
        trend_strength = min((curr_ema_50 - curr_ema_20) / curr_ema_50 * 100, 1.0) if curr_ema_50 > 0 else 0.0
        vote = -(0.55 + trend_strength * 0.35)
        confidence = min(0.85, 0.5 + trend_strength * 0.25)

    if swing_highs and curr_close > swing_highs[-1] and uptrend:
        vote = max(vote, 0.75)
        confidence = max(confidence, 0.75)

    if swing_lows and curr_close < swing_lows[-1] and downtrend:
        vote = min(vote, -0.75)
        confidence = max(confidence, 0.75)

    neutral = {
        "swing_trend_strength": min(abs(curr_ema_20 - curr_ema_50) / curr_ema_50 * 10, 1.0) if curr_ema_50 > 0 else 0.0,
        "swing_atr_pct": min(atr_pct * 100, 1.0),
        "swing_ema_distance": min(abs(curr_close - curr_ema_20) / curr_ema_20 * 10, 1.0) if curr_ema_20 > 0 else 0.0,
    }

    notes = []
    if bullish_pullback:
        notes.append("swing_bullish_pullback")
    if bearish_pullback:
        notes.append("swing_bearish_pullback")
    if swing_highs and curr_close > swing_highs[-1] and uptrend:
        notes.append("swing_breakout_high")
    if swing_lows and curr_close < swing_lows[-1] and downtrend:
        notes.append("swing_breakout_low")

    # The swing geometry the tunable stop/target multiples describe: a stop
    # ``swing_k_stop`` ATRs below the entry and a target ``swing_k_target`` ATRs
    # above it, on a daily bar. These are the numbers a swing position would be
    # managed with, so they are computed here rather than hard-coded.
    k_stop = param(snap, "swing_k_stop", 2.0)
    k_target = param(snap, "swing_k_target", 3.0)
    atr = atr_pct * curr_close if curr_close > 0 else 0.0
    extras = {
        "swing_atr": float(atr),
        "swing_stop_distance": float(atr * k_stop),
        "swing_target_distance": float(atr * k_target),
        "swing_k_stop": float(k_stop),
        "swing_k_target": float(k_target),
    }

    return EngineReport(
        "swing",
        vote=_clamp(vote, 1.0),
        confidence=float(confidence),
        signed={
            "swing_trend": float(_clamp(vote, 1.0)),
            "swing_ema_distance": min(abs(curr_close - curr_ema_20) / curr_ema_20 * 10, 1.0) if curr_ema_20 > 0 else 0.0,
        },
        neutral=neutral,
        notes=tuple(notes),
        extras=extras,
    )