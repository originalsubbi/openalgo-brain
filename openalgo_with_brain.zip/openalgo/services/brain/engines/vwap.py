"""VWAP engine: Volume Weighted Average Price with pullback entries.

Reads intraday bars and computes VWAP, then signals:

* **VWAP deviation** — how far spot is from VWAP (in % and ATR units).
  * Price above VWAP = bullish bias; below VWAP = bearish bias.
  * Extreme deviation (> 2 ATR) = mean-reversion candidate (fade the extreme).
* **VWAP pullback** — in a trending market, price returns to VWAP = high-probability entry.
  * Uptrend + price at/below VWAP = bullish pullback (buy).
  * Downtrend + price at/above VWAP = bearish pullback (sell/buy put).
* **VWAP cross** — price crosses VWAP = trend change signal.

VWAP is computed as typical_price * volume cumulative / volume cumulative,
reset at session start (09:15 IST). With no volume data (index feeds), falls
back to close-price weighting.

With fewer than 20 bars the engine abstains.
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np

from services.brain.types import EngineReport, Snapshot, param, session_slice

EPS = 1e-12


def _vwap(bars: np.ndarray) -> tuple[float, float]:
    """Return (vwap, deviation_pct) for the last bar of ``bars``.

    Typical price = (high + low + close) / 3.
    VWAP = sum(typical * volume) / sum(volume).
    If volume is zero/absent, falls back to typical price average.

    The caller passes the current session's bars only, so the average is
    anchored at the open. A cumulative average over the whole fetched window
    would be a multi-day mean price, not an intraday benchmark, and the
    "deviation from VWAP" reading would be meaningless against it.
    """
    o, h, lo, c, v = bars[:, 1], bars[:, 2], bars[:, 3], bars[:, 4], bars[:, 5]
    tp = (h + lo + c) / 3.0
    vol = np.maximum(v, 1.0)  # avoid div by zero
    cum_tpv = np.cumsum(tp * vol)
    cum_v = np.cumsum(vol)
    vwap = cum_tpv / cum_v
    last_vwap = float(vwap[-1])
    last_close = float(c[-1])
    dev_pct = (last_close - last_vwap) / last_vwap if last_vwap > 0 else 0.0
    return last_vwap, dev_pct


def _atr(high: np.ndarray, low: np.ndarray, close: np.ndarray, n: int = 14) -> float:
    """The average true range, in price points.

    It used to be divided by the last close on the way out, which made it a
    percentage, and the engine then divided a *price* deviation by it. The
    "2 ATR" overextension trigger therefore fired at a deviation of a fraction
    of a percent, and the VWAP mean-reversion reading was on all the time.
    """
    prev = close[:-1]
    tr = np.maximum.reduce(
        [high[1:] - low[1:], np.abs(high[1:] - prev), np.abs(low[1:] - prev)]
    )
    if len(tr) < n:
        return float(np.mean(tr)) if len(tr) else 0.0
    val = float(np.mean(tr[:n]))
    for x in tr[n:]:
        val = (val * (n - 1) + x) / n
    return val


def _math_tanh(x: float) -> float:
    import math
    return math.tanh(x)


def analyze(snap) -> EngineReport:
    """VWAP engine: deviation, pullback, cross signals.

    The thresholds it works to (``vwap_dev_atr`` for the overextension trigger,
    ``vwap_pullback_atr`` for what counts as "at" VWAP) are tunable and read
    from the live parameters, so a slider moved in the UI reaches this engine.
    """
    b = snap.bars
    if len(b) < 20:
        return EngineReport("vwap", 0.0, 0.0, neutral={"vwap_available": 0.0})

    # Only the current session: VWAP is anchored at the open, so yesterday's
    # bars must not be in the average.
    sess = session_slice(b)
    if len(sess) < 5:
        return EngineReport("vwap", 0.0, 0.0, neutral={"vwap_available": 0.0})

    dev_atr_mult = param(snap, "vwap_dev_atr", 2.0)
    pullback_atr = param(snap, "vwap_pullback_atr", 0.5)

    o, h, lo, c, v = sess[:, 1], sess[:, 2], sess[:, 3], sess[:, 4], sess[:, 5]
    spot = float(c[-1])

    vwap, dev_pct = _vwap(sess)
    atr_abs = _atr(h, lo, c)
    dev_atr = (spot - vwap) / atr_abs if atr_abs > 0 else 0.0

    # ---- trend context -------------------------------------------------------
    # short EMA vs longer EMA for trend direction. The long EMA needs a full
    # 21 session bars: below that it degrades to the spot itself, which read
    # every rising morning as a downtrend (e9 > spot is impossible) at full
    # confidence. No session history yet → no trend opinion.
    if len(c) >= 21:
        e9 = float(np.mean(c[-9:]))
        e21 = float(np.mean(c[-21:]))
        trend = 1.0 if e9 > e21 else -1.0  # +1 uptrend, -1 downtrend
    else:
        e9 = e21 = spot
        trend = 0.0

    # ---- signals -------------------------------------------------------------
    vote = 0.0
    notes = []

    # 1) Extreme deviation = mean reversion (fade the extreme)
    #    Price > VWAP + N ATR = overextended long -> bearish (fade)
    #    Price < VWAP - N ATR = overextended short -> bullish (fade)
    if dev_atr > dev_atr_mult:
        mean_rev = -_math_tanh((dev_atr - dev_atr_mult) / 2.0)  # bearish when overextended long
        vote += 0.25 * mean_rev
        notes.append(f"vwap_extreme_bearish={dev_atr:+.1f}ATR")
    elif dev_atr < -dev_atr_mult:
        mean_rev = _math_tanh((-dev_atr - dev_atr_mult) / 2.0)  # bullish when overextended short
        vote += 0.25 * mean_rev
        notes.append(f"vwap_extreme_bullish={dev_atr:+.1f}ATR")

    # 2) VWAP pullback in trend = high-probability entry
    #    Uptrend + price at/below VWAP = bullish pullback
    #    Downtrend + price at/above VWAP = bearish pullback
    at_vwap = abs(dev_atr) <= pullback_atr  # within N ATR of VWAP = "at" VWAP
    if trend > 0 and at_vwap and spot <= vwap * 1.002:
        # uptrend pullback to VWAP = bullish
        pullback = _math_tanh((pullback_atr - abs(dev_atr)) / max(pullback_atr, 1e-6))
        vote += 0.35 * pullback
        notes.append("vwap_bullish_pullback")
    elif trend < 0 and at_vwap and spot >= vwap * 0.998:
        # downtrend pullback to VWAP = bearish
        pullback = _math_tanh((pullback_atr - abs(dev_atr)) / max(pullback_atr, 1e-6))
        vote -= 0.35 * pullback
        notes.append("vwap_bearish_pullback")

    # 3) VWAP cross — price just crossed VWAP
    if len(c) >= 2:
        prev_close = float(c[-2])
        prev_vwap = _vwap(sess[:-1])[0] if len(sess) > 1 else vwap
        crossed_up = prev_close <= prev_vwap and spot > vwap
        crossed_down = prev_close >= prev_vwap and spot < vwap
        if crossed_up:
            vote += 0.20
            notes.append("vwap_cross_up")
        elif crossed_down:
            vote -= 0.20
            notes.append("vwap_cross_down")

    vote = _math_tanh(vote)

    # confidence: higher when VWAP is well-defined (volume present) and trend is clear
    has_vol = float(np.sum(v > 0)) / len(v) if len(v) > 0 else 0.0
    conf = min(1.0, 0.4 + 0.3 * has_vol + 0.3 * abs(trend))

    signed = {
        "vwap_dev_atr": dev_atr,
        "vwap_dev_pct": dev_pct * 100.0,
        "vwap_trend": float(trend),
    }
    neutral = {
        "vwap_available": 1.0,
        "vwap_vwap": vwap,
        "vwap_dev_atr_abs": abs(dev_atr),
        "vwap_e9": e9,
        "vwap_e21": e21,
        "vwap_vol_ratio": has_vol,
    }

    return EngineReport(
        "vwap",
        vote=float(vote),
        confidence=float(conf),
        signed=signed,
        neutral=neutral,
        notes=tuple(notes),
    )


__all__ = ["analyze", "_vwap", "_atr", "_math_tanh"]
