"""ML engine: online classification, probability calibration, drift detection.

A deliberately small model, because the sample is small. An online logistic
regression with L2 shrinkage learns ``P(target before stop | features, side)``
from triple-barrier labels. Platt scaling then calibrates its output on
out-of-sample pairs, and the population stability index (PSI) of each feature
tells the learner when today's market no longer looks like the training data.

Pure numpy, no scikit-learn, fully serialisable to JSON so a model version can
be stored, compared, promoted and rolled back.
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np

EPS = 1e-9
LEGACY_EPOCHS = 3  # models saved before ``n_rows`` existed were always fitted for 3 epochs
LEGACY_OVERLAP = 12.0  # ...and their label overlap is unknown: assume the most overlapped case


# --- interaction features ----------------------------------------------------
# Cross-engine products the linear model could otherwise never express: an
# engine's vote is only informative when another engine's context agrees with
# it. They are computed here, at model time, from the stored base feature dict
# (the one ``fusion.build_features`` produced) rather than inside
# ``build_features`` itself. Journal rows written before they existed therefore
# train and score consistently -- ``vector`` recomputes them from the base keys
# on every fit and every prediction.
INTERACTION_NAMES: list[str] = [
    "int.slope_range",  # math.slope_z x orb.orb_range_atr: trend with an expanding range
    "int.vwap_fused",  # vwap.vwap_dev_atr x fused: VWAP aligned with the consensus side
    "int.ivr_pcr",  # options.iv_rank x options.pcr_tilt: the options edge by IV regime
    "int.os_ivr",  # option_selling.os_iv_rank x os_sell_strength: selling premium by IV regime
    "int.agree_strength",  # agree_frac x |fused|: how hard the agreeing engines point
    "int.trend_fused",  # regime.trend x fused: consensus is worth more in a trend
]


def model_names(base_names: list[str]) -> list[str]:
    """The feature names a model should carry: the base set plus the interactions."""
    return list(base_names) + [n for n in INTERACTION_NAMES if n not in base_names]


def augment_features(feats: dict[str, float]) -> dict[str, float]:
    """Add the interaction features to a base feature dict (missing keys read as 0)."""
    out = dict(feats)
    fused = float(out.get("fused", 0.0))
    out["int.slope_range"] = float(out.get("math.slope_z", 0.0)) * float(
        out.get("orb.orb_range_atr", 0.0)
    )
    out["int.vwap_fused"] = float(out.get("vwap.vwap_dev_atr", 0.0)) * fused
    out["int.ivr_pcr"] = float(out.get("options.iv_rank", 0.0)) * float(
        out.get("options.pcr_tilt", 0.0)
    )
    out["int.os_ivr"] = float(out.get("option_selling.os_iv_rank", 0.0)) * float(
        out.get("option_selling.os_sell_strength", 0.0)
    )
    out["int.agree_strength"] = float(out.get("agree_frac", 0.0)) * abs(fused)
    out["int.trend_fused"] = float(out.get("regime.trend", 0.0)) * fused
    return out


#: Lifetime rows fitted before the standardisation switches to exponential weighting.
WARMUP_ROWS = 200
#: Per-row decay of the standardisation: an observation ~200 rows back still carries weight ~1/e.
EW_DECAY = 0.995
#: Per-row decay of the update counter that drives the learning step (same memory horizon).
RECENT_DECAY = 0.995
#: The learning step never falls below this share of the base learning rate.
STEP_FLOOR = 0.2


def effective_sample_size(starts, spans) -> float:
    """Number of independent samples hiding in rows whose label windows overlap.

    Each row's label looks ``spans[i]`` bars ahead from bar ``starts[i]``. Two rows whose
    windows share bars carry the same future, so they are not two observations. The
    average-uniqueness estimate (Lopez de Prado, *Advances in Financial Machine Learning*,
    ch. 4) weights every row by the mean of ``1 / concurrency`` over the bars of its own
    window and sums those weights. Non-overlapping rows count one each; ``k`` rows that
    all cover the same window count as one between them.
    """
    s = np.asarray(starts, dtype=np.int64)
    if s.size == 0:
        return 0.0
    w = np.maximum(np.asarray(spans, dtype=np.int64), 1)
    # Squeeze long gaps (nights, weekends) down to the longest window: overlap only exists
    # between starts closer than a window, so the answer is unchanged and the grid stays small.
    uniq = np.unique(s)
    cap = int(w.max())
    gaps = np.minimum(np.diff(uniq), cap)
    coord = np.concatenate([[0], np.cumsum(gaps)])
    s2 = coord[np.searchsorted(uniq, s)]
    e2 = s2 + w
    size = int(e2.max()) + 1
    diff = np.zeros(size + 1)
    np.add.at(diff, s2, 1.0)
    np.add.at(diff, e2, -1.0)
    conc = np.cumsum(diff)[:size]
    inv = np.where(conc > 0, 1.0 / np.maximum(conc, 1.0), 0.0)
    pref = np.concatenate([[0.0], np.cumsum(inv)])
    uniqueness = (pref[e2] - pref[s2]) / w
    return float(uniqueness.sum())


def sigmoid(z: np.ndarray | float) -> np.ndarray | float:
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30.0, 30.0)))


class OnlineLogit:
    """Logistic regression with running standardisation and decaying step size."""

    def __init__(self, names: list[str], l2: float = 0.02, lr: float = 0.08) -> None:
        self.names = list(names)
        d = len(names)
        self.w = np.zeros(d)
        self.b = 0.0
        self.mean = np.zeros(d)
        self.m2 = np.ones(d)
        # ``n`` counts optimiser *updates* (one per row per epoch). It drives the step-size
        # decay and the running standardisation and nothing else. How much the model is
        # believed is ``credibility_n``, built from ``n_rows`` and ``n_eff`` below.
        self.n = 0
        self.n_rows = 0  # distinct rows the model was fitted on
        self.n_eff: float | None = None  # rows after discounting overlapping labels
        self.ew_n = 0.0  # decayed weight mass behind the standardisation (0 = still warming up)
        self.n_recent = 0.0  # decayed update counter that drives the learning step
        self.l2 = l2
        self.lr = lr
        self.platt_a = 1.0  # calibrated p = sigmoid(a * logit + c)
        self.platt_c = 0.0
        self.base_rate = 0.5  # running win rate, anchors the intercept

    # --- standardisation (Welford warm-up, then exponentially weighted) ----------
    # Lifetime averages never forget: feature scales measured in 2023 would
    # permanently distort the normalisation of 2026 data. The first WARMUP_ROWS
    # observations use the plain Welford estimator (exact, and identical to the
    # historical behaviour); after that both the mean and the variance decay
    # with EW_DECAY per row, so the standardisation tracks the recent regime.
    def _observe(self, x: np.ndarray) -> None:
        self.n += 1
        delta = x - self.mean
        if self.n < WARMUP_ROWS:
            self.mean = self.mean + delta / self.n
            self.m2 = self.m2 + delta * (x - self.mean)
            return
        if self.ew_n <= 0.0:  # first row past the warm-up: carry the Welford mass across
            self.ew_n = float(self.n)
        self.ew_n = EW_DECAY * self.ew_n + 1.0
        self.mean = self.mean + delta / self.ew_n
        self.m2 = EW_DECAY * self.m2 + delta * (x - self.mean)

    def _std(self) -> np.ndarray:
        if self.n < 2:
            return np.ones_like(self.mean)
        if self.n < WARMUP_ROWS:
            denom = float(self.n - 1)
        else:
            denom = max(self.ew_n - 1.0, 2.0)
        return np.sqrt(np.maximum(self.m2 / denom, 1e-6))

    def _z(self, x: np.ndarray) -> np.ndarray:
        return np.clip((x - self.mean) / self._std(), -5.0, 5.0)

    @property
    def credibility_n(self) -> float:
        """The sample size to weigh this model against the prior with.

        Distinct rows with overlapping labels discounted, never the number of optimiser
        updates: three epochs over 150 rows is still 150 rows, and 150 rows whose labels
        each span 12 bars of a 3-bar stride hold about a quarter of that in independent
        information.
        """
        if self.n_eff is not None:
            return float(self.n_eff)
        return float(self.n_rows)

    def vector(self, feats: dict[str, float]) -> np.ndarray:
        full = augment_features(feats)
        return np.array([float(full.get(k, 0.0)) for k in self.names])

    # --- inference
    def raw_logit(self, feats: dict[str, float]) -> float:
        x = self.vector(feats)
        return float(self.b + self.w @ self._z(x))

    def predict(self, feats: dict[str, float]) -> float:
        z = self.raw_logit(feats)
        if not math.isfinite(z):
            # A non-finite logit (corrupt feature row) is no opinion at all:
            # 0.5 keeps the caller's blending honest instead of letting a NaN
            # vote past every ``<`` gate downstream.
            return 0.5
        return float(sigmoid(self.platt_a * z + self.platt_c))

    # --- learning
    def partial_fit(self, feats: dict[str, float], y: float, weight: float = 1.0) -> None:
        x = self.vector(feats)
        # A single NaN/inf feature row would update w and b with NaN — and a
        # NaN weight is permanent: every future prediction is NaN and every
        # persisted version is poisoned until the model is reset by hand.
        # Skip the row instead. (predict() gets the same guard downstream.)
        if not (np.isfinite(x).all() and math.isfinite(float(y)) and math.isfinite(float(weight))):
            self.n_skipped_nan = getattr(self, "n_skipped_nan", 0) + 1
            return
        self._observe(x)
        zx = self._z(x)
        p = float(sigmoid(self.b + self.w @ zx))
        # The step decays with *recent* updates, not lifetime ones: a few thousand
        # historical rows must not leave the model unable to react when the regime
        # changes. ``n_recent`` saturates near 1/(1 - RECENT_DECAY) rows of memory,
        # and the floor keeps a minimum learning rate forever.
        self.n_recent = RECENT_DECAY * self.n_recent + 1.0
        step = max(
            self.lr / math.sqrt(1.0 + self.n_recent / 200.0),
            STEP_FLOOR * self.lr,
        )
        grad = (p - y) * weight
        self.w = self.w - step * (grad * zx + self.l2 * self.w)
        self.b = self.b - step * grad
        self.base_rate += (y - self.base_rate) / min(self.n, 500)

    def fit_batch(
        self, rows: list[dict[str, float]], ys: list[float], epochs: int = 3, seed: int = 7
    ) -> None:
        rng = np.random.default_rng(seed)
        idx = np.arange(len(rows))
        self.n_rows += len(rows)
        for _ in range(epochs):
            rng.shuffle(idx)
            for i in idx:
                self.partial_fit(rows[i], ys[i])

    def calibrate(self, rows: list[dict[str, float]], ys: list[float], iters: int = 40) -> None:
        """Platt scaling on held-out pairs by Newton's method on two parameters."""
        if len(rows) < 30 or len(set(ys)) < 2:
            return
        z = np.array([self.raw_logit(r) for r in rows])
        y = np.array(ys, dtype=float)
        a, c = 1.0, 0.0
        for _ in range(iters):
            p = sigmoid(a * z + c)
            g = np.array([((p - y) * z).sum(), (p - y).sum()]) + np.array([1e-3 * (a - 1.0), 0.0])
            wgt = p * (1 - p) + EPS
            H = np.array(
                [[(wgt * z * z).sum() + 1e-3, (wgt * z).sum()], [(wgt * z).sum(), wgt.sum()]]
            )
            try:
                step = np.linalg.solve(H, g)
            except np.linalg.LinAlgError:
                break
            a, c = a - step[0], c - step[1]
            if float(np.abs(step).max()) < 1e-6:
                break
        self.platt_a, self.platt_c = float(np.clip(a, 0.1, 3.0)), float(np.clip(c, -2.0, 2.0))

    def explain(self, feats: dict[str, float], top: int = 3) -> list[tuple[str, float]]:
        contrib = self.w * self._z(self.vector(feats))
        order = np.argsort(-np.abs(contrib))[:top]
        return [(self.names[i], float(contrib[i])) for i in order]

    # --- persistence
    def to_dict(self) -> dict[str, Any]:
        return {
            "names": self.names,
            "w": self.w.tolist(),
            "b": self.b,
            "mean": self.mean.tolist(),
            "m2": self.m2.tolist(),
            "n": self.n,
            "n_rows": self.n_rows,
            "n_eff": self.n_eff,
            "ew_n": self.ew_n,
            "n_recent": self.n_recent,
            "l2": self.l2,
            "lr": self.lr,
            "platt_a": self.platt_a,
            "platt_c": self.platt_c,
            "base_rate": self.base_rate,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any], names: list[str]) -> OnlineLogit:
        m = cls(names, l2=d.get("l2", 0.02), lr=d.get("lr", 0.08))
        old = d.get("names", [])
        if old != names:  # feature set changed: keep the overlap, start the rest at zero
            lookup = {k: i for i, k in enumerate(old)}
            for j, k in enumerate(names):
                if k in lookup:
                    i = lookup[k]
                    m.w[j], m.mean[j], m.m2[j] = d["w"][i], d["mean"][i], d["m2"][i]
        else:
            m.w, m.mean, m.m2 = np.array(d["w"]), np.array(d["mean"]), np.array(d["m2"])
        m.b, m.n = float(d.get("b", 0.0)), int(d.get("n", 0))
        if d.get("n_rows") is not None:
            m.n_rows = int(d["n_rows"])
            m.n_eff = None if d.get("n_eff") is None else float(d["n_eff"])
        else:
            # Saved before rows were counted: ``n`` is updates over LEGACY_EPOCHS epochs, and the
            # overlap is unknown, so take the harshest plausible discount. A retrain replaces it.
            m.n_rows = m.n // LEGACY_EPOCHS
            m.n_eff = m.n_rows / LEGACY_OVERLAP
        m.platt_a, m.platt_c = float(d.get("platt_a", 1.0)), float(d.get("platt_c", 0.0))
        m.ew_n = float(d.get("ew_n", 0.0))
        m.n_recent = float(d.get("n_recent", 0.0))
        m.base_rate = float(d.get("base_rate", 0.5))
        return m


# --- evaluation helpers -------------------------------------------------------
def brier(ps: list[float], ys: list[float]) -> float:
    if not ps:
        return 0.25
    return float(np.mean((np.array(ps) - np.array(ys)) ** 2))


def log_loss(ps: list[float], ys: list[float]) -> float:
    if not ps:
        return math.log(2)
    p = np.clip(np.array(ps), 1e-4, 1 - 1e-4)
    y = np.array(ys)
    return float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))


def psi(expected: np.ndarray, actual: np.ndarray, bins: int = 10) -> float:
    """Population stability index. <0.1 stable, 0.1-0.25 shifting, >0.25 drifted."""
    expected, actual = np.asarray(expected, float), np.asarray(actual, float)
    if len(expected) < 30 or len(actual) < 15 or expected.std() < 1e-9:
        return 0.0
    edges = np.unique(np.quantile(expected, np.linspace(0, 1, bins + 1)))
    if len(edges) < 3:
        return 0.0
    edges[0], edges[-1] = -np.inf, np.inf
    e = np.histogram(expected, edges)[0] / len(expected) + 1e-4
    a = np.histogram(actual, edges)[0] / len(actual) + 1e-4
    return float(((a - e) * np.log(a / e)).sum())
