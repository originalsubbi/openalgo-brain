"""Option-selling engine: credit spreads when IV is rich.

When implied volatility is elevated, option premiums are expensive and theta
decay favours the seller. This engine detects that regime and states which
side can be sold.

Signals:
* **IV regime**: IV rank at or above ``os_iv_rank_skip`` = premiums are rich,
  so premium may be sold; below ``os_iv_rank_cheap`` = premiums are thin and
  selling them is not worth the risk.
* **Skew**: a rich put side means fear, so the put can be sold (a bullish
  credit spread); a rich call side means greed, so the call can be sold.
* **DTE**: the closer to expiry, the faster the crush — but the closer to
  expiry, the more gamma there is to survive.
* **Delta targeting**: the leg that gets sold targets ``os_sell_delta`` and the
  protective leg ``os_hedge_delta``, so the trade is a defined-risk spread.

The vote is signed: positive = sell a put spread (bullish bias), negative =
sell a call spread (bearish bias). Near-zero = no directional edge.

The thresholds are tunable and read from the live parameters, so the regime
this engine trades can be moved from the UI or by the learner.
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np

from services.brain.types import EngineReport, Snapshot, param

EPS = 1e-12


def _math_exp(x: float) -> float:
    return math.exp(x)


def _math_tanh(x: float) -> float:
    return math.tanh(x)


def _num(row: dict[str, Any], key: str) -> float:
    v = row.get(key)
    try:
        f = float(v)
    except (TypeError, ValueError):
        return 0.0
    return f if np.isfinite(f) else 0.0


def _iv(v: float) -> float:
    return v / 100.0 if v > 3.0 else v


def analyze(snap) -> EngineReport:
    """Option-selling engine: credit spreads when IV is rich."""
    chain = snap.chain
    if not chain or not chain.get("rows"):
        return EngineReport("option_selling", 0.0, 0.0, neutral={"selling_available": 0.0})

    spot = float(chain.get("spot") or snap.spot)
    rows = chain.get("rows") or []
    if not rows:
        return EngineReport("option_selling", 0.0, 0.0, neutral={"selling_available": 0.0})

    lot = int(chain.get("lot_size") or 1)
    dte = float(chain.get("dte") or 0.0)
    atm_iv = float(chain.get("atm_iv", 0.0) or 0.0)
    iv_rank = snap.iv_rank if snap.iv_rank is not None else 0.5

    # ---- IV regime gate -------------------------------------------------------
    # Premium too thin to sell: the credit would not cover the spread of the
    # trade and the risk of being run over is paid for nothing.
    cheap_line = param(snap, "os_iv_rank_cheap", 0.30)
    skip_line = param(snap, "os_iv_rank_skip", 0.60)
    if iv_rank < cheap_line:
        return EngineReport(
            "option_selling",
            0.0,
            0.0,
            neutral={
                "selling_available": 1.0,
                "os_iv_rank": iv_rank,
                "sell_reason": "iv_too_cheap",
            },
        )
    if iv_rank >= skip_line:
        sell_strength = _math_tanh((iv_rank - skip_line) / max(1.0 - skip_line, 1e-6))
    else:
        sell_strength = 0.0  # neutral zone

    # ---- Directional bias from skew -------------------------------------------
    # Put skew (puts richer than calls) = fear = sell a put spread (bullish)
    # Call skew (calls richer) = greed = sell a call spread (bearish)
    # Same strike on both sides, so the comparison is a real skew.
    by_strike = {float(_num(r, "strike")): r for r in rows}
    strike_list = sorted(by_strike)
    atm_idx = min(range(len(strike_list)), key=lambda i: abs(strike_list[i] - spot))
    atm_row = by_strike[strike_list[atm_idx]]
    put_iv = _iv(_num(atm_row, "pe_iv"))
    call_iv = _iv(_num(atm_row, "ce_iv"))
    atm_iv_ref = _iv(_num(atm_row, "ce_iv"))
    skew = (put_iv - call_iv) / atm_iv_ref if put_iv > 0 and call_iv > 0 and atm_iv_ref > 0 else 0.0

    # skew > 0 = puts richer (fear) -> sell the puts: the rich side is the side
    # whose premium pays the most to sell. skew < 0 = calls richer (greed) ->
    # sell the calls.
    skew_dir = _math_tanh(skew * 3.0)  # +1 = sell puts (bullish), -1 = sell calls (bearish)

    # ---- fuse into vote -------------------------------------------------------
    # sell_strength controls how much we want to sell premium
    # skew_dir controls direction (put spread vs call spread)
    vote = sell_strength * skew_dir

    # Confidence: higher when IV rank is high and DTE is near (faster crush)
    dte_crush = _math_exp(-max(dte, 0.0) / 2.0)  # near expiry = faster crush
    conf = min(1.0, 0.3 + 0.4 * sell_strength + 0.3 * dte_crush)

    signed = {
        "os_sell_strength": sell_strength,
        "os_skew_dir": skew_dir,
        "oi_skew": skew,
    }
    neutral = {
        "selling_available": 1.0,
        "os_iv_rank": iv_rank,
        "os_atm_iv": atm_iv,
        "os_skew": skew,
        "os_dte": min(1.0, dte / 7.0),
        "os_dte_crush": dte_crush,
        "os_strategy": 1.0 if abs(skew_dir) > 0.3 else 0.0,  # 1 = directional spread, 0 = flat
    }
    notes = []
    if iv_rank >= skip_line:
        notes.append(f"os_iv_rank={iv_rank:.2f}_sell_premium")
    if abs(skew) > 0.03:
        notes.append(f"os_skew={skew:+.2f}")
    if dte_crush > 0.5:
        notes.append("os_near_expiry_crush")

    return EngineReport(
        "option_selling",
        vote=float(vote),
        confidence=float(conf),
        signed=signed,
        neutral=neutral,
        notes=tuple(notes),
    )


__all__ = ["analyze"]
