"""Positional trading engine for the AI Brain.

Trades on weekly timeframe with 1-8 week hold periods.
Uses trend following with support/resistance bounces.

Aggregates 1m bars to weekly bars internally, then applies positional logic.

Features:
- Trend detection: Price above/below weekly EMA(50)
- Entry: Bounce from major support/resistance levels
- Exit: Trail stop below weekly swing low / above swing high, or target at major level
- Position sizing: Smallest (widest stops = smallest size)
- Hold period: Weeks to months
"""

from __future__ import annotations

import numpy as np

from services.brain.types import EngineReport, Snapshot, param

IST_OFFSET = 19800  # seconds, UTC+05:30
EPS = 1e-12


def _ema(values: np.ndarray, period: int) -> np.ndarray:
    """Exponential moving average."""
    if len(values) < 2:
        return np.full_like(values, np.nan, dtype=float)
    alpha = 2.0 / (period + 1.0)
    out = np.empty_like(values, dtype=float)
    out[0] = values[0]
    for i in range(1, len(values)):
        out[i] = alpha * values[i] + (1.0 - alpha) * out[i - 1]
    return out


def _atr(high: np.ndarray, low: np.ndarray, close: np.ndarray, n: int = 14) -> float:
    """Average True Range as absolute value."""
    prev = close[:-1]
    tr = np.maximum.reduce([high[1:] - low[1:], np.abs(high[1:] - prev), np.abs(low[1:] - prev)])
    if len(tr) < n:
        return float(np.mean(tr)) if len(tr) else 0.0
    return float(np.mean(tr[-n:]))


def _find_swing_lows(lows: np.ndarray, window: int = 3) -> list[float]:
    """Find swing lows (local minima) for weekly data."""
    swings = []
    for i in range(window, len(lows) - window):
        if lows[i] <= lows[i - window : i + window + 1].min():
            swings.append(float(lows[i]))
    return swings


def _find_swing_highs(highs: np.ndarray, window: int = 3) -> list[float]:
    """Find swing highs (local maxima) for weekly data."""
    swings = []
    for i in range(window, len(highs) - window):
        if highs[i] >= highs[i - window : i + window + 1].max():
            swings.append(float(highs[i]))
    return swings


def _clamp(x: float, lim: float = 1.0) -> float:
    return float(max(-lim, min(lim, x)))


def _aggregate_1m_to_weekly(bars: np.ndarray) -> np.ndarray:
    """Aggregate intraday bars to weekly OHLCV bars.

    Input: (n, 6) array of [ts, open, high, low, close, volume]
    Output: (m, 6) array of weekly OHLCV bars

    Weeks are IST weeks starting on Monday. The IST day boundary is applied
    first, so a week is a run of IST days rather than a run of UTC days.
    """
    if len(bars) == 0:
        return bars

    ts = bars[:, 0]
    # IST day, then the Monday-anchored week that day falls in.
    days = ((ts + IST_OFFSET) // 86400).astype(int)
    # 1970-01-01 was a Thursday: shift so weeks start on Monday.
    weeks = ((days + 3) // 7).astype(int)

    weekly_rows = []
    for week in np.unique(weeks):
        mask = weeks == week
        week_bars = bars[mask]
        if len(week_bars) == 0:
            continue
        weekly_rows.append([
            week_bars[0, 0],      # timestamp of first bar of week
            week_bars[0, 1],      # open = first open of week
            week_bars[:, 2].max(),  # high = max high of week
            week_bars[:, 3].min(),  # low = min low of week
            week_bars[-1, 4],     # close = last close of week
            week_bars[:, 5].sum(), # volume = sum volume of week
        ])

    if len(weekly_rows) == 0:
        return np.empty((0, 6))

    return np.array(weekly_rows)


def _is_weekly_bar_complete(weekly_bars: np.ndarray, snap_ts: float) -> bool:
    """Return True if the last aggregated weekly bar is almost certainly complete.

    A weekly bar is built from this week's intraday bars while the week is still
    underway; reacting to it mid-week means the signal can flip as new daily
    data lands. We treat it as complete when its IST week differs from the
    snapshot's current IST week.
    """
    if len(weekly_bars) == 0:
        return False
    last_bar_ts = float(weekly_bars[-1, 0])
    # Same week-anchor arithmetic as _aggregate_1m_to_weekly.
    days_last = int((last_bar_ts + 19800) // 86400)
    days_now = int((snap_ts + 19800) // 86400)
    weeks_last = (days_last + 3) // 7
    weeks_now = (days_now + 3) // 7
    return weeks_last != weeks_now


def analyze(snap: Snapshot) -> EngineReport:
    """Positional trading engine using weekly bars aggregated from 1m data.

    Detects major trend direction and enters on bounces from key levels.
    """
    # Aggregate 1m bars to weekly bars
    weekly_bars = _aggregate_1m_to_weekly(snap.bars)

    if len(weekly_bars) < 52:  # Need at least ~1 year of weekly data
        return EngineReport("positional", 0.0, 0.0)

    o, h, l, c, v = weekly_bars[:, 1], weekly_bars[:, 2], weekly_bars[:, 3], weekly_bars[:, 4], weekly_bars[:, 5]

    # This week's weekly bar may still be forming; exclude it from signal
    # conditions so the engine never reacts to partial-week noise that can
    # reverse as the remaining days arrive. Use the last *completed* week's
    # values for decisions (same strategy as the daily swing engine).
    _complete_weekly = _is_weekly_bar_complete(weekly_bars, snap.ts)
    sig_c = c[:-1] if not _complete_weekly else c
    sig_o = o[:-1] if not _complete_weekly else o
    sig_h = h[:-1] if not _complete_weekly else h
    sig_l = l[:-1] if not _complete_weekly else l
    sig_ema20 = _ema(sig_c, 20)
    sig_ema50 = _ema(sig_c, 50)
    sig_ema200 = _ema(sig_c, 200)

    if len(sig_c) == 0:
        return EngineReport("positional", 0.0, 0.0, neutral={"positional_available": 0.0})

    curr_close = float(sig_c[-1])
    curr_open = float(sig_o[-1])
    curr_high = float(sig_h[-1])
    curr_low = float(sig_l[-1])
    curr_ema_20 = float(sig_ema20[-1])
    curr_ema_50 = float(sig_ema50[-1])
    curr_ema_200 = float(sig_ema200[-1])

    # Previous EMAs for crossover detection, computed on the completed series.
    prev_ema_50 = float(sig_ema50[-2]) if len(sig_ema50) >= 2 else curr_ema_50
    prev_ema_200 = float(sig_ema200[-2]) if len(sig_ema200) >= 2 else curr_ema_200

    atr = _atr(sig_h, sig_l, sig_c, 14)
    atr_pct = atr / curr_close if curr_close > 0 else 0.0

    # Trend determination using weekly EMAs
    uptrend = bool(curr_close > curr_ema_50 > curr_ema_200)
    downtrend = bool(curr_close < curr_ema_50 < curr_ema_200)

    # Golden cross / death cross detection
    golden_cross = bool(prev_ema_50 <= prev_ema_200 and curr_ema_50 > curr_ema_200)
    death_cross = bool(prev_ema_50 >= prev_ema_200 and curr_ema_50 < curr_ema_200)

    # Bounce detection
    bullish_bounce = bool(
        uptrend
        and curr_low <= curr_ema_50 * 1.01
        and curr_close > curr_ema_50
        and curr_close > curr_open
    )

    bearish_bounce = bool(
        downtrend
        and curr_high >= curr_ema_50 * 0.99
        and curr_close < curr_ema_50
        and curr_close < curr_open
    )

    # Swing points for stop placement (using longer window for weekly, on completed bars only)
    swing_lows = _find_swing_lows(sig_l, 3)
    swing_highs = _find_swing_highs(sig_h, 3)

    vote = 0.0
    confidence = 0.0

    if bullish_bounce:
        dist_to_ema = abs(curr_close - curr_ema_50) / curr_ema_50 if curr_ema_50 > 0 else 0.0
        trend_strength = min((curr_ema_50 - curr_ema_200) / curr_ema_200 * 50, 1.0) if curr_ema_200 > 0 else 0.0
        vote = 0.6 + trend_strength * 0.3
        confidence = min(0.85, 0.55 + trend_strength * 0.25)

    elif bearish_bounce:
        dist_to_ema = abs(curr_close - curr_ema_50) / curr_ema_50 if curr_ema_50 > 0 else 0.0
        trend_strength = min((curr_ema_200 - curr_ema_50) / curr_ema_200 * 50, 1.0) if curr_ema_200 > 0 else 0.0
        vote = -(0.6 + trend_strength * 0.3)
        confidence = min(0.85, 0.55 + trend_strength * 0.25)

    if golden_cross:
        vote = max(vote, 0.8)
        confidence = max(confidence, 0.85)

    if death_cross:
        vote = min(vote, -0.8)
        confidence = max(confidence, 0.85)

    if swing_highs and curr_close > swing_highs[-1] and uptrend:
        vote = max(vote, 0.7)
        confidence = max(confidence, 0.7)

    if swing_lows and curr_close < swing_lows[-1] and downtrend:
        vote = min(vote, -0.7)
        confidence = max(confidence, 0.7)

    # The positional geometry the tunable stop/target multiples describe: a
    # stop ``positional_k_stop`` weekly ATRs away and a target
    # ``positional_k_target`` weekly ATRs away.
    k_stop = param(snap, "positional_k_stop", 3.0)
    k_target = param(snap, "positional_k_target", 4.0)
    extras = {
        "pos_atr": float(atr),
        "pos_stop_distance": float(atr * k_stop),
        "pos_target_distance": float(atr * k_target),
        "pos_k_stop": float(k_stop),
        "pos_k_target": float(k_target),
    }

    neutral = {
        "pos_trend_strength": min(abs(curr_ema_50 - curr_ema_200) / curr_ema_200 * 20, 1.0) if curr_ema_200 > 0 else 0.0,
        "pos_atr_pct": min(atr_pct * 100, 1.0),
        "pos_ema_distance": min(abs(curr_close - curr_ema_50) / curr_ema_50 * 10, 1.0) if curr_ema_50 > 0 else 0.0,
    }

    notes = []
    if bullish_bounce:
        notes.append("pos_bullish_bounce")
    if bearish_bounce:
        notes.append("pos_bearish_bounce")
    if golden_cross:
        notes.append("pos_golden_cross")
    if death_cross:
        notes.append("pos_death_cross")
    if swing_highs and curr_close > swing_highs[-1] and uptrend:
        notes.append("pos_breakout_high")
    if swing_lows and curr_close < swing_lows[-1] and downtrend:
        notes.append("pos_breakout_low")

    return EngineReport(
        "positional",
        vote=_clamp(vote, 1.0),
        confidence=float(confidence),
        signed={
            "pos_trend": float(_clamp(vote, 1.0)),
            "pos_ema_distance": min(abs(curr_close - curr_ema_50) / curr_ema_50 * 10, 1.0) if curr_ema_50 > 0 else 0.0,
        },
        neutral=neutral,
        notes=tuple(notes),
        extras=extras,
    )