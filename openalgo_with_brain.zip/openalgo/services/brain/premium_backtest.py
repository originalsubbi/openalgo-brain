"""Premium-space replay: what an option position actually earns, after costs.

``backtest`` prices a trade in the underlying's R-space. That is the right space
for fitting and grading a model, and the wrong one for deciding whether to
deploy: an option bought at 10:00 is not worth what it was at 14:00 with the
spot unchanged, and theta is charged whether or not the engines were right. A
spot-space backtest can therefore show an edge the broker account never sees.

This module keeps ``backtest.precompute`` (the engines are the expensive part and
do not depend on the economics) and replays each accepted candidate as a
real long option position:

* the option is priced with Black-Scholes at every bar from the underlying's
  close and the calendar time left to the symbol's weekly expiry;
* implied volatility is trailing realised volatility of 5-minute returns (EWMA),
  inflated by a variance-risk-premium factor. The archive holds no chain before
  the last week, so a chain cannot be read for 2021-2025; realised vol is the
  honest substitute, and the inflation factor is swept rather than assumed;
* entry pays the ask and exits receive the bid, so the spread is a cost rather
  than a rounding error;
* brokerage, STT, exchange transaction charges, SEBI fees, GST are deducted in
  rupees using post-Oct-2023 NSE rates for index options;
* trading-knowledge rules from Indian index-options research are applied:
  IV-rank gating (don't buy expensive vol), put-skew adjustment (puts are
  systematically richer in Indian indices), entry-window filtering
  (9:35-13:00 IST), research-based exits (25% stop / 50% target / 90-min time
  stop), and real per-bar delta tracking instead of a fixed 0.50.

Both sides are long premium: the SHORT engine buys a put, it does not write one,
so neither side carries margin.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

import numpy as np

from services.brain import backtest, fusion
from services.brain.config import RiskLimits, TunableParams
from services.brain.executor import BARS_PER_TRADING_DAY, plan_levels, select_legs
from services.brain.labeling import BAR_S, Metrics, metrics
from services.brain.types import Snapshot

IST = timezone(timedelta(hours=5, minutes=30))

# The archive holds index spot bars only for most of its history, so the option
# leg has to be reconstructed. These are the contract facts reconstruction needs.
# The values live in services/brain/contracts.py so the live Brain and the
# backtester can never disagree about a lot size.
from services.brain.contracts import LOT_SIZES, STRIDE  # noqa: E402  (re-exported)
# Weekday of the weekly expiry, read off the option symbols the archive does hold
# (NIFTY 17-Nov-2026 is a Tuesday, SENSEX 19-Nov-2026 a Thursday, and so on).
EXPIRY_WEEKDAY = {
    "NIFTY": 1,  # Tuesday
    "BANKNIFTY": 0,  # Monday
    "FINNIFTY": 0,
    "MIDCPNIFTY": 0,
    "SENSEX": 3,  # Thursday
    "BANKEX": 3,
}

# Trading-knowledge gates — prevent buying options in unfavorable vol regimes.
VIX_SKIP_THRESHOLD = 22.0   # above this, premium-buyer expectancy is structurally negative
VIX_REDUCED_THRESHOLD = 12.0  # above this but below skip: halve risk per trade


def _approx_vix(iv_fraction: float) -> float:
    """Rough IndiaVIX equivalent from an implied-vol fraction."""
    return max(8.0, iv_fraction * 100.0)


def _select_dte(bars_ts: np.ndarray, ts: float, symbol: str) -> tuple[float, float]:
    """Pick expiry DTE and timestamp with trading-knowledge bias toward second week.

    Preference order: second weekly (5–14 DTE) > nearest (>= 1 DTE) > fallback 0.4.
    This avoids maximum theta drag that comes from buying the front-week contract.
    """
    weekday = EXPIRY_WEEKDAY.get(symbol, 1)
    dt = datetime.fromtimestamp(float(ts), IST)
    ahead_nearest = (weekday - dt.weekday()) % 7
    if ahead_nearest == 0:
        ahead_nearest = 7
    nearest_exp = datetime(dt.year, dt.month, dt.day, 16, 0, tzinfo=IST) + timedelta(days=ahead_nearest)
    nearest_dte = (nearest_exp.timestamp() - float(ts)) / 86400.0
    second_exp = nearest_exp + timedelta(days=7)
    second_dte = (second_exp.timestamp() - float(ts)) / 86400.0

    remaining_bars = len(bars_ts) - int(ts // BAR_S) if len(bars_ts) else 0
    bars_per_day = 75 * 6  # five-minute bars per trading day, ~6 hours
    max_useful_dte = min(14.0, remaining_bars / bars_per_day) if bars_per_day > 0 else 14.0

    candidates: list[tuple[float, float]] = []
    if 3.0 <= second_dte <= max_useful_dte:
        candidates.append((second_dte, second_exp.timestamp()))
    if 1.0 <= nearest_dte <= max_useful_dte:
        candidates.append((nearest_dte, nearest_exp.timestamp()))
    if not candidates:
        return max(nearest_dte, 0.4), nearest_exp.timestamp()
    # Prefer dte near 7 days (sweet spot between theta and gamma)
    best = min(candidates, key=lambda x: abs(x[0] - 7.0))
    return best[0], best[1]


def _norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _norm_pdf(x: float) -> float:
    return math.exp(-0.5 * x * x) / math.sqrt(2.0 * math.pi)


def bs_price(spot: float, strike: float, t_years: float, vol: float, kind: str) -> float:
    """Black-Scholes price, European, no dividend. ``t_years`` may be tiny."""
    intrinsic = (spot - strike) if kind == "ce" else (strike - spot)
    if t_years <= 0.0 or vol <= 0.0:
        return max(intrinsic, 0.0)
    sig_t = vol * math.sqrt(t_years)
    if sig_t <= 1e-12:
        return max(intrinsic, 0.0)
    d1 = (math.log(spot / strike) + 0.5 * vol * vol * t_years) / sig_t
    d2 = d1 - sig_t
    disc = math.exp(-0.065 * t_years)
    if kind == "ce":
        return spot * _norm_cdf(d1) - strike * disc * _norm_cdf(d2)
    return strike * disc * _norm_cdf(-d2) - spot * _norm_cdf(-d1)


def bs_delta(spot: float, strike: float, t_years: float, vol: float, kind: str) -> float:
    """Black-Scholes delta per unit of spot.

    Calls: N(d1) in (0, 1). Puts: -N(-d1) in (-1, 0).
    """
    if t_years <= 0.0 or vol <= 0.0:
        intrinsic = (spot - strike) if kind == "ce" else (strike - spot)
        return 1.0 if intrinsic > 0 else 0.0
    sig_t = vol * math.sqrt(t_years)
    if sig_t <= 1e-12:
        intrinsic = (spot - strike) if kind == "ce" else (strike - spot)
        return 1.0 if intrinsic > 0 else 0.0
    d1 = (math.log(spot / strike) + 0.5 * vol * vol * t_years) / sig_t
    if kind == "ce":
        return _norm_cdf(d1)
    return _norm_cdf(d1) - 1.0


def next_expiry(symbol: str, ts: float) -> float:
    """Entry time of the weekly expiry at or after ``ts`` (16:00 IST)."""
    weekday = EXPIRY_WEEKDAY.get(symbol, 1)
    dt = datetime.fromtimestamp(ts, IST)
    ahead = (weekday - dt.weekday()) % 7
    exp = datetime(dt.year, dt.month, dt.day, 16, 0, tzinfo=IST) + timedelta(days=ahead)
    exp_ts = exp.timestamp()
    return exp_ts if exp_ts > ts else exp_ts + 7 * 86400.0


def _mod_min(ts: float) -> int:
    """IST minutes since midnight at the bar's close, counted the way ``_snap`` counts them.

    Bars are labelled by their open time; the clock events the Brain acts on
    (entry window, square-off) happen at the close, so the minute of day is
    the label plus one bar. Without the offset the square-off fires one bar
    early relative to what the live loop would see.
    """
    return int(((ts + BAR_S + backtest.IST_OFFSET) // 60) % 1440)


def _entry_window_ok(minute_of_day: int, entry_start_min: int = 9 * 60 + 35, entry_cutoff_min: int = 13 * 60) -> bool:
    """Entry window per Indian index-options research: 9:35-13:00 IST.

    Research consensus: avoid the first 30 minutes (opening volatility) and
    avoid trading after 1 PM as theta decay accelerates into the close.
    """
    return entry_start_min <= minute_of_day < entry_cutoff_min


@dataclass(frozen=True, slots=True)
class CostModel:
    """Statutory and brokerage costs of one round trip, in rupees.

    Post-Oct-2024 NSE rates for index options:
    * STT: 0.1% on sell-side premium only (raised from 0.05% in Oct 2024)
    * Transaction charge: 0.03503% each side (NSE derivatives, premium value)
    * SEBI fee: 0.0001% each side
    * GST: 18% on brokerage + txn + SEBI
    * No stamp duty on index derivatives
    """

    brokerage_per_order: float = 20.0
    stt_sell_pct: float = 0.001  # 0.1% on sell-side premium only (since Oct 2024)
    txn_charge_pct: float = 0.0003503  # 0.03503% each side
    sebi_pct: float = 0.000001  # 0.0001% each side
    stamp_pct: float = 0.0  # index derivatives exempt
    gst_pct: float = 0.18  # 18% on brokerage + txn + sebi
    slippage_points: float = 1.0  # premium units per leg, on top of the spread

    def round_trip(self, entry_mid: float, exit_mid: float, qty: int) -> dict[str, float]:
        buy_prem = entry_mid * qty
        sell_prem = exit_mid * qty
        brokerage = self.brokerage_per_order * 2.0
        stt = sell_prem * self.stt_sell_pct
        txn = (buy_prem + sell_prem) * self.txn_charge_pct
        sebi = (buy_prem + sell_prem) * self.sebi_pct
        stamp = buy_prem * self.stamp_pct
        gst = (brokerage + txn + sebi) * self.gst_pct
        slippage = self.slippage_points * qty * 2.0
        return {
            "brokerage": brokerage,
            "stt": stt,
            "txn": txn,
            "sebi": sebi,
            "stamp": stamp,
            "gst": gst,
            "slippage": slippage,
            "total": brokerage + stt + txn + sebi + stamp + gst + slippage,
        }


@dataclass(frozen=True, slots=True)
class VolModel:
    """Trailing realised vol, inflated into an implied vol.

    Realised vol of 5-minute returns is observable at every bar; the
    multiplier is the variance risk premium.
    """

    half_life_bars: float = 200.0  # ~17 hours of 5-minute bars
    vrp: float = 1.25
    lo: float = 0.06
    hi: float = 1.20
    min_samples: int = 60

    def series(self, bars: np.ndarray) -> np.ndarray:
        close = bars[:, 4]
        ret = np.diff(np.log(np.maximum(close, 1e-9)), prepend=np.nan)
        lam = math.exp(math.log(0.5) / self.half_life_bars)
        var, seen = 0.0, 0
        out = np.full(len(bars), np.nan, dtype=float)
        for i in range(len(bars)):
            r = ret[i]
            if not math.isnan(r):
                var = lam * var + (1.0 - lam) * r * r
                seen += 1
            if seen < self.min_samples:
                continue
            ann = math.sqrt(max(var, 0.0) * BARS_PER_TRADING_DAY * 252.0) * self.vrp
            out[i] = min(max(ann, self.lo), self.hi)
        return out


@dataclass
class IVRankTracker:
    """Track IV rank/percentile over a rolling window for regime gating.

    Research: don't buy options when IV rank > 60% (options expensive,
    IV-crush risk). Don't sell when IV rank < 30% (premium too cheap).
    """

    window_bars: int = 200 * BARS_PER_TRADING_DAY  # ~200 sessions of 5-min bars each

    def __init__(self) -> None:
        self._iv_history: list[float] = []

    def update(self, iv: float) -> None:
        if iv > 0 and not math.isnan(iv):
            self._iv_history.append(iv)
            if len(self._iv_history) > self.window_bars:
                self._iv_history = self._iv_history[-self.window_bars :]

    def rank(self, iv: float) -> float:
        """Return IV rank in [0, 1]: fraction of history below ``iv``."""
        if len(self._iv_history) < 20:
            return 0.5  # neutral when no history
        below = sum(1 for v in self._iv_history if v < iv)
        return below / len(self._iv_history)

    def percentile(self, iv: float) -> float:
        """Same as rank for compatibility with research terminology."""
        return self.rank(iv)


@dataclass
class Trade:
    symbol: str
    side: str
    regime: str
    entry_ts: float
    exit_ts: float
    entry_spot: float
    exit_spot: float
    paid: float  # ask paid per unit
    received: float  # bid received per unit
    lots: int
    lot_size: int
    qty: int
    k_stop: float
    sigma_h: float
    rr: float
    score: float
    prob: float
    ev_r: float
    exit_reason: str
    bars_held: int
    pnl_gross: float
    pnl_net: float
    r_net: float
    costs: dict[str, float] = field(default_factory=dict)
    iv_rank_at_entry: float = 0.0
    delta_at_entry: float = 0.5

    @property
    def is_win(self) -> bool:
        return self.pnl_net > 0


@dataclass(frozen=True, slots=True)
class Book:
    """A run's trades and the numbers a deployment decision is made on."""

    trades: list[Trade]
    capital: float
    gross: float
    net: float
    costs: float
    r_metrics: Metrics
    max_dd_pct: float
    daily_net: dict[str, float]
    symbol: str = ""

    def as_dict(self) -> dict[str, object]:
        return {
            "symbol": self.symbol,
            "trades": len(self.trades),
            "days": len(self.daily_net),
            "capital": round(self.capital, 2),
            "gross_rupees": round(self.gross, 2),
            "net_rupees": round(self.net, 2),
            "costs_rupees": round(self.costs, 2),
            "net_pct_of_capital": round(100.0 * self.net / self.capital, 3) if self.capital else 0.0,
            "net_per_day": round(self.net / max(len(self.daily_net), 1), 2),
            "max_dd_pct": round(self.max_dd_pct, 2),
            "r": self.r_metrics.as_dict(),
        }


def _snap(symbol: str, bars: np.ndarray, i: int, lot: int) -> Snapshot:
    window = bars[max(0, i - 399) : i + 1]
    mod = int(((float(bars[i, 0]) + BAR_S + backtest.IST_OFFSET) // 60) % 1440)
    return Snapshot(
        underlying=symbol,
        ts=float(bars[i, 0]),
        bars=window,
        spot=float(window[-1, 4]),
        lot_size=lot,
        bench_close=None,
        chain=None,
        iv_rank=None,
        vix=None,
        minute_of_day=mod,
    )


def synthetic_leg(
    symbol: str,
    side: str,
    spot: float,
    dte: float,
    iv: float,
    costs: CostModel,
    target_delta: float = 0.50,
    iv_rank: float = 0.5,
) -> dict[str, object]:
    """Synthesise one option row with ITM-biased strike selection.

    ``target_delta`` controls moneyness: 0.50 = ATM, 0.55-0.65 = modestly ITM,
    0.40-0.45 = OTM. ITM is preferred for intraday because it has lower theta
    decay per unit of directional exposure and more stable delta during the hold
    window.

    Put skew adjustment: Indian index options show persistent put skew
    (OTM puts carry 2-6 vol points more IV than equidistant OTM calls). When
    buying puts we inflate IV by a skew factor because we are buying the rich
    side; when buying calls we deflate IV slightly because we are buying the
    cheaper side.
    """
    stride = STRIDE.get(symbol, 50.0)
    kind = "ce" if side == "LONG" else "pe"

    # Put skew adjustment: inflate IV for puts (rich side), deflate for calls (cheap side)
    # Typical NIFTY put skew is +2 to +6 vol points. Use 3 points as default skew adjustment.
    skew_adj = 0.03 if kind == "pe" else -0.015
    adjusted_iv = min(max(iv + skew_adj, 0.05), 1.20)

    # IV-rank penalty: when IV rank is high, options are expensive; apply a
    # further inflation to reflect IV-crush risk on long premium.
    if iv_rank > 0.6:
        adjusted_iv = min(adjusted_iv * (1.0 + 0.2 * (iv_rank - 0.6) / 0.4), 1.20)

    # Compute delta-based strike: shift from ATM by delta offset
    # Approximation: each 50-pt move on NIFTY changes delta by ~0.05 near ATM
    delta_shift_pts = (target_delta - 0.50) / 0.05 * stride
    if kind == "ce":
        itm_strike_raw = spot - abs(delta_shift_pts)
    else:
        itm_strike_raw = spot + abs(delta_shift_pts)
    strike = round(itm_strike_raw / stride) * stride
    # Cap the ITM offset at four strikes either way. The call branch used
    # min(strike, spot - 4*stride), which forced EVERY call at least four strikes
    # deep ITM (delta ~0.75) whatever target_delta asked for.
    if kind == "pe":
        strike = max(stride, min(strike, spot + 4 * stride))
    else:
        strike = max(stride, max(strike, spot - 4 * stride))

    mid = bs_price(spot, strike, max(dte, 0.4) / 365.0, adjusted_iv, kind)
    half = max(mid * 0.012, 0.75) + costs.slippage_points * 0.5
    approx_delta = bs_delta(spot, strike, max(dte, 0.4) / 365.0, adjusted_iv, kind)
    row = {
        "strike": strike,
        f"{kind}_symbol": f"{symbol}{strike}{kind.upper()}",
        f"{kind}_ltp": max(mid, 0.05),
        f"{kind}_bid": max(mid - half, 0.05),
        f"{kind}_ask": mid + half,
        f"{kind}_delta": approx_delta if kind == "ce" else -approx_delta,
        f"{kind}_gamma": 0.0,
    }
    chain = {"spot": spot, "dte": dte, "lot_size": LOT_SIZES.get(symbol, 65), "rows": [row]}
    # The row is synthesised at ``target_delta`` (0.55 by default), which sits just
    # above the ATM band's 0.55 ceiling once the strike snaps to the grid, so asking
    # for "ATM" alone raised for every candidate and the backtest took no trades.
    legs = select_legs(chain, side, spot)
    leg = legs.get("ATM") or legs.get("ITM") or legs.get("OTM")
    if leg is None:
        raise ValueError(f"no tradable leg for {symbol} {side}")
    return {**leg, "kind": kind, "strike": strike,
            # A long buys at the ask; a short sells at the bid — crediting the
            # ask on a short entry overstates the credit and flatters every
            # short's P&L by the full spread.
            "entry": float(row[f"{kind}_ask"]) if side == "LONG" else float(row[f"{kind}_bid"]),
            "spread_pct": (float(row[f"{kind}_ask"]) - float(row[f"{kind}_bid"])) / max(float(row[f"{kind}_ltp"]), 1e-9) * 100.0,
            "delta": approx_delta if kind == "ce" else -approx_delta}


def premium_at(
    spot: float, strike: float, bar_ts: float, expiry_ts: float, iv: float, kind: str
) -> float:
    t_years = max(expiry_ts - bar_ts, 0.0) / (365.0 * 86400.0)
    return bs_price(spot, strike, t_years, iv, kind)


def simulate(
    bars: np.ndarray,
    reports: list[backtest.BarEval],
    symbol: str,
    params: TunableParams | None = None,
    limits: RiskLimits | None = None,
    costs: CostModel | None = None,
    vol: VolModel | None = None,
    model=None,
    use_options: bool = False,
    capital: float = 200_000.0,
    risk_per_trade_pct: float | None = None,
    max_lots: int | None = None,
    hold_overnight: bool = False,
) -> Book:
    """Replay accepted candidates as option positions and account for them.

    Trading-knowledge rules applied (per Indian index-options research):

    Entry filters:
    * Entry window 9:35-13:00 IST only (avoid opening vol + late-day theta)
    * IV rank gate: skip buying when IV rank > 60% (expensive vol / IV crush risk)
    * IV rank < 30% reduces risk per trade (cheap vol = better buyer edge)
    * Put skew adjustment built into synthetic leg pricing

    Exit rules:
    * Stop loss: 25% of premium paid (research standard)
    * Target: 50% of premium paid (research standard)
    * Time stop: exit after 90 min unless premium up 15%
    * Day-end squareoff at 15:10 IST (30 min before close to avoid gamma cliff)
    * Max 2 trades per day, stop after 2 consecutive losses
    """
    params = params or TunableParams()
    limits = limits or RiskLimits()
    costs = costs or CostModel()
    vol = vol or VolModel()
    lot_size = LOT_SIZES.get(symbol, 65)
    risk_pct = limits.risk_per_trade_pct if risk_per_trade_pct is None else risk_per_trade_pct
    cap_lots = limits.max_lots if max_lots is None else max_lots
    start_capital = capital

    iv_series = vol.series(bars)
    bar_ts = bars[:, 0]
    spot_col = bars[:, 4]
    cooldown_bars = max(1, int(limits.cooldown_minutes / (BAR_S / 60.0)))

    # IV rank tracker for regime gating
    iv_tracker = IVRankTracker()

    trades: list[Trade] = []
    pos: dict | None = None
    trades_today = 0
    losses_streak = 0
    day = ""
    day_start_equity = capital
    blocked_until = -1

    for be in reports:
        i = be.index
        ts = float(bar_ts[i])
        iv = float(iv_series[i]) if not math.isnan(iv_series[i]) else 0.0
        here = datetime.fromtimestamp(ts, IST)
        minute = _mod_min(ts)

        # --- daily reset -----------------------------------------------------
        if here.date().isoformat() != day:
            day = here.date().isoformat()
            trades_today = 0
            losses_streak = 0
            day_start_equity = capital

        iv_tracker.update(iv)
        iv_rank = iv_tracker.rank(iv)
        pick = None

        # --- manage the open position --------------------------------------
        if pos is not None:
            mid = premium_at(
                float(spot_col[i]), pos["strike"], ts, pos["expiry"], iv or pos["iv"], pos["kind"]
            )
            position_type = pos.get("position_type", "long")
            if position_type == "short":
                # Short premium: profit when premium decreases
                open_pnl = pos["paid"] - mid
            else:
                # Long premium: profit when premium increases
                open_pnl = mid - pos["paid"]
            peak = max(pos["peak"], open_pnl)
            armed = pos["armed"] or open_pnl >= pos["trail_trigger"]

            bars_held = i - pos["entry_i"]
            pnl_pct = open_pnl / abs(pos["paid"]) if pos["paid"] > 0 else 0.0

            reason, level = None, 0.0
            if position_type == "short":
                # Short: stop = premium up 50% (loss), target = premium down 50% (profit)
                if open_pnl <= -0.50 * pos["paid"]:
                    reason, level = "STOP", pos["paid"] + 0.50 * pos["paid"]
                elif open_pnl >= 0.50 * pos["paid"]:
                    reason, level = "TARGET", pos["paid"] - 0.50 * pos["paid"]
                elif bars_held >= 18 and pnl_pct < 0.15:
                    reason, level = "TIME", mid
                elif armed and open_pnl <= peak - pos["trail_gap"]:
                    reason, level = "TRAIL", mid
                elif _mod_min(ts) >= 15 * 60 + 10 and not hold_overnight:
                    reason, level = "SQUAREOFF", mid
            else:
                # Long: stop = premium down 25%, target = premium up 50%
                if open_pnl <= -0.25 * pos["paid"]:
                    reason, level = "STOP", pos["paid"] - 0.25 * pos["paid"]
                elif open_pnl >= 0.50 * pos["paid"]:
                    reason, level = "TARGET", pos["paid"] + 0.50 * pos["paid"]
                elif bars_held >= 18 and pnl_pct < 0.15:
                    reason, level = "TIME", mid
                elif armed and open_pnl <= peak - pos["trail_gap"]:
                    reason, level = "TRAIL", mid
                elif _mod_min(ts) >= 15 * 60 + 10 and not hold_overnight:
                    reason, level = "SQUAREOFF", mid

            if reason is not None:
                if position_type == "short":
                    # Short exit: buy at ask (pay), so fill = mid + spread
                    fill = min(max(level, mid) + max(mid * 0.012, 0.75), mid * 2.0)
                else:
                    # Long exit: sell at bid (receive), so fill = mid - spread
                    fill = max(min(level, mid) - max(mid * 0.012, 0.75), 0.05)
                trades.append(_close(pos, symbol, i, ts, float(spot_col[i]), reason, fill, costs, lot_size))
                capital += trades[-1].pnl_net
                losses_streak = losses_streak + 1 if trades[-1].pnl_net < 0 else 0
                blocked_until = i + cooldown_bars
                pos = None
                continue

            pos["peak"], pos["armed"] = peak, armed
            continue

        # --- look for a new position ---------------------------------------
        if i <= blocked_until:
            continue
        if trades_today >= limits.max_trades_per_day:
            continue
        if losses_streak >= limits.max_consecutive_losses:
            continue
        if capital - day_start_equity <= -abs(limits.max_daily_loss_pct) / 100.0 * max(capital, 1.0):
            continue
        if iv <= 0.0:
            continue

        # --- Entry window filter (trading knowledge) -----------------------
        if not _entry_window_ok(minute, limits.entry_start_min, limits.entry_cutoff_min):
            continue

        cands = fusion.evaluate(
            _snap(symbol, bars, i, lot_size), be.reports, params, model, use_options=use_options
        )
        pick = fusion.best(cands)
        if pick is None:
            continue

        # Whether a trade is a credit (short premium) or a debit is a property
        # of the Candidate fusion selected — it is only knowable AFTER the pick,
        # and fusion sets ``position_type`` from the engine that produced it.
        is_short = pick.position_type == "short"

        # --- IV regime gate (trading knowledge) ----------------------------
        # IV rank >= 0.60: expensive vol - bad for buying, good for selling
        # IV rank < 0.30: cheap vol - good for buying, bad for selling
        if iv_rank >= 0.60 and not is_short:
            # IV expensive: option buying structurally unfavorable
            continue
        effective_risk_pct = risk_pct
        if iv_rank < 0.30 and not is_short:
            # Cheap vol: slightly larger size acceptable for buying
            effective_risk_pct = risk_pct * 1.25
        elif iv_rank >= 0.60 and is_short:
            # Expensive vol: good for selling, can size up
            effective_risk_pct = risk_pct * 1.25

        dte, expiry_ts = _select_dte(bars[:, 0], ts, symbol)
        try:
            leg = synthetic_leg(symbol, pick.side, float(spot_col[i]), dte, iv, costs,
                                target_delta=0.50, iv_rank=iv_rank)  # ATM: what the live path buys by default
        except ValueError:
            continue
        entry_premium = float(leg["entry"])
        if entry_premium < limits.min_premium:
            continue
        if float(leg["spread_pct"]) > limits.max_spread_pct:
            continue

        levels = plan_levels(pick, leg, float(spot_col[i]), params)
        risk_per_unit = float(levels["risk_per_unit"])
        risk_amount = capital * (effective_risk_pct / 100.0)
        lots = int(risk_amount // max(risk_per_unit * lot_size, 1e-9))
        # Zero lots means the trade cannot be sized down to fit the risk
        # budget: skipping it beats the old max(1, ...) floor, which silently
        # risked more than the budget allowed on rich premium.
        if lots < 1:
            continue
        lots = min(lots, cap_lots)
        outlay_cap = int(capital * limits.max_exposure_pct / 100.0 // max(entry_premium * lot_size, 1))
        lots = min(lots, outlay_cap)
        if lots < 1:
            # The outlay cap binds before the risk cap does: still unaffordable.
            continue

        pos = {
            "side": pick.side,
            "regime": pick.regime,
            "entry_ts": ts,
            "entry_i": i,
            "spot": float(spot_col[i]),
            "strike": float(leg["strike"]),
            "kind": leg["kind"],
            "expiry": expiry_ts,
            "iv": iv,
            "paid": entry_premium,
            "lots": lots,
            "qty": lots * lot_size,
            "lot_size": lot_size,
            "risk_per_unit": risk_per_unit,
            "k_stop": pick.k_stop,
            "sigma_h": pick.sigma_h,
            "rr": pick.rr,
            "score": pick.score,
            "prob": pick.prob,
            "ev_r": pick.ev_r,
            "peak": 0.0,
            "armed": False,
            "trail_trigger": float(levels["trail_trigger"]),
            "trail_gap": float(levels["trail_gap"]),
            "iv_rank_at_entry": iv_rank,
            "delta_at_entry": float(leg.get("delta", 0.5)),
            "position_type": "short" if is_short else "long",
        }
        trades_today += 1

    if pos is not None:
        last = len(bars) - 1
        iv_last = float(iv_series[last]) if not math.isnan(iv_series[last]) else pos["iv"]
        mid = premium_at(
            float(spot_col[last]), pos["strike"], float(bar_ts[last]), pos["expiry"], iv_last, pos["kind"]
        )
        position_type = pos.get("position_type", "long")
        if position_type == "short":
            fill = min(mid + max(mid * 0.012, 0.75), mid * 2.0)  # buy at ask
        else:
            fill = max(mid - max(mid * 0.012, 0.75), 0.05)  # sell at bid
        t = _close(pos, symbol, last, float(bar_ts[last]), float(spot_col[last]), "END", fill, costs, lot_size)
        trades.append(t)
        capital += t.pnl_net

    return summarise(trades, capital, symbol, start_capital=start_capital)


def _select_dte(bars_ts: np.ndarray, ts: float, symbol: str) -> tuple[float, float]:
    """Pick expiry DTE and timestamp with trading-knowledge bias toward second week.

    Preference: second weekly (5-14 DTE) > nearest (>= 1 DTE) > fallback 0.4.
    Avoids maximum theta drag of front-week contract.
    """
    weekday = EXPIRY_WEEKDAY.get(symbol, 1)
    dt = datetime.fromtimestamp(float(ts), IST)
    ahead_nearest = (weekday - dt.weekday()) % 7
    if ahead_nearest == 0:
        ahead_nearest = 7
    nearest_exp = datetime(dt.year, dt.month, dt.day, 16, 0, tzinfo=IST) + timedelta(days=ahead_nearest)
    nearest_dte = (nearest_exp.timestamp() - float(ts)) / 86400.0
    second_exp = nearest_exp + timedelta(days=7)
    second_dte = (second_exp.timestamp() - float(ts)) / 86400.0

    # Bars left in the archive after this bar. The old arithmetic subtracted
    # ``ts // BAR_S`` — an epoch-second count (~5.7 million) treated as a bar
    # index — which made every candidate branch dead and silently fell through
    # to the front-week fallback. searchsorted finds the bar's position in the
    # sorted timestamp array instead.
    used = int(np.searchsorted(bars_ts, ts, side="right")) if len(bars_ts) else 0
    remaining_bars = len(bars_ts) - used
    bars_per_day = BARS_PER_TRADING_DAY
    max_useful_dte = min(14.0, remaining_bars / bars_per_day) if bars_per_day > 0 else 14.0

    candidates: list[tuple[float, float]] = []
    if 3.0 <= second_dte <= max_useful_dte:
        candidates.append((second_dte, second_exp.timestamp()))
    if 1.0 <= nearest_dte <= max_useful_dte:
        candidates.append((nearest_dte, nearest_exp.timestamp()))
    if not candidates:
        return max(nearest_dte, 0.4), nearest_exp.timestamp()
    best = min(candidates, key=lambda x: abs(x[0] - 7.0))
    return best[0], best[1]


def _close(
    pos: dict,
    symbol: str,
    i: int,
    ts: float,
    spot: float,
    reason: str,
    fill: float,
    costs: CostModel,
    lot_size: int,
) -> Trade:
    """Settle one position at ``fill`` per unit."""
    qty = int(pos["qty"])
    position_type = pos.get("position_type", "long")
    if position_type == "short":
        # Short premium: received at entry, pay at exit
        gross = (pos["paid"] - fill) * qty
    else:
        # Long premium: pay at entry, receive at exit
        gross = (fill - pos["paid"]) * qty
    c = costs.round_trip(pos["paid"], fill, qty)
    net = gross - c["total"]
    # The R denominator is the risk the sim actually enforces at the stop —
    # 25% of the premium paid for a long, 50% for a short — not the plan_levels
    # risk the live path uses, which would make every R-multiple a lie.
    if position_type == "short":
        risk_rupees = 0.50 * pos["paid"] * qty
    else:
        risk_rupees = 0.25 * pos["paid"] * qty
    return Trade(
        symbol=symbol,
        side=pos["side"],
        regime=pos["regime"],
        entry_ts=pos["entry_ts"],
        exit_ts=ts,
        entry_spot=pos["spot"],
        exit_spot=spot,
        paid=pos["paid"],
        received=fill,
        lots=pos["lots"],
        lot_size=lot_size,
        qty=qty,
        k_stop=pos["k_stop"],
        sigma_h=pos["sigma_h"],
        rr=pos["rr"],
        score=pos["score"],
        prob=pos["prob"],
        ev_r=pos["ev_r"],
        exit_reason=reason,
        bars_held=max(i - pos["entry_i"], 0),
        pnl_gross=gross,
        pnl_net=net,
        r_net=(net / risk_rupees) if risk_rupees > 0 else 0.0,
        costs=c,
        iv_rank_at_entry=pos.get("iv_rank_at_entry", 0.5),
        delta_at_entry=pos.get("delta_at_entry", 0.5),
    )


def summarise(
    trades: list[Trade], capital: float, symbol: str = "", start_capital: float | None = None
) -> Book:
    """R statistics and rupee statistics of a finished book.

    ``capital`` is the ending equity (reported as-is); ``start_capital`` — the
    equity the run began with — denominates the max drawdown percentage,
    because a drawdown measured against post-profit equity understates risk.
    """
    equity = peak = max_dd = 0.0
    daily: dict[str, float] = {}
    for t in trades:
        equity += t.pnl_net
        peak = max(peak, equity)
        max_dd = max(max_dd, peak - equity)
        key = datetime.fromtimestamp(t.entry_ts, IST).date().isoformat()
        daily[key] = daily.get(key, 0.0) + t.pnl_net
    return Book(
        trades=trades,
        capital=capital,
        gross=float(sum(t.pnl_gross for t in trades)),
        net=float(sum(t.pnl_net for t in trades)),
        costs=float(sum(sum(t.costs.values()) for t in trades)),
        r_metrics=metrics([t.r_net for t in trades]),
        max_dd_pct=(100.0 * max_dd / (start_capital or capital)) if (start_capital or capital) else 0.0,
        daily_net=daily,
        symbol=symbol,
    )


def format_report(book: Book, title: str = "") -> str:
    m = book.r_metrics
    label = f"{title}{book.symbol} " if book.symbol else title
    return "\n".join(
        [
            f"{label}: {len(book.trades)} trades over {len(book.daily_net)} days",
            f"  net Rs{book.net:+,.0f} ({100.0 * book.net / book.capital:+.2f}% of capital)"
            f" | gross Rs{book.gross:+,.0f} | costs Rs{book.costs:,.0f}",
            f"  per trading day Rs{book.net / max(len(book.daily_net), 1):+,.0f}"
            f" | max DD {book.max_dd_pct:.2f}% of capital",
            f"  win rate {100 * m.win_rate:.1f}% | expectancy {m.expectancy_r:+.3f}R"
            f" | LCB {m.lcb_r:+.3f}R | PF {m.profit_factor:.2f} | totalR {m.total_r:+.2f}",
        ]
    )


def monthly_breakdown(book: Book) -> list[tuple[str, int, float]]:
    out: dict[str, list[float]] = {}
    for t in book.trades:
        key = datetime.fromtimestamp(t.entry_ts, IST).strftime("%Y-%m")
        agg = out.setdefault(key, [0, 0.0])
        agg[0] += 1
        agg[1] += t.pnl_net
    return [(k, int(v[0]), float(v[1])) for k, v in sorted(out.items())]


def exit_breakdown(book: Book) -> dict[str, tuple[int, float]]:
    out: dict[str, list[float]] = {}
    for t in book.trades:
        agg = out.setdefault(t.exit_reason, [0, 0.0])
        agg[0] += 1
        agg[1] += t.pnl_net
    return {k: (int(v[0]), float(v[1])) for k, v in sorted(out.items())}


__all__ = [
    "BAR_S",
    "Book",
    "CostModel",
    "IVRankTracker",
    "LOT_SIZES",
    "STRIDE",
    "Trade",
    "VolModel",
    "bs_delta",
    "bs_price",
    "exit_breakdown",
    "format_report",
    "monthly_breakdown",
    "next_expiry",
    "premium_at",
    "simulate",
    "summarise",
    "synthetic_leg",
]
