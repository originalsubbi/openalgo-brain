"""Decision Fusion: engine opinions -> regime, probability, expected value, candidate.

Pure. Takes the engines' reports and the tunable parameters, and answers one
question per side (LONG / SHORT): *is this trade worth taking, and why*.

Probability is a Bayesian blend. The prior is a seeded Monte Carlo of the
triple-barrier game under the posterior drift and fitted GARCH volatility, which
is honest even with zero history. The ML model's calibrated estimate then takes
over in proportion to how much it has seen: ``z = n / (n + K)``. A new model
therefore cannot override the prior on a handful of samples.
"""

from __future__ import annotations

import math
import os
from dataclasses import replace
from typing import Any

import numpy as np

from services.brain.config import ENGINE_NAMES, REGIMES, TunableParams
from services.brain.engines import (
    chart_patterns,
    market,
    math_engine,
    options,
    oi_pcr,
    orb,
    option_selling,
    patterns,
    signal,
    stat,
    swing,
    positional,
    vol_breakout,
    vwap,
)
from services.brain.engines.ml import OnlineLogit
from services.brain.labeling import deseam
from services.brain.spreads import select_spread
from services.brain.types import Candidate, EngineReport, Snapshot

CREDIBILITY_K = 60.0  # effective model samples at which the model and the prior count equally
COST_R = 0.08  # round-trip spread, slippage and charges, in units of risk
# How much of the drift-driven edge in the prior is believed. The prior simulates the
# triple-barrier game under a drift estimated from the last 40 bars. That estimate is mostly
# noise, and the candidates that get picked are the ones where the noise happens to point the
# right way, so the raw prior overstates P(target) and EV in every market, including one with
# no edge at all. The prior is therefore a blend of the zero-drift game (what a random walk
# earns) and the drift game, taken this share of the way toward the drift game.
# 0.0 = trust no drift, 1.0 = the old behaviour.
# Override with BRAIN_PRIOR_EDGE_SHRINK (0..1). Raising it makes the Brain trade more on the prior
# alone, which matters only for paper trading: live trading additionally needs a validated model.
def _shrink_from_env(default: float = 0.75) -> float:
    try:
        return min(max(float(os.getenv("BRAIN_PRIOR_EDGE_SHRINK", default)), 0.0), 1.0)
    except (TypeError, ValueError):
        return default


PRIOR_EDGE_SHRINK = _shrink_from_env()  # 0.75: see docs/brain_review_fixes.md for the sweep

#: The version of the engines' meaning.
#:
#: A stored vote is only interpretable against the engine that produced it. When
#: an engine starts reading the market differently — a session-anchored VWAP
#: instead of a multi-day one, the option-selling signal separated from the
#: directional average — every stored vote and every model trained on it means
#: something else. Bumping this epoch tells the journal to rebuild itself and
#: the champion to be retired.
FEATURE_EPOCH = "2026-11-15.1"

#: Engines that do not carry a direction of their own.
#:
#: ``option_selling`` says *which kind of trade* to take — sell premium, on this
#: side — and not which way the underlying should move. Counting it in the
#: directional average would have turned "sell a put spread" into "buy a
#: call", which is the opposite trade. It is read separately, in
#: ``evaluate``, to choose the position type.
NON_DIRECTIONAL_ENGINES = frozenset({"option_selling"})

SIGNED_KEYS = {
    "math": ["slope_z", "curv_z", "trend_angle", "trend_tstat", "cycle_mom"],
    "signal": ["kalman_vel_z", "wavelet_slope_z", "kalman_innov"],
    "stat": ["drift_z", "bayes_up_tilt"],
    "options": ["pcr_tilt", "skew_tilt", "wall_tilt", "pain_tilt"],
    "market": ["trend", "ema_dist", "flow_z", "rel_strength"],
    "patterns": [
        "doji", "engulf_bull", "engulf_bear", "harami_bull", "harami_bear",
        "hammer", "hanging_man", "inv_hammer", "shooting_star",
        "morning_star", "evening_star", "soldiers", "crows",
        "tweezer_top", "tweezer_bottom", "marubozu",
        "inside_bar", "outside_bar",
        "slope_flip", "hh_bias", "ll_bias",
    ],
    "chart_patterns": [
        "h_and_s_bear", "h_and_s_bull",
        "double_top", "double_bottom",
        "triple_top", "triple_bottom",
        "asc_triangle", "desc_triangle", "sym_triangle",
        "bull_flag", "bear_flag",
        "bull_pennant", "bear_pennant",
        "cup_handle",
        "rising_wedge", "falling_wedge",
        "rectangle",
    ],
    "swing": [
        "doji", "engulf_bull", "engulf_bear", "harami_bull", "harami_bear",
        "hammer", "hanging_man", "inv_hammer", "shooting_star",
        "morning_star", "evening_star", "soldiers", "crows",
        "tweezer_top", "tweezer_bottom", "marubozu",
        "inside_bar", "outside_bar",
        "slope_flip", "hh_bias", "ll_bias",
    ],
    "positional": [
        "doji", "engulf_bull", "engulf_bear", "harami_bull", "harami_bear",
        "hammer", "hanging_man", "inv_hammer", "shooting_star",
        "morning_star", "evening_star", "soldiers", "crows",
        "tweezer_top", "tweezer_bottom", "marubozu",
        "inside_bar", "outside_bar",
        "slope_flip", "hh_bias", "ll_bias",
    ],
    "vol_breakout": [
        "vol_breakout", "vol_atr_ratio", "vol_volume_ratio",
    ],
    "oi_pcr": [
        "oi_pcr_tilt", "oi_pain_tilt", "oi_centroid_tilt", "oi_skew_tilt",
    ],
    "vwap": [
        "vwap_dev_atr", "vwap_dev_pct", "vwap_trend",
    ],
    "orb": [
        "orb_dev_from_high", "orb_dev_from_low", "orb_range_atr",
    ],
    "option_selling": [
        "os_sell_strength", "os_skew_dir", "oi_skew",
    ],
}
NEUTRAL_KEYS = {
    "math": ["cycle_r2", "pc1_share", "rel_beta"],
    "signal": [
        "perm_entropy",
        "shannon_entropy",
        "spec_flatness",
        "lowfreq_share",
        "wavelet_noise_share",
        "dom_period",
    ],
    "stat": ["vol_ratio", "garch_persist", "sigma_h_pct", "p_up_gt_half"],
    "options": [
        "opt_available",
        "gex_sign",
        "gex_norm",
        "dist_flip",
        "atm_iv",
        "iv_rank",
        "vrp",
        "expected_move_pct",
    ],
    "market": ["adx", "rel_volume", "atr_pct", "corr_bench", "spread_pct"],
    "patterns": [
        "doji_strength", "atr_ratio", "contraction", "expansion",
        "swing_span_pct", "swing_count", "body_avg_pct",
    ],
    "chart_patterns": [
        "cp_strength", "cp_active", "cp_vol_confirm",
        "cp_trend_align", "cp_swing_count", "cp_atr_ratio",
    ],
    "swing": [
        "doji_strength", "atr_ratio", "contraction", "expansion",
        "swing_span_pct", "swing_count", "body_avg_pct",
    ],
    "positional": [
        "doji_strength", "atr_ratio", "contraction", "expansion",
        "swing_span_pct", "swing_count", "body_avg_pct",
    ],
    "vol_breakout": [
        "vol_atr_pct", "vol_atr_ratio", "vol_volume_ratio",
        "vol_expansion", "vol_quiet",
    ],
    "oi_pcr": [
        "oi_pcr", "oi_total_oi", "oi_max_pain_dist", "oi_dte",
    ],
    "vwap": [
        "vwap_vwap", "vwap_dev_atr_abs", "vwap_e9", "vwap_e21", "vwap_vol_ratio",
    ],
    "orb": [
        "orb_high", "orb_low", "orb_range_atr", "orb_minutes_since", "orb_time_decay",
    ],
    "option_selling": [
        "os_iv_rank", "os_atm_iv", "os_skew", "os_dte", "os_dte_crush", "os_strategy",
    ],
}
FEATURE_NAMES: list[str] = (
    [f"{e}.{k}" for e in ENGINE_NAMES for k in SIGNED_KEYS[e]]
    + [f"{e}.{k}" for e in ENGINE_NAMES for k in NEUTRAL_KEYS[e]]
    + ["fused", "agree_frac", "tod_sin", "tod_cos"]
    + [f"regime.{r}" for r in REGIMES]
)


def _deseam_series(raw_bars: np.ndarray, series: np.ndarray) -> np.ndarray:
    """A closes-only benchmark on the same bar grid, with the same day boundaries neutralised.

    Without opens the gap cannot be separated from the first bar's own move, so the whole
    first-bar return is taken out. A small loss of information, a large gain in consistency
    with the deseamed main series it is compared to.
    """
    day = ((raw_bars[:, 0] + 19800) // 86400).astype(np.int64)
    first = np.nonzero(np.diff(day))[0] + 1
    if first.size == 0:
        return series
    out = np.asarray(series, dtype=float).copy()
    ratio = np.ones(len(out))
    ratio[first] = out[first] / out[first - 1]
    cum = np.cumprod(ratio)  # product of every boundary jump up to each bar
    return out / cum * cum[-1]


def _engine_report(name: str, fn, snap: Snapshot, **kwargs: Any) -> EngineReport:
    """Run one engine, or return a neutral abstention when it raises.

    A single engine throwing (e.g. an eigvalsh domain error on a degenerate
    correlation matrix) used to kill all fifteen for that bar — and with them
    every signal the bar could have produced. One engine failing is one
    engine's opinion missing, not an outage.
    """
    try:
        return fn(snap, **kwargs)
    except Exception as e:  # noqa: BLE001 - isolation is the point
        return EngineReport(
            name=name,
            vote=0.0,
            confidence=0.0,
            notes=(f"engine_error: {type(e).__name__}: {e}",),
        )


def run_engines(
    snap: Snapshot, horizon: int, spread_pct: float | None = None
) -> dict[str, EngineReport]:
    # Engines read returns as diff(log(close)); take the overnight gaps out first so no return
    # spans a session boundary (the latest day is untouched, so the last bar is the real one).
    bars = deseam(snap.bars)
    bench = snap.bench_close
    if bench is not None and len(bench) == len(bars):
        bench = _deseam_series(snap.bars, bench)
    snap = replace(snap, bars=bars, bench_close=bench)
    return {
        "math": _engine_report("math", math_engine.analyze, snap),
        "signal": _engine_report("signal", signal.analyze, snap),
        "stat": _engine_report("stat", stat.analyze, snap, horizon=horizon),
        "options": _engine_report("options", options.analyze, snap),
        "market": _engine_report("market", market.analyze, snap, spread_pct=spread_pct),
        "patterns": _engine_report("patterns", patterns.analyze, snap),
        "chart_patterns": _engine_report("chart_patterns", chart_patterns.analyze, snap),
        "swing": _engine_report("swing", swing.analyze, snap),
        "positional": _engine_report("positional", positional.analyze, snap),
        "vol_breakout": _engine_report("vol_breakout", vol_breakout.analyze, snap),
        "oi_pcr": _engine_report("oi_pcr", oi_pcr.analyze, snap),
        "vwap": _engine_report("vwap", vwap.analyze, snap),
        "orb": _engine_report("orb", orb.analyze, snap),
        "option_selling": _engine_report("option_selling", option_selling.analyze, snap),
    }


def classify_regime(reports: dict[str, EngineReport]) -> str:
    vol_ratio = reports["stat"].neutral.get("vol_ratio", 0.5) * 2.0
    adx = reports["market"].neutral.get("adx", 0.3) * 50.0
    trend = abs(reports["market"].signed.get("trend", 0.0))
    if vol_ratio >= 1.35:
        return "volatile"
    if adx >= 22.0 and trend >= 0.4:
        return "trend"
    if vol_ratio <= 0.8 and adx < 18.0:
        return "quiet"
    return "range"


def fuse(
    reports: dict[str, EngineReport],
    regime: str,
    params: TunableParams,
    use_options: bool = True,
) -> tuple[float, int, dict[str, float]]:
    """Confidence-weighted vote. Returns (score in [-1, 1], engines agreeing, votes).

    An engine that abstains (confidence 0, e.g. options with no chain) is left
    out of the average entirely: counting it in the denominator would shrink
    every score toward zero for a reason unrelated to the market. With
    ``use_options`` False the options engine is observed (its vote is still
    returned and journalled, so the learner can judge it) but does not move the
    score or the agreement count.
    """
    w = params.weights.get(regime) or {}
    num = den = 0.0
    votes: dict[str, float] = {}
    agree = 0
    for name in ENGINE_NAMES:
        r = reports.get(name)
        if r is None:
            continue
        votes[name] = r.vote
        if (
            r.confidence <= 0.0
            or (name == "options" and not use_options)
            or name in NON_DIRECTIONAL_ENGINES
        ):
            continue
        weight = float(w.get(name, 1.0))
        num += weight * r.confidence * r.vote
        den += weight * r.confidence
    score = num / den if den > 0 else 0.0
    sign = 1.0 if score >= 0 else -1.0
    for name, v in votes.items():
        r = reports[name]
        if (
            r.confidence <= 0.0
            or (name == "options" and not use_options)
            or name in NON_DIRECTIONAL_ENGINES
        ):
            continue
        if abs(v) > 0.15 and (v > 0) == (sign > 0):
            agree += 1
    return float(max(-1.0, min(1.0, score))), agree, votes


def rescore(
    votes: dict[str, float],
    confs: dict[str, float],
    regime: str,
    side: str,
    params: TunableParams,
    use_options: bool = True,
) -> tuple[float, int]:
    """Re-fuse a stored decision under ``params``. Returns (side score, agreeing engines).

    The same arithmetic as ``fuse`` + ``evaluate``, driven by stored votes and
    confidences, so tuning weights and thresholds together is judged on scores
    the new weights would actually have produced, not the old ones.
    """
    w = params.weights.get(regime) or {}
    num = den = 0.0
    counted: dict[str, float] = {}
    for name in ENGINE_NAMES:
        if name not in votes:
            continue
        c = float(confs.get(name, 0.0))
        if (
            c <= 0.0
            or (name == "options" and not use_options)
            or name in NON_DIRECTIONAL_ENGINES
        ):
            continue
        wt = float(w.get(name, 1.0))
        v = float(votes[name])
        num += wt * c * v
        # The same denominator as ``fuse``: the engine's own confidence and
        # nothing else. A confidence floor added here would score every stored
        # decision on a scale the live gate never uses, and the learner tunes
        # ``min_confluence`` on these scores, so a live entry would be admitted
        # that the same threshold rejects in the backtest. Low-confidence bars
        # diverge most, which is exactly where the threshold matters.
        den += wt * c
        counted[name] = v
    fused = max(-1.0, min(1.0, num / den if den > 0 else 0.0))
    sign = 1 if side == "LONG" else -1
    agree = sum(1 for v in counted.values() if abs(v) > 0.15 and v * sign > 0)
    return sign * fused, agree


def build_features(
    reports: dict[str, EngineReport],
    regime: str,
    fused: float,
    agree: int,
    minute_of_day: int,
    sign: int,
) -> dict[str, float]:
    """One flat feature dict for one side. Directional features flip with the side."""
    f: dict[str, float] = {}
    for e in ENGINE_NAMES:
        r = reports.get(e)
        for k in SIGNED_KEYS[e]:
            f[f"{e}.{k}"] = sign * float(r.signed.get(k, 0.0) or 0.0) if r else 0.0
        for k in NEUTRAL_KEYS[e]:
            f[f"{e}.{k}"] = float(r.neutral.get(k, 0.0) or 0.0) if r else 0.0
    # Stored so the learner can re-fuse a past decision under new weights. They are
    # not in FEATURE_NAMES, so the model ignores them.
    for e in ENGINE_NAMES:
        r = reports.get(e)
        f[f"conf.{e}"] = float(r.confidence) if r else 0.0
    f["fused"] = sign * fused
    f["agree_frac"] = agree / len(ENGINE_NAMES)
    ang = 2.0 * math.pi * (minute_of_day % 1440) / 1440.0
    f["tod_sin"], f["tod_cos"] = math.sin(ang), math.cos(ang)
    for r_ in REGIMES:
        f[f"regime.{r_}"] = 1.0 if r_ == regime else 0.0
    return f


def prior_probabilities(
    reports: dict[str, EngineReport],
    sign: int,
    k_stop: float,
    k_target: float,
    horizon: int,
    edge_shrink: float | None = None,
) -> dict[str, float] | None:
    """Barrier-game odds for one side: zero-drift baseline plus a shrunk share of the drift edge.

    Both simulations use the same seeded noise, so their difference is the effect of the
    drift estimate alone and the blend does not add Monte Carlo jitter.
    """
    st = reports.get("stat")
    if st is None or not st.extras:
        return None
    lam = PRIOR_EDGE_SHRINK if edge_shrink is None else edge_shrink
    lam = min(max(float(lam), 0.0), 1.0)
    ex = st.extras
    if "sigma_path" in ex:
        sigma = np.asarray(ex["sigma_path"], dtype=float)[:horizon]
        mu = np.asarray(ex["mu_path"], dtype=float)[:horizon]
        sig_h = float(ex["sigma_h"])
        if len(sigma) < horizon:  # horizon longer than the stored path: hold the last bar's level
            pad = horizon - len(sigma)
            sigma = np.concatenate([sigma, np.full(pad, sigma[-1])])
            mu = np.concatenate([mu, np.full(pad, mu[-1])])
            sig_h = float(np.sqrt(np.sum(sigma**2)))
    else:  # an engine report without per-bar paths: constant per-bar sigma and drift
        g = ex["garch"]
        sig_h = stat.horizon_sigma(g, horizon)
        sigma, mu = math.sqrt(g["var_next"]), ex["mu_bar"]
    stop_d, tgt_d = k_stop * sig_h, k_target * sig_h
    base = stat.barrier_probabilities(0.0, sigma, stop_d, tgt_d, horizon)
    if lam <= 0.0:
        blended = base
    else:
        drift = stat.barrier_probabilities(sign * mu, sigma, stop_d, tgt_d, horizon)
        blended = {k: base[k] + lam * (drift[k] - base[k]) for k in base}
    return {**blended, "sigma_h": sig_h}


def short_premium_side(
    reports: dict[str, EngineReport], params: TunableParams
) -> str | None:
    """Which side, if any, should be traded by *selling* premium.

    ``None`` means the Brain buys premium as usual. A side means: sell a credit
    spread on that side, because implied volatility is rich and the skew says
    which side's premium is the expensive one.

    The engine's own vote is signed (positive = sell a put spread), so a
    positive vote points at the LONG side of the underlying (a bullish credit
    put spread) and a negative vote at the SHORT side.
    """
    if not params.short_premium_enabled:
        return None
    r = reports.get("option_selling")
    if r is None:
        return None
    strength = float(r.signed.get("os_sell_strength", 0.0))
    direction = float(r.signed.get("os_skew_dir", 0.0))
    if strength <= 0.0 or abs(direction) <= 0.15:
        return None
    return "LONG" if direction > 0 else "SHORT"


def evaluate(
    snap: Snapshot,
    reports: dict[str, EngineReport],
    params: TunableParams,
    model: OnlineLogit | None = None,
    cost_r: float = COST_R,
    use_options: bool = True,
) -> list[Candidate]:
    """Both sides, fully scored. ``passed`` says whether the thresholds are met."""
    regime = classify_regime(reports)
    score, agree_all, votes = fuse(reports, regime, params, use_options)
    counted = {
        n: v
        for n, v in votes.items()
        if reports[n].confidence > 0.0
        and (use_options or n != "options")
        and n not in NON_DIRECTIONAL_ENGINES
    }
    out: list[Candidate] = []
    rr = params.k_target / params.k_stop
    sell_side = short_premium_side(reports, params)
    spread_geo: dict[str, Any] | None = None
    if sell_side is not None:
        # The spread has to exist before the side can be traded at all: no
        # tradable credit spread on this chain means no short-premium trade.
        spread_geo = select_spread(snap.chain, sell_side, snap.spot, params)
        if spread_geo is None:
            sell_side = None
    for side, sign in (("LONG", 1), ("SHORT", -1)):
        is_sell = side == sell_side
        # A short-premium trade wins when the underlying moves the OTHER way:
        # a short put spread wants the index down, a short call spread wants it
        # up. The prior for that direction is the other side's prior.
        prior_sign = -sign if is_sell else sign
        prior = prior_probabilities(
            reports, prior_sign, params.k_stop, params.k_target, params.horizon_bars
        )
        if prior is None:
            continue
        side_score = sign * score
        agree = sum(1 for v in counted.values() if abs(v) > 0.15 and (v * sign) > 0)
        feats = build_features(reports, regime, score, agree, snap.minute_of_day, sign)

        p_prior = prior["p_target"]  # timeouts are not wins
        p_ml = None
        if model is not None and model.credibility_n > 0 and not is_sell:
            # The model was trained on long-premium outcomes. It has never seen a
            # credit spread, so its probability is not used to size one.
            p_ml = model.predict(feats)
        z = model_weight(model) if p_ml is not None else 0.0
        p = z * (p_ml if p_ml is not None else 0.0) + (1.0 - z) * p_prior

        # Split the non-win mass between stop and timeout in the prior's proportions.
        lose_mass = max(1.0 - p, 0.0)
        denom = prior["p_stop"] + prior["p_timeout"]
        q_stop = lose_mass * (prior["p_stop"] / denom) if denom > 1e-9 else lose_mass
        q_to = lose_mass - q_stop
        mean_r_timeout = 0.0  # conservative: a timeout is worth nothing before costs
        side_rr = rr
        if is_sell and spread_geo is not None:
            # The spread's own reward-to-risk: half the credit taken against a
            # loss of the full strike width.
            side_rr = float(spread_geo["rr"])
        ev_r = p * side_rr - q_stop + q_to * mean_r_timeout - cost_r

        reasons, reject = [], ""
        # NaN comparisons are always False, so a bare ``<`` gate would let a
        # non-finite score/probability/EV sail through as a pass. Non-finite
        # is no opinion: hard reject, never fail open.
        if not (
            math.isfinite(side_score) and math.isfinite(p) and math.isfinite(ev_r)
        ):
            reject = "non-finite score/probability/EV"
        elif side_score < params.min_confluence:
            reject = f"confluence {side_score:.2f} < {params.min_confluence:.2f}"
        elif agree < params.min_agree:
            reject = f"only {agree} engines agree (< {params.min_agree})"
        elif p < params.min_prob:
            reject = f"probability {p:.2f} < {params.min_prob:.2f}"
        elif ev_r < params.min_ev_r:
            reject = f"EV {ev_r:+.2f}R < {params.min_ev_r:.2f}R"
        passed = reject == ""
        if passed:
            top = sorted(((n_, v * sign) for n_, v in counted.items()), key=lambda kv: -abs(kv[1]))[
                :3
            ]
            reasons = [
                f"regime={regime}",
                *[f"{n_} {v:+.2f}" for n_, v in top],
                f"p={p:.2f} (prior {p_prior:.2f}, model weight {z:.2f})",
                f"EV={ev_r:+.2f}R",
            ]
            if is_sell and spread_geo is not None:
                reasons.append(
                    f"sell credit spread: credit {spread_geo['credit']:.1f} "
                    f"width {spread_geo['width']:.0f} max loss {spread_geo['max_loss']:.1f}"
                )
        out.append(
            Candidate(
                underlying=snap.underlying,
                side=side,
                position_type="short" if is_sell else "long",
                regime=regime,
                score=float(side_score),
                agree=agree,
                prob=float(p),
                prob_prior=float(p_prior),
                ev_r=float(ev_r),
                rr=float(side_rr),
                sigma_h=float(prior["sigma_h"]),
                k_stop=params.k_stop,
                k_target=params.k_target,
                horizon_bars=params.horizon_bars,
                features=feats,
                votes={k: float(v) for k, v in votes.items()},
                reasons=tuple(reasons),
                passed=passed,
                reject=reject,
            )
        )
    return out


def model_weight(model: OnlineLogit | None) -> float:
    """Share of the probability that comes from the model rather than the prior.

    Built from the model's effective sample size (distinct rows, overlapping labels
    discounted), so a model fitted for three epochs on 150 overlapping rows is not credited
    with 450 independent observations.
    """
    if model is None:
        return 0.0
    n = float(model.credibility_n)
    return n / (n + CREDIBILITY_K) if n > 0 else 0.0


def best(cands: list[Candidate]) -> Candidate | None:
    ok = [c for c in cands if c.passed]
    return max(ok, key=lambda c: c.ev_r) if ok else None


def dump(c: Candidate) -> dict[str, Any]:
    return {
        "underlying": c.underlying,
        "side": c.side,
        "regime": c.regime,
        "score": round(c.score, 3),
        "agree": c.agree,
        "prob": round(c.prob, 3),
        "prob_prior": round(c.prob_prior, 3),
        "ev_r": round(c.ev_r, 3),
        "rr": round(c.rr, 2),
        "sigma_h": c.sigma_h,
        "horizon_bars": c.horizon_bars,
        "passed": c.passed,
        "reject": c.reject,
        "reasons": list(c.reasons),
        "votes": {k: round(v, 3) for k, v in c.votes.items()},
    }


__all__ = [
    "FEATURE_NAMES",
    "best",
    "build_features",
    "classify_regime",
    "dump",
    "evaluate",
    "rescore",
    "fuse",
    "model_weight",
    "run_engines",
    "np",
]
