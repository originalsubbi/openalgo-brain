"""Feature gate: extra filters applied after fusion.evaluate, before order dispatch.

The gate lives between the engine score and the broker pipe. It answers one
question per candidate: *given what we know right now, should this trade be
taken at all*. Unlike ``fusion.evaluate`` (which scores every candidate) the
gate is cheap — it reads from the snapshot and a few global constants rather
than re-running engines or hitting the database.

Two reasons to keep it separate:

1. The gates are human-owned policy, not learned parameters. A trader changes
   them directly in the environment instead of waiting for the learner to find
   them.
2. A gate that fails is a hard refusal: the candidate disappears from the
   scan summary and the journal writes ``BLOCKED`` with the reason. The
   learner reads these rows and can see when the gate is the thing keeping
   bad trades out.

The default set covers three failure modes the edge study showed most clearly:

symbol_excluded
    a hardcoded list of underlyings whose prior is demonstrably negative
    across every configuration tested; trade them and the pool drags down.

iv_extreme
    IV rank below 0.10 or above 0.90: the distribution is so fat-tailed that
    the triple-barrier R scale becomes unreliable and every label is noise.

consecutive_loss_halt
    ``RiskLimits.consecutive_loss_halt`` consecutive losing trades; no new
    risk is taken until a win resets the streak.

drawdown_halt
    the equity curve has fallen more than ``RiskLimits.drawdown_halt_pct``
    (a fraction of the peak, ``BRAIN_DRAWDOWN_HALT_PCT``) below its peak.

Future gates (vol-compression squeeze, benchmark-momentum collapse, etc.)
belong here, not in the engines or in fusion, because they are policy, not
signal.
"""

from __future__ import annotations

import os
from typing import Any

from database import brain_db as _db
from services.brain.knobs import BrainTuneParams, DEFAULT_TUNE_KNOBS
from services.brain.types import Candidate, Snapshot

# Underlyings excluded from trading because the walk-forward study found their
# pooled expectancy negative across every barrier grid (h=6..24, ks=0.6..1.5).
# Add an underlying here once you have the evidence; do not remove it without
# rerunning the study against the new configuration first.
_EXCLUDED_UNDERLYINGS: tuple[str, ...] = ("BANKNIFTY",)


def _excluded_underlyings() -> tuple[str, ...]:
    """Exclusion list, editable without a code change.

    ``BRAIN_EXCLUDED_UNDERLYINGS`` is a comma list (``NIFTY,SENSEX``); an empty
    value excludes nothing. Unset keeps the study-backed default above.
    """
    raw = os.getenv("BRAIN_EXCLUDED_UNDERLYINGS")
    if raw is None:
        return _EXCLUDED_UNDERLYINGS
    return tuple(x.strip().upper() for x in raw.split(",") if x.strip())

#: Persisted key for the live-adaptive IV-band state. Reads/writes are gated by
#: the same ``db.state_get`` / ``db.state_set`` helpers the rest of Brain uses.
_IV_STATE_KEY = "gate_iv_tune"
#: Hard floor/ceiling on any adaptive band so a mis-calibrated tuner cannot
#: widen past something that would let every trade through or block all of them.
# (the IV-band floor, ceiling, throttle and sample floor are tune-knobs now: see knobs.py)
_IV_BAND_HARD_FLOOR = 0.05
_IV_BAND_HARD_CEILING = 0.95
#: Seconds between IV-band re-computations. Kept short so a vol-of-vol regime
#: shift closes in on the same day rather than waiting hours.
_IV_TUNE_THROTTLE_S = 600
#: At least this many closed fusion trades must carry an iv_rank sample before
#: we trust the distribution enough to shift the band.
_IV_TUNE_MIN_SAMPLES = 20


def _limits(limits: Any = None) -> Any:
    """The human-owned limits: the ones passed in, else rebuilt from .env."""
    if limits is not None:
        return limits
    from services.brain.config import RiskLimits

    return RiskLimits.from_env()


def _drawdown_halt_pct(limits: Any = None) -> float:
    """Drawdown-halt threshold as a fraction of the equity peak (0.03 = 3 %).

    Human-owned: ``RiskLimits.drawdown_halt_pct`` (``BRAIN_DRAWDOWN_HALT_PCT``,
    editable in the UI). 0 disables the halt; an out-of-range value falls back to 0.03.
    """
    return float(_limits(limits).drawdown_halt_pct)


def _consecutive_loss_halt(limits: Any = None) -> int:
    """Consecutive losing TRADES that halt new entries; 0 disables.

    Human-owned: ``RiskLimits.consecutive_loss_halt``
    (``BRAIN_CONSECUTIVE_LOSS_HALT``, editable in the UI).
    """
    return int(_limits(limits).consecutive_loss_halt)


def is_symbol_allowed(underlying: str) -> bool:
    """Return False when the underlying is in the exclusion list."""
    return underlying.upper() not in _excluded_underlyings()


def is_vol_regime_ok(snap: Snapshot, knobs: BrainTuneParams | None = None) -> bool:
    """IV rank must sit inside the adaptive band.

    The base band defaults to the walk-forward-study bounds [0.10, 0.90].
    When the market is in an extreme-IV regime (rank already outside roughly
    the middle third) the band narrows inward so buying premium when IV is
    near-cap or selling it when IV is near-floor does not slip through. The
    opposite direction is not applied: a quiet market deserves *wider* bands,
    not tighter ones — the edge is harder to find there and we should not
    auto-reject candidates that the human would still want to see.
    """
    iv_rank = snap.iv_rank
    if iv_rank is None:
        return True  # unknown IV: cannot judge, let it through
    lo, hi = iv_band(snap, knobs)
    return lo <= iv_rank <= hi


def iv_band(snap: Snapshot, knobs: BrainTuneParams | None = None) -> tuple[float, float]:
    """Return ``(lo, hi)`` for the current IV-regime gate.

    Reads the persisted band from ``_IV_STATE_KEY`` and then applies the
    vol-of-vol tightening rule based on the snapshot's own IV rank. Falls back
    to the static constants when nothing is stored yet.
    """
    k = knobs or DEFAULT_TUNE_KNOBS
    try:
        raw = _db.state_get(_IV_STATE_KEY)
        if isinstance(raw, dict):
            lo = float(raw.get("lo", 0.10))
            hi = float(raw.get("hi", 0.90))
        else:
            lo, hi = 0.10, 0.90
    except Exception:  # DB errors are non-fatal; the gate stays conservative
        lo, hi = 0.10, 0.90
    lo = max(lo, k.iv_band_hard_floor)
    hi = min(hi, k.iv_band_hard_ceiling)
    # Vol-of-vol tightening: when IV rank itself is extreme, narrow the band
    # from the inside so a candidate near the edge gets rejected outright.
    if snap.iv_rank is not None:
        r = float(snap.iv_rank)
        if r > 0.80:
            hi = min(hi, r - 0.05)
        elif r < 0.20:
            lo = max(lo, r + 0.05)
    return lo, hi


def tune_iv_band(now: float, knobs: BrainTuneParams | None = None) -> dict[str, Any] | None:
    """Re-derive the IV band from recent closed-trade IV distribution.

    Throttled internally via the persisted last-tune timestamp. Writes the new
    band back into ``_IV_STATE_KEY`` so subsequent calls to ``iv_band`` pick it
    up immediately. Returns ``None`` when throttled or under the sample floor;
    otherwise returns a summary dict the caller can log.
    """
    k = knobs or DEFAULT_TUNE_KNOBS
    try:
        stored = _db.state_get(_IV_STATE_KEY)
        last_ts = float((stored or {}).get("ts", 0)) if isinstance(stored, dict) else 0.0
        if now - last_ts < k.iv_tune_throttle_s:
            return None
        # Pull iv_rank samples from recently-closed fusion trades. We read the
        # database directly; apply_gate does not import it so we keep the loop
        # clean.
        rows = _db.positions_closed(limit=200)
        samples: list[float] = []
        for row in rows:
            ivr = row.get("iv_rank")
            if ivr is not None:
                try:
                    v = float(ivr)
                    if 0.0 <= v <= 1.0:
                        samples.append(v)
                except (TypeError, ValueError):
                    pass
        if len(samples) < k.iv_tune_min_samples:
            return None
        # Use the empirical 10th and 90th percentiles as the band edges. This
        # is intentionally one-sided: the 10th percentile protects against
        # over-buying in thin-premium regimes; the 90th protects against
        # over-selling in panic regimes. A wider empirical range would risk
        # letting every signal through during calm periods.
        ss = sorted(samples)
        n = len(ss)
        lo = ss[max(0, int(n * 0.10))]
        hi = ss[min(n - 1, int(n * 0.90))]
        lo = max(lo, k.iv_band_hard_floor)
        hi = min(hi, k.iv_band_hard_ceiling)
        if hi <= lo:
            return None  # degenerate distribution; leave the old band alone
        payload = {"lo": round(lo, 3), "hi": round(hi, 3), "n": n, "ts": now}
        _db.state_set(_IV_STATE_KEY, payload)
        return payload
    except Exception:
        return None


def is_momentum_benign(snap: Snapshot) -> bool:
    """Benchmark move over the last 12 bars must not be extreme.

    A benchmark that gapped > 1.5 % in either direction in the last hour means
    the market is in a news-driven state; the Engines' drift estimates are
    garbage and the candidate's EV is unreliable. Skip such signals.

    Computed from ``snap.bench_close`` when available; falls through when the
    benchmark series is absent (backtest / missing peer).
    """
    bc = snap.bench_close
    if bc is None or len(bc) < 12:
        return True
    try:
        ref = float(bc[-12])
        cur = float(bc[-1])
        if ref <= 0:
            return True
        return abs((cur - ref) / ref) < 0.015
    except (TypeError, ValueError):
        return True


def apply_gate(
    candidates: list[Candidate],
    snap: Snapshot,
    params: Any,
    *,
    daily_pnl: float = 0.0,
    equity_peak: float = 0.0,
    consecutive_losses: int = 0,
    knobs: BrainTuneParams | None = None,
    limits: Any = None,
) -> tuple[list[Candidate], dict[int, str]]:
    """Filter ``candidates`` through every enabled gate.

    Returns ``(kept, reasons)`` where ``reasons`` maps each rejected candidate's
    Python object id to the first gate reason that fired. The caller writes
    these into the journal as ``gate_reasons``.
    """
    kept: list[Candidate] = []
    reasons: dict[int, str] = {}
    drawdown_halt = _drawdown_halt_pct(limits)
    loss_halt_n = _consecutive_loss_halt(limits)

    for c in candidates:
        why: list[str] = []

        if not is_symbol_allowed(c.underlying):
            why.append("symbol_excluded")

        if not is_vol_regime_ok(snap, knobs):
            why.append("iv_extreme")

        if not is_momentum_benign(snap):
            why.append("momentum_extreme")

        if drawdown_halt > 0 and equity_peak > 0:
            drawdown = (equity_peak - daily_pnl) / equity_peak
            if drawdown >= drawdown_halt:
                why.append("drawdown_halt")

        if loss_halt_n > 0 and consecutive_losses >= loss_halt_n:
            why.append("consecutive_loss_halt")

        if why:
            reasons[id(c)] = "; ".join(why)
        else:
            kept.append(c)

    return kept, reasons
