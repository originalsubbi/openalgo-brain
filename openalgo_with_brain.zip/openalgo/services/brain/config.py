"""Configuration for the AI Brain, split by who is allowed to change it.

``RiskLimits``  - human-owned. Read once from ``BRAIN_*`` environment variables,
                  frozen, consumed by ``risk_gate`` and ``executor`` only.
                  Nothing in ``learner`` or ``fusion`` imports it.
``TunableParams`` - machine-owned. The learner may change these, always through
                    ``clamp`` so a bad search step can never leave the bounds.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field, replace
from typing import Any

ENGINE_NAMES = (
    "math",
    "signal",
    "stat",
    "options",
    "market",
    "patterns",
    "chart_patterns",
    "swing",
    "positional",
    "vol_breakout",
    "oi_pcr",
    "vwap",
    "orb",
    "option_selling",
)
REGIMES = ("trend", "range", "volatile", "quiet")


def _f(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except (TypeError, ValueError):
        return float(default)


def _i(name: str, default: int) -> int:
    try:
        return int(float(os.getenv(name, default)))
    except (TypeError, ValueError):
        return int(default)


def _b(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def _hhmm(text: str) -> int:
    """'09:30' -> minutes since midnight (IST wall clock)."""
    hh, mm = text.strip().split(":")
    return int(hh) * 60 + int(mm)


def _halt_frac(value: float, default: float) -> float:
    """A drawdown-halt fraction: 0 disables it, 0 < v < 1 is used, anything else -> default."""
    if value != value:  # NaN
        return default
    return value if 0.0 <= value < 1.0 else default


@dataclass(frozen=True, slots=True)
class RiskLimits:
    """Fixed rules. Changed only by editing the environment and restarting."""

    capital_base: float = 0.0  # 0 = use available funds reported by the broker
    risk_per_trade_pct: float = 0.5
    max_daily_loss_pct: float = 1.5
    max_open_positions: int = 2
    max_open_per_underlying: int = 1  # one position per underlying: no stacking
    max_trades_per_day: int = 6
    max_lots: int = 5
    max_exposure_pct: float = 25.0  # premium outlay as % of capital
    max_consecutive_losses: int = 3
    cooldown_minutes: int = 45
    # Entry window: 09:35-13:00 IST per research — skip the first 30 minutes
    # (opening volatility) and stop before 13:00 (theta cliff). This is THE
    # single source of truth: the live gate (orchestrator.entry_window_ok),
    # the learner's takeable() replay filter and the label windows all read
    # it, so BRAIN_ENTRY_START / BRAIN_ENTRY_CUTOFF move them together.
    entry_start_min: int = 9 * 60 + 35
    entry_cutoff_min: int = 13 * 60
    squareoff_min: int = 15 * 60 + 15
    # Expiry-day square-off for open options: out by this IST minute on the
    # contract's expiry day, before settlement-pin behaviour the stop/target
    # policy was never priced for. Human-owned, like squareoff_min.
    expiry_squareoff_min: int = 14 * 60 + 45
    max_spread_pct: float = 3.0
    min_premium: float = 5.0
    # Cheap-premium cap: proposals with a per-unit premium above this are
    # denied. 0 = no cap. Human-owned, like min_premium — the "cheap premium"
    # preference that keeps the Brain hunting low-rupee options.
    max_premium: float = 0.0
    min_leg_oi: int = 500  # a strike thinner than this open interest is not tradable
    max_margin_pct: float = 20.0  # share of available funds one position may tie up
    margin_factor: float = 0.25  # SPAN proxy: margin as a share of a spread's width
    max_data_age_s: float = 45.0  # seconds since the market data was last fetched
    max_bar_lag_s: float = 150.0  # seconds the newest completed 5-minute bar may be behind
    max_drawdown_pct: float = 6.0  # of capital, from the Brain's own equity peak
    # Feature-gate halts (gate.apply_gate). Both were hidden .env-only knobs.
    # drawdown_halt_pct is a FRACTION of the equity peak (0.03 = 3 %), kept as a
    # fraction so existing BRAIN_DRAWDOWN_HALT_PCT values keep their meaning; 0 = off.
    # consecutive_loss_halt counts consecutive losing TRADES; 0 = off.
    drawdown_halt_pct: float = 0.03
    consecutive_loss_halt: int = 5
    live_enabled: bool = False
    # Live trading is judged on the paper record by a lower confidence bound, not a point
    # estimate: with ~50 trades the standard error of expectancy is ~0.15R, three times the old
    # 0.05R bar, and a strategy with no edge cleared it about 3 times in 10. At 150 trades and a
    # one-sided 95% bound that falls to about 1 in 20.
    live_min_trades: int = 150
    live_min_expectancy_r: float = 0.05
    live_lcb_sigmas: float = 1.645  # standard errors subtracted from the paper expectancy
    live_min_lcb_r: float = 0.0  # ...and what must still be left after subtracting them
    live_min_profit_factor: float = 1.15
    live_max_drawdown_r: float = 8.0
    # Swing / Positional hold limits (days). Intraday positions still square off at
    # squareoff_min; swing/positional may carry overnight up to these limits.
    swing_max_hold_days: int = 5
    positional_max_hold_days: int = 20
    swing_max_daily_loss_pct: float = 1.0
    positional_max_daily_loss_pct: float = 2.0
    swing_margin_factor: float = 0.30  # margin as share of available funds for swing
    positional_margin_factor: float = 0.40  # margin as share of available funds for positional
    # Near-target profit buffer (percent). When > 0, a position whose last price
    # is within this percent of target is treated as target hit and profit is
    # booked immediately, so a reversal just before target doesn't give back the
    # gain. 0 = off (exact target required, the historic behaviour).
    target_buffer_pct: float = 0.0
    # Hedge protection. A credit spread's protective (bought) leg is paid at the
    # ask and sold back at the bid, so a wide quote there is a direct cost and
    # the leg that must be exitable in a hurry. Capped on its own, because
    # far-OTM wings are quoted wider than the sold leg and a shared cap either
    # rejects every spread or loosens the sold-leg cap to let one through. The
    # default equals max_spread_pct, which is what both legs were held to before
    # this knob existed.
    max_hedge_spread_pct: float = 3.0
    # Cheap/expiry sidecar (services/brain/premiumCheapExp.py). The module reads
    # BRAIN_CHEAP_* itself on every call; these mirror it so the Brain page and
    # /brain/api/limits see and edit the same values. Bounds match the module's.
    cheap_mode_enabled: bool = False
    cheap_premium_max: float = 50.0
    cheap_premium_min: float = 15.0
    cheap_risk_rupees: float = 500.0
    cheap_max_lots: int = 2
    cheap_max_daily_risk_pct: float = 2.0
    cheap_expiry_start_min: int = 10 * 60
    cheap_expiry_cutoff_min: int = 14 * 60
    cheap_max_spread_ticks: int = 2
    # Cheap/expiry paper trades needed before it may go live. Defaults to
    # live_min_trades when BRAIN_CHEAP_GRADUATION_MIN_TRADES is not set.
    cheap_graduation_min_trades: int = 150

    @classmethod
    def from_env(cls) -> RiskLimits:
        d = cls()
        return cls(
            capital_base=_f("BRAIN_CAPITAL", d.capital_base),
            risk_per_trade_pct=_f("BRAIN_RISK_PER_TRADE_PCT", d.risk_per_trade_pct),
            max_daily_loss_pct=_f("BRAIN_MAX_DAILY_LOSS_PCT", d.max_daily_loss_pct),
            max_open_positions=_i("BRAIN_MAX_OPEN_POSITIONS", d.max_open_positions),
            max_open_per_underlying=_i("BRAIN_MAX_OPEN_PER_UNDERLYING", d.max_open_per_underlying),
            max_trades_per_day=_i("BRAIN_MAX_TRADES_PER_DAY", d.max_trades_per_day),
            max_lots=_i("BRAIN_MAX_LOTS", d.max_lots),
            max_exposure_pct=_f("BRAIN_MAX_EXPOSURE_PCT", d.max_exposure_pct),
            max_consecutive_losses=_i("BRAIN_MAX_CONSECUTIVE_LOSSES", d.max_consecutive_losses),
            cooldown_minutes=_i("BRAIN_COOLDOWN_MINUTES", d.cooldown_minutes),
            entry_start_min=_hhmm(os.getenv("BRAIN_ENTRY_START", "09:35")),
            entry_cutoff_min=_hhmm(os.getenv("BRAIN_ENTRY_CUTOFF", "13:00")),
            squareoff_min=_hhmm(os.getenv("BRAIN_SQUAREOFF", "15:15")),
            expiry_squareoff_min=_hhmm(os.getenv("BRAIN_EXPIRY_SQUAREOFF", "14:45")),
            max_spread_pct=_f("BRAIN_MAX_SPREAD_PCT", d.max_spread_pct),
            min_premium=_f("BRAIN_MIN_PREMIUM", d.min_premium),
            max_premium=_f("BRAIN_MAX_PREMIUM", d.max_premium),
            min_leg_oi=_i("BRAIN_MIN_LEG_OI", d.min_leg_oi),
            max_margin_pct=_f("BRAIN_MAX_MARGIN_PCT", d.max_margin_pct),
            margin_factor=_f("BRAIN_MARGIN_FACTOR", d.margin_factor),
            max_data_age_s=_f("BRAIN_MAX_DATA_AGE_S", d.max_data_age_s),
            max_bar_lag_s=_f("BRAIN_MAX_BAR_LAG_S", d.max_bar_lag_s),
            max_drawdown_pct=_f("BRAIN_MAX_DRAWDOWN_PCT", d.max_drawdown_pct),
            drawdown_halt_pct=_halt_frac(
                _f("BRAIN_DRAWDOWN_HALT_PCT", d.drawdown_halt_pct), d.drawdown_halt_pct
            ),
            consecutive_loss_halt=max(
                0, _i("BRAIN_CONSECUTIVE_LOSS_HALT", d.consecutive_loss_halt)
            ),
            live_enabled=_b("BRAIN_LIVE_ENABLED", d.live_enabled),
            live_min_trades=_i("BRAIN_LIVE_MIN_TRADES", d.live_min_trades),
            live_min_expectancy_r=_f("BRAIN_LIVE_MIN_EXPECTANCY_R", d.live_min_expectancy_r),
            live_lcb_sigmas=_f("BRAIN_LIVE_LCB_SIGMAS", d.live_lcb_sigmas),
            live_min_lcb_r=_f("BRAIN_LIVE_MIN_LCB_R", d.live_min_lcb_r),
            live_min_profit_factor=_f("BRAIN_LIVE_MIN_PROFIT_FACTOR", d.live_min_profit_factor),
            live_max_drawdown_r=_f("BRAIN_LIVE_MAX_DRAWDOWN_R", d.live_max_drawdown_r),
            # Swing / positional limits
            swing_max_hold_days=_i("BRAIN_SWING_MAX_HOLD_DAYS", d.swing_max_hold_days),
            positional_max_hold_days=_i(
                "BRAIN_POSITIONAL_MAX_HOLD_DAYS", d.positional_max_hold_days
            ),
            swing_max_daily_loss_pct=_f(
                "BRAIN_SWING_MAX_DAILY_LOSS_PCT", d.swing_max_daily_loss_pct
            ),
            positional_max_daily_loss_pct=_f(
                "BRAIN_POSITIONAL_MAX_DAILY_LOSS_PCT", d.positional_max_daily_loss_pct
            ),
            swing_margin_factor=_f("BRAIN_SWING_MARGIN_FACTOR", d.swing_margin_factor),
            positional_margin_factor=_f(
                "BRAIN_POSITIONAL_MARGIN_FACTOR", d.positional_margin_factor
            ),
            target_buffer_pct=_f("BRAIN_TARGET_BUFFER_PCT", d.target_buffer_pct),
            max_hedge_spread_pct=_f("BRAIN_MAX_HEDGE_SPREAD_PCT", d.max_hedge_spread_pct),
            cheap_mode_enabled=_b("BRAIN_CHEAP_MODE", d.cheap_mode_enabled),
            cheap_premium_max=max(_f("BRAIN_CHEAP_PREMIUM_MAX", d.cheap_premium_max), 5.0),
            cheap_premium_min=min(
                max(_f("BRAIN_CHEAP_PREMIUM_MIN", d.cheap_premium_min), 1.0), 99.0
            ),
            cheap_risk_rupees=max(_f("BRAIN_CHEAP_RISK_RUPEES", d.cheap_risk_rupees), 50.0),
            cheap_max_lots=max(_i("BRAIN_CHEAP_MAX_LOTS", d.cheap_max_lots), 1),
            cheap_max_daily_risk_pct=min(
                max(_f("BRAIN_CHEAP_MAX_DAILY_RISK_PCT", d.cheap_max_daily_risk_pct), 0.5), 10.0
            ),
            cheap_expiry_start_min=_hhmm(os.getenv("BRAIN_CHEAP_EXPIRY_START", "10:00")),
            cheap_expiry_cutoff_min=_hhmm(os.getenv("BRAIN_CHEAP_EXPIRY_CUTOFF", "14:00")),
            cheap_max_spread_ticks=max(
                _i("BRAIN_CHEAP_MAX_SPREAD_TICKS", d.cheap_max_spread_ticks), 1
            ),
            cheap_graduation_min_trades=_i(
                "BRAIN_CHEAP_GRADUATION_MIN_TRADES",
                _i("BRAIN_LIVE_MIN_TRADES", d.live_min_trades),
            ),
        )

    def as_dict(self) -> dict[str, Any]:
        return {name: getattr(self, name) for name in self.__slots__}


# name -> (low, high). The learner may move a value anywhere inside, never outside.
PARAM_BOUNDS: dict[str, tuple[float, float]] = {
    "k_stop": (0.6, 2.5),  # stop distance, in horizon sigmas of the underlying
    "k_target": (0.8, 5.0),  # target distance, in horizon sigmas
    "horizon_bars": (6, 36),  # 5-minute bars a trade is allowed to live
    "min_prob": (0.10, 0.70),  # P(target before stop); small by nature, EV is the real filter
    "min_ev_r": (0.0, 0.60),
    "min_confluence": (0.10, 0.80),  # |fused score|
    "min_agree": (2, 5),  # engines that must agree on the side
    "trail_trigger_r": (0.5, 2.0),
    "trail_gap_r": (0.3, 1.5),
    # Swing/positional specific
    "swing_k_stop": (1.0, 4.0),  # swing stop distance in ATR multiples
    "swing_k_target": (1.5, 5.0),  # swing target distance in ATR multiples
    "swing_horizon_bars": (5, 20),  # swing horizon in days
    "positional_k_stop": (1.5, 6.0),  # positional stop distance in ATR multiples
    "positional_k_target": (2.0, 8.0),  # positional target distance in ATR multiples
    "positional_horizon_bars": (10, 40),  # positional horizon in trading days
    # Volatility breakout specific
    "vol_breakout_atr_mult": (1.2, 2.5),  # ATR expansion multiplier threshold
    "vol_breakout_vol_mult": (1.0, 2.0),  # volume confirmation multiplier
    # OI/PCR specific
    "oi_pcr_panic": (1.20, 2.00),  # PCR above this = put panic (contrarian buy)
    "oi_pcr_euphoria": (0.50, 0.80),  # PCR below this = call euphoria (contrarian sell)
    "oi_pain_weight": (0.0, 1.0),  # weight of max-pain gravity signal
    # VWAP specific
    "vwap_dev_atr": (1.0, 3.0),  # ATR deviation from VWAP for mean reversion
    "vwap_pullback_atr": (0.2, 1.0),  # ATR within VWAP for pullback entry
    # ORB specific
    "orb_range_atr_min": (0.3, 1.5),  # min OR range in ATR for valid breakout
    "orb_decay_min": (30, 180),  # minutes after open for OR signal decay
    # IV regime (the buyer/seller switch)
    "iv_rank_skip": (0.40, 0.90),  # above this, long premium is not worth buying
    "iv_rank_cheap": (0.10, 0.50),  # below this, premium is cheap and the buyer is favoured
    # Expiry selection
    "min_dte_days": (0, 10),  # never buy a contract with fewer than this many days left
    "max_dte_days": (3, 45),  # ...nor one with more than this many (theta is dead money)
    # Option selling
    "os_sell_delta": (0.10, 0.40),  # target delta of the leg that is sold
    "os_hedge_delta": (0.02, 0.15),  # target delta of the protective leg
    "os_min_credit_pct": (0.05, 0.50),  # credit as a share of the sold leg's premium
    "os_min_credit_points": (1.0, 20.0),  # absolute credit floor, in premium points
    "os_iv_rank_skip": (0.40, 0.90),  # IV rank at which premium is worth selling
    "os_iv_rank_cheap": (0.10, 0.50),  # below this, the credit is too thin to sell
    "short_premium_enabled": (0, 1),  # 1 = the Brain may sell defined-risk spreads
    # Cheap/expiry sidecar. Same bounds as premiumCheapExp.load_config clamps to.
    "cheap_reach_sigma": (0.5, 2.0),  # underlying move needed to double the premium, in sigmas
    "cheap_stop_pct": (0.15, 0.45),  # share of the entry premium risked at the stop
}
WEIGHT_BOUNDS = (0.2, 3.0)

#: Parameters that are whole numbers. Everything else in PARAM_BOUNDS is a float.
INT_PARAMS = frozenset(
    {
        "horizon_bars",
        "min_agree",
        "swing_horizon_bars",
        "positional_horizon_bars",
        "orb_decay_min",
        "min_dte_days",
        "max_dte_days",
        "short_premium_enabled",
    }
)


def _default_weights() -> dict[str, dict[str, float]]:
    base = dict.fromkeys(ENGINE_NAMES, 1.0)
    w = {r: dict(base) for r in REGIMES}
    # Starting beliefs only. The learner moves them from evidence.
    # The engine names here must match ENGINE_NAMES exactly: a typo silently
    # costs an engine its per-regime weight and leaves it on the 1.0 default.
    w["trend"].update(
        math=1.3,
        signal=1.3,
        market=1.3,
        stat=0.9,
        options=0.8,
        swing=1.2,
        patterns=0.8,
        chart_patterns=0.9,
        positional=0.7,
        vol_breakout=1.1,
        oi_pcr=1.0,
        vwap=1.2,
        orb=1.3,
        option_selling=0.4,
    )
    w["range"].update(
        options=1.4,
        stat=1.2,
        math=0.7,
        signal=0.7,
        market=0.8,
        swing=0.8,
        patterns=1.2,
        chart_patterns=1.0,
        positional=0.8,
        vol_breakout=0.9,
        oi_pcr=1.2,
        vwap=1.3,
        orb=0.7,
        option_selling=1.3,
    )
    w["volatile"].update(
        options=1.2,
        stat=1.1,
        market=0.9,
        swing=1.0,
        patterns=0.8,
        chart_patterns=0.8,
        positional=0.6,
        vol_breakout=1.3,
        oi_pcr=0.8,
        vwap=1.1,
        orb=1.4,
        option_selling=1.2,
    )
    w["quiet"].update(
        options=0.9,
        stat=0.8,
        math=0.7,
        signal=0.7,
        market=0.6,
        swing=0.8,
        patterns=0.9,
        chart_patterns=0.7,
        positional=0.9,
        vol_breakout=0.5,
        oi_pcr=1.3,
        vwap=1.2,
        orb=0.6,
        option_selling=0.8,
    )
    return w


@dataclass(frozen=True, slots=True)
class TunableParams:
    k_stop: float = 0.6
    k_target: float = 1.2
    horizon_bars: int = 24
    min_prob: float = 0.15
    min_ev_r: float = 0.0
    min_confluence: float = 0.20
    min_agree: int = 2
    trail_trigger_r: float = 1.0
    trail_gap_r: float = 0.7
    # Swing/positional specific parameters
    swing_k_stop: float = 1.5
    swing_k_target: float = 4.0
    swing_horizon_bars: int = 10
    positional_k_stop: float = 3.0
    positional_k_target: float = 4.0
    positional_horizon_bars: int = 20
    # Volatility breakout parameters
    vol_breakout_atr_mult: float = 1.5
    vol_breakout_vol_mult: float = 1.2
    # OI/PCR parameters
    oi_pcr_panic: float = 1.35
    oi_pcr_euphoria: float = 0.70
    oi_pain_weight: float = 0.25
    # VWAP parameters
    vwap_dev_atr: float = 2.0
    vwap_pullback_atr: float = 0.5
    # ORB parameters
    orb_range_atr_min: float = 0.5
    orb_decay_min: int = 120
    # IV regime — the buyer/seller switch
    iv_rank_skip: float = 0.60
    iv_rank_cheap: float = 0.30
    # Expiry selection (Indian index options: weekly expiries, 0-DTE on expiry day)
    min_dte_days: int = 2
    max_dte_days: int = 20
    # Option selling
    os_sell_delta: float = 0.3
    os_hedge_delta: float = 0.08
    os_min_credit_pct: float = 0.15
    os_min_credit_points: float = 3.0
    os_iv_rank_skip: float = 0.60
    os_iv_rank_cheap: float = 0.30
    short_premium_enabled: int = 1
    # Cheap/expiry sidecar. The sidecar reads its working values through
    # premiumCheapExp.load_config; /brain/api/params mirrors these into it.
    cheap_reach_sigma: float = 1.0
    cheap_stop_pct: float = 0.25
    # Swing/positional hold limits and margin factors are human-owned
    # RiskLimits, not learner-tunable. They are deliberately absent here so the
    # learner cannot move risk limits that the executor enforces from RiskLimits.
    weights: dict[str, dict[str, float]] = field(default_factory=_default_weights)

    def clamp(self) -> TunableParams:
        """Return a copy with every value forced inside its hard bounds."""
        updates: dict[str, Any] = {}
        for name, (lo, hi) in PARAM_BOUNDS.items():
            value = float(getattr(self, name))
            value = min(max(value, lo), hi)
            if name in INT_PARAMS:
                updates[name] = int(round(value))
            else:
                updates[name] = float(value)
        wlo, whi = WEIGHT_BOUNDS
        weights: dict[str, dict[str, float]] = {}
        for regime in REGIMES:
            row = (self.weights or {}).get(regime, {})
            weights[regime] = {e: min(max(float(row.get(e, 1.0)), wlo), whi) for e in ENGINE_NAMES}
        updates["weights"] = weights
        return replace(self, **updates)

    def to_dict(self) -> dict[str, Any]:
        return {
            **{n: getattr(self, n) for n in PARAM_BOUNDS},
            "weights": {r: dict(w) for r, w in self.weights.items()},
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> TunableParams:
        data = data or {}
        known = {k: data[k] for k in PARAM_BOUNDS if k in data}
        weights = data.get("weights") or _default_weights()
        return cls(**known, weights=weights).clamp()
