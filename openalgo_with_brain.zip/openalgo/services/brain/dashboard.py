"""Self-contained dashboard served at /brain (no frontend build required)."""

HTML = r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>AI Brain</title><style>
:root{--bg:#0b0d12;--card:#141821;--fg:#e6e9ef;--mut:#8b93a5;--ok:#2fbf71;--bad:#e5484d;--warn:#f5a524;--acc:#5b8def;color-scheme:dark}
@media (prefers-color-scheme:light){:root{--bg:#f5f6f8;--card:#fff;--fg:#14171f;--mut:#5f6778;color-scheme:light}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.45 system-ui,sans-serif;padding:16px}
h1{font-size:20px;margin:0 0 4px}h2{font-size:13px;color:var(--mut);text-transform:uppercase;letter-spacing:.06em;margin:0 0 8px}
.grid{display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(280px,1fr))}.card{background:var(--card);border-radius:12px;padding:14px}
.k{display:flex;justify-content:space-between;padding:3px 0;border-bottom:1px solid #8883}.k:last-child{border:0}
.pill{padding:2px 8px;border-radius:99px;font-size:12px;font-weight:600}.on{background:#2fbf7122;color:var(--ok)}.off{background:#8b93a522;color:var(--mut)}.red{background:#e5484d22;color:var(--bad)}.amb{background:#f5a52422;color:var(--warn)}
button{background:var(--acc);color:#fff;border:0;border-radius:8px;padding:8px 12px;font-weight:600;cursor:pointer;margin:2px}button.d{background:var(--bad)}button.g{background:#8b93a533;color:var(--fg)}
.wrap{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:12.5px}th,td{text-align:left;padding:5px 8px;border-bottom:1px solid #8883;white-space:nowrap}th{color:var(--mut)}
.pos{color:var(--ok)}.neg{color:var(--bad)}.mut{color:var(--mut)}#msg{margin:8px 0;min-height:18px;color:var(--warn)}
</style></head><body>
<h1>AI Brain</h1><div class="mut">Learns from every signal, trades only inside limits you own. Paper first.</div><div id="msg"></div>
<div class="grid">
<div class="card"><h2>Control</h2><div id="ctl"></div></div>
<div class="card"><h2>Status</h2><div id="st"></div></div>
<div class="card"><h2>Maturity</h2><div id="mat"></div></div>
<div class="card"><h2>Human-owned limits (read-only)</h2><div id="lim"></div></div>
</div>
<div class="card" style="margin-top:12px"><h2>Open positions</h2><div class="wrap" id="open"></div></div>
<div class="card" style="margin-top:12px"><h2>Latest suggestions</h2><div class="wrap" id="sig"></div></div>
<div class="card" style="margin-top:12px"><h2>Closed trades</h2><div class="wrap" id="closed"></div></div>
<div class="card" style="margin-top:12px"><h2>Audit trail</h2><div class="wrap" id="ev"></div></div>
<script>
let csrf="";const $=id=>document.getElementById(id);
const f=(n,d=2)=>n==null?"-":Number(n).toFixed(d);const cls=n=>n>0?"pos":n<0?"neg":"";
const esc=t=>String(t==null?"":t).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&#34;","'":"&#39;"}[c]));
const pill=(on,t,c)=>`<span class="pill ${on?(c||"on"):"off"}">${esc(t)}</span>`;
async function api(p,o){const r=await fetch(p,o);return r.json()}
async function act(action){if(["kill","flatten","auto_on"].includes(action)&&!confirm("Confirm: "+action))return;
 const r=await api("/brain/api/control",{method:"POST",headers:{"Content-Type":"application/json","X-CSRFToken":csrf},body:JSON.stringify({action})});
 if(action==="scan_now"&&r.status==="started"&&typeof r.seq==="number"){for(let a=0;a<90;a++){await new Promise(x=>setTimeout(x,2000));const d=await api("/brain/api/scan-result");if(d.scan){$("msg").textContent="Scan complete @ "+new Date((d.scan.ts??0)*1000).toLocaleTimeString();refresh();return;}if(d.seq<r.seq)break}$("msg").textContent="Scan still running; try again shortly.";return;}
 $("msg").textContent=r.message||(r.result?JSON.stringify(r.result).slice(0,300):action+" done");refresh()}
async function boot(){const r=await api("/brain/api/bootstrap",{method:"POST",headers:{"Content-Type":"application/json","X-CSRFToken":csrf},body:JSON.stringify({underlying:"NIFTY",days:25})});$("msg").textContent=JSON.stringify(r);refresh()}
function tbl(h,rows){return `<table><tr>${h.map(x=>`<th>${x}</th>`).join("")}</tr>${rows.join("")}</table>`}
async function refresh(){
 const s=await api("/brain/api/status");
 $("ctl").innerHTML=`<div>${pill(s.enabled,"ENABLED")} ${pill(s.auto_trade,"AUTO-TRADE","amb")} ${pill(s.kill_switch,"KILL","red")} ${pill(s.degraded,"DEGRADED","red")} ${pill(s.drawdown_halt,"DD HALT","red")}</div>
 <div style="margin-top:8px"><button onclick="act('${s.enabled?"disable":"enable"}')">${s.enabled?"Disable":"Enable"}</button>
 <button class="g" onclick="act('${s.auto_trade?"auto_off":"auto_on"}')">${s.auto_trade?"Auto-trade OFF":"Auto-trade ON"}</button>
 <button class="g" onclick="act('scan_now')">Scan now</button><button class="g" onclick="act('learn_now')">Learn now</button>
 <button class="g" onclick="boot()">Bootstrap from history</button>
 <button class="d" onclick="act('kill')">KILL</button><button class="d" onclick="act('flatten')">Flatten</button>
 <button class="g" onclick="act('release_kill')">Release kill</button><button class="g" onclick="act('release_halt')">Clear halt</button></div>`;
 $("st").innerHTML=[["Platform mode",s.platform_mode==="sandbox"?"paper (analyzer)":"LIVE"],["Underlyings",esc(s.underlyings.join(", "))],["Model #",esc(s.model_id)+" ("+s.model_samples+" samples)"],
  ["P&L today",`<span class="${cls(s.pnl_today)}">${f(s.pnl_today,0)}</span>`],["Trades today",s.trades_today],["Open",s.open_positions],
  ["Last scan",s.last_scan?new Date(s.last_scan*1000).toLocaleTimeString():"-"],["Loop",s.thread_alive?"running":"stopped"],["Error",esc(s.last_error||"-")]].map(([a,b])=>`<div class="k"><span class="mut">${a}</span><span>${b}</span></div>`).join("");
 const m=s.maturity,p=m.paper;
 $("mat").innerHTML=[["Stage",esc(m.stage)],["Labelled signals",m.labelled_signals],["Options engine",m.options_engine.voting?"voting":"observing ("+m.options_engine.chain_labelled+"/"+m.options_engine.needed+" chain-labelled)"],["Paper trades",p.n],["Paper expectancy",f(p.expectancy_r)+" R"],["Profit factor",f(p.profit_factor)],["Max drawdown",f(p.max_dd_r,1)+" R"]].map(([a,b])=>`<div class="k"><span class="mut">${a}</span><span>${b}</span></div>`).join("")+
  (m.live_blockers.length?`<div class="mut" style="margin-top:6px">Live locked: ${esc(m.live_blockers.join("; "))}</div>`:"");
 $("lim").innerHTML=Object.entries(s.limits).map(([a,b])=>`<div class="k"><span class="mut">${esc(a)}</span><span>${esc(b)}</span></div>`).join("");
 const pz=await api("/brain/api/positions");
 $("open").innerHTML=pz.open.length?tbl(["#","Symbol","Mode","State","Qty","Entry","Stop","Target","Exit kind"],pz.open.map(p=>`<tr><td>${p.id}</td><td>${esc(p.symbol)}</td><td>${esc(p.mode)}</td><td>${esc(p.state)}</td><td>${p.qty}</td><td>${f(p.entry_price)}</td><td>${f(p.stop_price)}</td><td>${f(p.target_price)}</td><td>${esc(p.exit_kind||"")}</td></tr>`)):'<span class="mut">none</span>';
 $("closed").innerHTML=pz.closed.length?tbl(["#","Symbol","Mode","Entry","Exit","P&L","R","Why"],pz.closed.slice(0,20).map(p=>`<tr><td>${p.id}</td><td>${esc(p.symbol)}</td><td>${esc(p.mode)}</td><td>${f(p.entry_price)}</td><td>${f(p.exit_price)}</td><td class="${cls(p.pnl)}">${f(p.pnl,0)}</td><td class="${cls(p.r_multiple)}">${f(p.r_multiple)}</td><td>${esc(p.exit_reason||"")}</td></tr>`)):'<span class="mut">none yet</span>';
 const sg=await api("/brain/api/signals?limit=30&suggested=1");
 $("sig").innerHTML=sg.data.length?tbl(["Time","Underlying","Side","Regime","Score","P","EV(R)","Status","Why"],sg.data.map(x=>`<tr><td>${new Date(x.ts*1000).toLocaleTimeString()}</td><td>${esc(x.underlying)}</td><td>${esc(x.side)}</td><td>${esc(x.regime)}</td><td>${f(x.score)}</td><td>${f(x.prob)}</td><td>${f(x.ev_r)}</td><td>${esc(x.status)}</td><td>${esc((x.reasons||[]).join(" | "))}${x.gate_reasons?" ⛔ "+esc(x.gate_reasons):""}</td></tr>`)):'<span class="mut">none yet</span>';
 const ev=await api("/brain/api/events?limit=25");
 $("ev").innerHTML=tbl(["Time","Level","Kind","Message"],ev.data.map(e=>`<tr><td>${new Date(e.ts*1000).toLocaleTimeString()}</td><td>${esc(e.level)}</td><td>${esc(e.kind)}</td><td>${esc(e.message)}</td></tr>`));
}
(async()=>{csrf=(await api("/auth/csrf-token")).csrf_token||"";refresh();setInterval(refresh,10000)})();
</script></body></html>"""
