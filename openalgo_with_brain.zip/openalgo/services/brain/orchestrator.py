"""The AI Brain: central coordinator.

One loop on a plain (green under eventlet) daemon thread:

* every ``tick`` seconds   manage open positions (protective exits via the risk core)
* every ``scan_interval``  scan the underlyings: engines -> fusion -> journal -> gate -> execute
* every 5 minutes          reconcile the journal against the position book
* once after the close     the learning cycle

``scan_once`` and ``tick_once`` take their collaborators as arguments, so the
same code is exercised by tests with a fake data source and gateway.

Defaults are conservative on purpose: the Brain starts disabled, auto-trade
starts off, and when it does trade it trades the **sandbox** unless live
trading has been enabled by a human *and* the paper record has earned it.
"""

from __future__ import annotations

import json
import math
import os
import threading
import time
from collections import deque
from datetime import datetime, timedelta, timezone
from typing import Any, Protocol

import numpy as np

from database import brain_db as db
from database.sandbox_db import get_config
from services.brain import chain_log, executor, fusion, gate, knobs, learner, risk_gate
from services.brain.bands import band_offsets, pick_band
from services.brain.config import RiskLimits, TunableParams
from services.brain.contracts import lot_size
from services.brain.engines import (
    chart_patterns,
    market,
    math_engine,
    ml,
    oi_pcr,
    option_selling,
    orb,
    patterns,
    signal,
    stat,
    vol_breakout,
    vwap,
)
from services.brain.engines import (
    options as options_engine,
)
from services.brain.engines import (
    positional as positional_engine,
)
from services.brain.engines import (
    swing as swing_engine,
)
from services.brain.engines.ml import OnlineLogit
from services.brain.spreads import select_spread
from services.brain.types import Snapshot
from utils.env_config import paper_capital
from utils.keyed_locks import KeyedLocks
from utils.logging import get_logger

logger = get_logger(__name__)
_mode_fallback_logged = 0.0  # last time platform_mode() logged its fallback
IST = timezone(timedelta(hours=5, minutes=30))

BAR_S = 300.0  # the Brain works in 5-minute bars
BAR_SETTLE_S = 8.0  # wait this long after a bar closes before the first scan of it
REFRESH_MIN_INTERVAL_S = 45.0  # least gap between Historify top-ups for one underlying
_REFRESHED: dict[str, float] = {}  # underlying -> when Historify was last topped up
#: How much history the journal bootstrap replays, and the least it will
#: accept. The engines need a 150-bar warm-up; the replay needs more than
#: that to say anything at all.
BOOTSTRAP_HISTORY_DAYS = 120
BOOTSTRAP_MAX_BARS = 8000
BOOTSTRAP_MIN_BARS = 250

# One claim per underlying for a whole scan pass. ``scan_once`` runs from the
# loop and from the operator's "Scan now" worker, on two threads that
# interleave at every broker call, and a pass reads then writes the journal,
# the risk gate and the position book. Two passes on one underlying could both
# find a signal unseen and the gate open, journalling twice and entering twice
# — which ``max_open_per_underlying`` exists to prevent. The claim makes a
# pass atomic per underlying; the passes on other underlyings still run
# independently, and no broker I/O is serialised beyond what already was.
#
# Not reentrant, deliberately: a reentrant lock would grant the same key to a
# second claim from the holder's own thread and quietly make the guard a no-op,
# which is exactly the shape a nested scan would take.
_ENTRY_CLAIMS = KeyedLocks(reentrant=False, name="brain-scan")


def entry_claim(key: str, timeout: float | None = 0.0):
    """Hold the scan claim for ``key``, yielding whether it was taken.

    ``timeout=0`` stands aside instead of waiting: the holder is already doing
    the work for this underlying, and the next bar re-evaluates.
    """
    return _ENTRY_CLAIMS.try_hold(key, timeout)


# ── Trading-knowledge filters (from Indian index-options research) ────────────
# These are applied in the live scan so the Brain only trades when the
# economics favor the buyer: cheap vol, right time of day, right strike.
#
# The thresholds live in the tunable parameters, not here, so the Brain (or the
# operator) can move them at runtime. The defaults are the research values.


# Entry window defaults live in RiskLimits (config.py) so the live gate, the
# learner and the label windows all move together — do not hardcode a second
# copy here. The function reads the caller's limits when given one (the
# orchestrator passes its live-mutable ``self.limits``) and falls back to env.
def entry_window_ok(minute_of_day: int, limits: RiskLimits | None = None) -> bool:
    """Return True if ``minute_of_day`` falls inside the research-backed entry
    window (09:35-13:00 IST by default). Outside this window the Brain abstains."""
    lim = limits if limits is not None else RiskLimits.from_env()
    return lim.entry_start_min <= minute_of_day < lim.entry_cutoff_min


def iv_regime_ok(iv_rank: float | None, params: TunableParams) -> tuple[bool, float]:
    """Return (allowed, risk_multiplier) for *buying* premium, from the IV rank.

    Research consensus: buying options when IV rank is above the skip line is
    structurally unfavourable (IV crush risk). Below the cheap line the premium
    is cheap and a slightly larger size is acceptable.
    """
    if iv_rank is None:
        return True, 1.0  # no IV data yet -> don't block, but don't boost either
    if iv_rank >= params.iv_rank_skip:
        return False, 0.0  # too expensive to buy
    if iv_rank < params.iv_rank_cheap:
        return True, 1.25  # cheap vol -> slightly larger size
    return True, 1.0


# ── end trading-knowledge filters ─────────────────────────────────────────────


# ---- Brain self-tuner (real-time limit adaptation from learning) ----
# Watches recent closed fusion trades and tightens/loosens the running risk
# limits so the Brain trades more when it's winning and less when it's losing.
# Adjustments apply to ``self.limits`` immediately — no restart, no .env write
# needed unless a human moves a slider (then that slider is owned manually).
_BRAIN_AUTO_TUNE_RECENT_N = 10  # recent closed trades to read
_BRAIN_AUTO_TUNE_MIN_SAMPLES = 5  # min samples before acting
_BRAIN_AUTO_TUNE_LOOSEN_MIN_SAMPLES = 8  # ...and the larger one before loosening
_BRAIN_AUTO_TUNE_LOOSEN_SIGMAS = 1.645  # one-sided 95% bound under the mean R
_BRAIN_AUTO_TUNE_BAND_R = 0.10  # |mean R| beyond which the tuner acts
_BRAIN_AUTO_TUNE_THROTTLE_S = 300  # min seconds between adjustments
_BRAIN_AUTO_TUNE_STATE_KEY = "brain_auto_tune"

# Adaptive cheap-premium cap (services/brain/premium_auto.py): the human's
# BRAIN_MAX_PREMIUM slider is the hard ceiling; inside it the effective cap is
# re-derived from recent closed-trade outcomes. Both engines share the gate.
_PREMIUM_CAP_THROTTLE_S = 300  # min seconds between re-derivations
_PREMIUM_CAP_STATE_KEY = "premium_auto_cap"
_PREMIUM_CAP_PROBE_INTERVAL_S = 4 * 3600  # re-open a losing band this often...
_PREMIUM_CAP_PROBE_WINDOW_S = 90 * 60  # ...for this long, then re-decide

# Live-adaptive IV-band gate. The band edges read from ``gate.iv_band`` are
# re-derived every ``_IV_TUNE_THROTTLE_S`` seconds from the empirical IV-rank
# distribution of recent closed fusion trades and written into brain_state so
# the live scan picks them up immediately. Tightening applies when IV rank
# itself is extreme; loosening does not — the edge is harder to find in calm
# regimes and we should not auto-reject candidates the human would still want.
_IV_TUNE_THROTTLE_S = 600
_IV_TUNE_MIN_SAMPLES = 20

UNDERLYINGS = {
    "NIFTY": ("NSE_INDEX", "NFO"),
    "BANKNIFTY": ("NSE_INDEX", "NFO"),
    "FINNIFTY": ("NSE_INDEX", "NFO"),
    "MIDCPNIFTY": ("NSE_INDEX", "NFO"),
    "SENSEX": ("BSE_INDEX", "BFO"),
    "BANKEX": ("BSE_INDEX", "BFO"),
}

# The peer series each underlying is measured against, for the correlation and
# PCA-share features of the market and math engines. This used to be "whichever
# other underlying happened to come next in the scan dict", which made the peer
# a function of configuration order and gave NIFTY BANKNIFTY as its benchmark
# one day and SENSEX the next. A benchmark is a choice, so it is written down:
# the broad NSE index for everything else, and the other large NSE index for
# NIFTY itself, which cannot be measured against its own returns.
BENCHMARKS: dict[str, str] = {
    "NIFTY": "BANKNIFTY",
    "BANKNIFTY": "NIFTY",
    "FINNIFTY": "NIFTY",
    "MIDCPNIFTY": "NIFTY",
    "SENSEX": "NIFTY",
    "BANKEX": "NIFTY",
}
# Stocks and any user-added underlying are measured against the market index.
DEFAULT_BENCHMARK = "NIFTY"


# User-added underlyings live in the Brain's own database.
# Format: dict {"SYMBOL": "EXCHANGE", ...} e.g. {"RELIANCE": "NSE"}
#
# Options do not trade on the cash segment: an NSE instrument's options are
# NFO, a BSE instrument's are BFO. The add route only accepts NSE/BSE and the
# mapping below is applied on read, so a stock's derivatives are always placed
# on the right segment rather than an "approximation" that the broker refuses.
_FO_BY_CASH = {
    "NSE": "NFO",
    "BSE": "BFO",
    "NSE_INDEX": "NFO",
    "BSE_INDEX": "BFO",
}


def _load_custom_underlyings() -> dict[str, str]:
    try:
        return db.underlyings_get()
    except Exception:
        logger.exception("brain: failed to load user-added underlyings")
        return {}


def get_underlyings() -> dict[str, tuple[str, str]]:
    """Return merged default + user-configured underlyings."""
    custom = _load_custom_underlyings()
    merged = dict(UNDERLYINGS)
    for symbol, exch in custom.items():
        fo = _FO_BY_CASH.get(exch.upper())
        if fo is None:
            logger.warning(
                "brain: custom underlying %s has unknown exchange %s; skipping it",
                symbol,
                exch,
            )
            continue
        merged[symbol.upper()] = (exch.upper(), fo)
    return merged


def clear_scan_caches() -> None:
    """Drop the module-level scan caches (Historify top-up throttle book).

    Called when the Brain is disabled so a stale "last topped up" timestamp
    cannot make the next enable reuse a data window that is hours old.
    """
    _REFRESHED.clear()


class DataSource(Protocol):
    def bars(self, underlying: str, count: int = 400) -> np.ndarray | None: ...
    def chain(self, underlying: str) -> dict[str, Any] | None: ...
    def funds(self) -> float | None: ...

    # Optional: ``bars_fetched_at(underlying) -> float | None``. A source that has it lets the
    # Brain measure data age from the fetch; one that does not is judged on the bar's age.


def _ist(ts: float) -> datetime:
    return datetime.fromtimestamp(ts, IST)


def staleness(now: float, bar_ts: float, fetched_at: float | None) -> tuple[float, float]:
    """(data_age, bar_lag) in seconds for a decision made now on the bar that opened at ``bar_ts``.

    ``data_age`` is how long ago the market data was last fetched. It used to be measured from
    the bar's close, which is wrong in both directions: a decision is by construction made some
    seconds after its bar closes, so a perfectly fresh feed read 30-60s old and only about 70%
    of bars could ever trade, while a fetch that never refreshed would only look stale by luck.

    ``bar_lag`` is how long after the bar's close the decision is being made. The risk gate
    caps it separately (``max_bar_lag_s``): it is what catches a feed that was fetched a moment
    ago but is still handing back an old bar.

    A source that cannot say when it fetched is judged on the bar alone, the old behaviour.
    """
    bar_lag = max(now - (bar_ts + BAR_S), 0.0)
    if fetched_at is None:
        return bar_lag, bar_lag
    return max(now - fetched_at, 0.0), bar_lag


def scan_due(now: float, last_scan: float, last_bucket: int, interval: float) -> tuple[bool, int]:
    """Is a scan due, and which 5-minute bucket has it covered?

    A decision is made once, at the first scan that sees a new bar, so that scan should come
    right after the close rather than wherever a free-running 60s timer happens to land. A scan
    is due as soon as ``BAR_SETTLE_S`` has passed in a bucket not yet scanned, and then every
    ``interval`` seconds as a retry while the data for the new bar has not arrived.
    """
    bucket = int(now // BAR_S)
    if bucket != last_bucket and (now % BAR_S) >= BAR_SETTLE_S:
        return True, bucket
    return (now - last_scan) >= interval, last_bucket


def _refresh_window(ts: float) -> bool:
    d = _ist(ts)
    minute = d.hour * 60 + d.minute
    return d.weekday() < 5 and 9 * 60 + 10 <= minute < 15 * 60 + 50


def minute_of_day(ts: float) -> int:
    d = _ist(ts)
    return d.hour * 60 + d.minute


def market_open(ts: float) -> bool:
    d = _ist(ts)
    return d.weekday() < 5 and 9 * 60 + 15 <= d.hour * 60 + d.minute < 15 * 60 + 30


class OpenAlgoData:
    """Production data source: OpenAlgo's history, option chain and funds services."""

    def __init__(self, api_key: str, source: str = "api") -> None:
        self.api_key = api_key
        self.source = source
        self._cache: dict[str, tuple[float, Any]] = {}
        self._fetched: dict[str, float] = {}  # underlying -> last successful bars fetch
        self._underlyings = get_underlyings()

    def bars_fetched_at(self, underlying: str) -> float | None:
        return self._fetched.get(underlying.upper())

    def _refresh_intraday(self, underlying: str, exchange: str) -> None:
        """Top up today's 1-minute bars in Historify from the broker, then let it build 5m from them.

        Historify only holds what has been downloaded into it. Without a schedule doing that
        during the session, the Brain reads a store that stops at the last manual download and
        every decision looks stale. This asks for today's bars at most once per
        ``REFRESH_MIN_INTERVAL_S`` per underlying, only while the market is open, and carries on
        with whatever the store holds if the broker is slow or refuses. Switch it off with
        ``BRAIN_HISTORIFY_REFRESH=0`` when an operator-run Historify schedule already does this.
        """
        if self.source != "db":
            return
        if os.getenv("BRAIN_HISTORIFY_REFRESH", "1").strip().lower() in ("0", "false", "no", "off"):
            return
        now = time.time()
        if not _refresh_window(now):
            return
        if now - _REFRESHED.get(underlying, 0.0) < REFRESH_MIN_INTERVAL_S:
            return
        _REFRESHED[underlying] = now
        try:
            from services.historify_service import download_data

            today = _ist(now).date().isoformat()
            ok, resp, _ = download_data(underlying, exchange, "1m", today, today, self.api_key)
            if not ok:
                logger.warning(
                    "brain: historify top-up for %s failed: %s",
                    underlying,
                    (resp or {}).get("message"),
                )
        except Exception:
            logger.exception("brain: historify top-up for %s raised", underlying)

    def _cached(self, key: str, ttl: float, fn):
        hit = self._cache.get(key)
        if hit and time.time() - hit[0] < ttl:
            return hit[1]
        val = fn()
        self._cache[key] = (time.time(), val)
        return val

    def bars(
        self, underlying: str, count: int = 400, since: float | None = None
    ) -> np.ndarray | None:
        from services.history_service import get_history

        u = underlying.upper()
        if u not in self._underlyings:
            logger.error("brain: unknown underlying %s", underlying)
            return None
        exch = self._underlyings[u][0]

        def fetch():
            self._refresh_intraday(u, exch)
            end = _ist(time.time()).date()
            start = _ist(since).date() if since else end - timedelta(days=7)
            ok, resp, _ = get_history(
                underlying,
                exch,
                "5m",
                start.isoformat(),
                end.isoformat(),
                api_key=self.api_key,
                source=self.source,
            )
            if not ok:
                return None
            self._fetched[u] = time.time()
            rows = []
            for r in resp.get("data") or []:
                try:
                    row = [
                        float(r["timestamp"]),
                        float(r["open"]),
                        float(r["high"]),
                        float(r["low"]),
                        float(r["close"]),
                        float(r.get("volume") or 0),
                    ]
                except (KeyError, TypeError, ValueError):
                    continue
                # float("nan") parses fine, so the type check above does not
                # catch it — and one NaN bar poisons every engine's rolling
                # stats downstream. Drop it here, at ingress.
                if not all(math.isfinite(v) for v in row):
                    continue
                rows.append(row)
            return np.array(rows) if rows else None

        arr = self._cached(f"bars:{underlying}:{since}", 20.0, fetch)
        if arr is None:
            return None
        if arr[-1, 0] + 300 > time.time():  # drop the bar still forming
            arr = arr[:-1]
        return arr[-count:] if len(arr) else None

    def daily_bars(self, underlying: str, count: int = 500, days: int = 900) -> np.ndarray | None:
        """Daily bars for the swing and positional engines.

        The intraday engine reads 5-minute bars, which cannot answer "is the
        index above its 50-week average". The swing and positional engines need
        the daily (and, aggregated from it, the weekly) series, so they are
        fetched at their own interval over their own history window.
        """
        from services.history_service import get_history

        u = underlying.upper()
        if u not in self._underlyings:
            logger.error("brain: unknown underlying %s", underlying)
            return None
        exch = self._underlyings[u][0]

        def fetch():
            end = _ist(time.time()).date()
            start = end - timedelta(days=days)
            ok, resp, _ = get_history(
                underlying,
                exch,
                "D",
                start.isoformat(),
                end.isoformat(),
                api_key=self.api_key,
                source=self.source,
            )
            if not ok:
                return None
            rows = []
            for r in resp.get("data") or []:
                try:
                    row = [
                        float(r["timestamp"]),
                        float(r["open"]),
                        float(r["high"]),
                        float(r["low"]),
                        float(r["close"]),
                        float(r.get("volume") or 0),
                    ]
                except (KeyError, TypeError, ValueError):
                    continue
                # Same NaN guard as the intraday path: the swing/positional
                # engines aggregate this series; one NaN bar follows them.
                if not all(math.isfinite(v) for v in row):
                    continue
                rows.append(row)
            return np.array(rows) if rows else None

        arr = self._cached(f"daily:{underlying}", 900.0, fetch)
        if arr is None or len(arr) == 0:
            return None
        return arr[-count:] if len(arr) else None

    def _pick_expiry(
        self, underlying: str, expiries: list[Any], need_dte: int | None = None
    ) -> str | None:
        """The expiry to trade, honouring the days-to-expiry bounds.

        The nearest expiry on an index is the current weekly, which on expiry
        day is a zero-DTE contract: the gamma is brutal and the theta is
        already gone. The live Brain therefore asks for the nearest expiry
        with at least ``min_dte_days`` left and no more than ``max_dte_days``,
        both tunable. With nothing inside the band the nearest non-expired
        expiry is used, and with nothing at all the chain is skipped.

        ``need_dte`` (swing/positional) overrides the band when the intended
        hold outlives it: a positional trade that means to live 20 trading
        days cannot ride a 3-DTE weekly into settlement, so the nearest
        expiry that covers the hold is chosen — up to executor.MAX_HORIZON_DTE_CAP,
        beyond which theta is dead money whatever the horizon says. Only
        when no listed expiry covers the hold does the band logic below
        decide, and the entry gate records the shortfall.
        """
        min_dte, max_dte = 2, 20
        try:
            from services.brain.learner import load_champion

            params = load_champion()[0]
            min_dte = int(params.min_dte_days)
            max_dte = int(params.max_dte_days)
        except Exception:
            logger.debug("brain: expiry bounds unavailable, using defaults")
        today = _ist(time.time()).date()
        parsed: list[tuple[str, int]] = []
        for raw in expiries or []:
            exp = str(raw).replace("-", "").strip().upper()
            try:
                d = datetime.strptime(exp, "%d%b%y").date()
            except ValueError:
                continue
            dte = (d - today).days
            if dte < 0:
                continue
            parsed.append((exp, dte))
        if not parsed:
            # No valid expiry at all: surface it so the operator knows something is wrong.
            db.event(
                "error",
                "no_valid_expiry",
                f"{underlying}: no valid options expiry found; options data unavailable",
                {"symbol": underlying},
            )
            return None
        if need_dte is not None:
            covering = [
                (dte, exp) for exp, dte in parsed if need_dte <= dte <= executor.MAX_HORIZON_DTE_CAP
            ]
            if covering:
                dte, exp = min(covering)
                db.event(
                    "info",
                    "expiry_horizon",
                    f"{underlying}: expiry {exp} ({dte} DTE) covers the {need_dte}-day hold",
                    {"symbol": underlying, "expiry": exp, "dte": dte, "need_dte": need_dte},
                )
                return exp
        for exp, dte in parsed:
            if min_dte <= dte <= max_dte:
                # Exactly what we want — use it straight away.
                return exp
        # Nothing inside the DTE band. A near-expiry contract is risky; tell
        # the operator why we are still going to use it rather than dropping
        # the whole chain silently.
        fallback, best_dte = parsed[0]
        db.event(
            "warn",
            "expiry_out_of_band",
            f"{underlying}: nearest expiry is {fallback} ({best_dte} DTE) but "
            f"this Brain wants DTE between {min_dte} and {max_dte}; falling back to it anyway",
            {"symbol": underlying, "nearest_dte": best_dte, "desired_range": [min_dte, max_dte]},
        )
        return fallback

    def chain(self, underlying: str, need_dte: int | None = None) -> dict[str, Any] | None:
        from services.expiry_service import get_expiry_dates
        from services.option_chain_service import get_option_chain

        u = underlying.upper()
        if u not in self._underlyings:
            logger.error("brain: unknown underlying %s", underlying)
            return None
        idx_ex, fo_ex = self._underlyings[u]

        def fetch():
            ok, resp, _ = get_expiry_dates(underlying, fo_ex, "options", api_key=self.api_key)
            if not ok or not resp.get("data"):
                return None
            expiry = self._pick_expiry(u, resp["data"], need_dte=need_dte)
            if expiry is None:
                return None
            ok, ch, _ = get_option_chain(
                underlying, idx_ex, expiry, 10, api_key=self.api_key, with_greeks=True
            )
            return (ch, expiry) if ok else None

        got = self._cached(f"chain:{underlying}:{need_dte or 0}", 25.0, fetch)
        if not got:
            return None
        ch, expiry = got
        rows = []
        for r in ch.get("chain") or []:
            ce, pe = r.get("ce") or {}, r.get("pe") or {}
            rows.append(
                {
                    "strike": r.get("strike"),
                    "ce_symbol": ce.get("symbol"),
                    "pe_symbol": pe.get("symbol"),
                    "ce_ltp": ce.get("ltp"),
                    "pe_ltp": pe.get("ltp"),
                    "ce_oi": ce.get("oi"),
                    "pe_oi": pe.get("oi"),
                    "ce_bid": ce.get("bid"),
                    "ce_ask": ce.get("ask"),
                    "pe_bid": pe.get("bid"),
                    "pe_ask": pe.get("ask"),
                    "ce_iv": (ce.get("greeks") or ce).get("implied_volatility"),
                    "pe_iv": (pe.get("greeks") or pe).get("implied_volatility"),
                    "ce_delta": (ce.get("greeks") or ce).get("delta"),
                    "pe_delta": (pe.get("greeks") or pe).get("delta"),
                    "ce_gamma": (ce.get("greeks") or ce).get("gamma"),
                    "pe_gamma": (pe.get("greeks") or pe).get("gamma"),
                    "ce_lotsize": ce.get("lotsize"),
                    "pe_lotsize": pe.get("lotsize"),
                }
            )
        try:
            dte = max(
                (datetime.strptime(expiry, "%d%b%y").date() - _ist(time.time()).date()).days, 0
            )
        except ValueError:
            dte = 3
        lot = next((int(x["ce_lotsize"]) for x in rows if x.get("ce_lotsize")), 1)
        return {
            "spot": ch.get("underlying_ltp"),
            "atm_strike": ch.get("atm_strike"),
            "lot_size": lot,
            "dte": dte,
            "rows": rows,
            "expiry": expiry,
        }

    def funds(self) -> float | None:
        from services.funds_service import get_funds

        ok, resp, _ = get_funds(api_key=self.api_key)
        if not ok:
            return None
        try:
            return float((resp.get("data") or {}).get("availablecash"))
        except (TypeError, ValueError):
            return None


def resolve_api_key() -> str | None:
    """The first configured user's key, the way the scalping monitor resolves it."""
    try:
        from database import auth_db, user_db

        user = user_db.find_user_by_username()
        key = auth_db.get_api_key_for_tradingview(user.username) if user else None
        return key
    except Exception:
        logger.exception("brain: could not resolve api key")
        return None
    finally:
        for mod in ("user_db", "auth_db"):
            try:
                __import__("database." + mod, fromlist=[mod]).db_session.remove()
            except Exception:
                pass


def platform_mode() -> str:
    try:
        from database.settings_db import get_analyze_mode

        return "sandbox" if get_analyze_mode() else "live"
    except Exception as e:
        now = time.time()
        global _mode_fallback_logged
        if now - _mode_fallback_logged >= 300:
            _mode_fallback_logged = now
            logger.warning(
                "brain: analyzer-mode lookup failed (%s); assuming SANDBOX until it works. "
                "A live operator should treat any trades made while this shows as paper moves.",
                e,
            )
            try:
                db.event("warn", "mode_fallback", "analyzer mode lookup failed; assuming sandbox")
            except Exception:
                pass  # even the journal may be down; the warning above is the record
        return "sandbox"  # when unsure, the harmless one


_TUNE_KNOB_VALUES_KEY = "brain_tune_knob_values"


class BrainService:
    # Class-level default so BrainService.__new__() (used in tests) still finds it.
    tune_knobs: knobs.BrainTuneParams = knobs.CURRENT_TUNE_KNOBS

    def __init__(self) -> None:
        self.limits = RiskLimits.from_env()
        # RLock, not Lock: scan_once holds it for the whole scan (to serialize
        # concurrent gate decisions) and _snapshot()/reload_champion() re-acquire
        # it inside — a plain Lock self-deadlocks on the very first scan.
        self.lock = threading.RLock()
        self.thread: threading.Thread | None = None
        self.stop_flag = threading.Event()
        self.params: TunableParams = TunableParams()
        self.tune_knobs: knobs.BrainTuneParams = knobs.CURRENT_TUNE_KNOBS
        self.model: OnlineLogit | None = None
        self.model_id = 0
        self.last_scan: dict[str, Any] = {}
        self.last_error = ""
        # The learn gate is NOT seeded from the database here. A restart does
        # run one cheap cycle (label, drift watch, prune) straight away, but
        # the search itself is what costs anything, and the tuner state in
        # brain_state holds a fingerprint of the fit slice: a search over an
        # unchanged slice returns "no_new_data" instead of training the same
        # challenger again. Reading the brain database during application
        # boot is not worth the risk for a gate that only skips cheap work.
        self._last = {
            "scan": 0.0,
            "scan_bucket": -1,
            "reconcile": 0.0,
            "learn_day": "",
            "learn": 0.0,
        }
        self._underlyings_override: list[str] | None = None
        self.scan_interval = float(os.getenv("BRAIN_SCAN_INTERVAL_S", "60"))
        # Swing/positional scan intervals (seconds)
        self.swing_scan_interval = float(os.getenv("BRAIN_SWING_SCAN_INTERVAL_S", "86400"))  # daily
        self.positional_scan_interval = float(
            os.getenv("BRAIN_POSITIONAL_SCAN_INTERVAL_S", "604800")
        )  # weekly
        self._last["swing_scan"] = 0.0
        self._last["positional_scan"] = 0.0
        self._swing_bars_cache: dict[str, np.ndarray] = {}  # underlying -> daily aggregated bars
        self._positional_bars_cache: dict[
            str, np.ndarray
        ] = {}  # underlying -> weekly aggregated bars
        # Self-tuning for the stale-data ceiling. Broker 5m-candle publish jitter
        # (60s-3min is normal) makes a fixed max_bar_lag_s either block good
        # entries (too low) or miss dead feeds (too high). Track recent observed
        # bar lags per underlying and set the ceiling to p90 + buffer, floored at
        # the configured value so it never loosens below what the operator set.
        self._TUNE_WINDOW = 20  # observations per underlying
        self._TUNE_BUFFER_S = 60.0  # seconds above typical lag
        self._bar_lag_hist: dict[str, deque] = {}
        self._swing_signals: dict[str, Any] = {}
        self._positional_signals: dict[str, Any] = {}
        # Swing/positional signals persist until the next daily/weekly scan, but
        # _enter_swing_positional runs every loop pass. Track which underlyings
        # have already been processed for the current signal set so a signal
        # fires once per condition instead of every ~5s.
        self._swing_processed: set[str] = set()
        self._positional_processed: set[str] = set()
        # Reused across loop passes so the OpenAlgoData / OpenAlgoGateway TTL
        # caches (bars, quotes, chain) actually pay off. Recreated only when the
        # resolved API key changes.
        self._loop_data: OpenAlgoData | None = None
        self._loop_gw: Any = None
        self._loop_api_key: str | None = None
        # Consecutive loop errors, for exponential backoff so a repeatedly
        # failing tick does not hot-loop while logging.
        self._loop_errors = 0

    @property
    def underlyings(self) -> list[str]:
        """What to scan: ``BRAIN_UNDERLYINGS`` limited to names the Brain knows.

        Worked out when asked, not in ``__init__``. ``brain = BrainService()`` runs while ``app.py``
        is still importing, before the Brain tables exist, and checking the user-added names then
        read ``brain_state`` from an empty database and logged a traceback on every first start.
        """
        if self._underlyings_override is not None:
            return list(self._underlyings_override)
        known = get_underlyings()
        wanted = os.getenv("BRAIN_UNDERLYINGS", "NIFTY,BANKNIFTY").split(",")
        return [u for u in (w.strip().upper() for w in wanted) if u and u in known]

    @underlyings.setter
    def underlyings(self, names: list[str]) -> None:
        self._underlyings_override = [str(u).strip().upper() for u in names]

    # --- switches (persisted) ---------------------------------------------
    def enabled(self) -> bool:
        return bool(db.state_get("enabled", False))

    def auto_trade(self) -> bool:
        return bool(db.state_get("auto_trade", False))

    def kill(self) -> bool:
        return bool(db.state_get("kill_switch", False))

    def reload_champion(self) -> None:
        with self.lock:
            self.params, self.model, self.model_id = learner.load_champion()

    # Snapshot the live triple so callers (scan_once, tick_once) read a
    # consistent point-in-time set of params/model/model_id even while
    # reload_champion is swapping them under us. Returns a tuple the caller
    # passes into the downstream helpers instead of reading self.* directly.
    def _snapshot(self) -> tuple[TunableParams, OnlineLogit | None, int]:
        with self.lock:
            return (self.params, self.model, self.model_id)

    # --- state for the gate -----------------------------------------------
    def gate_state(
        self,
        data: DataSource,
        gw: executor.Gateway,
        now: float,
        data_age: float,
        bar_lag: float = 0.0,
        bar_lag_thresh: float = 0.0,
        underlying: str = "",
    ) -> risk_gate.GateState:
        today0 = datetime.combine(_ist(now).date(), datetime.min.time(), IST).timestamp()
        closed = db.positions_closed()
        today = [p for p in closed if (p["exit_ts"] or 0) >= today0 and p["pnl"] is not None]
        open_pos = db.positions_open()
        unreal = 0.0
        for p in open_pos:
            q = gw.quote(p["symbol"], p["exchange"])
            if not q or p["state"] != "OPEN":
                continue
            if str(p.get("position_type") or "long").lower() == "short":
                # A short spread was opened on a credit (entry_price) and is
                # worth the sold leg's price MINUS the protective leg's price.
                # The hedge quote is the real mark; when it is unavailable,
                # fall back to the hedge's recorded entry price so the mark
                # stays conservative (never flatters the short's profit).
                hq = gw.quote(
                    str(p.get("hedge_symbol") or ""),
                    str(p.get("hedge_exchange") or p["exchange"]),
                )
                hedge_val = hq if hq is not None else float(p.get("hedge_entry_price") or 0.0)
                unreal += (float(p["entry_price"]) - (float(q) - hedge_val)) * int(p["qty"])
            else:
                unreal += (q - float(p["entry_price"])) * int(p["qty"])
        losses = 0
        last_loss_ts = None
        for p in reversed(
            [c for c in closed if c["pnl"] is not None and c["r_multiple"] is not None]
        ):
            if p["pnl"] < 0:
                losses += 1
                last_loss_ts = last_loss_ts or p["exit_ts"]
            else:
                break
        closed_pnl = [float(p["pnl"]) for p in closed if p["pnl"] is not None]
        curve = np.cumsum(closed_pnl) if closed_pnl else np.array([0.0])
        funds = data.funds() or 0.0
        # In sandbox (analyzer) mode the Brain trades with the same shared paper
        # account as the sandbox engine and PPA: the updated paper equity —
        # base capital (starting_capital on /sandbox, overridden by
        # BRAIN_PAPER_CAPITAL in .env) plus the account's realised P&L.
        # Profits raise the risk budget, losses shrink it, and a blown-up
        # account (equity <= 0) stops trading until the user adds money on the
        # dashboard card. When not in sandbox mode, fall back to the env var /
        # daily snapshot / broker funds chain as before.
        if platform_mode() == "sandbox":
            try:
                from services.brain.premium_pa import paper_equity

                cap = paper_equity()
            except Exception:
                logger.debug("paper_equity unavailable; sizing from configured capital")
                try:
                    configured = float(get_config("starting_capital", "1000000.00") or 0)
                except (TypeError, ValueError):
                    configured = 0.0
                cap = paper_capital(configured)
        else:
            cap = self.limits.capital_base or float(db.state_get("capital_snapshot", 0.0) or funds)
            if not self.limits.capital_base and _ist(now).date().isoformat() != db.state_get(
                "capital_day"
            ):
                db.state_set("capital_snapshot", funds)
                db.state_set("capital_day", _ist(now).date().isoformat())
                cap = funds
        d = _ist(now)
        return risk_gate.GateState(
            now_min=d.hour * 60 + d.minute,
            weekday=d.weekday(),
            capital=cap,
            funds_available=funds,
            realized_pnl_today=sum(
                float(p["net_pnl"]) if p.get("net_pnl") is not None else float(p.get("pnl") or 0)
                for p in today
                if not db.is_refused_entry(p)
            ),
            unrealized_pnl=unreal,
            open_positions=len(open_pos),
            open_exposure=sum(float(p["entry_price"]) * int(p["qty"]) for p in open_pos),
            trades_today=len(today) + len(open_pos),
            consecutive_losses=losses,
            minutes_since_last_loss=((now - last_loss_ts) / 60.0) if last_loss_ts else None,
            equity=float(curve[-1]),
            peak_equity=float(max(curve.max(), 0.0)),
            data_age_s=data_age,
            kill_switch=self.kill(),
            drawdown_halt=bool(db.state_get("drawdown_halt", False)),
            bar_lag_s=bar_lag,
            bar_lag_thresh=bar_lag_thresh,
            open_same_underlying=(
                sum(1 for p in open_pos if p["underlying"].upper() == underlying.upper())
                if underlying
                else 0
            ),
        )

    # --- the scan ---------------------------------------------------------
    def entry_mode(self, gw_key: str | None) -> tuple[str | None, str]:
        """Which pipe an automatic entry may use, or why none."""
        if platform_mode() == "sandbox":
            return "sandbox", "analyzer (paper) mode"
        m = learner.maturity(self.limits)
        if m["stage"] != "LIVE_ELIGIBLE":
            return None, "live trading not unlocked: " + "; ".join(m["live_blockers"])
        try:
            from services.order_router_service import should_route_to_pending

            if gw_key and should_route_to_pending(gw_key, "placeorder"):
                return (
                    None,
                    "order mode is semi-auto: entries need human approval, so the Brain only suggests",
                )
        except Exception as e:
            # Fail safe: a router we cannot query is treated as approval-required.
            # Continuing on error would silently turn a broken semi-auto setup
            # into full-auto live trading — the one case where silence bites.
            logger.exception("brain: order-router check failed; blocking live entry")
            return None, f"order-router check failed ({e}); live entries blocked until it works"
        return "live", "live"

    def scan_once(
        self, data: DataSource, gw: executor.Gateway, api_key: str | None, now: float | None = None
    ) -> dict[str, Any]:
        # The snapshot/model read is serialised so a reload cannot swap them
        # mid-scan, and each underlying's pass takes its own claim (below), so
        # the background "Scan now" worker and the main loop never decide and
        # enter on the same underlying at once. Broker I/O stays outside both
        # so one slow underlying cannot freeze every other underlying.
        now = now or time.time()
        summary: dict[str, Any] = {"ts": now, "underlyings": {}}
        bars_by: dict[str, np.ndarray] = {}
        with self.lock:
            snap_params, snap_model, snap_model_id = self._snapshot()
            underlyings = list(self.underlyings)
        for u in underlyings:
            b = data.bars(u)
            if b is not None and len(b) >= 160:
                bars_by[u] = b
        for u, bars in bars_by.items():
            # A pass decides and then writes: the same-bar journal check, the
            # risk gate's read of the open book, and the entry that follows.
            # Those are separated by broker calls that yield, so the loop and
            # the "Scan now" worker could otherwise both pass and enter twice
            # on one underlying. A pass that cannot take the claim stands
            # aside: the holder is already scanning it.
            with entry_claim(f"scan:{u}", timeout=0.0) as claimed:
                if not claimed:
                    summary["underlyings"][u] = {
                        "skipped": "scan already running for this underlying"
                    }
                    continue
                try:
                    summary["underlyings"][u] = self._scan_underlying(
                        u,
                        bars,
                        bars_by,
                        data,
                        gw,
                        api_key,
                        now,
                        snap_params,
                        snap_model,
                        snap_model_id,
                    )
                except Exception as e:  # one broken underlying must not stop the others
                    logger.exception("brain scan failed for %s", u)
                    summary["underlyings"][u] = {"error": str(e)}
                    # A broken scan is a broken Brain, not a quiet one. It used to
                    # be swallowed here: the per-underlying guard kept the other
                    # underlyings alive, and the failure only ever reached the
                    # log file, so a name error in the scan path went unnoticed
                    # for weeks. It is recorded where the operator can see it.
                    db.event(
                        "error",
                        "scan_failed",
                        f"{u}: the scan could not complete — {e}",
                        {"underlying": u},
                    )
                # the premium-PA sidecar runs regardless of what the fusion path did
                try:
                    ppa_out = self._ppa(u, bars, data, gw, api_key, now, summary)
                    if ppa_out:
                        summary["underlyings"].setdefault(u, {}).setdefault("ppa", {}).update(
                            ppa_out
                        )
                except Exception:
                    logger.exception("ppa sidecar failure for %s", u)
                # ...and so does the cheap/expiry sidecar, behind its own switch
                try:
                    cheap_out = self._cheap(u, bars, data, gw, api_key, now)
                    if cheap_out:
                        summary["underlyings"].setdefault(u, {}).setdefault("cheap", {}).update(
                            cheap_out
                        )
                except Exception:
                    logger.exception("cheap/expiry sidecar failure for %s", u)
        self.last_scan = summary
        db.state_set("last_scan", now)
        chain_log.maybe_prune(now)
        return summary

    def _adaptive_bar_lag_threshold(self, underlying: str, observed: float) -> float:
        """Self-tune the bar-lag ceiling from recent observations.

        Broker 5m-candle publish jitter is normal (60s-3min). A fixed ceiling
        either blocks good entries (too low) or misses dead feeds (too high).
        Track the recent p90 of observed bar lags per underlying and set the
        ceiling to p90 + buffer, never below the configured floor.

        A genuinely dead feed pushes bar_lag beyond any p90-based ceiling while
        data_age also grows, so the stale condition
        (bar_lag > thresh AND data_age > max_data_age_s) still fires on a dead
        feed but stays off during routine jitter.
        """
        hist = self._bar_lag_hist.setdefault(underlying, deque(maxlen=self.tune_knobs.bar_lag_tune_window))
        hist.append(observed)
        # Read the floor from env on every scan so ``BRAIN_MAX_BAR_LAG_S`` edits
        # take effect live (RiskLimits.from_env() is cached at loop startup).
        floor = float(os.getenv("BRAIN_MAX_BAR_LAG_S", "150"))
        if len(hist) < 3:
            return floor
        ordered = sorted(hist)
        p90 = ordered[max(0, int(len(ordered) * 0.90) - 1)]
        return max(floor, p90 + self.tune_knobs.bar_lag_tune_buffer_s)

    # --- Brain self-tuner: adapt risk limits from recent trade outcomes ----

    def _brain_auto_tune_state(self) -> dict[str, Any]:
        """Read persisted Brain auto-tune state (manual overrides + last tune time)."""
        raw = db.state_get(_BRAIN_AUTO_TUNE_STATE_KEY)
        return raw if isinstance(raw, dict) else {}

    def _save_brain_auto_tune_state(self, state: dict[str, Any]) -> None:
        """Persist Brain auto-tune state so overrides survive a restart."""
        db.state_set(_BRAIN_AUTO_TUNE_STATE_KEY, state)

    def _restore_tune_knobs(self) -> None:
        """Re-apply human-edited tune-knobs after a restart.

        ``POST /brain/api/tune-knobs`` stores every edited value under
        ``brain_tune_knob_values``. Before this, a restart rebuilt the knobs from
        the shipped defaults while the "manual" flag persisted, so the page
        showed a manual value that was no longer in force.
        """
        try:
            saved = db.state_get(_TUNE_KNOB_VALUES_KEY)
            if not isinstance(saved, dict) or not saved:
                return
            manual = self._brain_auto_tune_state().get("manual") or {}
            cur = self.tune_knobs.to_dict()
            apply = {
                k: v
                for k, v in saved.items()
                if k in self.tune_knobs.TUNE_BOUNDS and manual.get(k) and cur.get(k) != v
            }
            if apply:
                new_k = knobs.BrainTuneParams.from_dict({**cur, **apply})
                knobs.CURRENT_TUNE_KNOBS = new_k
                self.tune_knobs = new_k
        except Exception:
            logger.exception("brain: restoring tune-knobs failed")

    def _restore_tuned_limits(self) -> None:
        """Re-apply Brain-tuned limit values that exist only in memory.

        ``self.limits`` is rebuilt from .env on startup and whenever a human
        edits a limit; auto-tuned values are not in .env. Without this, both
        events reset every tuned limit to its base while the dashboard still
        showed it as Brain-owned. A value is restored only while its owner is
        still "auto": anything the human has since set stays theirs.
        """
        self._restore_tune_knobs()
        try:
            state = self._brain_auto_tune_state()
            tuned = state.get("tuned")
            srcs = state.get("sources") if isinstance(state.get("sources"), dict) else {}
            if not isinstance(tuned, dict) or not tuned:
                return
            cur = self.limits.as_dict()
            apply = {
                k: v for k, v in tuned.items() if k in cur and srcs.get(k) == "auto" and cur[k] != v
            }
            if apply:
                self.limits = RiskLimits(**{**cur, **apply})
        except Exception:
            logger.exception("brain: restoring auto-tuned limits failed")

    def _auto_tune_brain_limits(self, now: float) -> None:
        """Self-tune Brain risk limits from recent closed fusion trade outcomes.

        Reads the mean R of the last N closed non-PPA trades. When the Brain is
        underwater it tightens the running limits (fewer trades/day, longer
        cooldown, lower risk per trade, stop-sooner on losses); when it is
        comfortably positive it relaxes them slightly. Sliders the human has
        moved manually are never touched. Changes apply to ``self.limits`` on
        the spot — no restart, no .env write required.
        """
        k = self.tune_knobs
        state = self._brain_auto_tune_state()
        last_tune = float(state.get("last_tune") or 0)
        if now - last_tune < k.auto_tune_throttle_s:
            return

        # Recent closed trades that are NOT premium-PA (i.e. fusion/Brain path).
        from database import brain_db as db

        rows = db.positions_closed(limit=k.auto_tune_recent_n)
        fusion_rows = [r for r in rows if str(r.get("note") or "") != "premium_pa"]
        if len(fusion_rows) < k.auto_tune_min_samples:
            return

        # Act only on NEW evidence. The throttle above is a clock; the window
        # below is the last N closed trades. With a clock alone, one bad (or
        # lucky) window was re-read every 5 minutes and acted on again and
        # again: a losing window tightened every limit to its floor within the
        # hour, after which too few trades closed for the window to ever change
        # (a death spiral); a winning window loosened risk and trade count the
        # same way with no new proof. Now a step needs a trade that closed
        # after the previous step.
        newest_id = max((int(r.get("id") or 0) for r in fusion_rows), default=0)
        if newest_id and newest_id <= int(state.get("last_trade_id") or 0):
            return

        r_values: list[float] = []
        for r in fusion_rows:
            rm = r.get("r_multiple")
            if rm is None:
                risk_total = float(r.get("risk_per_unit") or 0) * int(r.get("qty") or 0)
                rm = (float(r.get("pnl") or 0) / risk_total) if risk_total > 0 else None
            if rm is not None:
                r_values.append(float(rm))

        if len(r_values) < k.auto_tune_min_samples:
            return

        mean_r = sum(r_values) / len(r_values)
        if abs(mean_r) <= k.auto_tune_band_r:
            return

        # Loosening is the dangerous direction: it raises the trade count, the
        # risk per trade and the size, and it does so on a mean taken from a
        # handful of trades. A run of five lucky wins has a mean well above the
        # band and says nothing about the edge, so the loosening branch also
        # demands a *lower confidence bound* still above the band — the same
        # test ``risk_gate.live_eligible`` applies before real money, with the
        # same Student-t correction, since the normal quantile is optimistic at
        # this sample size. Tightening is deliberately not bounded: cutting
        # size on an unlucky run costs little, and waiting for proof of a
        # losing edge before acting on one is the expensive mistake.
        if mean_r > k.auto_tune_band_r:
            if len(r_values) < k.auto_tune_loosen_min_samples:
                return
            df = len(r_values) - 1
            variance = sum((x - mean_r) ** 2 for x in r_values) / df
            stderr_r = (variance / len(r_values)) ** 0.5
            z = k.auto_tune_loosen_sigmas
            t_crit = z + (z**3 + z) / (4.0 * df)
            if mean_r - t_crit * stderr_r <= k.auto_tune_band_r:
                logger.info(
                    "brain auto-tune: mean %+.2fR over %d trades is not yet a proven edge "
                    "(lower bound %+.2fR), leaving limits alone",
                    mean_r,
                    len(r_values),
                    mean_r - t_crit * stderr_r,
                )
                return

        manual = state.get("manual") or {}
        if not isinstance(manual, dict):
            manual = {}
        owners = state.get("sources") if isinstance(state.get("sources"), dict) else {}

        def _human(key: str) -> bool:
            # A limit is the human's when they moved its slider (POST /limits
            # records sources[key] == "manual") or locked it through
            # /autotune/manual (truthy flag). The old test was `key in manual`:
            # it never saw slider edits (they only wrote `sources`), so the
            # tuner overwrote sliders the UI labelled "manual", and it treated
            # a key RELEASED back to auto (flag False) as still locked.
            return bool(manual.get(key)) or owners.get(key) == "manual"

        cur = self.limits.as_dict()
        new_vals: dict[str, Any] = {}

        if mean_r < -_BRAIN_AUTO_TUNE_BAND_R:
            # Losing streak: tighten so the Brain trades less and smaller.
            if not _human("max_trades_per_day"):
                new_vals["max_trades_per_day"] = max(1, int(cur["max_trades_per_day"]) - 1)
            if not _human("cooldown_minutes"):
                new_vals["cooldown_minutes"] = min(180, int(cur["cooldown_minutes"]) + 15)
            if not _human("max_consecutive_losses"):
                new_vals["max_consecutive_losses"] = max(1, int(cur["max_consecutive_losses"]) - 1)
            if not _human("risk_per_trade_pct"):
                new_vals["risk_per_trade_pct"] = round(
                    max(0.10, float(cur["risk_per_trade_pct"]) - 0.05), 2
                )
        else:
            # Winning: loosen a little so good streaks can run.
            if not _human("max_trades_per_day"):
                new_vals["max_trades_per_day"] = min(12, int(cur["max_trades_per_day"]) + 1)
            if not _human("cooldown_minutes"):
                new_vals["cooldown_minutes"] = max(15, int(cur["cooldown_minutes"]) - 5)
            if not _human("risk_per_trade_pct"):
                new_vals["risk_per_trade_pct"] = round(
                    min(1.00, float(cur["risk_per_trade_pct"]) + 0.02), 2
                )

        if not new_vals:
            return

        # Apply to the running limits immediately (no restart, no .env write).
        self.limits = RiskLimits(**{**cur, **new_vals})

        # Persist: mark newly-tuned keys as auto-owned so the tuner owns them
        # until the human moves that slider again.
        srcs = dict(state.get("sources") or {})
        for key in new_vals:
            srcs[key] = "auto"
        # Keep the tuned VALUES too. They used to live only in self.limits, so a
        # restart or any human limit edit (which rebuilds the limits from .env)
        # silently dropped them while `sources` still said "auto".
        tuned = dict(state.get("tuned") or {})
        tuned.update(new_vals)
        state.update(
            {
                "last_tune": now,
                "last_trade_id": newest_id,
                "mean_r": round(mean_r, 4),
                "samples": len(r_values),
                "manual": manual,
                "sources": srcs,
                "tuned": tuned,
            }
        )
        self._save_brain_auto_tune_state(state)

        db.event(
            "info",
            "brain_auto_tune",
            f"mean R {mean_r:+.3f} over {len(r_values)} trades -> {', '.join(f'{k}={v}' for k, v in new_vals.items())}",
        )

    def _auto_tune_premium_cap(self, now: float) -> None:
        """Adapt the effective cheap-premium cap inside the human ceiling, real time.

        The human's ``BRAIN_MAX_PREMIUM`` slider is the hard ceiling and is
        never exceeded. Inside it, ``premium_auto.compute`` walks rupee bands
        of recent closed trades from the cheapest upward and keeps the cap
        where the bands still pay. A losing band cuts the cap below itself —
        which would also starve that band of fresh outcomes forever, so every
        few hours the controller re-opens just that band for a probe window
        (explore/exploit) and re-decides when its fresh trades have closed.
        Main Brain and PPA both read ``self.limits`` at gate time, so one
        update per tick covers both. No .env write: a restart re-derives the
        same value from the same closed-trade record.
        """
        k = self.tune_knobs
        try:
            from dataclasses import replace as _replace

            from services.brain import premium_auto

            raw = os.getenv("BRAIN_MAX_PREMIUM", "0")
            try:
                ceiling = float(raw)
            except (TypeError, ValueError):
                ceiling = 0.0
            if ceiling <= 0:
                # Cap turned Off: the stale effective value must go too, or the
                # gate would keep denying above a ceiling that no longer exists.
                if self.limits.max_premium > 0:
                    from dataclasses import replace as _replace

                    prev = float(self.limits.max_premium)
                    self.limits = _replace(self.limits, max_premium=0.0)
                    db.state_set(
                        _PREMIUM_CAP_STATE_KEY,
                        {"eff": 0.0, "ceiling": 0.0, "reason": "cap is Off (0)", "ts": now},
                    )
                    db.event(
                        "info",
                        "premium_auto",
                        f"cheap-premium cap auto: {prev:g} -> 0 (the human turned the cap Off)",
                    )
                return

            saved = db.state_get(_PREMIUM_CAP_STATE_KEY)
            state = dict(saved) if isinstance(saved, dict) else {}
            if now - float(state.get("ts") or 0) < k.premium_cap_throttle_s:
                return

            rows = db.positions_closed(limit=60)
            eff, reason, stats = premium_auto.compute(rows, ceiling, self.limits.min_premium)

            exploring = bool(state.get("exploring"))
            probe_started = float(state.get("probe_started") or 0)
            probed = state.get("probed_band")
            if exploring:
                # Probe ends when fresh outcomes land in the probed band (the
                # walk re-decides with current evidence) or the window elapses.
                fresh = probed and any(
                    float(r.get("exit_ts") or 0) > probe_started
                    and probed[0] <= float(r.get("entry_price") or 0) < probed[1]
                    for r in rows
                )
                if fresh or now - probe_started >= k.premium_cap_probe_window_s:
                    exploring = False
                    state["probe_end"] = now
                    eff, reason, stats = premium_auto.compute(
                        rows, ceiling, self.limits.min_premium
                    )
                else:
                    eff, reason, stats = premium_auto.compute(
                        rows, ceiling, self.limits.min_premium, explore=True
                    )
                    reason = f"[probe] {reason}"
            elif (
                eff < ceiling
                and (stats.get("failing_band") or probed is not None)
                and now - float(state.get("probe_end") or 0) >= k.premium_cap_probe_interval_s
            ):
                # Cut is active and its band has not been re-sampled lately:
                # open a probe window for it.
                eff_p, reason_p, stats_p = premium_auto.compute(
                    rows, ceiling, self.limits.min_premium, explore=True
                )
                if eff_p > eff:
                    exploring = True
                    probe_started = now
                    probed = stats_p.get("failing_band")
                    eff, reason, stats = eff_p, f"[probe] {reason_p}", stats_p

            state.update(
                {
                    "eff": eff,
                    "ceiling": ceiling,
                    "reason": reason,
                    "stats": stats,
                    "ts": now,
                    "exploring": exploring,
                    "probe_started": probe_started if exploring else 0,
                    "probed_band": probed if exploring else None,
                }
            )
            db.state_set(_PREMIUM_CAP_STATE_KEY, state)

            prev = state.get("prev_eff")
            prev = float(prev) if prev is not None else float(self.limits.max_premium)
            if abs(eff - prev) < 0.01:
                state["prev_eff"] = prev
                db.state_set(_PREMIUM_CAP_STATE_KEY, state)
                return
            self.limits = _replace(self.limits, max_premium=eff)
            state["prev_eff"] = eff
            db.state_set(_PREMIUM_CAP_STATE_KEY, state)
            db.event(
                "info",
                "premium_auto",
                f"cheap-premium cap auto: {prev:g} -> {eff:g} of ceiling {ceiling:g} ({reason})",
                {
                    "eff": eff,
                    "ceiling": ceiling,
                    "prev": prev,
                    "exploring": exploring,
                    **{k: v for k, v in (stats or {}).items() if k != "bands"},
                },
            )
        except Exception:
            logger.exception("brain: premium cap auto-tune failed")

    def _benchmark_bars(self, u: str, bars_by: dict[str, np.ndarray]) -> np.ndarray | None:
        """The benchmark's closes for ``u``, or None when it was not scanned.

        None is the honest answer for a missing peer: the engines then report
        no correlation rather than comparing the name with itself.
        """
        name = BENCHMARKS.get(u.upper(), DEFAULT_BENCHMARK)
        if name == u.upper():
            return None
        peer = bars_by.get(name)
        return peer[:, 4] if peer is not None else None

    def _scan_underlying(
        self, u, bars, bars_by, data, gw, api_key, now, snap_params, snap_model, snap_model_id
    ) -> dict[str, Any]:
        # Snapshot params/model/model_id passed in from scan_once (already under lock)
        # so a concurrent reload_champion() cannot swap them mid-scan.
        bar_ts = float(bars[-1, 0])
        fetched_at = getattr(data, "bars_fetched_at", None)
        data_age, bar_lag = staleness(now, bar_ts, fetched_at(u) if fetched_at else None)
        spot = float(bars[-1, 4])
        # Self-tune the bar-lag ceiling from recent broker publish jitter; the
        # stale condition (bar_lag > thresh AND data_age > max_data_age_s) stays
        # off during routine cycles and only flags a genuinely dead feed.
        bar_lag_thresh = self._adaptive_bar_lag_threshold(u, bar_lag)
        # Read the data-age ceiling from env on every scan so
        # ``BRAIN_MAX_DATA_AGE_S`` edits take effect live.
        max_data_age_s = float(os.getenv("BRAIN_MAX_DATA_AGE_S", "45"))
        stale = bar_lag > bar_lag_thresh and data_age > max_data_age_s
        chain = data.chain(u)
        iv_rank = None
        if chain and chain.get("rows"):
            chain = {**chain, "spot": chain.get("spot") or spot}
            stats = options_engine.summarize(chain)
            atm_iv = stats["atm_iv"]
            # The at-the-money IV belongs on the chain itself: the option-selling
            # engine reads it from there.
            chain = {**chain, "atm_iv": atm_iv}
            chain_log.log_snapshot(u, bar_ts, now, chain, stats)
            if atm_iv > 0:
                db.iv_add(u, atm_iv, now)
                iv_rank = db.iv_rank(u, atm_iv)
                if iv_rank is None:
                    # The rank needs 30 samples (~half an hour of a live chain).
                    # The engines quietly lose this feature until then; say so
                    # once per day rather than degrading silently forever.
                    today = _ist(now).date().isoformat()
                    if today != db.state_get("iv_warming_day"):
                        db.state_set("iv_warming_day", today)
                        db.event(
                            "info",
                            "iv_warming",
                            f"{u}: IV rank stays unavailable until 30 IV samples exist "
                            f"(currently {db.iv_sample_count(u)}); normal on a fresh install",
                        )
        other = self._benchmark_bars(u, bars_by)
        snap = Snapshot(
            u,
            now,
            bars,
            spot,
            int((chain or {}).get("lot_size") or 1),
            other,
            chain,
            iv_rank,
            None,
            minute_of_day(bar_ts + 300),
            snap_params,
        )
        reports = fusion.run_engines(snap, snap_params.horizon_bars)
        use_options, _ = learner.options_ready()

        # The summary is created BEFORE the filters, because the filters write
        # their reason into it. It used to be created after, and the first
        # filter that fired raised an UnboundLocalError — which was hidden
        # behind an earlier failure in the same function for weeks.
        res: dict[str, Any] = {
            "options_voting": use_options,
            "regime": None,
            "candidates": [],
        }

        # ── Trading-knowledge filters (live scan) ──────────────────────────
        minute = snap.minute_of_day
        in_entry_window = entry_window_ok(minute, self.limits)
        iv_allowed, iv_risk_mult = iv_regime_ok(snap.iv_rank, snap_params)

        if not in_entry_window:
            # Outside the research-backed entry window (09:35-13:00 IST):
            # skip fusion evaluation entirely to avoid trading expensive
            # opening-volatility or late-day-theta setups.
            cands = []
            res["iv_skip"] = "outside_entry_window"
        else:
            cands = fusion.evaluate(snap, reports, snap_params, snap_model, use_options=use_options)
            # The IV gate is a statement about the *direction* of the trade.
            # Buying premium into rich volatility is what the research warns
            # against; selling premium into rich volatility is what it favours.
            # So the gate is applied per candidate, by position type.
            kept: list[Any] = []
            for c in cands:
                if c.position_type == "short":
                    # Selling premium: only when the premium is worth selling.
                    if snap.iv_rank is not None and snap.iv_rank < snap_params.os_iv_rank_cheap:
                        res["iv_skip"] = "iv_too_cheap_to_sell"
                        continue
                    kept.append(c)
                    continue
                if not iv_allowed:
                    res["iv_skip"] = f"iv_rank_{snap.iv_rank:.2f}_>=_{snap_params.iv_rank_skip:.2f}"
                    continue
                kept.append(c)
            cands = kept
            # Feature gate: extra policy filters on top of the IV and entry-window
            # rules above. Symbol exclusions and extreme-regime skips live here
            # because they are human-owned decisions, not learned weights.
            # Pass live risk inputs (daily PnL, peak equity, consecutive losses)
            # so the drawdown-halt and consecutive-loss-halt filters actually fire
            # instead of always seeing zeros. gate_state() is computed here only
            # when there are candidates to filter; it is reused below at the
            # risk-gate call so the same state sizes the order.
            state = None
            if cands:
                state = self.gate_state(data, gw, now, data_age, bar_lag, bar_lag_thresh, underlying=u)
                cands, _gate_reasons = gate.apply_gate(
                    cands,
                    snap,
                    snap_params,
                    daily_pnl=state.equity,
                    equity_peak=state.peak_equity,
                    consecutive_losses=state.consecutive_losses,
                    knobs=self.tune_knobs,
                    limits=self.limits,
                )
            if _gate_reasons:
                res["gate"] = _gate_reasons
            # Cheap-vol regime: slightly larger size acceptable (applied by the
            # risk core when sizing the order).
            if iv_risk_mult != 1.0:
                res["iv_risk_mult"] = round(iv_risk_mult, 2)
        # ────────────────────────────────────────────────────────────────────

        res["regime"] = cands[0].regime if cands else None
        res["candidates"] = [fusion.dump(c) for c in cands]
        # Dashboard fields: the UI's Fusion Score and Engine Votes cards read these
        # keys off the scan summary per underlying. ``votes`` carries each engine's
        # full report (vote, confidence, notes) — journal votes are plain numbers,
        # which is why the cards stayed empty until this was added.
        res["spot"] = spot
        res["votes"] = {
            name: {
                "vote": round(r.vote, 3),
                "confidence": round(r.confidence, 3),
                "notes": list(r.notes),
            }
            for name, r in reports.items()
        }
        top = max(cands, key=lambda c: abs(c.score)) if cands else None
        if top is not None:
            res["side"] = top.side
            res["score"] = round(top.score, 3)
            res["agree"] = top.agree
            res["prob"] = round(top.prob, 3)
            res["ev_r"] = round(top.ev_r, 3)
            res["passed"] = top.passed
            res["reject"] = top.reject
        res["bar_lag"] = bar_lag
        res["data_age"] = data_age
        res["bar_lag_thresh"] = round(bar_lag_thresh, 1)
        res["stale_data"] = stale
        ids: dict[tuple[str, str], int] = {}  # (side, band) -> signal id
        legs_by_side: dict[str, dict[str, dict[str, Any]]] = {}
        for c in cands:
            if not c.passed and abs(c.score) < 0.10:
                continue  # nothing worth learning from, keep the journal small
            # One row per moneyness band, each carrying its own option leg and
            # the premium levels that leg would trade, so the labeler can grade
            # which moneyness (ITM / ATM / OTM) actually pays. With no chain —
            # or no liquid leg in any band — a single band-less row keeps the
            # journal shape the learner already understands.
            if c.side not in legs_by_side and chain:
                legs_by_side[c.side] = executor.select_legs(chain, c.side, spot)
            legs = legs_by_side.get(c.side) or {}
            per_band: list[tuple[str, dict[str, Any] | None]] = (
                [(b, leg) for b, leg in legs.items()] if legs else [("", None)]
            )
            for band, leg in per_band:
                if db.signal_seen(u, c.side, bar_ts, band):
                    continue
                lv = executor.plan_levels(c, leg, spot, snap_params) if leg else None
                ids[(c.side, band)] = db.signal_add(
                    {
                        "ts": now,
                        "bar_ts": bar_ts,
                        "underlying": u,
                        "side": c.side,
                        "regime": c.regime,
                        "score": c.score,
                        "agree": c.agree,
                        "prob": c.prob,
                        "prob_prior": c.prob_prior,
                        "ev_r": c.ev_r,
                        "rr": c.rr,
                        "sigma_h": c.sigma_h,
                        "k_stop": c.k_stop,
                        "k_target": c.k_target,
                        "horizon_bars": c.horizon_bars,
                        "entry_spot": spot,
                        "passed": c.passed,
                        "reject": c.reject,
                        "status": "SUGGESTED" if c.passed else "OBSERVED",
                        "path": "Fusion",
                        "features": c.features,
                        "votes": c.votes,
                        "reasons": list(c.reasons),
                        "model_version": snap_model_id,
                        "band": band,
                        "position_type": c.position_type,
                        "symbol": leg["symbol"] if leg else "",
                        "dte": leg["dte"] if leg else 0.0,
                        "gamma": leg["gamma"] if leg else 0.0,
                        "leg_delta": leg["delta"] if leg else 0.0,
                        "leg_entry": lv["entry"] if lv else 0.0,
                        "leg_stop": lv["stop"] if lv else 0.0,
                        "leg_target": lv["target"] if lv else 0.0,
                    }
                )
        sides_journaled = {side for side, _ in ids}
        pick = fusion.best([c for c in cands if c.side in sides_journaled])
        if pick is None:
            return res
        res["suggestion"] = fusion.dump(pick)
        if not (self.enabled() and self.auto_trade()) or not chain:
            return res
        if db.state_get("degraded", False):
            res["auto"] = "paused: model degraded or feature drift"
            return res
        mode, why = self.entry_mode(api_key)
        if mode is None:
            res["auto"] = why
            return res
        if state is None:
            state = self.gate_state(data, gw, now, data_age, bar_lag, bar_lag_thresh, underlying=u)
        fo_ex = get_underlyings()[u][1]

        if pick.position_type == "short":
            # Selling premium: a defined-risk credit spread, not a single leg.
            geo = select_spread(chain, pick.side, spot, snap_params, min_oi=self.limits.min_leg_oi)
            if geo is None:
                res["auto"] = "no tradeable credit spread on this chain"
                return res
            lv = executor.plan_levels_short(geo, snap_params)
            verdict = risk_gate.check_entry(
                self.limits,
                state,
                risk_gate.Proposal(
                    geo["credit"],
                    geo["lot_size"],
                    geo["sell_spread_pct"],
                    lv["risk_per_unit"],
                    band="",
                    dte=float((chain or {}).get("dte") or 0.0),
                    margin_per_unit=geo["width"] * self.limits.margin_factor,
                    trade_type="short",
                    hedge_spread_pct=geo["hedge_spread_pct"],
                ),
            )
            sig_id = ids.get((pick.side, "")) or 0
            if not verdict.allow:
                if sig_id:
                    db.signal_update(
                        sig_id, status="BLOCKED", gate_reasons="; ".join(verdict.reasons)
                    )
                res["auto"] = "blocked by risk gate: " + "; ".join(verdict.reasons)
                return res
            ok, pid, msg = executor.enter_spread(
                gw,
                pick,
                geo,
                verdict.lots,
                mode,
                sig_id,
                snap_params,
                snap_model_id,
                exchange=fo_ex,
                now=now,
            )
            res["auto"] = f"entered credit spread {pid}" if ok else f"entry failed: {msg}"
            return res

        legs = legs_by_side.get(pick.side) or executor.select_legs(
            chain, pick.side, spot, min_oi=self.limits.min_leg_oi
        )
        if not legs:
            res["auto"] = "no liquid option leg"
            return res
        dte = float(next(iter(legs.values()))["dte"])
        band = pick_band(legs, pick.ev_r, band_offsets(u, pick.regime), dte)
        leg = legs.get(band) if band else None
        if leg is None:
            res["auto"] = "no tradeable moneyness band"
            return res
        lv = executor.plan_levels(pick, leg, spot, snap_params)
        verdict = risk_gate.check_entry(
            self.limits,
            state,
            risk_gate.Proposal(
                leg["entry"],
                leg["lot_size"],
                leg["spread_pct"],
                lv["risk_per_unit"],
                band=band,
                dte=leg["dte"],
            ),
        )
        sig_id = ids.get((pick.side, band)) or ids.get((pick.side, "")) or 0
        if not verdict.allow:
            if sig_id:
                db.signal_update(sig_id, status="BLOCKED", gate_reasons="; ".join(verdict.reasons))
            res["auto"] = "blocked by risk gate: " + "; ".join(verdict.reasons)
            return res
        ok, pid, msg = executor.enter(
            gw,
            pick,
            leg,
            verdict.lots,
            mode,
            sig_id,
            spot,
            snap_params,
            snap_model_id,
            exchange=fo_ex,  # BrainService has no ._underlyings (only the data source does)
            now=now,
        )
        res["auto"] = f"entered position {pid}" if ok else f"entry failed: {msg}"
        return res

    def _ppa(self, u, bars, data, gw, api_key, now, summary) -> dict[str, Any]:
        """The option-premium PA sidecar: paper entries + PPA position management.

        Runs from ``scan_once`` for every underlying that had bars, whether or
        not the fusion path produced a candidate. Every failure here is
        contained so the main forecasting loop never stops because of it.
        """
        try:
            from services.brain import premium_pa

            if not premium_pa.load_config()["enable"]:
                return {}
            chain = data.chain(u) if hasattr(data, "chain") else None
            spot = float(bars[-1, 4])
            out = premium_pa.on_scan(u, chain, bars, spot, gw, api_key, now)
            out["entry"] = premium_pa.try_enter(
                u, chain, bars, spot, gw, now, self, data=data, api_key=api_key
            )
            return out
        except Exception:
            logger.exception("ppa: scan hook failed for %s", u)
            return {}

    def _cheap(self, u, bars, data, gw, api_key, now) -> dict[str, Any]:
        """The cheap/expiry sidecar: manage its open positions, then look for an entry.

        Same contract as ``_ppa``: runs for every underlying that had bars, does
        nothing unless BRAIN_CHEAP_MODE is on, and every failure is contained so
        the main forecasting loop never stops because of it. Entries are paper
        in sandbox mode; in live mode the sidecar's own maturity and
        BRAIN_LIVE_ENABLED gates apply (see premiumCheapExp.try_enter).
        """
        try:
            from services.brain import premiumCheapExp

            if not premiumCheapExp.load_config()["enable"]:
                return {}
            chain = data.chain(u) if hasattr(data, "chain") else None
            spot = float(bars[-1, 4])
            out = premiumCheapExp.on_scan(u, chain, bars, spot, gw, api_key, now)
            out["entry"] = premiumCheapExp.try_enter(
                u, chain, bars, spot, gw, now, self, data=data, api_key=api_key
            )
            return out
        except Exception:
            logger.exception("cheap/expiry: scan hook failed for %s", u)
            return {}

    # --- Brain-owned PPA overrides (AI-driven, lower priority than manual UI) ---
    def _auto_tune_ppa(self, now: float) -> None:
        """Adjust PPA edge knobs from overall performance learning.

        Reads the mean R of all closed PPA trades. When the PPA path is clearly
        underwater (mean R < −0.15), tightens ``min_score`` by +0.03. When it
        is comfortably profitable (+0.10), loosens by −0.01. Writes with source
        ``"ai"`` so the PPA self-tuner won't override it, but a human can still
        lock a value to ``"manual"`` from the UI.

        Throttled to once every 10 minutes so the knob doesn't oscillate.
        """
        k = self.tune_knobs
        from database import brain_db as dbb
        from services.brain import premium_pa as _ppa

        last = float(dbb.state_get("brain_ppa_tune_last", 0))
        if now - last < 600:  # 10 min throttle
            return
        try:
            from services.brain.premium_pa import set_ai_overrides

            st = _ppa._state()
            stats = st.get("stats") or {}
            recent = list(stats.get("recent") or [])
            if len(recent) < k.ppa_tune_min_samples:
                return
            # The PPA "Self-Tune" switch means "do not adjust my knobs for me":
            # honour it here too (this tuner used to ignore it).
            if not _ppa.load_config().get("auto_tune"):
                return
            # New evidence only (see _auto_tune_brain_limits): the same 10 trades
            # were re-read every 10 minutes and min_score ratcheted to its cap
            # with nothing new learned.
            last_ts = float(stats.get("last_ts") or 0)
            if last_ts <= float(dbb.state_get("brain_ppa_tune_ts", 0) or 0):
                return
            n_recent = min(len(recent), k.ppa_tune_recent_n)
            mean_r = sum(float(r) for r in recent[-n_recent:]) / n_recent
            overrides: dict[str, Any] = {}
            if mean_r < -k.ppa_tune_band_r:
                base_min = _ppa.load_config()["min_score"]
                overrides["min_score"] = round(min(base_min + 0.03, 0.80), 2)
            elif mean_r > k.ppa_tune_band_r:
                base_min = _ppa.load_config()["min_score"]
                overrides["min_score"] = round(max(base_min - 0.01, 0.20), 2)
            if overrides:
                _, err = set_ai_overrides(overrides)
                if not err:
                    dbb.state_set("brain_ppa_tune_last", now)
                    dbb.state_set("brain_ppa_tune_ts", last_ts)
                    dbb.event(
                        "info",
                        "brain_ppa_tune",
                        f"Brain AI adjusted PPA (mean R {mean_r:+.3f}): {overrides}",
                    )
        except Exception:
            logger.exception("brain: PPA auto-tune failed")

    def _auto_tune_iv_band(self, now: float) -> None:
        """Re-derive the IV-band gate from recent closed-fusion-trade IV ranks.

        Throttled to once every ``k.iv_tune_throttle_s`` seconds by reading the
        persisted last-tune timestamp out of brain_state. Writes back whenever
        we have enough samples; the new band is read by ``gate.iv_band`` on the
        next scan pass so it takes effect within one minute.

        The band is computed as the empirical 10th / 90th percentile of the iv_rank
        values stored on recently-closed fusion positions. When the snapshot's own
        IV rank sits in an extreme tail the band narrows inward automatically
        (handled inside :func:`gate.iv_band`), but the persisted quantile itself
        only shifts when the pooled distribution warrants it. Hard clamps keep
        the band from collapsing below ``(k.iv_band_hard_floor, k.iv_band_hard_ceiling)``.
        """
        k = self.tune_knobs
        try:
            from services.brain import gate as _gate

            payload = _gate.tune_iv_band(now, k)
            if payload is not None:
                db.event(
                    "info",
                    "iv_band_tune",
                    f"IV band adapted to [{payload['lo']:.3f}, {payload['hi']:.3f}] "
                    f"from {payload['n']} recent trades",
                )
        except Exception:
            logger.exception("brain: IV-band auto-tune failed")

    # --- one management tick ---------------------------------------------
    def tick_once(
        self, data: DataSource, gw: executor.Gateway, now: float | None = None
    ) -> dict[str, Any]:
        now = now or time.time()
        out: dict[str, Any] = {}
        if not getattr(self, "_tuned_restored", False):
            self._tuned_restored = True
            self._restore_tuned_limits()
        # Auto-tune Brain risk limits from recent closed trade outcomes on every
        # tick (throttled to 5 min internally) — real-time, no restart needed.
        self._auto_tune_brain_limits(now)
        # Same idea for the cheap-premium cap: adapt it inside the human
        # ceiling from what actually pays, throttled to 5 min internally.
        self._auto_tune_premium_cap(now)
        # Also let the Brain AI nudge PPA edge knobs from performance data.
        self._auto_tune_ppa(now)
        # Adaptive IV-band: re-derive the live gate band from recent trade
        # outcomes on a 10-minute throttle so an IV-rank distribution that has
        # drifted stays relevant across the session without re-parsing bars.
        self._auto_tune_iv_band(now)
        if not db.positions_open():
            return out
        state = self.gate_state(data, gw, now, 0.0)
        if (
            state.equity < state.peak_equity
            and risk_gate.drawdown_pct(state) >= self.limits.max_drawdown_pct
        ):
            if not db.state_get("drawdown_halt", False):
                db.state_set("drawdown_halt", True)
                db.event(
                    "error",
                    "drawdown_halt",
                    f"drawdown {risk_gate.drawdown_pct(state):.1f}% reached the limit; halted until released by a human",
                )
        verdict = risk_gate.check_manage(self.limits, state)
        out["manage"] = executor.manage(
            gw,
            now,
            flatten_reason="; ".join(verdict.reasons) if verdict.flatten else None,
            limits=self.limits,
            now_min=state.now_min,
        )
        return out

    # --- loop ---------------------------------------------------------------
    def _bars_for_labels(self, data: OpenAlgoData):
        return lambda u, since: data.bars(u, 2000, since=since)

    # --- Swing / positional scanning ----------------------------------------
    def _scan_swing(self, data: OpenAlgoData, gw: Any, api_key: str, now: float) -> dict[str, Any]:
        """Scan underlyings for swing-trade opportunities using daily bars.

        Daily bars are fetched at their own interval: the swing engine needs
        60+ daily sessions for its 20/50/200 EMA stack, and a 5-minute window
        could never supply them. If daily bars are unavailable, a single event
        is recorded so the operator knows why the card shows nothing rather
        than wondering if it silently failed.
        """
        results: dict[str, Any] = {}
        self._swing_processed.clear()
        params, _, _ = self._snapshot()
        for u in self.underlyings:
            try:
                bars = data.daily_bars(u, count=500, days=1200)
                if bars is None or len(bars) < 80:
                    # Only warn once per day; re-fetching on every scan would spam the journal.
                    today_str = _ist(now).date().isoformat()
                    warned_key = f"swing_no_daily:{u}"
                    if db.state_get(warned_key) != today_str:
                        db.state_set(warned_key, today_str)
                        logger.warning(
                            "brain: swing missing daily bars for %s (have %d, need ≥80)",
                            u,
                            len(bars) if bars is not None else 0,
                        )
                    continue
                snap = Snapshot(
                    u,
                    now,
                    bars,
                    float(bars[-1, 4]),
                    lot_size=self._underlyings_lot_size(u),
                    chain=None,
                    iv_rank=None,
                    vix=None,
                    minute_of_day=0,
                    params=params,
                )
                res = swing_engine.analyze(snap)
                if abs(res.vote) > 0.3 and res.confidence > 0.4:
                    results[u] = {
                        "vote": float(res.vote),
                        "confidence": float(res.confidence),
                        "notes": list(res.notes),
                        "stop_distance": float(res.extras.get("swing_stop_distance", 0.0)),
                        "target_distance": float(res.extras.get("swing_target_distance", 0.0)),
                        "ts": now,
                    }
            except Exception:
                logger.exception("swing scan failed for %s", u)
        return results

    def _scan_positional(
        self, data: OpenAlgoData, gw: Any, api_key: str, now: float
    ) -> dict[str, Any]:
        """Scan underlyings for positional-trade opportunities using weekly bars.

        The weekly series is aggregated from daily bars by the engine itself.
        If no daily bars are available this is worth noting rather than
        disappearing into silence — a positional trade needs years of history,
        and the absence is an operator-visible constraint.
        """
        results: dict[str, Any] = {}
        self._positional_processed.clear()
        params, _, _ = self._snapshot()
        for u in self.underlyings:
            try:
                bars = data.daily_bars(u, count=1600, days=4000)
                if bars is None or len(bars) < 300:
                    today_str = _ist(now).date().isoformat()
                    warned_key = f"positional_no_daily:{u}"
                    if db.state_get(warned_key) != today_str:
                        db.state_set(warned_key, today_str)
                        logger.warning(
                            "brain: positional missing daily bars for %s (have %d, need ≥300)",
                            u,
                            len(bars) if bars is not None else 0,
                        )
                    continue
                snap = Snapshot(
                    u,
                    now,
                    bars,
                    float(bars[-1, 4]),
                    lot_size=self._underlyings_lot_size(u),
                    chain=None,
                    iv_rank=None,
                    vix=None,
                    minute_of_day=0,
                    params=params,
                )
                res = positional_engine.analyze(snap)
                if abs(res.vote) > 0.3 and res.confidence > 0.4:
                    results[u] = {
                        "vote": float(res.vote),
                        "confidence": float(res.confidence),
                        "notes": list(res.notes),
                        "stop_distance": float(res.extras.get("pos_stop_distance", 0.0)),
                        "target_distance": float(res.extras.get("pos_target_distance", 0.0)),
                        "ts": now,
                    }
            except Exception:
                logger.exception("positional scan failed for %s", u)
        return results

    def _enter_swing_positional(
        self, data: OpenAlgoData, gw: Any, api_key: str, now: float
    ) -> None:
        """Convert strong swing/positional scan signals into position entries.

        Swing and positional signals are produced by the daily/weekly scans and
        stored in ``self._swing_signals`` / ``self._positional_signals``. This
        method turns the strongest ones into live positions, gated by the same
        risk core as intraday fusion trades but with swing/positional hold
        limits and margin factors.
        """
        for kind, signals, position_type, trade_type in (
            ("swing", self._swing_signals, "swing", "swing"),
            ("positional", self._positional_signals, "positional", "positional"),
        ):
            for u, sig in signals.items():
                processed = self._swing_processed if kind == "swing" else self._positional_processed
                if u in processed:
                    continue  # already acted on this signal in the current cycle
                processed.add(u)
                try:
                    vote = float(sig.get("vote", 0.0))
                    confidence = float(sig.get("confidence", 0.0))
                    if abs(vote) < 0.3 or confidence < 0.4:
                        continue
                    side = "LONG" if vote > 0 else "SHORT"
                    snap_params, _, _ = self._snapshot()
                    # Horizon in 5-min bars: hold days x 78 bars/day (6.5h x 12 bars/hr).
                    hold_days = (
                        snap_params.swing_horizon_bars
                        if position_type == "swing"
                        else snap_params.positional_horizon_bars
                    )
                    horizon_bars = int(hold_days * executor.BARS_PER_TRADING_DAY)
                    # The contract must outlive the intended hold. Trading days
                    # expand to calendar days at 7/5 (a week of five sessions
                    # spans seven days), plus one day of margin — this is the
                    # expiry the chain is asked for, before any leg is priced.
                    required_dte = int(hold_days * executor.CALENDAR_DAYS_PER_TRADING_DAY) + 1
                    chain = data.chain(u, need_dte=required_dte) if hasattr(data, "chain") else None
                    spot = float(sig.get("spot", 0)) or (
                        float(data.bars(u, 1)[-1, 4]) if data.bars(u, 1) is not None else 0.0
                    )
                    if not chain or not spot:
                        continue
                    # Entry window check — swing/positional entries must also fall
                    # inside the research-backed entry window (09:35–13:00 IST).
                    minute_of_day = int((now + 19800) % 86400 // 60)
                    if not entry_window_ok(minute_of_day, self.limits):
                        continue
                    # IV gate per position type: buying premium into rich vol is
                    # unfavourable; selling premium into cheap vol is unfavourable.
                    chain = {**chain, "spot": chain.get("spot") or spot}
                    stats = options_engine.summarize(chain)
                    atm_iv = stats["atm_iv"]
                    if atm_iv > 0:
                        db.iv_add(u, atm_iv, now)
                        iv_rank = db.iv_rank(u, atm_iv)
                    else:
                        iv_rank = None
                    iv_allowed, _ = iv_regime_ok(iv_rank, snap_params)
                    # Swing/positional candidates buy premium, so a rich IV
                    # rank is the disqualifier. (Short-premium candidates never
                    # reach this loop; their IV gate lives on the short path.)
                    if not iv_allowed:
                        logger.info(
                            "brain: %s entry skipped for %s: iv rank too high to buy",
                            position_type,
                            u,
                        )
                        continue
                    # Select an option leg for the swing/positional direction
                    legs = executor.select_legs(chain, side, spot)
                    if not legs:
                        continue
                    dte = float(legs[next(iter(legs))].get("dte") or 0.0)
                    # The horizon gate: even with a horizon-aware expiry request
                    # the listed expiries can fall short (a fresh listing, or a
                    # hold longer than anything listed). Entering anyway would
                    # guarantee settlement before the thesis can play out.
                    if dte < required_dte:
                        gate_key = f"expiry_too_short:{kind}:{u}"
                        today_str = _ist(now).date().isoformat()
                        if db.state_get(gate_key) != today_str:
                            db.state_set(gate_key, today_str)
                            db.event(
                                "warn",
                                "expiry_too_short",
                                f"{u}: {kind} entry skipped — needs {required_dte} DTE to cover "
                                f"a {hold_days}-day hold; best listed expiry has {dte:.0f}",
                                {"symbol": u, "need_dte": required_dte, "dte": dte},
                            )
                        continue
                    # Band choice uses the same learned picker as the intraday
                    # path: OTM only inside the gamma zone, with per-band
                    # expectancy offsets learned from each band's own results.
                    band = pick_band(legs, vote * confidence, band_offsets(u, "trend"), dte)
                    if band is None:
                        # No learned preference could pick: stay nearest to spot.
                        band = min(legs.keys(), key=lambda b: abs(float(legs[b]["strike"]) - spot))
                    leg = legs[band]
                    # Build a minimal Candidate for plan_levels / risk gate
                    from services.brain.fusion import Candidate

                    # Use swing/positional-specific k_stop/k_target from params
                    k_stop = (
                        snap_params.swing_k_stop
                        if position_type == "swing"
                        else snap_params.positional_k_stop
                    )
                    k_target = (
                        snap_params.swing_k_target
                        if position_type == "swing"
                        else snap_params.positional_k_target
                    )
                    # Horizon in 5-min bars and required DTE were computed above,
                    # before the chain was requested — the expiry must be picked
                    # to cover the hold, not the other way round.
                    sigma_h = abs(vote) * 0.01  # proxy: vote as a % move
                    cand = Candidate(
                        underlying=u,
                        side=side,
                        position_type=position_type,
                        regime="trend",
                        score=vote,
                        agree=1,
                        prob=confidence,
                        prob_prior=confidence,
                        ev_r=vote * confidence,
                        rr=k_target / k_stop if k_stop > 0 else 1.0,
                        sigma_h=sigma_h,
                        k_stop=k_stop,
                        k_target=k_target,
                        horizon_bars=horizon_bars,
                        features={},
                        votes={},
                        reasons=(f"{kind} signal: vote={vote:.2f} conf={confidence:.2f}",),
                        passed=True,
                        reject="",
                    )
                    lv = executor.plan_levels(cand, leg, spot, snap_params)
                    state = self.gate_state(data, gw, now, 0.0, underlying=u)
                    verdict = risk_gate.check_entry(
                        self.limits,
                        state,
                        risk_gate.Proposal(
                            leg["entry"],
                            leg["lot_size"],
                            leg.get("spread_pct", 0.0),
                            lv["risk_per_unit"],
                            band=band,
                            dte=dte,
                            trade_type=trade_type,
                        ),
                    )
                    if not verdict.allow:
                        logger.info(
                            "brain: %s entry blocked for %s: %s",
                            position_type,
                            u,
                            "; ".join(verdict.reasons),
                        )
                        continue
                    mode, why = self.entry_mode(api_key)
                    if mode is None:
                        continue
                    fo_ex = get_underlyings()[u][1]
                    sig_id = db.signal_add(
                        {
                            "ts": now,
                            "bar_ts": now,
                            "underlying": u,
                            "side": side,
                            "regime": cand.regime,
                            "score": cand.score,
                            "agree": cand.agree,
                            "prob": cand.prob,
                            "prob_prior": cand.prob_prior,
                            "ev_r": cand.ev_r,
                            "rr": cand.rr,
                            "sigma_h": cand.sigma_h,
                            "k_stop": cand.k_stop,
                            "k_target": cand.k_target,
                            "horizon_bars": cand.horizon_bars,
                            "entry_spot": spot,
                            "passed": cand.passed,
                            "reject": cand.reject,
                            "status": "SUGGESTED" if cand.passed else "OBSERVED",
                            "path": "Fusion",
                            "features": cand.features,
                            "votes": cand.votes,
                            "reasons": list(cand.reasons),
                            "model_version": 0,
                            "position_type": cand.position_type,
                            "band": band,
                            "symbol": leg["symbol"],
                            "dte": leg["dte"],
                            "gamma": leg["gamma"],
                            "leg_delta": leg["delta"],
                            "leg_entry": lv["entry"],
                            "leg_stop": lv["stop"],
                            "leg_target": lv["target"],
                        }
                    )
                    ok, pid, msg = executor.enter(
                        gw,
                        cand,
                        leg,
                        verdict.lots,
                        mode,
                        sig_id,
                        spot,
                        snap_params,
                        0,  # model_version
                        exchange=fo_ex,
                        now=now,
                    )
                    if ok:
                        db.event(
                            "info",
                            f"{position_type}_entry",
                            f"{u}: entered {position_type} {side} position {pid} ({msg})",
                            {"underlying": u, "position_type": position_type, "position_id": pid},
                        )
                except Exception:
                    logger.exception("brain: %s entry failed for %s", kind, u)

    @staticmethod
    def _underlyings_lot_size(underlying: str) -> int:
        """The contract multiplier for an index."""
        try:
            return lot_size(underlying)
        except Exception:
            return 65

    # --- main scan loop -------------------------------------------------------
    def _loop(self) -> None:
        logger.info("AI Brain loop started")
        db.event("info", "start", "Brain loop started")
        api_key = None
        key_refreshed = 0.0
        while not self.stop_flag.is_set():
            try:
                now = time.time()
                if self.enabled():
                    # Re-resolve regularly (cheap DB read) so a key added,
                    # changed or account-switched takes effect without a
                    # restart. Keep the previous key if the lookup fails —
                    # a transient DB hiccup must not blind the loop.
                    if now - key_refreshed >= 300:
                        key_refreshed = now
                        resolved = resolve_api_key()
                        if resolved:
                            api_key = resolved
                    if api_key:
                        # Reuse OpenAlgoData / OpenAlgoGateway across loop passes so
                        # their TTL caches (bars, quotes, chain) actually pay off.
                        # Recreate only when the resolved API key changes.
                        if (
                            self._loop_data is None
                            or self._loop_gw is None
                            or self._loop_api_key != api_key
                        ):
                            self._loop_data = OpenAlgoData(api_key, source="api")
                            self._loop_gw = executor.OpenAlgoGateway(api_key)
                            self._loop_api_key = api_key
                        data, gw = self._loop_data, self._loop_gw
                        if market_open(now):
                            self.tick_once(data, gw, now)
                            due, bucket = scan_due(
                                now,
                                self._last["scan"],
                                int(self._last["scan_bucket"]),
                                self.scan_interval,
                            )
                            if due:
                                self._last["scan"] = now
                                self._last["scan_bucket"] = bucket
                                self.scan_once(data, gw, api_key, now)
                            # Swing scan - runs at swing_scan_interval (default daily)
                            if now - self._last.get("swing_scan", 0) >= self.swing_scan_interval:
                                self._last["swing_scan"] = now
                                self._swing_signals = self._scan_swing(data, gw, api_key, now)
                            # Positional scan - runs at positional_scan_interval (default weekly)
                            if (
                                now - self._last.get("positional_scan", 0)
                                >= self.positional_scan_interval
                            ):
                                self._last["positional_scan"] = now
                                self._positional_signals = self._scan_positional(
                                    data, gw, api_key, now
                                )
                            # Convert strong swing/positional signals into position entries.
                            self._enter_swing_positional(data, gw, api_key, now)
                            if now - self._last["reconcile"] >= 300:
                                self._last["reconcile"] = now
                                executor.reconcile(gw, platform_mode(), now)
                            # Periodic self-tuning during market hours: label newly-elapsed
                            # signals, tune thresholds/weights, and promote/rollback the champion
                            # so the Brain adapts to the live market without waiting for the close.
                            if now - self._last["learn"] >= 1800:
                                self._last["learn"] = now
                                self.learn(data, search=False)
                        else:
                            # Out of hours: still honour a kill switch and the square-off for anything left open.
                            if db.positions_open() and _ist(now).weekday() < 5:
                                self.tick_once(data, gw, now)
                            day = _ist(now).date().isoformat()
                            # Also consult the persisted learn-day so a restart that lands on the
                            # same calendar day does not run the daily search again; the DB value
                            # survives crashes while self._last["learn_day"] is reset to "" on boot.
                            persisted_day = db.state_get("learn_day", "")
                            if (
                                _ist(now).hour * 60 + _ist(now).minute >= 15 * 60 + 40
                                and self._last["learn_day"] != day
                                and persisted_day != day
                            ):
                                self._last["learn_day"] = day
                                db.state_set("learn_day", day)
                                self.learn(data)
                            self._ppa_daily_report(now)
                self.last_error = ""
                self._loop_errors = 0
            except Exception as e:
                self.last_error = str(e)
                self._loop_errors += 1
                logger.exception("brain loop error")
                db.event("error", "loop", str(e))
                # Exponential backoff on consecutive errors so a repeatedly
                # failing tick does not hot-loop; cap at 5 minutes.
                backoff = min(5.0 * (2.0 ** (self._loop_errors - 1)), 300.0)
                self.stop_flag.wait(backoff)
                continue
            self.stop_flag.wait(5.0)

    def _ppa_daily_report(self, now: float) -> None:
        """Once per trading day after the close: label what has matured and journal a summary.

        The line goes to the Events tab (kind ``ppa_candidates``), the log, and
        ``brain_state['ppa_candidates_last']``. One attempt per day: the day is
        recorded first, so a failure cannot loop. Read-only apart from labelling.
        """
        d = _ist(now)
        day = d.date().isoformat()
        if d.weekday() >= 5 or d.hour * 60 + d.minute < 15 * 60 + 45:
            return
        if db.state_get("ppa_report_day", "") == day:
            return
        db.state_set("ppa_report_day", day)
        try:
            from services.brain import ppa_candidates

            labelled = ppa_candidates.label_pending(now, force=True)
            summary = ppa_candidates.summary()
            line = ppa_candidates.format_summary(summary, labelled)
            db.state_set(
                "ppa_candidates_last",
                json.loads(
                    json.dumps({"day": day, "labelled_now": labelled, **summary}, default=str)
                ),
            )
            db.event("info", "ppa_candidates", line, summary)
            logger.info("brain: %s", line)
        except Exception:
            logger.exception("brain: PPA daily candidate report failed")

    def learn(self, data: OpenAlgoData | None = None, search: bool = True) -> dict[str, Any]:
        if data is None:
            key = resolve_api_key()
            if not key:
                return {"error": "no api key"}
            data = OpenAlgoData(key, source="db")
        with self.lock:
            # Auto-bootstrap on fresh install: if the signal journal is empty,
            # replay historical bars for every underlying so the learning cycle
            # has labelled data to train on without manual intervention.
            try:
                self._reset_stale_journal()
                counts = db.signal_counts()
                if counts["total"] == 0:
                    self._auto_bootstrap(data)
            except Exception:
                logger.exception("brain: auto-bootstrap check failed")
            out = learner.learn_cycle(
                self._bars_for_labels(data), search=search, api_key=getattr(data, "api_key", "")
            )
            if search:
                # Only a search can change the champion, so only a search may
                # reload it. The live config is the champion's and nothing else.
                self.reload_champion()
        return out

    @staticmethod
    def _reset_stale_journal() -> None:
        """Rebuild the journal when the engines' meaning has changed.

        The stored votes were produced by the engines as they were then. When
        an engine reads the market differently, those votes describe a
        different system, and a model trained on them is trained on the wrong
        thing. The journal is rebuilt from the bars and the champion retired.
        """
        current = db.state_get("journal_epoch", "")
        if current == fusion.FEATURE_EPOCH:
            return
        try:
            counts = db.signal_counts()
            if counts["total"]:
                cleared = db.clear_signals()
                retired = db.retire_champions(f"engine epoch {fusion.FEATURE_EPOCH}")
                db.event(
                    "warn",
                    "journal_reset",
                    f"the engines changed meaning (epoch {fusion.FEATURE_EPOCH}); "
                    f"dropped {cleared['deleted']} stored signals and retired "
                    f"{retired} champion model(s). The journal rebuilds from the bars.",
                )
            db.state_set("journal_epoch", fusion.FEATURE_EPOCH)
        except Exception:
            logger.exception("brain: could not reset the stale journal")

    def _auto_bootstrap(self, data: OpenAlgoData) -> None:
        """Seed the journal with historical signals on a fresh install.

        The replay needs a few weeks of 5-minute bars: the engines have a
        150-bar warm-up, and a handful of sessions is not enough to say
        anything about how they behave. The store holds years of it, so the
        bootstrap reads a wide window rather than the live scan's seven days.
        """
        underlyings = get_underlyings()
        since = time.time() - BOOTSTRAP_HISTORY_DAYS * 86400.0
        for underlying in underlyings:
            try:
                bars = data.bars(underlying, BOOTSTRAP_MAX_BARS, since=since)
                if bars is None or len(bars) < BOOTSTRAP_MIN_BARS:
                    logger.warning(
                        "brain: auto-bootstrap insufficient bars for %s (%s)",
                        underlying,
                        len(bars) if bars is not None else 0,
                    )
                    continue
                n = learner.bootstrap_from_bars(bars, underlying)
                logger.info("brain: auto-bootstrapped %s signals for %s", n, underlying)
            except Exception:
                logger.exception("brain: auto-bootstrap failed for %s", underlying)

    def start(self) -> None:
        if self.thread and self.thread.is_alive():
            return
        db.init_db()
        self.reload_champion()
        self.stop_flag.clear()
        self.thread = threading.Thread(target=self._loop, name="ai-brain", daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self.stop_flag.set()
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=10.0)


brain = BrainService()
