"""Historical bars for the Brain, read from Historify.

The live Brain reads a few days of 5-minute bars from whatever source the
orchestrator was given. A study over the whole stored history needs the same
bars in the same shape, for years, without the live source's throttles, top-ups
and caches. This module owns that read: it turns a date range into the
``(n, 6)`` float array of ``[timestamp, open, high, low, close, volume]`` rows
that ``backtest.precompute`` and ``backtest.replay`` already accept.

It is deliberately small and free of Brain logic. Every function here is either
a calendar calculation or a dataframe-to-array normalisation, so a test can run
it without DuckDB, without a broker and without a database.

Timestamps are epoch seconds throughout, and every calendar calculation is in
IST, because the exchange day, the square-off and the bar labels all are.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone

import numpy as np

from utils.logging import get_logger

logger = get_logger(__name__)

IST = timezone(timedelta(hours=5, minutes=30))

#: The Brain decides on 5-minute bars (``labeling.BAR_S``).
BAR_S = 300
INTERVAL = "5m"

#: Columns of the bar array, in order.
BAR_FIELDS = ("timestamp", "open", "high", "low", "close", "volume")

#: Bars the engines need behind a decision. ``precompute`` hands the engines
#: ``bars[:i + 1][-400:]``, so a fold whose first sampled bar has fewer than
#: this many bars behind it would run the engines on a truncated window.
MIN_WARMUP_BARS = 400

#: Calendar slack around a range, so the lookback and the label window of the
#: outermost folds are backed by real bars rather than by nothing.
DEFAULT_LOOKBACK_DAYS = 15
DEFAULT_PAD_DAYS = 10

FOLDS = ("month", "quarter", "year")

BarsFetcher = Callable[[str, str, int, int], "np.ndarray | None"]
"""(underlying, exchange, start_ts, end_ts) -> bar array, or None if unavailable."""


@dataclass(frozen=True, slots=True)
class Fold:
    """One evaluation period, in IST calendar days. ``end`` is exclusive."""

    label: str
    start: date
    end: date

    @property
    def start_ts(self) -> float:
        return day_start(self.start)

    @property
    def end_ts(self) -> float:
        return day_start(self.end)


def day_start(d: date) -> float:
    """Epoch seconds of midnight IST on ``d``."""
    return datetime(d.year, d.month, d.day, tzinfo=IST).timestamp()


def ist_date(ts: float) -> date:
    """The IST calendar date an epoch timestamp falls on."""
    return datetime.fromtimestamp(float(ts), IST).date()


def _align(d: date, fold: str) -> date:
    """The first day of the fold that contains ``d``."""
    if fold == "month":
        return date(d.year, d.month, 1)
    if fold == "quarter":
        return date(d.year, ((d.month - 1) // 3) * 3 + 1, 1)
    if fold == "year":
        return date(d.year, 1, 1)
    raise ValueError(f"unknown fold {fold!r}, expected one of {FOLDS}")


def _advance(d: date, fold: str) -> date:
    if fold == "month":
        return date(d.year + (d.month == 12), d.month % 12 + 1, 1)
    if fold == "quarter":
        m = d.month + 3
        return date(d.year + (m - 1) // 12, (m - 1) % 12 + 1, 1)
    return date(d.year + 1, 1, 1)


def _label(d: date, fold: str) -> str:
    if fold == "month":
        return f"{d.year}-{d.month:02d}"
    if fold == "quarter":
        return f"{d.year}Q{(d.month - 1) // 3 + 1}"
    return str(d.year)


def fold_ranges(start: date, end: date, fold: str = "quarter") -> list[Fold]:
    """Split ``[start, end)`` into consecutive labelled folds.

    The first fold is aligned back to its own start, so a run from mid-February
    still reports the whole of that quarter and the folds never overlap. The
    last fold is clipped at ``end``.
    """
    if end <= start:
        return []
    out: list[Fold] = []
    cursor = _align(start, fold)
    while cursor < end:
        nxt = _advance(cursor, fold)
        out.append(Fold(_label(cursor, fold), cursor, min(nxt, end)))
        cursor = nxt
    return out


def normalise(rows) -> np.ndarray:
    """The bar array a backtest needs, from anything dataframe- or array-shaped.

    Rows arrive from DuckDB as a DataFrame and from a stored source as a list of
    lists. Both are coerced to ``float64`` here and then cleaned: a NaN, an
    inf, a zero or negative price, a high below its low, or a bar timestamped
    at or before the epoch is dropped rather than allowed into an engine's
    rolling statistics, where one bad row poisons every window after it. Bars
    are sorted by time and a repeated timestamp keeps its last row (Historify
    is rewritten in place on a re-download, so the later row is the correction).
    """
    if rows is None:
        return np.empty((0, len(BAR_FIELDS)), dtype=float)
    if hasattr(rows, "to_numpy"):
        try:
            arr = rows[list(BAR_FIELDS)].to_numpy(dtype=float)
        except (KeyError, ValueError, TypeError):
            return np.empty((0, len(BAR_FIELDS)), dtype=float)
    else:
        arr = np.asarray(rows, dtype=float)
    if arr.ndim != 2 or arr.shape[1] < len(BAR_FIELDS):
        return np.empty((0, len(BAR_FIELDS)), dtype=float)
    arr = arr[:, : len(BAR_FIELDS)]
    arr = arr[np.isfinite(arr).all(axis=1)]
    if len(arr) == 0:
        return np.empty((0, len(BAR_FIELDS)), dtype=float)
    keep = (arr[:, 0] > 0) & (arr[:, 3] > 0) & (arr[:, 2] >= arr[:, 3])
    arr = arr[keep]
    if len(arr) == 0:
        return np.empty((0, len(BAR_FIELDS)), dtype=float)
    arr = arr[np.argsort(arr[:, 0], kind="stable")]
    keep = np.ones(len(arr), dtype=bool)
    keep[:-1] = arr[1:, 0] != arr[:-1, 0]  # keep the last row of each timestamp
    return np.ascontiguousarray(arr[keep])


def historify_fetcher(underlying: str, exchange: str, start_ts: int, end_ts: int):
    """The default fetcher: 5-minute bars aggregated from Historify's 1-minute store.

    Historify stores 1-minute bars and aggregates on read, aligned to the
    exchange's own open, which is the same series the live Brain sees. Returns
    ``None`` when the store cannot be read at all, so the caller can tell "no
    history" from "empty range".
    """
    from database.historify_db import get_ohlcv

    try:
        df = get_ohlcv(
            symbol=underlying,
            exchange=exchange,
            interval=INTERVAL,
            start_timestamp=int(start_ts),
            end_timestamp=int(end_ts),
        )
    except Exception:
        logger.exception("brain history: reading %s from Historify failed", underlying)
        return None
    if df is None or len(df) == 0:
        return None
    return df


def load_bars(
    underlying: str,
    exchange: str,
    start_ts: float,
    end_ts: float,
    fetch: BarsFetcher | None = None,
) -> np.ndarray:
    """Bars for one underlying over ``[start_ts, end_ts]``, cleaned and sorted.

    An unavailable or empty range is an empty array, never ``None``: a study
    over a hundred ranges should not need a null check on each one.
    """
    fetcher = fetch or historify_fetcher
    raw = fetcher(underlying, exchange, int(start_ts), int(end_ts))
    return normalise(raw)


def window_slice(bars: np.ndarray, start_ts: float, end_ts: float) -> tuple[int, int]:
    """``(i0, i1)``: the half-open bar range whose timestamps fall in ``[start, end)``.

    ``i0 == i1`` means the range holds no bars at all.
    """
    if len(bars) == 0:
        return 0, 0
    i0 = int(np.searchsorted(bars[:, 0], float(start_ts), side="left"))
    i1 = int(np.searchsorted(bars[:, 0], float(end_ts), side="left"))
    return i0, max(i0, i1)


def study_range(
    start: date,
    end: date,
    lookback_days: int = DEFAULT_LOOKBACK_DAYS,
    pad_days: int = DEFAULT_PAD_DAYS,
) -> tuple[float, float]:
    """Epoch bounds to load so every fold's warmup and label window has real bars."""
    lo = day_start(start - timedelta(days=lookback_days))
    hi = day_start(end + timedelta(days=pad_days))
    return lo, hi


def align_bench(bars: np.ndarray, bench: np.ndarray) -> np.ndarray | None:
    """The benchmark series reindexed onto ``bars``' own timestamps.

    The engines measure ``bars`` against the closes of a peer series and index
    both by the same position, so the two must be row-for-row the same length
    and the same instants. Two exchanges do not always agree: a missing bar in
    one, an extra one in the other, a different holiday calendar. Where the
    benchmark has no bar at an instant, the last close it did print is carried
    forward — the same stale price a live scan would see — and leading bars
    take the first one it printed. That makes a benchmark usable without ever
    letting the two series drift apart by one bar, which would silently
    correlate every later row with the wrong instant.

    ``None`` when there is no benchmark at all: the engines then see the absent
    peer they already handle, which is what a live scan with an unfetched
    benchmark looks like.
    """
    if len(bars) == 0 or bench is None or len(bench) == 0:
        return None
    idx = np.searchsorted(bench[:, 0], bars[:, 0], side="right") - 1
    idx = np.clip(idx, 0, len(bench) - 1)
    out = bench[idx].copy()
    out[:, 0] = bars[:, 0]
    return out
