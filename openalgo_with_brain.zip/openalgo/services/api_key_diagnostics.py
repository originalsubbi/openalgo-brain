"""API-key diagnostics for the REST surface.

The most common mistake on this surface is sending the *broker's* key where
OpenAlgo's own API key is expected: the broker credential is a composite
("client_id:::api_key" for Dhan) and never matches an OpenAlgo API key, so the
call dies with a flat "Invalid openalgo apikey" that says nothing about why.

These helpers turn that dead end into a precise, safe answer. No key material
is ever echoed: only the *shape* of what was sent is described.
"""

from __future__ import annotations

BROKER_KEY_MARKER = ":::"

INVALID_KEY_MESSAGE = "Invalid openalgo apikey"


def looks_like_broker_key(api_key: str | None) -> bool:
    """True when the value is a broker credential rather than an OpenAlgo key.

    Broker plugins compose their credential ("client_id:::api_key", or a
    "<client>:<secret>" pair) and those never authenticate against OpenAlgo's
    own API-key table.
    """
    if not api_key:
        return False
    key = str(api_key).strip()
    if BROKER_KEY_MARKER in key:
        return True
    # "<token>:<secret>" style credentials from the HTTP-based brokers.
    if key.count(":") == 1 and len(key.split(":", 1)[1]) >= 16:
        return True
    return False


def invalid_key_message(api_key: str | None = None) -> str:
    """The message to return for a rejected key, with the likely cause named."""
    if looks_like_broker_key(api_key):
        return (
            f"{INVALID_KEY_MESSAGE}: this is a broker credential, not an OpenAlgo API key. "
            "Use the OpenAlgo API key shown on the /apikey page."
        )
    return (
        f"{INVALID_KEY_MESSAGE}: the key is not one of this installation's OpenAlgo API keys. "
        "Use the key shown on the /apikey page (the broker key does not work here)."
    )


__all__ = [
    "BROKER_KEY_MARKER",
    "INVALID_KEY_MESSAGE",
    "invalid_key_message",
    "looks_like_broker_key",
]
