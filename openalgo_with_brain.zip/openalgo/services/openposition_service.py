import copy
from typing import Any, Dict, Optional, Tuple

from database.analyzer_db import async_log_analyzer
from database.apilog_db import async_log_order
from database.apilog_db import executor as log_executor
from database.auth_db import get_auth_token_broker
from database.settings_db import get_analyze_mode
from extensions import emit_from_any_thread
from utils.logging import get_logger

# Initialize logger
logger = get_logger(__name__)


def _emit_analyzer_update(payload: dict[str, Any]) -> None:
    """Tell the browser about an analyzer-mode request. Never raises.

    Emitted on the caller's thread rather than on a new one per event: the
    Socket.IO server serialises emits itself (``extensions.SerializedSocketIO``),
    and a thread per emit let two updates reach the browser out of order.
    ``emit_from_any_thread`` hands the emit to the hub when a real OS thread
    calls under eventlet (the agent's order tools reach this service).
    """
    try:
        emit_from_any_thread("analyzer_update", payload)
    except Exception:
        logger.exception("Could not send the analyzer update to the browser")


def emit_analyzer_error(request_data: dict[str, Any], error_message: str) -> dict[str, Any]:
    """
    Helper function to emit analyzer error events

    Args:
        request_data: Original request data
        error_message: Error message to emit

    Returns:
        Error response dictionary
    """
    error_response = {"mode": "analyze", "status": "error", "message": error_message}

    # Store complete request data without apikey
    analyzer_request = request_data.copy()
    if "apikey" in analyzer_request:
        del analyzer_request["apikey"]
    analyzer_request["api_type"] = "openposition"

    # Log to analyzer database
    log_executor.submit(async_log_analyzer, analyzer_request, error_response, "openposition")

    # Emit socket event (non-blocking: the server only queues it)
    _emit_analyzer_update({"request": analyzer_request, "response": error_response})

    return error_response


def get_open_position_with_auth(
    position_data: dict[str, Any], auth_token: str, broker: str, original_data: dict[str, Any]
) -> tuple[bool, dict[str, Any], int]:
    """
    Get quantity of an open position using provided auth token.

    Args:
        position_data: Position data containing symbol, exchange, and product
        auth_token: Authentication token for the broker API
        broker: Name of the broker
        original_data: Original request data for logging

    Returns:
        Tuple containing:
        - Success status (bool)
        - Response data (dict)
        - HTTP status code (int)
    """
    request_data = copy.deepcopy(original_data)
    if "apikey" in request_data:
        request_data.pop("apikey", None)

    # If in analyze mode, route to sandbox for real position data
    if get_analyze_mode():
        from services.sandbox_service import sandbox_get_positions

        api_key = original_data.get("apikey")
        if not api_key:
            return (
                False,
                {
                    "status": "error",
                    "message": "API key required for sandbox mode",
                    "mode": "analyze",
                },
                400,
            )

        # Get all positions from sandbox
        success, positions_response, status_code = sandbox_get_positions(api_key, original_data)

        if not success:
            return False, positions_response, status_code

        # Find the specific position for the requested symbol/exchange/product
        symbol = position_data.get("symbol")
        exchange = position_data.get("exchange")
        product = position_data.get("product")

        positions = positions_response.get("data", [])
        quantity = 0

        for pos in positions:
            if (
                pos.get("symbol") == symbol
                and pos.get("exchange") == exchange
                and pos.get("product") == product
            ):
                quantity = pos.get("quantity", 0)
                break

        response_data = {"quantity": quantity, "status": "success", "mode": "analyze"}

        # Log and emit
        analyzer_request = request_data.copy()
        analyzer_request["api_type"] = "openposition"
        log_executor.submit(async_log_analyzer, analyzer_request, response_data, "openposition")
        # Emit SocketIO event (non-blocking: the server only queues it)
        _emit_analyzer_update({"request": analyzer_request, "response": response_data})

        return True, response_data, 200

    # Live mode - get position from positionbook
    try:
        from services.positionbook_service import get_positionbook

        api_key = position_data.get("apikey")
        success, positionbook_data, status_code = get_positionbook(api_key=api_key)

        if not success:
            error_response = {
                "status": "error",
                "message": positionbook_data.get("message", "Failed to fetch positionbook"),
            }
            log_executor.submit(async_log_order, "openposition", original_data, error_response)
            return False, error_response, status_code

        # Find the specific position
        position_found = None
        for position in positionbook_data["data"]:
            if (
                position.get("symbol") == position_data["symbol"]
                and position.get("exchange") == position_data["exchange"]
                and position.get("product") == position_data["product"]
            ):
                position_found = position
                break

        # Return 0 quantity if position not found
        if not position_found:
            response_data = {"quantity": 0, "status": "success"}
            log_executor.submit(async_log_order, "openposition", request_data, response_data)
            return True, response_data, 200

        # Return the position quantity
        response_data = {"quantity": position_found["quantity"], "status": "success"}
        log_executor.submit(async_log_order, "openposition", request_data, response_data)

        return True, response_data, 200

    except Exception as e:
        logger.exception(f"Error processing open position: {e}")
        error_response = {"status": "error", "message": str(e)}
        log_executor.submit(async_log_order, "openposition", original_data, error_response)
        return False, error_response, 500


def get_open_position(
    position_data: dict[str, Any],
    api_key: str | None = None,
    auth_token: str | None = None,
    broker: str | None = None,
) -> tuple[bool, dict[str, Any], int]:
    """
    Get quantity of an open position.
    Supports both API-based authentication and direct internal calls.

    Args:
        position_data: Position data containing symbol, exchange, and product
        api_key: OpenAlgo API key (for API-based calls)
        auth_token: Direct broker authentication token (for internal calls)
        broker: Direct broker name (for internal calls)

    Returns:
        Tuple containing:
        - Success status (bool)
        - Response data (dict)
        - HTTP status code (int)
    """
    original_data = copy.deepcopy(position_data)
    if api_key:
        original_data["apikey"] = api_key

    # Case 1: API-based authentication
    if api_key and not (auth_token and broker):
        # Add API key to position data
        position_data["apikey"] = api_key

        AUTH_TOKEN, broker_name = get_auth_token_broker(api_key)
        if AUTH_TOKEN is None:
            error_response = {"status": "error", "message": "Invalid openalgo apikey"}
            # Skip logging for invalid API keys to prevent database flooding
            return False, error_response, 403

        return get_open_position_with_auth(position_data, AUTH_TOKEN, broker_name, original_data)

    # Case 2: Direct internal call with auth_token and broker
    elif auth_token and broker:
        return get_open_position_with_auth(position_data, auth_token, broker, original_data)

    # Case 3: Invalid parameters
    else:
        error_response = {
            "status": "error",
            "message": "Either api_key or both auth_token and broker must be provided",
        }
        return False, error_response, 400
