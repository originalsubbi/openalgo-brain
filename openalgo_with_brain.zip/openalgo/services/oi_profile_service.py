"""
OI Profile Service
Combines futures candlestick data with options Open Interest profile.

Three panels:
  1. Futures OHLC candles (intraday, user-selected interval)
  2. Current OI butterfly (CE right, PE left per strike)
  3. Daily OI change butterfly (CE change right, PE change left)

Current OI is fetched efficiently via option chain (multiquotes).
Daily OI change is computed from daily history (parallel execution).
"""

import time
from datetime import datetime, timedelta
from typing import Any

import pytz

from database.token_db_enhanced import fno_search_symbols
from services.history_service import get_history
from services.option_chain_service import get_option_chain
from services.strategy_chart_service import (
    _cap_last_n_trading_dates,
    _resolve_trading_window,
)
from utils import runtime
from utils.constants import CRYPTO_EXCHANGES, INSTRUMENT_PERPFUT
from utils.logging import get_logger

logger = get_logger(__name__)

#: Longest one OI Profile request spends fetching previous-day OI under the
#: gthread worker, in seconds. A 20-strike chain is up to 82 contracts, and
#: broker history requests are paced at about three a second, so a complete
#: fetch normally takes 30 to 40 seconds and fits. What the budget cuts short
#: is the case that ran for minutes: repeated broker refusals, each followed by
#: a backoff, while the request holds one of the gthread worker's fixed pool of
#: threads. Under eventlet and the development server there is no budget.
GTHREAD_OI_CHANGE_BUDGET_SECONDS = 60.0


def _oi_change_deadline() -> float | None:
    """Return the time.monotonic() deadline for the daily OI fetch, or None."""
    if not runtime.gthread_active():
        return None
    return time.monotonic() + GTHREAD_OI_CHANGE_BUDGET_SECONDS


def _oi_change_note(loaded: int, requested: int) -> str:
    """The sentence shown when the daily OI change covers only some contracts."""
    return (
        f"Loading the previous day's OI took too long, so the daily OI change is "
        f"shown for {loaded} of {requested} option contracts. Refresh in a minute "
        f"to load the rest."
    )


# Index symbols that need special exchange for quotes
NSE_INDEX_SYMBOLS = {
    "NIFTY",
    "BANKNIFTY",
    "FINNIFTY",
    "MIDCPNIFTY",
    "NIFTYNXT50",
}

BSE_INDEX_SYMBOLS = {"SENSEX", "BANKEX", "SENSEX50"}


def _find_futures_symbol(
    underlying: str, exchange: str, expiry_date: str, api_key: str
) -> dict | None:
    """
    Find the futures contract matching the underlying and expiry.

    Returns dict with 'symbol' and 'exchange' keys, or None.
    """
    try:
        # Convert DDMMMYY to DD-MMM-YY for database lookup
        expiry_formatted = f"{expiry_date[:2]}-{expiry_date[2:5]}-{expiry_date[5:]}".upper()

        # Search for futures contract matching this expiry
        # For crypto exchanges, perpetuals (PERPFUT) serve as the underlying
        if exchange.upper() in CRYPTO_EXCHANGES:
            _perp = fno_search_symbols(
                query=f"{underlying}USDFUT",
                exchange=exchange,
                instrumenttype=INSTRUMENT_PERPFUT,
                limit=1,
            )
            if not _perp:
                return None
            futures = [{"symbol": _perp[0]["symbol"], "exchange": _perp[0]["exchange"]}]
        else:
            futures = fno_search_symbols(
                underlying=underlying,
                exchange=exchange,
                instrumenttype="FUT",
                expiry=expiry_formatted,
                limit=1,
            )

        if not futures:
            # Try without expiry filter to get nearest futures
            if exchange.upper() in CRYPTO_EXCHANGES:
                logger.warning(f"No perpetual contracts found for {underlying} on {exchange}")
                return None
            futures = fno_search_symbols(
                underlying=underlying,
                exchange=exchange,
                instrumenttype="FUT",
                limit=10,
            )
            if not futures:
                logger.warning(f"No futures contracts found for {underlying} on {exchange}")
                return None

            # Sort by expiry to get nearest
            def parse_expiry(exp_str: str) -> datetime:
                try:
                    return datetime.strptime(exp_str, "%d-%b-%y")
                except (ValueError, TypeError):
                    return datetime.max

            futures.sort(key=lambda f: parse_expiry(f.get("expiry", "")))

        return {"symbol": futures[0]["symbol"], "exchange": futures[0]["exchange"]}
    except Exception as e:
        logger.warning(f"Error finding futures symbol: {e}")
        return None


def _fetch_daily_oi_changes(
    option_symbols: list[dict],
    options_exchange: str,
    api_key: str,
    deadline: float | None = None,
) -> dict[str, float]:
    """
    Fetch daily history for options and return previous day's OI.

    Uses sequential batch processing with rate-limit handling to avoid
    broker 429 errors. Processes symbols in batches with delays between
    batches and retries individual failures with exponential backoff.

    Args:
        option_symbols: List of dicts with 'symbol' key
        options_exchange: Exchange for options (NFO, BFO)
        api_key: OpenAlgo API key
        deadline: A time.monotonic() value after which no further symbol is
            fetched and no retry is waited for, or None for no limit. A symbol
            not fetched in time is left out of the result rather than given
            a previous OI of zero.

    Returns:
        Dict mapping symbol -> previous_day_oi
    """
    end = datetime.now().strftime("%Y-%m-%d")
    start = (datetime.now() - timedelta(days=14)).strftime("%Y-%m-%d")

    results = {}

    # Only fetch for symbols with non-zero current OI
    symbols_to_fetch = [s["symbol"] for s in option_symbols if s.get("oi", 0) > 0]

    if not symbols_to_fetch:
        return results

    BATCH_SIZE = 5
    BATCH_DELAY = 0.5  # seconds between batches
    MAX_RETRIES = 2
    RETRY_BASE_DELAY = 1.0  # seconds, doubles each retry

    def out_of_time(wait: float = 0.0) -> bool:
        return deadline is not None and time.monotonic() + wait >= deadline

    def fetch_one_with_retry(symbol: str) -> tuple[str, float | None]:
        for attempt in range(MAX_RETRIES + 1):
            try:
                success, resp, status_code = get_history(
                    symbol=symbol,
                    exchange=options_exchange,
                    interval="D",
                    start_date=start,
                    end_date=end,
                    api_key=api_key,
                )
                if success and resp.get("data"):
                    data = resp["data"]
                    if len(data) >= 2:
                        prev_oi = data[-2].get("oi", 0) or 0
                        return symbol, float(prev_oi)
                    return symbol, 0.0

                # Rate limited - retry with backoff
                if status_code == 429 and attempt < MAX_RETRIES:
                    delay = RETRY_BASE_DELAY * (2**attempt)
                    if out_of_time(delay):
                        return symbol, None
                    logger.warning(
                        f"Rate limited fetching {symbol}, retry {attempt + 1} after {delay}s"
                    )
                    time.sleep(delay)
                    continue

                return symbol, 0.0
            except Exception as e:
                if attempt < MAX_RETRIES and "429" in str(e):
                    delay = RETRY_BASE_DELAY * (2**attempt)
                    if out_of_time(delay):
                        return symbol, None
                    logger.warning(
                        f"Rate limited fetching {symbol}, retry {attempt + 1} after {delay}s"
                    )
                    time.sleep(delay)
                    continue
                return symbol, 0.0
        return symbol, 0.0

    # Process in batches to respect rate limits
    for i in range(0, len(symbols_to_fetch), BATCH_SIZE):
        batch = symbols_to_fetch[i : i + BATCH_SIZE]
        for symbol in batch:
            if out_of_time():
                break
            sym, prev_oi = fetch_one_with_retry(symbol)
            if prev_oi is not None:
                results[sym] = prev_oi

        # Delay between batches (skip after last batch)
        if i + BATCH_SIZE < len(symbols_to_fetch):
            if out_of_time(BATCH_DELAY):
                break
            time.sleep(BATCH_DELAY)

    wanted = len(set(symbols_to_fetch))
    if deadline is not None and len(results) < wanted:
        logger.warning(
            f"OI Profile daily OI fetch stopped at its time budget: "
            f"{len(results)} of {wanted} contracts loaded"
        )

    return results


def get_oi_profile_data(
    underlying: str,
    exchange: str,
    expiry_date: str,
    interval: str,
    days: int,
    api_key: str,
) -> tuple[bool, dict[str, Any], int]:
    """
    Get OI Profile data: futures candles + OI butterfly + OI change.

    Args:
        underlying: Underlying symbol (e.g., NIFTY, BANKNIFTY)
        exchange: Exchange (NFO, BFO)
        expiry_date: Expiry in DDMMMYY format
        interval: Candle interval (1m, 5m, 15m)
        days: Number of days for futures candles
        api_key: OpenAlgo API key

    Returns:
        Tuple of (success, response_data, status_code)
    """
    try:
        # Determine options exchange
        options_exchange = exchange.upper()
        if options_exchange in ("NSE_INDEX", "NSE"):
            options_exchange = "NFO"
        elif options_exchange in ("BSE_INDEX", "BSE"):
            options_exchange = "BFO"

        # Step 1: Get option chain (current OI via multiquotes - efficient)
        success, chain_response, status_code = get_option_chain(
            underlying=underlying,
            exchange=exchange,
            expiry_date=expiry_date,
            strike_count=20,
            api_key=api_key,
        )

        if not success:
            return False, chain_response, status_code

        full_chain = chain_response.get("chain", [])
        atm_strike = chain_response.get("atm_strike")
        spot_price = chain_response.get("underlying_ltp")
        lot_size = None

        # Extract current OI data and build symbol list for daily history
        oi_chain = []
        option_symbols_for_history = []

        for item in full_chain:
            strike = item["strike"]
            ce = item.get("ce")
            pe = item.get("pe")

            ce_oi = 0
            pe_oi = 0
            ce_symbol = None
            pe_symbol = None

            if ce:
                ce_oi = ce.get("oi", 0) or 0
                ce_symbol = ce.get("symbol")
                if lot_size is None and ce.get("lotsize"):
                    lot_size = ce["lotsize"]
                if ce_symbol and ce_oi > 0:
                    option_symbols_for_history.append(
                        {"symbol": ce_symbol, "type": "CE", "strike": strike, "oi": ce_oi}
                    )

            if pe:
                pe_oi = pe.get("oi", 0) or 0
                pe_symbol = pe.get("symbol")
                if lot_size is None and pe.get("lotsize"):
                    lot_size = pe["lotsize"]
                if pe_symbol and pe_oi > 0:
                    option_symbols_for_history.append(
                        {"symbol": pe_symbol, "type": "PE", "strike": strike, "oi": pe_oi}
                    )

            oi_chain.append(
                {
                    "strike": strike,
                    "ce_oi": ce_oi,
                    "pe_oi": pe_oi,
                    "ce_symbol": ce_symbol,
                    "pe_symbol": pe_symbol,
                    "ce_oi_change": 0,
                    "pe_oi_change": 0,
                }
            )

        # Step 2: Find futures symbol and fetch candles
        futures_info = _find_futures_symbol(underlying, options_exchange, expiry_date, api_key)
        candles = []
        futures_symbol = None

        if futures_info:
            futures_symbol = futures_info["symbol"]
            fut_exchange = futures_info["exchange"]

            ist = pytz.timezone("Asia/Kolkata")
            # Generous calendar window; post-filter the returned candles to
            # the last N distinct trading dates with data so "3 days" stays
            # 3 days even when queried before market open / on holidays.
            start_date, end_date = _resolve_trading_window(days, ist)

            success_h, hist_response, _ = get_history(
                symbol=futures_symbol,
                exchange=fut_exchange,
                interval=interval,
                start_date=start_date,
                end_date=end_date,
                api_key=api_key,
            )

            if success_h and hist_response.get("data"):
                candles = hist_response["data"]
                # Normalize each candle's timestamp key so the helper can
                # read it — get_history returns `timestamp` in seconds/ms.
                # The helper expects a `time` key (Unix seconds) so tag that
                # from the existing `timestamp` column if needed.
                for c in candles:
                    if "time" not in c and "timestamp" in c:
                        try:
                            ts_val = c["timestamp"]
                            # Heuristic: ms if > 10^12, else seconds.
                            c["time"] = int(ts_val // 1000) if ts_val > 1e12 else int(ts_val)
                        except (TypeError, ValueError):
                            pass
                candles = _cap_last_n_trading_dates(candles, days, ist)

        # Step 3: Fetch daily OI changes (parallel)
        prev_oi_map = _fetch_daily_oi_changes(
            option_symbols_for_history,
            options_exchange,
            api_key,
            deadline=_oi_change_deadline(),
        )
        oi_change_requested = len({s["symbol"] for s in option_symbols_for_history})
        oi_change_loaded = len(prev_oi_map)

        # Step 4: Compute OI changes
        for item in oi_chain:
            ce_sym = item.get("ce_symbol")
            pe_sym = item.get("pe_symbol")

            if ce_sym and ce_sym in prev_oi_map:
                item["ce_oi_change"] = item["ce_oi"] - prev_oi_map[ce_sym]
            if pe_sym and pe_sym in prev_oi_map:
                item["pe_oi_change"] = item["pe_oi"] - prev_oi_map[pe_sym]

        # Remove internal symbol fields from response
        for item in oi_chain:
            item.pop("ce_symbol", None)
            item.pop("pe_symbol", None)

        response = {
            "status": "success",
            "underlying": chain_response.get("underlying", underlying),
            "spot_price": spot_price,
            "atm_strike": atm_strike,
            "lot_size": lot_size or 1,
            "expiry_date": expiry_date,
            "futures_symbol": futures_symbol,
            "interval": interval,
            "candles": candles,
            "oi_chain": oi_chain,
        }
        if oi_change_loaded < oi_change_requested:
            # Reachable only when the gthread time budget cut the fetch short.
            response["message"] = _oi_change_note(oi_change_loaded, oi_change_requested)
            response["oi_change_loaded"] = oi_change_loaded
            response["oi_change_requested"] = oi_change_requested

        return True, response, 200

    except Exception as e:
        logger.exception(f"Error in get_oi_profile_data: {e}")
        return (
            False,
            {"status": "error", "message": "Error fetching OI Profile data"},
            500,
        )
