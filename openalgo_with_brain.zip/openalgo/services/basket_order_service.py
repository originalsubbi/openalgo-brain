import copy
import importlib
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Tuple, Union

from database.auth_db import get_auth_token_broker
from database.settings_db import get_analyze_mode
from events import AnalyzerErrorEvent, BasketCompletedEvent, OrderFailedEvent
from utils.broker_backpressure import BrokerBusyError
from utils.constants import (
    REQUIRED_ORDER_FIELDS,
    VALID_ACTIONS,
    VALID_EXCHANGES,
    VALID_PRICE_TYPES,
    VALID_PRODUCT_TYPES,
)
from utils.event_bus import bus
from utils.httpx_client import UNANSWERED_ORDER_MESSAGE, watch_for_unanswered_writes
from utils.logging import get_logger

# Initialize logger
logger = get_logger(__name__)



def emit_analyzer_error(request_data: dict[str, Any], error_message: str) -> dict[str, Any]:
    """
    Helper function to emit analyzer error events via the event bus.

    Args:
        request_data: Original request data
        error_message: Error message to emit

    Returns:
        Error response dictionary
    """
    error_response = {"mode": "analyze", "status": "error", "message": error_message}

    # Store complete request data without apikey
    analyzer_request = request_data.copy()
    if "apikey" in analyzer_request:
        del analyzer_request["apikey"]
    analyzer_request["api_type"] = "basketorder"

    bus.publish(AnalyzerErrorEvent(
        mode="analyze",
        api_type="basketorder",
        request_data=analyzer_request,
        response_data=error_response,
        error_message=error_message,
        api_key=request_data.get("apikey", ""),
    ))

    return error_response


def import_broker_module(broker_name: str) -> Any | None:
    """
    Dynamically import the broker-specific order API module.

    Args:
        broker_name: Name of the broker

    Returns:
        The imported module or None if import fails
    """
    try:
        module_path = f"broker.{broker_name}.api.order_api"
        broker_module = importlib.import_module(module_path)
        return broker_module
    except ImportError as error:
        logger.error(f"Error importing broker module '{module_path}': {error}")
        return None


def validate_order(order_data: dict[str, Any]) -> tuple[bool, str | None]:
    """
    Validate individual order data

    Args:
        order_data: Order data to validate

    Returns:
        Tuple containing:
        - Success status (bool)
        - Error message (str) or None if validation succeeded
    """
    # Check for missing mandatory fields
    missing_fields = [field for field in REQUIRED_ORDER_FIELDS if field not in order_data]
    if missing_fields:
        return False, f"Missing mandatory field(s): {', '.join(missing_fields)}"

    # Validate exchange
    if order_data.get("exchange") not in VALID_EXCHANGES:
        return False, f"Invalid exchange. Must be one of: {', '.join(VALID_EXCHANGES)}"

    # Convert action to uppercase and validate
    if "action" in order_data:
        order_data["action"] = order_data["action"].upper()
        if order_data["action"] not in VALID_ACTIONS:
            return (
                False,
                f"Invalid action. Must be one of: {', '.join(VALID_ACTIONS)} (case insensitive)",
            )

    # Validate price type
    if "pricetype" in order_data and order_data["pricetype"] not in VALID_PRICE_TYPES:
        return False, f"Invalid price type. Must be one of: {', '.join(VALID_PRICE_TYPES)}"

    # Validate product type
    if "product" in order_data and order_data["product"] not in VALID_PRODUCT_TYPES:
        return False, f"Invalid product type. Must be one of: {', '.join(VALID_PRODUCT_TYPES)}"

    return True, None


def place_single_order(
    order_data: dict[str, Any],
    broker_module: Any,
    auth_token: str,
    total_orders: int,
    order_index: int,
) -> dict[str, Any]:
    """
    Place a single order (no per-order event emission - summary event emitted at end)

    Args:
        order_data: Order data
        broker_module: Broker module
        auth_token: Authentication token
        total_orders: Total number of orders in the basket
        order_index: Index of the current order

    Returns:
        Order result dictionary
    """
    unanswered: list[str] = []
    try:
        # Place the order
        with watch_for_unanswered_writes() as unanswered:
            res, response_data, order_id = broker_module.place_order_api(order_data, auth_token)

        if res.status == 200:
            # No per-order event emission - a summary event is emitted at the end of all orders.
            # exchange/product identify the leg: a basket spans several contracts, so the
            # summary event cannot supply them and subscribers have only this dict to key on.
            return {
                "symbol": order_data["symbol"],
                "exchange": order_data.get("exchange", ""),
                "product": order_data.get("product", ""),
                "status": "success",
                "orderid": order_id,
            }
        else:
            message = (
                response_data.get("message", "Failed to place order")
                if isinstance(response_data, dict)
                else "Failed to place order"
            )
            if unanswered:
                message = UNANSWERED_ORDER_MESSAGE
            return {"symbol": order_data["symbol"], "status": "error", "message": message}

    except BrokerBusyError as e:
        # Refused before it was sent: the broker's request queue was longer
        # than a caller may wait under the gthread worker. Never raised under
        # eventlet or the development server.
        logger.warning(f"Basket leg {order_data.get('symbol', 'Unknown')} not sent: {e}")
        return {
            "symbol": order_data.get("symbol", "Unknown"),
            "status": "error",
            "message": str(e),
        }
    except Exception as e:
        logger.exception(f"Error placing order for {order_data.get('symbol', 'Unknown')}: {e}")
        return {
            "symbol": order_data.get("symbol", "Unknown"),
            "status": "error",
            "message": UNANSWERED_ORDER_MESSAGE
            if unanswered
            else "Failed to place order due to internal error",
        }


def process_basket_order_with_auth(
    basket_data: dict[str, Any], auth_token: str, broker: str, original_data: dict[str, Any]
) -> tuple[bool, dict[str, Any], int]:
    """
    Process a basket order using provided auth token.

    Args:
        basket_data: Validated basket order data
        auth_token: Authentication token for the broker API
        broker: Name of the broker
        original_data: Original request data for logging

    Returns:
        Tuple containing:
        - Success status (bool)
        - Response data (dict)
        - HTTP status code (int)
    """
    basket_request_data = copy.deepcopy(original_data)
    if "apikey" in basket_request_data:
        basket_request_data.pop("apikey", None)

    api_key = basket_data.get("apikey")

    # If in analyze mode, route each order to sandbox
    if get_analyze_mode():
        from services.sandbox_service import sandbox_place_order

        analyze_results = []
        total_orders = len(basket_data["orders"])

        # Sort orders to prioritize BUY orders before SELL orders (same as live mode)
        buy_orders = [
            order for order in basket_data["orders"] if order.get("action", "").upper() == "BUY"
        ]
        sell_orders = [
            order for order in basket_data["orders"] if order.get("action", "").upper() == "SELL"
        ]
        sorted_orders = buy_orders + sell_orders

        # Pre-fetch all quotes in a single multiquotes call instead of
        # N individual REST calls (one per order). This reduces basket
        # order latency from N*300-500ms to ~150ms total.
        quote_cache = {}
        try:
            from services.quotes_service import get_multiquotes

            unique_symbols = {
                (o.get("symbol"), o.get("exchange")) for o in sorted_orders
                if o.get("symbol") and o.get("exchange")
            }
            if unique_symbols:
                symbols_list = [
                    {"symbol": s, "exchange": e} for s, e in unique_symbols
                ]
                success_mq, mq_response, _ = get_multiquotes(
                    symbols=symbols_list, api_key=api_key
                )
                if success_mq and "results" in mq_response:
                    for result in mq_response["results"]:
                        sym = result.get("symbol")
                        exch = result.get("exchange")
                        data = result.get("data")
                        if sym and exch and data:
                            quote_cache[(sym, exch)] = data
                    logger.info(
                        f"Pre-fetched {len(quote_cache)} quotes for sandbox basket order"
                    )
        except Exception as e:
            logger.debug(f"Multiquotes pre-fetch failed, falling back to per-order fetch: {e}")

        for i, order in enumerate(sorted_orders):
            # Create order data with common fields from basket order
            order_with_auth = order.copy()
            order_with_auth["apikey"] = api_key
            order_with_auth["strategy"] = basket_data["strategy"]

            # Validate order
            is_valid, error_message = validate_order(order_with_auth)
            if not is_valid:
                analyze_results.append(
                    {
                        "symbol": order.get("symbol", "Unknown"),
                        "status": "error",
                        "message": error_message,
                    }
                )
                continue

            # Look up pre-fetched quote for this symbol
            prefetched = quote_cache.get(
                (order.get("symbol"), order.get("exchange"))
            )

            # Place order in sandbox with pre-fetched quote
            success, response, status_code = sandbox_place_order(
                order_with_auth, api_key, {"apikey": api_key, "order_type": "basket"},
                prefetched_quote=prefetched,
            )

            if success:
                analyze_results.append(
                    {
                        "symbol": order.get("symbol", "Unknown"),
                        "exchange": order.get("exchange", ""),
                        "product": order.get("product", ""),
                        "status": "success",
                        "orderid": response.get("orderid"),
                        "batch_order": True,
                        "is_last_order": i == total_orders - 1,
                    }
                )
            else:
                analyze_results.append(
                    {
                        "symbol": order.get("symbol", "Unknown"),
                        "status": "error",
                        "message": response.get("message", "Order placement failed"),
                    }
                )

        response_data = {"mode": "analyze", "status": "success", "results": analyze_results}

        # Store complete request data without apikey
        analyzer_request = basket_request_data.copy()
        analyzer_request["api_type"] = "basketorder"

        successful_orders = sum(1 for r in analyze_results if r.get("status") == "success")
        bus.publish(BasketCompletedEvent(
            mode="analyze",
            api_type="basketorder",
            strategy=basket_data.get("strategy", ""),
            results=analyze_results,
            successful=successful_orders,
            total=total_orders,
            request_data=analyzer_request,
            response_data=response_data,
            api_key=basket_data.get("apikey", ""),
        ))

        return True, response_data, 200

    # Live mode - process actual orders
    broker_module = import_broker_module(broker)
    if broker_module is None:
        error_response = {"status": "error", "message": "Broker-specific module not found"}
        bus.publish(OrderFailedEvent(
            mode="live",
            api_type="basketorder",
            request_data=basket_request_data,
            response_data=error_response,
            error_message="Broker-specific module not found",
            api_key=basket_data.get("apikey", ""),
        ))
        return False, error_response, 404

    # Sort orders to prioritize BUY orders before SELL orders
    buy_orders = [
        order for order in basket_data["orders"] if order.get("action", "").upper() == "BUY"
    ]
    sell_orders = [
        order for order in basket_data["orders"] if order.get("action", "").upper() == "SELL"
    ]
    sorted_orders = buy_orders + sell_orders

    total_orders = len(sorted_orders)

    # Prepare all orders with auth fields (BUY first, then SELL)
    orders_with_auth = [
        {**order, "apikey": api_key, "strategy": basket_data["strategy"]}
        for order in sorted_orders
    ]

    # Place orders concurrently in batches of 10 with 1s delay between batches
    BATCH_SIZE = 10
    results = []

    for batch_start in range(0, total_orders, BATCH_SIZE):
        if batch_start > 0:
            time.sleep(1.0)  # Rate limit delay between batches

        batch = orders_with_auth[batch_start : batch_start + BATCH_SIZE]

        with ThreadPoolExecutor(max_workers=len(batch)) as executor:
            future_to_order = {
                executor.submit(
                    place_single_order, order_data, broker_module, auth_token, total_orders, batch_start + idx
                ): order_data
                for idx, order_data in enumerate(batch)
            }

            for future in as_completed(future_to_order):
                result = future.result()
                if result:
                    results.append(result)

    # Log the basket order results
    response_data = {"status": "success", "results": results}

    successful_orders = sum(1 for r in results if r.get("status") == "success")
    bus.publish(BasketCompletedEvent(
        mode="live",
        api_type="basketorder",
        strategy=basket_data.get("strategy", ""),
        results=results,
        successful=successful_orders,
        total=len(results),
        request_data=basket_request_data,
        response_data=response_data,
        api_key=original_data.get("apikey", ""),
    ))

    return True, response_data, 200


def place_basket_order(
    basket_data: dict[str, Any],
    api_key: str | None = None,
    auth_token: str | None = None,
    broker: str | None = None,
) -> tuple[bool, dict[str, Any], int]:
    """
    Place a basket of orders.
    Supports both API-based authentication and direct internal calls.

    Args:
        basket_data: Basket order data containing orders and strategy
        api_key: OpenAlgo API key (for API-based calls)
        auth_token: Direct broker authentication token (for internal calls)
        broker: Direct broker name (for internal calls)

    Returns:
        Tuple containing:
        - Success status (bool)
        - Response data (dict)
        - HTTP status code (int)
    """
    original_data = copy.deepcopy(basket_data)
    if api_key:
        original_data["apikey"] = api_key

    # Add API key to basket data if provided (needed for validation)
    if api_key:
        basket_data["apikey"] = api_key

    # Case 1: API-based authentication
    if api_key and not (auth_token and broker):
        # Check if order should be routed to Action Center (semi-auto mode)
        from services.order_router_service import queue_order, should_route_to_pending

        if should_route_to_pending(api_key, "basketorder"):
            return queue_order(api_key, original_data, "basketorder")

        AUTH_TOKEN, broker_name = get_auth_token_broker(api_key)
        if AUTH_TOKEN is None:
            error_response = {"status": "error", "message": "Invalid openalgo apikey"}
            # Skip logging for invalid API keys to prevent database flooding
            return False, error_response, 403

        return process_basket_order_with_auth(basket_data, AUTH_TOKEN, broker_name, original_data)

    # Case 2: Direct internal call with auth_token and broker
    elif auth_token and broker:
        return process_basket_order_with_auth(basket_data, auth_token, broker, original_data)

    # Case 3: Invalid parameters
    else:
        error_response = {
            "status": "error",
            "message": "Either api_key or both auth_token and broker must be provided",
        }
        return False, error_response, 400
