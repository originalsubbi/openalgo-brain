import copy
import importlib
import os
import time
from typing import Any, Dict, List, Optional, Tuple

from database.auth_db import get_auth_token_broker
from database.settings_db import get_analyze_mode
from events import AnalyzerErrorEvent, OrderFailedEvent, SplitCompletedEvent
from utils.broker_backpressure import BrokerBusyError
from utils.constants import (
    REQUIRED_ORDER_FIELDS,
    VALID_ACTIONS,
    VALID_EXCHANGES,
    VALID_PRICE_TYPES,
    VALID_PRODUCT_TYPES,
)
from utils.event_bus import bus
from utils.httpx_client import UNANSWERED_ORDER_MESSAGE, watch_for_unanswered_writes
from utils.logging import get_logger

# Initialize logger
logger = get_logger(__name__)

# Maximum number of orders allowed
MAX_ORDERS = 100


# Get rate limit from environment (default: 10 per second)
def get_order_rate_limit():
    """Parse ORDER_RATE_LIMIT and return delay in seconds between orders"""
    rate_limit_str = os.getenv("ORDER_RATE_LIMIT", "10 per second")
    try:
        rate = int(rate_limit_str.split()[0])
        return 1.0 / rate if rate > 0 else 0.1
    except (ValueError, IndexError):
        return 0.1  # Default 100ms delay


def emit_analyzer_error(request_data: dict[str, Any], error_message: str) -> dict[str, Any]:
    """
    Helper function to emit analyzer error events via the event bus.

    Args:
        request_data: Original request data
        error_message: Error message to emit

    Returns:
        Error response dictionary
    """
    error_response = {"mode": "analyze", "status": "error", "message": error_message}

    # Store complete request data without apikey
    analyzer_request = request_data.copy()
    if "apikey" in analyzer_request:
        del analyzer_request["apikey"]
    analyzer_request["api_type"] = "splitorder"

    bus.publish(AnalyzerErrorEvent(
        mode="analyze",
        api_type="splitorder",
        request_data=analyzer_request,
        response_data=error_response,
        error_message=error_message,
        api_key=request_data.get("apikey", ""),
    ))

    return error_response


def import_broker_module(broker_name: str) -> Any | None:
    """
    Dynamically import the broker-specific order API module.

    Args:
        broker_name: Name of the broker

    Returns:
        The imported module or None if import fails
    """
    try:
        module_path = f"broker.{broker_name}.api.order_api"
        broker_module = importlib.import_module(module_path)
        return broker_module
    except ImportError as error:
        logger.error(f"Error importing broker module '{module_path}': {error}")
        return None


def place_single_order(
    order_data: dict[str, Any],
    broker_module: Any,
    auth_token: str,
    order_num: int,
    total_orders: int,
) -> dict[str, Any]:
    """
    Place a single order (no per-order event emission - summary event emitted at end)

    Args:
        order_data: Order data
        broker_module: Broker module
        auth_token: Authentication token
        order_num: Order number in the sequence
        total_orders: Total number of orders

    Returns:
        Order result dictionary
    """
    unanswered: list[str] = []
    try:
        # Place the order using place_order_api
        with watch_for_unanswered_writes() as unanswered:
            res, response_data, order_id = broker_module.place_order_api(order_data, auth_token)

        if res.status == 200:
            # No per-order event emission - a summary event is emitted at the end of all orders
            return {
                "order_num": order_num,
                "quantity": int(order_data["quantity"]),
                "status": "success",
                "orderid": order_id,
            }
        else:
            message = (
                response_data.get("message", "Failed to place order")
                if isinstance(response_data, dict)
                else "Failed to place order"
            )
            if unanswered:
                message = UNANSWERED_ORDER_MESSAGE
            return {
                "order_num": order_num,
                "quantity": int(order_data["quantity"]),
                "status": "error",
                "message": message,
            }

    except BrokerBusyError as e:
        # Refused before it was sent: the broker's request queue was longer
        # than a caller may wait under the gthread worker. Never raised under
        # eventlet or the development server.
        logger.warning(f"Split order {order_num} not sent, broker busy: {e}")
        return {
            "order_num": order_num,
            "quantity": int(order_data["quantity"]),
            "status": "error",
            "message": str(e),
        }
    except Exception as e:
        logger.exception(f"Error placing order {order_num}: {e}")
        return {
            "order_num": order_num,
            "quantity": int(order_data["quantity"]),
            "status": "error",
            "message": UNANSWERED_ORDER_MESSAGE
            if unanswered
            else "Failed to place order due to internal error",
        }


def split_order_with_auth(
    split_data: dict[str, Any], auth_token: str, broker: str, original_data: dict[str, Any]
) -> tuple[bool, dict[str, Any], int]:
    """
    Split a large order into multiple orders of specified size using provided auth token.

    Args:
        split_data: Split order data
        auth_token: Authentication token for the broker API
        broker: Name of the broker
        original_data: Original request data for logging

    Returns:
        Tuple containing:
        - Success status (bool)
        - Response data (dict)
        - HTTP status code (int)
    """
    split_request_data = copy.deepcopy(original_data)
    if "apikey" in split_request_data:
        split_request_data.pop("apikey", None)

    # Validate quantities
    try:
        split_size = int(split_data["splitsize"])
        total_quantity = int(split_data["quantity"])
        if split_size <= 0:
            error_message = "Split size must be greater than 0"
            if get_analyze_mode():
                return False, emit_analyzer_error(original_data, error_message), 400
            error_response = {"status": "error", "message": error_message}
            bus.publish(OrderFailedEvent(
                mode="live",
                api_type="splitorder",
                request_data=split_request_data,
                response_data=error_response,
                error_message=error_message,
                api_key=original_data.get("apikey", ""),
            ))
            return False, error_response, 400

        # Calculate number of full-size orders and remaining quantity
        num_full_orders = total_quantity // split_size
        remaining_qty = total_quantity % split_size

        # Check if total number of orders exceeds limit
        total_orders = num_full_orders + (1 if remaining_qty > 0 else 0)
        if total_orders > MAX_ORDERS:
            error_message = f"Total number of orders would exceed maximum limit of {MAX_ORDERS}"
            if get_analyze_mode():
                return False, emit_analyzer_error(original_data, error_message), 400
            error_response = {"status": "error", "message": error_message}
            bus.publish(OrderFailedEvent(
                mode="live",
                api_type="splitorder",
                request_data=split_request_data,
                response_data=error_response,
                error_message=error_message,
                api_key=original_data.get("apikey", ""),
            ))
            return False, error_response, 400

    except ValueError:
        error_message = "Invalid quantity or split size"
        if get_analyze_mode():
            return False, emit_analyzer_error(original_data, error_message), 400
        error_response = {"status": "error", "message": error_message}
        bus.publish(OrderFailedEvent(
            mode="live",
            api_type="splitorder",
            request_data=split_request_data,
            response_data=error_response,
            error_message=error_message,
            api_key=original_data.get("apikey", ""),
        ))
        return False, error_response, 400

    # If in analyze mode, route to sandbox for sandbox trading
    if get_analyze_mode():
        from services.sandbox_service import sandbox_place_order

        api_key = original_data.get("apikey")
        if not api_key:
            return (
                False,
                emit_analyzer_error(original_data, "API key required for sandbox mode"),
                400,
            )

        analyze_results = []

        # Pre-fetch quote once for the symbol — all split orders share the
        # same symbol, so N individual REST calls are redundant.
        prefetched_quote = None
        try:
            from services.quotes_service import get_quotes
            success_q, q_response, _ = get_quotes(
                symbol=split_data.get("symbol"),
                exchange=split_data.get("exchange"),
                api_key=api_key,
            )
            if success_q and "data" in q_response:
                prefetched_quote = q_response["data"]
                logger.info(
                    f"Pre-fetched quote for split order: {split_data.get('symbol')} "
                    f"LTP={prefetched_quote.get('ltp')}"
                )
        except Exception as e:
            logger.debug(f"Quote pre-fetch failed for split order, falling back to per-order fetch: {e}")

        # Place full-size orders in sandbox
        for i in range(num_full_orders):
            order_data = copy.deepcopy(split_data)
            order_data["quantity"] = str(split_size)
            order_data["apikey"] = api_key

            # Place order in sandbox with pre-fetched quote
            success, response, status_code = sandbox_place_order(
                order_data, api_key, {"apikey": api_key, "order_type": "split"},
                prefetched_quote=prefetched_quote,
            )

            if success:
                analyze_results.append(
                    {
                        "order_num": i + 1,
                        "quantity": split_size,
                        "status": "success",
                        "orderid": response.get("orderid"),
                    }
                )
            else:
                analyze_results.append(
                    {
                        "order_num": i + 1,
                        "quantity": split_size,
                        "status": "error",
                        "message": response.get("message", "Order placement failed"),
                    }
                )

        # Place remaining quantity order if any
        if remaining_qty > 0:
            order_data = copy.deepcopy(split_data)
            order_data["quantity"] = str(remaining_qty)
            order_data["apikey"] = api_key

            success, response, status_code = sandbox_place_order(
                order_data, api_key, {"apikey": api_key, "order_type": "split"},
                prefetched_quote=prefetched_quote,
            )

            if success:
                analyze_results.append(
                    {
                        "order_num": num_full_orders + 1,
                        "quantity": remaining_qty,
                        "status": "success",
                        "orderid": response.get("orderid"),
                    }
                )
            else:
                analyze_results.append(
                    {
                        "order_num": num_full_orders + 1,
                        "quantity": remaining_qty,
                        "status": "error",
                        "message": response.get("message", "Order placement failed"),
                    }
                )

        response_data = {
            "mode": "analyze",
            "status": "success",
            "total_quantity": total_quantity,
            "split_size": split_size,
            "results": analyze_results,
        }

        # Store complete request data without apikey
        analyzer_request = split_request_data.copy()
        analyzer_request["api_type"] = "splitorder"

        successful_orders = sum(1 for r in analyze_results if r.get("status") == "success")
        bus.publish(SplitCompletedEvent(
            mode="analyze",
            api_type="splitorder",
            strategy=split_data.get("strategy", ""),
            symbol=split_data.get("symbol", ""),
            exchange=split_data.get("exchange", ""),
            action=split_data.get("action", ""),
            pricetype=split_data.get("pricetype", ""),
            product=split_data.get("product", ""),
            total_quantity=total_quantity,
            split_size=split_size,
            results=analyze_results,
            successful=successful_orders,
            total=len(analyze_results),
            request_data=analyzer_request,
            response_data=response_data,
            api_key=split_data.get("apikey", ""),
        ))

        return True, response_data, 200

    # Live mode - process actual orders
    broker_module = import_broker_module(broker)
    if broker_module is None:
        error_response = {"status": "error", "message": "Broker-specific module not found"}
        bus.publish(OrderFailedEvent(
            mode="live",
            api_type="splitorder",
            request_data=split_request_data,
            response_data=error_response,
            error_message="Broker-specific module not found",
            api_key=original_data.get("apikey", ""),
        ))
        return False, error_response, 404

    # Process orders sequentially with rate limiting
    results = []
    order_delay = get_order_rate_limit()

    # Place full-size orders
    for i in range(num_full_orders):
        if i > 0:
            time.sleep(order_delay)  # Rate limit delay between orders
        order_data = copy.deepcopy(split_data)
        order_data["quantity"] = str(split_size)
        result = place_single_order(order_data, broker_module, auth_token, i + 1, total_orders)
        results.append(result)

    # Place remaining quantity order if any
    if remaining_qty > 0:
        if num_full_orders > 0:
            time.sleep(order_delay)  # Rate limit delay
        order_data = copy.deepcopy(split_data)
        order_data["quantity"] = str(remaining_qty)
        result = place_single_order(
            order_data, broker_module, auth_token, total_orders, total_orders
        )
        results.append(result)

    # Log the split order results
    response_data = {
        "status": "success",
        "total_quantity": total_quantity,
        "split_size": split_size,
        "results": results,
    }

    successful_orders = sum(1 for r in results if r.get("status") == "success")
    bus.publish(SplitCompletedEvent(
        mode="live",
        api_type="splitorder",
        strategy=split_data.get("strategy", ""),
        symbol=split_data.get("symbol", ""),
        exchange=split_data.get("exchange", ""),
        action=split_data.get("action", ""),
        pricetype=split_data.get("pricetype", ""),
        product=split_data.get("product", ""),
        total_quantity=total_quantity,
        split_size=split_size,
        results=results,
        successful=successful_orders,
        total=len(results),
        request_data=split_request_data,
        response_data=response_data,
        api_key=original_data.get("apikey", ""),
    ))

    return True, response_data, 200


def split_order(
    split_data: dict[str, Any],
    api_key: str | None = None,
    auth_token: str | None = None,
    broker: str | None = None,
) -> tuple[bool, dict[str, Any], int]:
    """
    Split a large order into multiple orders of specified size.
    Supports both API-based authentication and direct internal calls.

    Args:
        split_data: Split order data
        api_key: OpenAlgo API key (for API-based calls)
        auth_token: Direct broker authentication token (for internal calls)
        broker: Direct broker name (for internal calls)

    Returns:
        Tuple containing:
        - Success status (bool)
        - Response data (dict)
        - HTTP status code (int)
    """
    original_data = copy.deepcopy(split_data)
    if api_key:
        original_data["apikey"] = api_key

    # Add API key to split data if provided (needed for validation)
    if api_key:
        split_data["apikey"] = api_key

    # Case 1: API-based authentication
    if api_key and not (auth_token and broker):
        # Check if order should be routed to Action Center (semi-auto mode)
        from services.order_router_service import queue_order, should_route_to_pending

        if should_route_to_pending(api_key, "splitorder"):
            return queue_order(api_key, original_data, "splitorder")

        AUTH_TOKEN, broker_name = get_auth_token_broker(api_key)
        if AUTH_TOKEN is None:
            error_response = {"status": "error", "message": "Invalid openalgo apikey"}
            # Skip logging for invalid API keys to prevent database flooding
            return False, error_response, 403

        return split_order_with_auth(split_data, AUTH_TOKEN, broker_name, original_data)

    # Case 2: Direct internal call with auth_token and broker
    elif auth_token and broker:
        return split_order_with_auth(split_data, auth_token, broker, original_data)

    # Case 3: Invalid parameters
    else:
        error_response = {
            "status": "error",
            "message": "Either api_key or both auth_token and broker must be provided",
        }
        return False, error_response, 400
