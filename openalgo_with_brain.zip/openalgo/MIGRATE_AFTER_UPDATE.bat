@echo off
REM Run ONCE after extracting the 2.0.3.3 update, BEFORE starting OpenAlgo.
REM Safe to run again: every step skips what is already done.
cd /d "%~dp0"
uv run upgrade\migrate_all.py
pause
